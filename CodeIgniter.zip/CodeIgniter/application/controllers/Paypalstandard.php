<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PaypalStandard extends CI_Controller {
	public $currency_codes=array(
		"USD"=>"U.S. Dollar",
		"AUD"=>"Australian Dollar",
		"BRL"=>"Brazilian Real",
		"CAD"=>"Canadian Dollar",
		"CZK"=>"Czech Koruna",
		"DKK"=>"Danish Krone",
		"EUR"=>"Euro",
		"HKD"=>"Hong Kong Dollar",
		"HUF"=>"Hungarian Forint",
		"ILS"=>"Israeli New Sheqel",
		"JPY"=>"Japanese Yen",
		"MYR"=>"Malaysian Ringgit",
		"MXN"=>"Mexican Peso",
		"NOK"=>"Norwegian Krone",
		"NZD"=>"New Zealand Dollar",
		"PHP"=>"Philippine Peso",
		"PLN"=>"Polish Zloty",
		"GBP"=>"Pound Sterling",
		"SGD"=>"Singapore Dollar",
		"SEK"=>"Swedish Krona",
		"CHF"=>"Swiss Franc",
		"TWD"=>"Taiwan New Dollar",
		"THB"=>"Thai Baht",
		"TRY"=>"Turkish Lira",
	);

	function __construct()
	{
		parent::__construct();
		$this->load->model('users');
		$this->load->model('options');
		$this->load->model('payments');
		$lang=$this->session->userdata('lang');
		$this->form_validation->set_error_delimiters('<p class="help-block error">', '</p>');
		$this->load->model('debugg');
		$this->load->library('paypal_lib');

	}

	function index(){
		redirect('paypal_pro/checkout');
	}

	function checkout(){
		redirect('my_account/add_funds');
		$this->load->model('packages');
		$data['packages']=$this->packages->get_all(true);

		$data['theme'] = $this->options->get('theme');
		$data['title'] = vlang('registration_payment_title');
		$data['body'] = '';
		$reg_step_data = $this->registrations->get_step_by_name('Payment Information');
		//NEED TO CREATE THE USER NOW BEFORE PAYMENT PROCESSING

		if($this->session->userdata('user_id')==false){
			$user_id=$this->users->create($this->session->userdata('reg_data'));
			$this->session->set_userdata('user_id',$user_id);

			//set account as expired until payment goes through (set below in IPN())
			$update=array(
				'expires'=>time()-(24*60*60)
			);
				$this->db->where('id',$user_id);
			$this->db->update('users', $update);
		}
		//echo "USER ID: <pre>".print_r($this->session->userdata('user_id'),true)."</pre>";exit();//debug

		$id=$this->uri->segment(3);
		$data['method_data']=$this->payments->get_method_by_id($id);
		$data['method_extradata']=json_decode($data['method_data']->data);

		$this->form_validation->set_rules('package', 'Package', 'required');
		$this->form_validation->set_rules('checkbox_terms', 'Terms and Conditions', 'required|xss_clean');
		$this->form_validation->set_rules('checkbox_approval', 'Approval', 'required|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view($data['theme'].'/my_account/add_funds', $data);
		}
		else
		{
			$skip=$this->input->post('skip');
			if($skip!="Pay Later"){
				$data['user_id']=$this->session->userdata('user_id');
				$package=$this->input->post('package');
				$data['package']=$this->packages->get_by_id($package);
				$data['package_xtra']=json_decode($data['package']->extradata);
				$data['extra_js']="<script type='text/javascript'>jQuery(document).ready(function($) { $('#paypal_auto_form').submit();});</script>";
				$data['redirect']="page/view/thank-you-for-registering";

				$this->load->view($data['theme'].'/payments/paypalstandard_redirect', $data);
			}else{
				redirect('page/view/thank-you-for-registering');
			}
		}

	}
	/******************************************************
		IPN
		This takes the data from paypal and does horrible horrible things to it.

	*******************************************************/
	function ipn(){


		$this->config->set_item('compress_output', FALSE);
		$debug=true;
		$debug_mail="true";
		//throw all get and post data into the debugg.txt file
		$request_data = var_export($_REQUEST, TRUE);
		$request_post_data = var_export($_POST, TRUE);
		$request_get_data = var_export($_GET, TRUE);

		$debug_mail.=$request_data."\n\n Post:\n\n".$request_post_data."\n\n Get:\n\n".$request_get_data."\n\n";



		$post=$_POST;


/*
		$post= array(

			  'mc_gross' => '0.10',
			  'protection_eligibility' => 'Eligible',
			  'address_status' => 'confirmed',
			  'payer_id' => '9ZMAQWAVNCW5A',
			  'address_street' => '58035 County Line Road',
			  'payment_date' => '10:47:58 Jul 15, 2016 PDT',
			  'payment_status' => 'Completed',
			  'charset' => 'windows-1252',
			  'address_zip' => '49093',
			  'first_name' => 'Isaiah Arnold',
			  'mc_fee' => '0.10',
			  'address_country_code' => 'US',
			  'address_name' => 'Isaiah Arnold Arnold',
			  'notify_version' => '3.8',
			  'custom' => '20',
			  'payer_status' => 'verified',
			  'business' => 'eileenplodge@gmail.com',
			  'address_country' => 'United States',
			  'address_city' => 'Three Rivers',
			  'quantity' => '1',
			  'verify_sign' => 'AzEinfZ7q3.mkSVbd.qCDjcQXO3-A83X6IrhuGKhZFoOBshsXab3gLrC',
			  'payer_email' => 'isaiahfrom3r@gmail.com',
			  'txn_id' => '62927923X8991220A',
			  'payment_type' => 'instant',
			  'last_name' => 'Arnold',
			  'address_state' => 'MI',
			  'receiver_email' => 'eileenplodge@gmail.com',
			  'payment_fee' => '0.10',
			  'receiver_id' => 'YX6NZJL9KLBA2',
			  'txn_type' => 'web_accept',
			  'item_name' => 'Add $10',
			  'mc_currency' => 'USD',
			  'item_number' => '1',
			  'residence_country' => 'US',
			  'transaction_subject' => '',
			  'payment_gross' => '0.10',
			  'ipn_track_id' => '359c4cfbce275',

		);
*/


		if(!empty($post)){
			if ($this->paypal_lib->validate_ipn_better($post)){

				$this->db->where('trans_id',$post['txn_id']);
				$q = $this->db->get("payments");
				if ($q->num_rows() > 0){
					die;
				}


				//Paypal sends IPN for signup and payment at creation. Only payment should be registered.
				//Cancelations can be ignored since it just updated the expiratation when a payment goes through.

				//Add payment to the site's payment log
				$this->load->model('packages');
				//if subscription update user info
				$product=$this->packages->get_by_id($post['item_number']);
				//$body='Begin!';

				if($product->type=="subscription"){
				}else{
					$gateway=$this->payments->get_gateway_by_sys_name('paypalstandard');
					$this->db->where('type_id',$gateway->cid);
					$method=$this->db->get('payment_method');
					$method=$method->row();
					$method_id=$method->cid;

					if(substr_count($this->input->post('custom'),"|")==0){

						$user_id=$post['custom'];

						if($debug) $debug_mail.="USER ID: ".$user_id.'\n\n';
					}elseif(substr_count($this->input->post('custom'),'|')==1){
						$temp=explode('|',$this->input->post('custom'));
						$user_id=$temp[0];
						$promo_code=$temp[1];
						if($debug) $debug_mail.="USER ID: ".$user_id."\n\nPROMO CODE: ".$promo_code."\n\n";
					}else{
						$user_id = $this->input->post('custom');
						//if($debug) $debug_mail.="SHIZ BE BROKE: ".$this->input->post('custom')."\n\n";
					}

					$payment_log=array(
						'user_id'=>$user_id,
						'trans_id'=>$post['txn_id'],
						'amount'=>$post['mc_gross'],
						'type'=>1,
						'status'=>$post['payment_status']=="Completed"?1:0,
						'approval_code'=>$post['ipn_track_id'],
						'product_id'=>$post['item_number'],
						'time'=>time(),
						'method_id'=>$method_id,
						'raw_return_data'=>json_encode($post)
					);


					$this->db->insert('payments',$payment_log);
					$payment_id = $this->db->insert_id();

					if($this->input->post('txn_type')=="subscr_payment" || $this->input->post('txn_type')=="subscr_signup" || $this->input->post('txn_type')=="web_accept"){
						if($this->input->post('payment_status')=="Completed"){
							//integrate with user_funds plugin
							$this->load->model('user_funds');
							//add transaction
							//$product_data=json_decode($product->extradata);
							if($debug) $debug_mail.="we inside";
							$this->user_funds->add_payment($user_id, $this->input->post('mc_gross'), $payment_id);
							$this->user_funds->apply_sign_up_promos($user_id, $this->input->post('mc_gross'));
							//add promo code stuff
							if(isset($promo_code) && !empty($promo_code)){
								if($debug) $debug_mail.="made it to the model function with ".$user_id.",".$promo_code.",".$this->input->post('mc_gross')."\n\n";
								$this->user_funds->apply_promo($user_id,$promo_code,$this->input->post('mc_gross'));
							}
						}else{
							if($debug) $debug_mail.="\n\n 005- WRONG PAYMENT STATUS: ".$this->input->post('payment_status')." n\n";
						}
					}else{
						if($debug) $debug_mail.="\n\n 004- WRONG txn_type n\n";
					}
				}
			}else{
				if($debug) $debug_mail.="\n\n 004- VALIDATION RETURNED FALSE n\n";
			}
		}
		if(!empty($debug_mail)) mail("isaiahfrom3r@gmail.com","paypal crap",$debug_mail);
	}
	/******************************************************
		SETUP
		Shows the form for setting up the payment method

	*******************************************************/
	function setup(){
		$this->users->auth_check();
		$this->users->is_admin_check();
		$data['admin_theme'] = $this->options->get('admin_theme');
		$data['active_menu'] = 'payment';
		$data['title'] = 'Setup Paypal Standard';
		$data['body'] = '';
		//echo "<pre>".print_r($this->currency_codes,true)."</pre>";exit;
		$data['currency_codes']=$this->currency_codes;

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');
		$this->form_validation->set_rules('currency_codes', 'Currency', 'required|xss_clean|trim');
		$this->form_validation->set_rules('account_email', 'Account Email', 'required|xss_clean|trim');
		//$this->form_validation->set_rules('sandbox', 'Sandbox', 'required');

		if ($this->form_validation->run() == FALSE)
		{
		}
		else
		{
			$paypal_standard_id=$this->payments->get_gateway_by_sys_name('paypalstandard');
			$paypal_standard_id=$paypal_standard_id->id;
			$data=array(
				'account_email'=>$this->input->post('account_email'),
				'currency_codes'=>$this->input->post('currency_codes'),
				//'sandbox'=>$this->input->post('sandbox'),
			);
			$insert=array(
				'name'=>$this->input->post('name'),
				'description'=>$this->input->post('description'),
				'type_id'=>$paypal_standard_id,
				'data'=>json_encode($data)
			);
			$this->payments->create_method($insert);

			$this->session->set_flashdata('success','Payment Method Created');
			redirect('admin_payment/show_gateways');
		}
		$data['method_data']=null;
		$data['method_extradata']=null;
		$this->load->view($data['admin_theme'].'/payments/paypalstandard_setup', $data);
	}
	/******************************************************
		EDIT
		Shows the form for editing up the payment method

	*******************************************************/
	function edit(){
		$this->users->auth_check();
		$this->users->is_admin_check();
		$data['admin_theme'] = $this->options->get('admin_theme');
		$data['active_menu'] = 'payment';
		$data['title'] = 'Edit Paypal Standard';
		$data['body'] = '';
		//echo "<pre>".print_r($this->currency_codes,true)."</pre>";exit;
		$data['currency_codes']=$this->currency_codes;

		$id=$this->uri->segment(3);

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');
		$this->form_validation->set_rules('currency_codes', 'Currency', 'required|xss_clean|trim');
		$this->form_validation->set_rules('account_email', 'Account Email', 'required|xss_clean|trim');

		if ($this->form_validation->run() == FALSE)
		{
		}
		else
		{
			$data['extra_js']="<script type='text/javascript'>jQuery(document).ready(function() { document.forms['paypal_auto_form'].submit();});</script>";
			$paypal_pro_id=$this->payments->get_gateway_by_sys_name('paypalstandard');
			$paypal_pro_id=$paypal_pro_id->id;
			$data=array(
				'account_email'=>$this->input->post('account_email'),
				'currency_codes'=>$this->input->post('currency_codes'),
			);
			$insert=array(
				'name'=>$this->input->post('name'),
				'description'=>$this->input->post('description'),
				'type_id'=>$paypal_pro_id,
				'data'=>json_encode($data)
			);
			$this->payments->update_method($id,$insert);

			$this->session->set_flashdata('success','Payment Method Edited');
			redirect('admin_payment/show_gateways');
		}

		$data['method_data']=$this->payments->get_method_by_id($id);
		$data['method_extradata']=json_decode($data['method_data']->data);
		$this->load->view($data['admin_theme'].'/payments/paypalstandard_setup', $data);
	}

	function renew(){
		$this->load->model('packages');
		$data['packages']=$this->packages->get_all(true);

		$data['theme'] = $this->options->get('theme');
		$data['title'] = vlang('registration_payment_title');
		$data['body'] = '';
		/*$data['extra_js']="<script type='text/javascript'>jQuery(document).ready(function($) { $('#paypal_auto_form').submit();});</script>";*/
		$data['user_id']=$this->users->ID();
		$package=$this->uri->segment(4);
		$data['method_data']=$this->payments->get_method_by_id($package);
		$data['method_extradata']=json_decode($data['method_data']->data);

		$package=$this->uri->segment(3);
		$data['package']=$this->packages->get_by_id($package);
		$data['package_xtra']=json_decode($data['package']->extradata);
		$data['redirect']="setting/payment_details";
		$this->load->view($data['theme'].'/payments/paypalstandard_redirect', $data);
	}

    function test(){
    	$this->load->model('user_funds');
    	$this->user_funds->apply_sign_up_promos(101,55);
    }
}
