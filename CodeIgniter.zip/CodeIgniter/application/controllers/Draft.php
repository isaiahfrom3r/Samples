<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Draft extends CI_Controller {

	public function __construct() {

		parent::__construct();
		$this->load->model('Teams');
		$this->load->model('Players');
		$this->load->model('Mocks');
		$this->load->model('Mocks');
		$this->load->model('Chats');
        $this->load->model('Events');
	}
	
	// Set public path to the draft function. 
	public function index(){
		redirect('/draft/draft');
	}
	
	// Function that hosts the main draft page. Requires League ID 
	public function draft($lid='3')
	{

		$user  = $this->users->get();
		$lid = $user->team_id;

		ini_set('memory_limit','-1');
		
		// grab data required for function
		$foot['scripts'] = array();
		$head['styles'] = array('/assets/css/icons.css');
		$head['scripts'] = array(base_url().'assets/js/draft_main.js',base_url().'assets/js/downcount.js');
		$foot['styles'] = array();
		$data['players'] = $this->Players->get_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);

		// grab teams and give them a map
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		foreach($data['teams'] as $key=>$team){
			if($team->user_id == $this->users->id()){
				$data['myteam'] =  $team;
			}

			$incteams[$team->user_id] = $team->user_id;
		}
		// grab draft order
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);

		$data['league'] =  $this->Leagues->get_by_id($lid);

		if(!in_array($this->users->id(), $incteams)){
			echo "This is not your Draft!"; die;
		}
		
		// pass data to views. 
		$this->load->view(THEME.'/draft/header',$head);
		$this->load->view(THEME.'/draft/main',$data);
		$this->load->view(THEME.'/draft/footer',$foot);

	}


	// Endpoint for AJAX to update player que
	public function update_que($tid){
		$data['team'] =  $this->Leagues->get_team_by_id($tid);

		$this->load->view(THEME.'/draft/draft_player_que.php',$data);
	}

	// Endpoint for AJAX to update player que for mobile vue
	public function mobile_que($tid){
		$data['team'] =  $this->Leagues->get_team_by_id($tid);

		$this->load->view(THEME.'/draft/draft_mobile_que.php',$data);
	}
	
	// Endpoint for AJAX to update draft lineup
	public function update_lineup($lid,$tid){
		$data['team'] =  $this->Leagues->get_team_by_id($tid);
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);

		$this->load->view(THEME.'/draft/draft_lineup.php',array('order' => $order,'teams' => $teams,'mid' => $lid));
	}
	
	// Endpoint that returns current pick based upon the league ID
	public function get_cur_pick($lid){
		$league = $data['league'] =  $this->Drafts->get_league_by_id($lid);
		$pick = $this->Drafts->get_pick($lid);

		echo $pick;
	}
	
	// returns the lineup for a user depended upon League Member ID
	public function get_cur_picker_lineup($mid){
		$league = $data['league'] =  $this->Drafts->get_league_by_id($mid);


		$pick = $this->Drafts->get_pick($mid);
		if($pick > 240){
			return 100;
		}
		$team = $this->Drafts->get_picker($mid);
		echo $team;
	}
	
	// Ajax endpoint that updataes my team view
	public function update_my_roster($tid){
		$data['team'] = $this->Leagues->get_team_by_id($tid);

		$this->load->view(THEME.'/draft/team-sidebar',$data);
	}
	
	// Returns player data of highlighted player. 
	public function player_info($pid='',$lid){
		$data['player'] =  $this->Players->get_by_id($pid);
		$data['league'] = $league = $this->Drafts->get_league_by_id($lid);
		$this->load->view(THEME.'/draft/draft_draft_mid',$data);

	}
	
	// endpoint that updates result tab
	public function update_results_tab($lid,$tid){
		$data['players'] = $this->Players->get_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		$data['team'] =  $this->Leagues->get_team_by_id($tid);;
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);
		$data['league'] =  $this->Drafts->get_league_by_id($lid);
		$this->load->view(THEME.'/draft/draft_results',$data);

	}
	
	// endpoint to update mobile results tab 
	public function mobile_update_results_tab($lid,$tid){
		$data['players'] = $this->Players->get_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		$data['team'] =  $this->Leagues->get_team_by_id($tid);;
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);
		$data['league'] =  $this->Drafts->get_league_by_id($lid);
		$this->load->view(THEME.'/draft/draft_results_mobile',$data);

	}
	
	
	public function pre_pick($lid){

		// check to see if cpu is up
		$league = $data['league'] =  $this->Drafts->get_league_by_id($lid);

		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);
		$pick = $this->Drafts->get_pick($lid);
		$team = $this->Drafts->get_picker($lid);
		$teamarr = $this->Leagues->get_team_by_id($team);

		foreach($order as $key=>$o){
			$ordpick = 1;
			foreach($o as $keynum=>$n){

				$new[$keynum]['round'] = $key;
				$new[$keynum]['pick'] = $keynum;
				$new[$keynum]['player'] = $n;
				$ordpick++;
			}
		}
		$round = $new[$pick]['round'];

		$prestuff = json_decode($teamarr->pre_draft,true);

		if(isset($prestuff[$round]) && $prestuff[$round] != ""){
			$player = $prestuff[$round];
			// add to roster
			$this->Drafts->add_to_roster($player,$team);
			$this->Drafts->update_draft_log($player,$league->cid);

			// update curr pick
			$this->Drafts->update_pick($pick,$league->cid);





			if(strlen($player) > 5){
				$player = $this->Players->get_by_id($player);
				$name = $player->first_name." ".$player->last_name;
			}else{
				$player = $this->Teams->get_by_id($player);

				$name = $player->city." ".$player->name;
			}
			if($teamarr->name == ""){
				$teamarr->name = "CPU ".$teamarr->draft_position;
			}
			$message = $teamarr->name." has PRE drafted ". $name;
			$this->Chats->chat_submit(0,$lid,$message,1);

			// respond that pick is in
			return 1;







		}else{




			return 0;


		}




	}
	
	// logic to run when computer is up for pick. 
	public function cpu_pick($lid){

		// check to see if cpu is up
		$league = $data['league'] =  $this->Drafts->get_league_by_id($lid);


		$pick = $this->Drafts->get_pick($lid);

		$team = $this->Drafts->get_picker($lid);
		$teamarr = $this->Leagues->get_team_by_id($team);



		// find the player they should take
		$i = 0;

		$checkforbye = 0;
		$exclueds = array();
		while($checkforbye == 0){

			$player = $this->Drafts->find_player($league,$pick,$team);
			echo "<pre>";
			print_r($player);
			echo "</pre>";

			$addex = $this->Drafts->bye_check($player,$league,$pick,$team);

			if($addex == 1){
				$checkforbye++;
			}else{
				$exclueds[$addex] = $addex;
			}

			$i ++;

			// must have to take them or something
			if($i == 10){
				$checkforbye++;
			}

		}

		if(empty($player)){
			return 0;
		}

		// adjust draft map
		//$redflag = $this->Drafts->adjust_map($player,$team,$pick);
/*
		if($redflag == 1){
			//echo "mapping broken!"; die;
		}
*/

		// add to roster
		$this->Drafts->add_to_roster($player,$team);
		$this->Drafts->update_draft_log($player,$league->cid);

		// update curr pick
		$this->Drafts->update_pick($pick,$league->cid);





		if(strlen($player) > 5){
			$player = $this->Players->get_by_id($player);
			$name = $player->first_name." ".$player->last_name;
		}else{
			$player = $this->Teams->get_by_id($player);

			$name = $player->city." ".$player->name;
		}
		if($teamarr->name == ""){
			$teamarr->name = "CPU ".$teamarr->draft_position;
		}
		$message = $teamarr->name." has drafted ". $name;
		$this->Chats->chat_submit(0,$lid,$message,1);

		// respond that pick is in
		echo 1;
	}
	
	// loads post draft view
	public function post_draft($lid){
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);
		$data['league'] =  $this->Drafts->get_league_by_id($lid);


		$this->load->view(THEME.'/draft/post_draft',$data);

	}
	
	// endpoint where a member submits via ajax / php that they are taking a player. URL will be provided and include team ID / League ID and Player ID
	public function draft_player($tid,$lid,$pid){

		if(strlen($pid) < 1){
			echo 'No Player Selected';die;
		}
		// make sure that guys is on the clock
		$league = $data['league'] =  $this->Drafts->get_league_by_id($lid);
		$pick = $this->Drafts->get_pick($lid);
		$team = $this->Drafts->get_picker($lid);
		$teamarr = $this->Leagues->get_team_by_id($team);

		if($league->draft_start > time()){
			echo "Draft Not Started"; die;
		}

		if(!isset($teamarr->id)){
			echo "Draft Is Over"; die;
		}
		if($teamarr->id != $tid){
			echo "Team Not On Clock"; die;
		}

		$data['players'] = $this->Players->get_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable($lid);
		$data['players'] = $players = array_merge($data['players'],$data['sport_teams']);


		// is player available
		foreach($data['players'] as $plrys){
			$pids[] = $plrys->cid;
		}
		if(!in_array($pid, $pids)){
			echo "Player Already Drafted!";  die;
		}

/*
		$checklegal = $this->Drafts->check_legal($teamarr,$pid);
		if($checklegal == 0){
			echo "No room for this player";  die;
		}
*/



		//$redflag = $this->Drafts->adjust_map($pid,$team,$pick);
		// add the guy and stuff
		$this->Drafts->add_to_roster($pid,$team);

		$this->Drafts->update_draft_log($pid,$league->cid);

		// update curr pick
		$this->Drafts->update_pick($pick,$league->cid);

		$data = array(
           'clock' => strtotime('+'.$league->draft_clock.' seconds'),
        );

		$this->db->where('cid', $lid);
		$this->db->update('leagues', $data);
		// if final pick then set the rosters and junk

		if(strlen($pid) > 5){
			$player = $this->Players->get_by_id($pid);
			$name = $player->first_name." ".$player->last_name;
		}else{
			$player = $this->Teams->get_by_id($pid);

			$name = $player->city." ".$player->name;
		}
		if($teamarr->name == ""){
			$teamarr->name = "CPU ".$teamarr->draft_position;
		}
		$message = $teamarr->name." has drafted ". $name;
		$this->Chats->chat_submit(0,$lid,$message,1);

	}
	
	// Function returns if player is drafted 
	public function is_drafted($pid,$lid){
		$leauge =  $this->Drafts->get_league_by_id($lid);
		$picks = json_decode($leauge->draft_results,true);

		if(empty($picks)){
			echo 1;
		}else{
			if(!in_array($pid, $picks)){
				echo 1;
			}else{
				echo 0;
			}
		}





	}
	
	
	// endpoint to update teams tab
	public function update_teams_tab($tid){
		$teamarr = $this->Leagues->get_team_by_id($tid);

		 $this->load->view(THEME.'/draft/league_teams',array('team'=>$teamarr));
	}
	
	// returns available players 
	public function player_pool($lid){
		$data['players'] = $this->Players->get_available_players($lid);

		$data['sport_teams'] =  $this->Teams->get_all_draftable($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);


		echo json_encode($data['players']);

	}
	
	//Returns teams that are live. 
	public function live_teams($lid){
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);



		echo json_encode($teams);

	}

	// Endpoint for team info in mid section. 
	public function team_info($pid='',$lid){
		$data['player'] =  $this->Teams->get_by_id($pid);
		$data['league'] = $league = $this->Drafts->get_league_by_id($lid);
		$this->load->view(THEME.'/draft/draft_draft_mid_d',$data);

	}
	
	// Endpoint that updates who is on the clock. 
	public function update_drafter($lid,$my){
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$lid);
		$data['mid'] =  $lid;
		$data['myid'] =  $my;
		$this->load->view(THEME.'/draft/draft_current_draft',$data);

	}

	// Returns players the logged in user drafted. 
	public function get_drafted_guys($lid){

		$league = $this->Drafts->get_league_by_id($lid);


		$res = json_decode($league->draft_results,true);
		echo json_encode($res);


	}
	// Adds player to the que
	public function add_que($pid,$uid){
		$this->Drafts->add_to_que($pid,$uid);
	}
	
	// moves the order of a player in the que 
	public function que_up($pid,$uid){
		$this->Drafts->que_up($pid,$uid);
	}
	
	// moves the order of a player in the que 
	public function que_down($pid,$uid){
		$this->Drafts->que_down($pid,$uid);
	}
	
	//remvoe player from que
	public function remove_que($pid,$uid){
		$this->Drafts->remove_to_que($pid,$uid);
	}
	
	// runs commands in background 
	public function execInBackground($cmd) {
		    if (substr(php_uname(), 0, 7) == "Windows"){
		        pclose(popen("start /B ". $cmd, "r"));
		    }
		    else {
		        exec($cmd . " > /dev/null &");
		    }
		}

	/**
	* our main curl function
	*
	* @since    1.0.0
	*
	* @param none
	* @return none
	*/
	function curl_for_data($feed){
		$ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $feed);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    $output = curl_exec($ch);
	    curl_close($ch);

	    return $output;
	}
	function curl_for_data_nowait($feed){
		$ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $feed);
	    curl_setopt($ch, CURLOPT_TIMEOUT_MS, 1);
		curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 0.1);
	    $output = curl_exec($ch);
	    curl_close($ch);

	    return $output;
	}

	// updates if team member is active
	public function update_live($mid){
		$data = array(
			'live' => time(),
		);

		$this->db->where('id', $mid);
		$this->db->update('league_team', $data);


	}
	
	// function for admin to pause draft. 
	public function pause_draft($mid){
		$mock = $this->Drafts->get_league_by_id($mid);
		if($mock->paused == 1){
			$paused = 0;
			$message = "Draft has resumed";
		}else{
			$paused = 1;
			$message = "Draft Paused";
		}


		$data = array(
			'paused' => $paused,
		);

		$this->db->where('cid', $mid);
		$this->db->update('leagues', $data);

		$this->advanceIT($mid);


		$this->Chats->chat_submit(0,$mid,$message,1);

		echo $paused;

	}


	// function for admin to dundo draft pick. 
	public function undo_pick($mid){
		$mock = $this->Drafts->get_league_by_id($mid);
		$data['teams'] = $teams = $this->Leagues->get_league_teams($mid);
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$mid);


		foreach($order as $key=>$o){
			$pick = 1;
			foreach($o as $keynum=>$n){

				$new[$keynum]['round'] = $key;
				$new[$keynum]['pick'] = $keynum;
				$new[$keynum]['player'] = $n;
				$pick++;
			}
		}

		$player = $new[$mock->current_pick -1 ]['player'];
		$results = json_decode($mock->draft_results,true);
		$guy = end($results);


		unset($results[$guy]);


		$nmock = array(
			'draft_results' => json_encode($results),
			'current_pick' => ($mock->current_pick - 1),
		);
		$this->advanceIT($mid);

		$this->db->where('cid', $mid);
		$this->db->update('leagues', $nmock);

		echo "<pre>";
		print_r($this->db->last_query());
		echo "</pre>";

		$teamarr = $this->Leagues->get_team_by_id($player);

		$newteam = array();
		$team_roster = json_decode($teamarr->roster,true);
		foreach($team_roster as $key=>$ros){
			foreach($ros as $keyp=>$p){
				if($p != $guy){
					$newteam[$key][$keyp] = $p;
				}
			}
		}


		$data = array(
		    'roster' => json_encode($newteam)
		);

		$this->db->where('id', $teamarr->id);
		$this->db->update('league_team', $data);

		echo "<pre>";
		print_r($this->db->last_query());
		echo "</pre>";


		$this->Chats->chat_submit(0,$mid,'Previous Pick Reversed',1);

	}
	
	
	// Loads the draft board for provided member ID
	public function draft_board($mid){
		$foot['styles'] = array();
		$foot['scripts'] = array();
		$head['styles'] = array();

		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		    $ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
		    $ip = $_SERVER['REMOTE_ADDR'];
		}

		if($ip != "73.74.157.47"){

			$head['scripts'] = array(base_url().'assets/js/board_main.js');

		}else{
			echo "<pre>";
			print_r('SCRIPT HAS BEEN REMOVED');
			echo "</pre>";
			$head['scripts'] = array();

		}

		$league = $data['league'] =  $this->Drafts->get_league_by_id($mid);
		$data['teams'] = $teams = $this->Leagues->get_league_teams($mid);

		$this->load->view(THEME.'/draft/header',$head);
		$this->load->view(THEME.'/draft/draft_draft-board',$data);
		$this->load->view(THEME.'/draft/footer',$foot);


	}
	
	// endpoint to update board content. 
	public function board_content($mid){


		$league = $data['league'] =  $this->Drafts->get_league_by_id($mid);
		$data['teams'] = $teams = $this->Leagues->get_league_teams($mid);

		$this->load->view(THEME.'/draft/draft_draft-board',$data);


	}
	
	//Endpoint to toggle autodraft or not. 
	public function auto_toggle($mid){
		$teamarr = $this->Leagues->get_team_by_id($mid);
		if($teamarr->auto == 1){
			$auto = 0;
		}else{
			$auto = 1;
		}

		$data = array(
			'auto' => $auto,
		);

		$this->db->where('id', $mid);
		$this->db->update('league_team', $data);

		echo $auto;
	}

	//CRON FOR DRAFT RUNS EVERY 5 SECONS
	public function cron(){
		$this->check_lock();

		$this->db->where('final',0);
		$this->db->where('paused',0);
 		//$this->db->where('cid !=',3387);
		$this->db->where('draft_start <',time());
		$this->db->where('draft_env',1);
		$q = $this->db->get("leagues");

		$q = $q->result();

		$i = 1;

		while($i <= 34){
			foreach($q as $key=>$m){


				$rawteams = $this->Leagues->get_league_teams($m->cid);

				$exists = array();
				foreach($rawteams as $t){
					if($t->user_id == 0){
						$joinable[] = $t;
					}else{
						$exists[] = $t;
					}
				}





				//$feed = 'wget -O /dev/null -q '.base_url().'draft/run_draft/'.$m->cid.' --no-check-certificate';
				//echo $feed; echo "<br>";
				//$feed = $this->execInBackground($feed);

				//$this->run_draft($m->cid);

				$url = base_url().'draft/run_draft/'.$m->cid;
				$ch = curl_init();
	            curl_setopt($ch, CURLOPT_URL, $url);
	            curl_setopt($ch, CURLOPT_HEADER, TRUE);
	            curl_setopt($ch, CURLOPT_NOBODY, TRUE); // remove body
	            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	            $head = curl_exec($ch);
	            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	            $server_output = curl_exec($ch);
	            curl_close($ch);




				echo "ran".time();

			}
			$i++;
			echo 'sleep'; echo "<br>";
			sleep(5);

		}

		$this->unlock_it();

	}
	
	// locks draft
	public function lock_it(){
		return ;
		$data = array(
            'onoff' => 1,
            'time' => time()
        );

		$this->db->where('cid', 1);
		$this->db->update('lock', $data);
	}
	
	// unlocks draft
	public function unlock_it(){
		return ;
		$data = array(
            'onoff' => 0,
            'time' => time()
        );

		$this->db->where('cid', 1);
		$this->db->update('lock', $data);
	}
	
	// checks draft lock status 
	public function check_lock(){
		return ;
		$this->db->where('cid',1);
		$q = $this->db->get("lock");
		$q = $q->row();

		if($q->onoff == 1){
			$data = array(
               'time' => time(),
               'lid' => $mid,
            );

			$this->db->insert('issues', $data);

			echo "File Locked!"; die;
		}else{
			$this->lock_it();
		}

	}

	// checks a log and then starts the draft process for the cron to que into. 
	public function run_draft($mid){

// 		$this->check_lock();

		$myFile = FCPATH."lock/lockleagueALL.txt";
		if (file_exists($myFile)) {

		} else {
		  $fh = fopen($myFile, 'w');
		  fwrite($fh, 'yo'."\n");
		  fclose($fh);
		}



		$fp = fopen(FCPATH."lock/lockleagueALL.txt", "r+");



		if(!flock($fp, LOCK_EX | LOCK_NB)) {

			$data = array(
               'time' => time(),
               'lid' => $mid,
            );

			$this->db->insert('issues', $data);

		    echo 'Unable to obtain lock';
		    exit(-1);


		    fclose($fp);
		}



		$data['teams'] = $teams = $this->Leagues->get_league_teams($mid);
		$data['order'] =  $order = $this->Drafts->grab_create_order($data['teams'],$mid);
		$data['players'] = $this->Players->get_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable($lid);
		$data['players'] = $players = array_merge($data['players'],$data['sport_teams']);


		// is player available
		foreach($data['players'] as $plrys){
			$pids[] = $plrys->cid;
		}

		$pick = $this->Drafts->get_pick($mid);

		$team = $this->Drafts->get_picker($mid);
		$teamarr = $this->Leagues->get_team_by_id($team);
		$mock = $this->Drafts->get_league_by_id($mid);
		if($mock->paused == 1){
			$this->unlock_it();
			echo "PAUSED"; die;
			fclose($fp);
		}


		$made = 0;
		$this->db->where('cid',$mid);
		$q = $this->db->get("leagues");
		$q = $q->row();
		$picked = array();
		if(isset($q->draft_results)){
			$picked = json_decode($q->draft_results,true);
		}
		if(!isset($teamarr)){
			$data = array(
               'final' => 1,
            );

			$this->db->where('cid', $mid);
			$this->db->update('leagues', $data);



			// nobody should have had a roster yet
			$this->db->where('league_id',$mid);
			$this->db->delete('league_team_rosters');

			// a little trick to try and pull all league teams and then obviously don't exist so go ahead and create.
			$data['week'] = $week = $this->Events->get_week();
			$data['league'] = $league = $this->Leagues->get_league_by_id($mid);
			$data['players'] = $players = $this->Leagues->get_league_players($league,$week,'QB');
			fclose($fp);
			return;
		}


		echo "<pre>";
		print_r($teamarr);
		echo "</pre>";

		$pre = $this->pre_pick($mid);
		if($pre == '1'){
			$made = 1;
			$pickq = 1;

		}else{


			if($teamarr->user_id == 0){
	 			$this->cpu_pick($mid);
				$made = 1;
				$pickq = 1;
			}

			if($teamarr->auto == 1){

				if(strlen($teamarr->que) > 5){
					$que = json_decode($teamarr->que);
					$pickq = 0;
					foreach($que as $q){
						// this checks for pre-draft players
						if(!in_array($q, $pids)){
							continue;
						}
						if(!is_array($picked) || !in_array($q, $picked)){
							// draft him;
							if($made == 0){
								$this->draft_player($team,$mid,$q);
								$made = 1;
								$pickq = 1;
							}

						}

					}

					if($pickq == 0){
						if($made == 0){
							$this->cpu_pick($mid);
							$made = 1;
						}
					}

				}else{
					if($made == 0){
						$this->cpu_pick($mid);
						$made = 1;
					}

				}
			}

			if(time() > $mock->clock){

				if(strlen($teamarr->que) > 5){
					$que = json_decode($teamarr->que);
					$pickq = 0;
					foreach($que as $q){
						// this checks for pre-draft players
						if(!in_array($q, $pids)){
							continue;
						}
						if(!is_array($picked) || !in_array($q, $picked)){
							// draft him;
							if($made == 0){
								$this->draft_player($team,$mid,$q);
								$made = 1;
								$pickq = 1;
							}

						}

					}

					if($pickq == 0){
						if($made == 0){
							$this->cpu_pick($mid);
							$made = 1;
						}
					}

				}else{
					if($made == 0){
						$this->cpu_pick($mid);
						$made = 1;
					}

				}


			}


		}


		// check if pick was made
		if($made ==1){

			$this->advanceIT($mid);

		}else{
			echo 'didnt pick anything'; echo "<br>";
			fclose($fp);
		}




		$this->unlock_it();

	}

// function to advance the draft. 
	public function advanceIT($mid){
			$league = $data['league'] =  $this->Drafts->get_league_by_id($mid);

			$data = array(
               'clock' => strtotime('+'.$league->draft_clock.' seconds'),
            );

			$this->db->where('cid', $mid);
			$this->db->update('leagues', $data);
	}





}
