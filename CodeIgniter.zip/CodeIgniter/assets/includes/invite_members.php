<h4>Invite Members To Your League</h4>

<hr>

<form method="" action="">
	<div class="form-group third">
		<label>Email #1</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #2</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #3</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #4</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #5</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #6</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #7</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #8</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #9</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #10</label>
		<input class="form-control" value="" type="text" name="">
	</div>
	<div class="form-group third">
		<label>Email #11</label>
		<input class="form-control" value="" type="text" name="">
	</div>

	<hr>

	<div class="text-center">
		<button class="btn btn-default" type="submit"><i class="fa fa-send-o"></i> Send Invites</button>
	</div>
</form>
