<h4>Update League Scoring</h4>

<hr>

<form method="post" action="">

	<div class="form-group">
		<div class="checkbox"><label><input type="checkbox" name=""> Mark League As Keeper</label></div>
	</div>

	<hr>


			<div class="form-group fourth">
			<label>Fractional Scoring</label>
			<div class="radio"><label><input type="radio" name="in_game_subs[]" checked> On</label></div>
			<div class="radio"><label><input type="radio" name="in_game_subs[]"> Off</label></div>
		</div>

<div class="form-group fourth">
			<label>Pass Interference Scoring</label>
			<div class="radio"><label><input type="radio" name="p_int_scoring[]" checked> On</label></div>
			<div class="radio"><label><input type="radio" name="p_int_scoring[]"> Off</label></div>
		</div>

		<div class="form-group fourth">
			<label>Live In-Game Substitutions</label>
			<div class="radio"><label><input type="radio" name="in_game_subs[]" checked> On</label></div>
			<div class="radio"><label><input type="radio" name="in_game_subs[]"> Off</label></div>
		</div>

		<div class="form-group fourth">
			<label>Live In-Game Substitutions Cooldown</label>
			<select class="form-control" name="">
				<option value="" selected>1 minute</option>
				<option value="">2 minutes</option>
				<option value="">5 minutes</option>
				<option value="">10 minutes</option>
				<option value="">15 minutes</option>
				<option value="">30 minutes</option>
				<option value="">60 minutes</option>
				<option value="">120 minutes</option>
				<option value="">240 minutes</option>
			</select>
		</div>



		<hr>


	<h4>Passing</h4>

	<div class="form-group fourth">
		<label>Passing TD</label>
		<input type="text" class="form-control" name="" value="4">
	</div>

	<div class="form-group fourth">
		<label>Passing 25yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>Passing INT</label>
		<input type="text" class="form-control" name="" value="-1">
	</div>

	<hr>

	<h4>Rushing</h4>

	<div class="form-group fourth">
		<label>Rushing 10yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>Rushing TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<hr>

	<h4>Receiving</h4>

	<div class="form-group fourth">
		<label>Receiving 10yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>Reception</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>Receiving TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>2PT Conversion</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>Fumble Lost</label>
		<input type="text" class="form-control" name="" value="-2">
	</div>

	<div class="form-group fourth">
		<label>Returned TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>Offensive Fum Returned TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<hr>

	<h4>Kicking</h4>

	<div class="form-group fourth">
		<label>FG 0-19yds</label>
		<input type="text" class="form-control" name="" value="3">
	</div>

	<div class="form-group fourth">
		<label>FG 20-29yds</label>
		<input type="text" class="form-control" name="" value="3">
	</div>

	<div class="form-group fourth">
		<label>FG 30-39yds</label>
		<input type="text" class="form-control" name="" value="3">
	</div>

	<div class="form-group fourth">
		<label>FG 40-49yds</label>
		<input type="text" class="form-control" name="" value="4">
	</div>

	<div class="form-group fourth">
		<label>FG 50+yds</label>
		<input type="text" class="form-control" name="" value="5">
	</div>

	<div class="form-group fourth">
		<label>Extra Point</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<hr>

	<h4>DEF Teams / Special Teams</h4>

	<div class="form-group fourth">
		<label>DEF Sack</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>DEF INT</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>DEF Rum-Rec</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>DEF TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>DEF Safety</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>DEF Blocked Kick</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return 10yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return 10yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>DEF 0pts allowed</label>
		<input type="text" class="form-control" name="" value="10">
	</div>

	<div class="form-group fourth">
		<label>DEF 1-6pts allowed</label>
		<input type="text" class="form-control" name="" value="7">
	</div>

	<div class="form-group fourth">
		<label>DEF 7-13pts allowed</label>
		<input type="text" class="form-control" name="" value="4">
	</div>

	<div class="form-group fourth">
		<label>DEF 14-20pts allowed</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>DEF 21-27pts allowed</label>
		<input type="text" class="form-control" name="" value="-1">
	</div>

	<div class="form-group fourth">
		<label>DEF 28-34pts allowed</label>
		<input type="text" class="form-control" name="" value="-4">
	</div>

	<hr>

	<h4>DEF Players</h4>

	<div class="form-group fourth">
		<label>DEF Tackle</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>DEF Sack</label>
		<input type="text" class="form-control" name="" value="0.2">
	</div>

	<div class="form-group fourth">
		<label>DEF INT</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>DEF Fum-Rec</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>DEF TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>DEF Safety</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>DEF Blocked Kick</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return TD</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return 10yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return 10yds</label>
		<input type="text" class="form-control" name="" value="1">
	</div>

	<hr>

	<h4>Passing Bonus</h4>

	<div class="form-group fourth">
		<label>Passing YDS 300+</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>Passing YDS 400+</label>
		<input type="text" class="form-control" name="" value="5">
	</div>

	<div class="form-group fourth">
		<label>Passing YDS 500+</label>
		<input type="text" class="form-control" name="" value="6">
	</div>

	<hr>

	<h4>Rushing Bonus</h4>

	<div class="form-group fourth">
		<label>Rushing YDS 100+</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>Rushing YDS 150+</label>
		<input type="text" class="form-control" name="" value="3">
	</div>

	<div class="form-group fourth">
		<label>Rushing YDS 200+</label>
		<input type="text" class="form-control" name="" value="4">
	</div>

	<hr>

	<h4>Receiving Bonus</h4>

	<div class="form-group fourth">
		<label>Receiving YDS 100+</label>
		<input type="text" class="form-control" name="" value="2">
	</div>

	<div class="form-group fourth">
		<label>Receiving YDS 150+</label>
		<input type="text" class="form-control" name="" value="3">
	</div>

	<div class="form-group fourth">
		<label>Receiving YDS 200+</label>
		<input type="text" class="form-control" name="" value="4">
	</div>

	<hr>


	<div class="form-group half">
		<label>Waiver Type</label>
		<select class="form-control" name="">
			<option value="" selected>Blind Bidding</option>
			<option value="">First Come First Serve Waivers</option>
			<option value="">Reverse Standings | Standard Waivers</option>
		</select>
	</div>

	<hr>

	<div class="text-center">
		<button class="btn btn-default" type="submit">Update</button>
	</div>

</form>
