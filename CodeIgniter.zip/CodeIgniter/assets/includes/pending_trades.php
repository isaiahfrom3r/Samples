<h4>Pending Trades</h4>

<div class="trading-area pending-trades">
	<div class="trade-wrap">
		<h4>
			<div class="avatar" style="background-image:url(assets/img/teambg1.jpg);"></div>
			The Shadowknights
			<div style="clear:both;"></div>
		</h4>
		<div class="table-responsive">
			<table class="table lobby-table trade-table" id="lineup_table">
				<tbody>
					<tr class="receiving">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								QB | Bye 8 | YTD 198  <br>
							</div>
						</td>
					</tr>
					<tr class="trading">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								RB | Bye 7 | YTD 84
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div class="trade-wrap">
		<h4>
			<div class="avatar" style="background-image:url(assets/img/teambg2.jpg);"></div>
			U Mad Bro?
			<div style="clear:both;"></div>
		</h4>
		<div class="table-responsive">
			<table class="table lobby-table trade-table" id="lineup_table">
				<tbody>
					<tr class="receiving">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								RB | Bye 7 | YTD 84
							</div>
						</td>
					</tr>
					<tr class="trading">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								QB | Bye 8 | YTD 198  <br>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div style="clear:both;"></div>
	<div class="actions text-center">
		<a href="#" class="btn btn-default view">Approve Trade</a>
		<a href="#" class="btn btn-default red">Revoke Trade</a>
	</div>
</div>

<div class="trading-area pending-trades">
	<div class="trade-wrap">
		<h4>
			<div class="avatar" style="background-image:url(assets/img/draft-pic.jpg);"></div>
			Footballers
			<div style="clear:both;"></div>
		</h4>
		<div class="table-responsive">
			<table class="table lobby-table trade-table" id="lineup_table">
				<tbody>
					<tr class="receiving">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								RB | Bye 8 | YTD 94  <br>
							</div>
						</td>
					</tr>
					<tr class="trading">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								WR | Bye 7 | YTD 84
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div class="trade-wrap">
		<h4>
			<div class="avatar" style="background-image:url(assets/img/draft-pic.jpg);"></div>
			No Romo
			<div style="clear:both;"></div>
		</h4>
		<div class="table-responsive">
			<table class="table lobby-table trade-table" id="lineup_table">
				<tbody>
					<tr class="receiving">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								WR | Bye 7 | YTD 84
							</div>
						</td>
					</tr>
					<tr class="trading">
						<td class="text-left">
							<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a>
							<div class="details">
								RB | Bye 8 | YTD 94  <br>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div style="clear:both;"></div>
	<div class="actions text-center">
		<a href="#" class="btn btn-default view">Approve Trade</a>
		<a href="#" class="btn btn-default red">Revoke Trade</a>
	</div>
</div>
