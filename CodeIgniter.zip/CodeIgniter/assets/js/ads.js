function click_ad(id){
	console.log(id);

	$.ajax({
       url: HOST_NAME+'/Ads_updater/click_count/'+id,
    }).done(function() {

   });
}
