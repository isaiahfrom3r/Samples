<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Teams extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function get_all(){

		$q = $this->db->get("sport_team");
		$q = $q->result();
		return $q;

	}

	public function get_by_id($tid){

		$this->db->where('cid',$tid);
		$q = $this->db->get("sport_team");
		$q = $q->row();
		return $q;

	}

	public function insert_update_team($team){

		$this->db->where('cid',$team['cid']);
		$q = $this->db->get("sport_team");

		if ($q->num_rows() > 0){

			$this->db->where('cid',$team['cid']);
			$this->db->update('sport_team', $team);

		}else{

			$this->db->insert('sport_team', $team);

		}

	}





}//  end feed class
