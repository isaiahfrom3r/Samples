<?php
class Misc extends CI_Model {

	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }


	function time_nice($time = '')
	{
		$time_now = time();
		$difference = $time_now - $time;
		if ($difference < 3600)
		{
			//return minutes
			return vlang('dashboard_minutes_ago', floor($difference / 60));
		}
		elseif ($difference < 86400)
		{
			//return hours
			//return floor($difference / 3600).' hours ago';
			return vlang('dashboard_hours_ago', floor($difference / 3600));
		}
		else
		{
			//return days
			//return floor($difference / 86400).' days ago';
			return vlang('dashboard_days_ago', floor($difference / 86400));
		}
	}
	function countries(){

		$countries = array(
			'United States',
			'United Kingdom',
			'Afghanistan',
			'Argentina',
			'Australia',
			'Belgium',
			'Brazil',
			'Canada',
			'Chile',
			'China',
			'Colombia',
			'Denmark',
			'France',
			'Germany',
			'India',
			'Indonesia',
			'Iran',
			'Iraq',
			'Israel',
			'Italy',
			'Japan',
			'Mexico',
			'Netherlands',
			'Philippines',
			'Poland',
			'Russia',
			'South Africa',
			'South Korea',
			'Spain',
			'Turkey',
		);

		return $countries;


	}
	function states_list()
	{
		$state_list = array(
				''=>'',
				'AL'=>"Alabama",
                'AK'=>"Alaska",
                'AZ'=>"Arizona",
                'AR'=>"Arkansas",
                'CA'=>"California",
                'CO'=>"Colorado",
                'CT'=>"Connecticut",
                'DE'=>"Delaware",
                'FL'=>"Florida",
                'GA'=>"Georgia",
                'HI'=>"Hawaii",
                'ID'=>"Idaho",
                'IL'=>"Illinois",
                'IN'=>"Indiana",
                'IA'=>"Iowa",
                'KS'=>"Kansas",
                'KY'=>"Kentucky",
                'LA'=>"Louisiana",
                'ME'=>"Maine",
                'MD'=>"Maryland",
                'MA'=>"Massachusetts",
                'MI'=>"Michigan",
                'MN'=>"Minnesota",
                'MS'=>"Mississippi",
                'MO'=>"Missouri",
                'MT'=>"Montana",
                'NE'=>"Nebraska",
                'NV'=>"Nevada",
                'NH'=>"New Hampshire",
                'NJ'=>"New Jersey",
                'NM'=>"New Mexico",
                'NY'=>"New York",
                'NC'=>"North Carolina",
                'ND'=>"North Dakota",
                'OH'=>"Ohio",
                'OK'=>"Oklahoma",
                'OR'=>"Oregon",
                'PA'=>"Pennsylvania",
                'RI'=>"Rhode Island",
                'SC'=>"South Carolina",
                'SD'=>"South Dakota",
                'TN'=>"Tennessee",
                'TX'=>"Texas",
                'UT'=>"Utah",
                'VT'=>"Vermont",
                'VA'=>"Virginia",
                'WA'=>"Washington",
                'WV'=>"West Virginia",
                'WI'=>"Wisconsin",
                'WY'=>"Wyoming",
);
		return $state_list;
	}

	function countries_list()
	{

		$countries = array(
			''=>'',
			"US"=>"UNITED STATES",
			"AF"=>"AFGHANISTAN",
			"AX"=>"ALAND ISLANDS",
			"AL"=>"ALBANIA",
			"DZ"=>"ALGERIA",
			"AS"=>"AMERICAN SAMOA",
			"AD"=>"ANDORRA",
			"AO"=>"ANGOLA",
			"AI"=>"ANGUILLA",
			"AQ"=>"ANTARCTICA",
			"AG"=>"ANTIGUA AND BARBUDA",
			"AR"=>"ARGENTINA",
			"AM"=>"ARMENIA",
			"AW"=>"ARUBA",
			"AU"=>"AUSTRALIA",
			"AT"=>"AUSTRIA",
			"AZ"=>"AZERBAIJAN",
			"BS"=>"BAHAMAS",
			"BH"=>"BAHRAIN",
			"BD"=>"BANGLADESH",
			"BB"=>"BARBADOS",
			"BY"=>"BELARUS",
			"BE"=>"BELGIUM",
			"BZ"=>"BELIZE",
			"BJ"=>"BENIN",
			"BM"=>"BERMUDA",
			"BT"=>"BHUTAN",
			"BO"=>"BOLIVIA",
			"BA"=>"BOSNIA AND HERZEGOVINA",
			"BW"=>"BOTSWANA",
			"BV"=>"BOUVET ISLAND",
			"BR"=>"BRAZIL",
			"IO"=>"BRITISH INDIAN OCEAN TERRITORY",
			"BN"=>"BRUNEI DARUSSALAM",
			"BG"=>"BULGARIA",
			"BF"=>"BURKINA FASO",
			"BI"=>"BURUNDI",
			"KH"=>"CAMBODIA",
			"CM"=>"CAMEROON",
			"CA"=>"CANADA",
			"CV"=>"CAPE VERDE",
			"CI"=>"CâTE D'IVOIRE",
			"KY"=>"CAYMAN ISLANDS",
			"CF"=>"CENTRAL AFRICAN REPUBLIC",
			"TD"=>"CHAD",
			"CL"=>"CHILE",
			"CN"=>"CHINA",
			"CX"=>"CHRISTMAS ISLAND",
			"CC"=>"COCOS (KEELING) ISLANDS",
			"CO"=>"COLOMBIA",
			"KM"=>"COMOROS",
			"CG"=>"CONGO",
			"CD"=>"CONGO, THE DEMOCRATIC REPUBLIC OF THE",
			"CK"=>"COOK ISLANDS",
			"CR"=>"COSTA RICA",
			"HR"=>"CROATIA",
			"CU"=>"CUBA",
			"CY"=>"CYPRUS",
			"CZ"=>"CZECH REPUBLIC",
			"DK"=>"DENMARK",
			"DJ"=>"DJIBOUTI",
			"DM"=>"DOMINICA",
			"DO"=>"DOMINICAN REPUBLIC",
			"EC"=>"ECUADOR",
			"EG"=>"EGYPT",
			"SV"=>"EL SALVADOR",
			"GQ"=>"EQUATORIAL GUINEA",
			"ER"=>"ERITREA",
			"EE"=>"ESTONIA",
			"ET"=>"ETHIOPIA",
			"FK"=>"FALKLAND ISLANDS (MALVINAS)",
			"FO"=>"FAROE ISLANDS",
			"FJ"=>"FIJI",
			"FI"=>"FINLAND",
			"FR"=>"FRANCE",
			"GF"=>"FRENCH GUIANA",
			"PF"=>"FRENCH POLYNESIA",
			"TF"=>"FRENCH SOUTHERN TERRITORIES",
			"GA"=>"GABON",
			"GM"=>"GAMBIA",
			"GE"=>"GEORGIA",
			"DE"=>"GERMANY",
			"GH"=>"GHANA",
			"GI"=>"GIBRALTAR",
			"GR"=>"GREECE",
			"GL"=>"GREENLAND",
			"GD"=>"GRENADA",
			"GP"=>"GUADELOUPE",
			"GU"=>"GUAM",
			"GT"=>"GUATEMALA",
			"GN"=>"GUINEA",
			"GW"=>"GUINEA-BISSAU",
			"GY"=>"GUYANA",
			"HT"=>"HAITI",
			"HM"=>"HEARD ISLAND AND MCDONALD ISLANDS",
			"VA"=>"HOLY SEE (VATICAN CITY STATE)",
			"HN"=>"HONDURAS",
			"HK"=>"HONG KONG",
			"HU"=>"HUNGARY",
			"IS"=>"ICELAND",
			"IN"=>"INDIA",
			"ID"=>"INDONESIA",
			"IR"=>"IRAN ISLAMIC REPUBLIC OF",
			"IQ"=>"IRAQ",
			"IE"=>"IRELAND",
			"IL"=>"ISRAEL",
			"IT"=>"ITALY",
			"JM"=>"JAMAICA",
			"JP"=>"JAPAN",
			"JO"=>"JORDAN",
			"KZ"=>"KAZAKHSTAN",
			"KE"=>"KENYA",
			"KI"=>"KIRIBATI",
			"KP"=>"KOREA DEMOCRATIC PEOPLE\'S REPUBLIC OF",
			"KR"=>"KOREA REPUBLIC OF",
			"KW"=>"KUWAIT",
			"KG"=>"KYRGYZSTAN",
			"LA"=>"LAO PEOPLE\'S DEMOCRATIC REPUBLIC",
			"LV"=>"LATVIA",
			"LB"=>"LEBANON",
			"LS"=>"LESOTHO",
			"LR"=>"LIBERIA",
			"LY"=>"LIBYAN ARAB JAMAHIRIYA",
			"LI"=>"LIECHTENSTEIN",
			"LT"=>"LITHUANIA",
			"LU"=>"LUXEMBOURG",
			"MO"=>"MACAO",
			"MK"=>"MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF",
			"MG"=>"MADAGASCAR",
			"MW"=>"MALAWI",
			"MY"=>"MALAYSIA",
			"MV"=>"MALDIVES",
			"ML"=>"MALI",
			"MT"=>"MALTA",
			"MH"=>"MARSHALL ISLANDS",
			"MQ"=>"MARTINIQUE",
			"MR"=>"MAURITANIA",
			"MU"=>"MAURITIUS",
			"YT"=>"MAYOTTE",
			"MX"=>"MEXICO",
			"FM"=>"MICRONESIA, FEDERATED STATES OF",
			"MD"=>"MOLDOVA, REPUBLIC OF",
			"MC"=>"MONACO",
			"MN"=>"MONGOLIA",
			"MS"=>"MONTSERRAT",
			"MA"=>"MOROCCO",
			"MZ"=>"MOZAMBIQUE",
			"MM"=>"MYANMAR",
			"NA"=>"NAMIBIA",
			"NR"=>"NAURU",
			"NP"=>"NEPAL",
			"NL"=>"NETHERLANDS",
			"AN"=>"NETHERLANDS ANTILLES",
			"NC"=>"NEW CALEDONIA",
			"NZ"=>"NEW ZEALAND",
			"NI"=>"NICARAGUA",
			"NE"=>"NIGER",
			"NG"=>"NIGERIA",
			"NU"=>"NIUE",
			"NF"=>"NORFOLK ISLAND",
			"MP"=>"NORTHERN MARIANA ISLANDS",
			"NO"=>"NORWAY",
			"OM"=>"OMAN",
			"PK"=>"PAKISTAN",
			"PW"=>"PALAU",
			"PS"=>"PALESTINIAN TERRITORY, OCCUPIED",
			"PA"=>"PANAMA",
			"PG"=>"PAPUA NEW GUINEA",
			"PY"=>"PARAGUAY",
			"PE"=>"PERU",
			"PH"=>"PHILIPPINES",
			"PN"=>"PITCAIRN",
			"PL"=>"POLAND",
			"PT"=>"PORTUGAL",
			"PR"=>"PUERTO RICO",
			"QA"=>"QATAR",
			"RE"=>"REUNION",
			"RO"=>"ROMANIA",
			"RU"=>"RUSSIAN FEDERATION",
			"RW"=>"RWANDA",
			"SH"=>"SAINT HELENA",
			"KN"=>"SAINT KITTS AND NEVIS",
			"LC"=>"SAINT LUCIA",
			"PM"=>"SAINT PIERRE AND MIQUELON",
			"VC"=>"SAINT VINCENT AND THE GRENADINES",
			"WS"=>"SAMOA",
			"SM"=>"SAN MARINO",
			"ST"=>"SAO TOME AND PRINCIPE",
			"SA"=>"SAUDI ARABIA",
			"SN"=>"SENEGAL",
			"CS"=>"SERBIA AND MONTENEGRO",
			"SC"=>"SEYCHELLES",
			"SL"=>"SIERRA LEONE",
			"SG"=>"SINGAPORE",
			"SK"=>"SLOVAKIA",
			"SI"=>"SLOVENIA",
			"SB"=>"SOLOMON ISLANDS",
			"SO"=>"SOMALIA",
			"ZA"=>"SOUTH AFRICA",
			"GS"=>"SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS",
			"ES"=>"SPAIN",
			"LK"=>"SRI LANKA",
			"SD"=>"SUDAN",
			"SR"=>"SURINAME",
			"SJ"=>"SVALBARD AND JAN MAYEN",
			"SZ"=>"SWAZILAND",
			"SE"=>"SWEDEN",
			"CH"=>"SWITZERLAND",
			"SY"=>"SYRIAN ARAB REPUBLIC",
			"TW"=>"TAIWAN PROVINCE OF CHINA",
			"TJ"=>"TAJIKISTAN",
			"TZ"=>"TANZANIA UNITED REPUBLIC OF",
			"TH"=>"THAILAND",
			"TL"=>"TIMOR-LESTE",
			"TG"=>"TOGO",
			"TK"=>"TOKELAU",
			"TO"=>"TONGA",
			"TT"=>"TRINIDAD AND TOBAGO",
			"TN"=>"TUNISIA",
			"TR"=>"TURKEY",
			"TM"=>"TURKMENISTAN",
			"TC"=>"TURKS AND CAICOS ISLANDS",
			"TV"=>"TUVALU",
			"UG"=>"UGANDA",
			"UA"=>"UKRAINE",
			"AE"=>"UNITED ARAB EMIRATES",
			"GB"=>"UNITED KINGDOM",
			"UM"=>"UNITED STATES MINOR OUTLYING ISLANDS",
			"UY"=>"URUGUAY",
			"UZ"=>"UZBEKISTAN",
			"VU"=>"VANUATU",
			"VE"=>"VENEZUELA",
			"VN"=>"VIETNAM",
			"VG"=>"VIRGIN ISLANDS BRITISH",
			"VI"=>"VIRGIN ISLANDS U.S.",
			"WF"=>"WALLIS AND FUTUNA",
			"EH"=>"WESTERN SAHARA",
			"YE"=>"YEMEN",
			"ZM"=>"ZAMBIA",
			"ZW"=>"ZIMBABWE"
		);
		return $countries;
	}

	function sources_list()
	{
		$sources = $this->config->item('usersources');
		/*$sources = array(
					'1' => 'From a friend',
					'2' => 'Radio',
					'3' => 'Magazine',
					'4' => 'Search engine (e.g. Google)',
					'5' => 'Online advert',
					'6' => 'News article or blog post',
					'7' => 'Other',
					'8' => 'RotoGrinders',
					);*/
		return $sources;
	}

	function geocodeGoogle($params)
	{
		$zip=explode('|',$params);
		$address=str_replace(" ","+",trim($zip[0]));
		$url = "http://maps.google.com/maps/api/geocode/json?address=".$address."&output=csv&sensor=false";
		if(!empty($zip[1])){
			$url.='&region='.$zip[1];
		}
		//echo $url;
		$response = file_get_contents($url);
		$response = json_decode($response);
		$address = $response->results[0]->address_components;
		//$country=$zip[1];
		foreach($address as $a){
			$type=$a->types[0];
			if($type=="country"){
				$country=$a->short_name;
			}
		}
		$response = $response->results[0]->geometry->location;
		//echo "<pre>";print_r($response);echo "</pre>";
		$return = array('latitude' => $response->lat, 'longitude' => $response->lng,'country'=>$country);
		//print_r($return);
		return $return;
	}
	function geocodeCountryCode($zip){
		$url = "http://maps.google.com/maps/api/geocode/json?address={$zip}&output=csv&sensor=false";
		$response = file_get_contents($url);
		$response = json_decode($response);
		//echo "<pre>";print_r($response);echo "</pre>";
		$response = $response->results[0]->address_components;

		$return=array();
		foreach($response as $r){
			$type=$r->types[0];
			if($type=="country"){
				$return=$r->short_name;
			}
		}
		return $return;
	}
	function geocodeAddress($zip){
		$zip=explode('|',$zip);
		$url = "http://maps.google.com/maps/api/geocode/json?address={$zip[0]}&output=csv&sensor=false";
		if(!empty($zip[1])){
			$url.='&region='.$zip[1];
		}
		$response = file_get_contents($url);
		$response = json_decode($response);
		//echo "<pre>";print_r($response);echo "</pre>";
		$response = $response->results[0]->address_components;

		$return=array();
		foreach($response as $r){
			$type=$r->types[0];
			if($type=="locality" | $type=="administrative_area_level_1" | $type=="country"){
				$return[]=$r->long_name;
			}
		}
		return implode(', ',$return);
	}
	function geocodeData($zip){
		$url = "http://maps.google.com/maps/api/geocode/json?address={$zip}&output=csv&sensor=false";
		$response = file_get_contents($url);
		$response = json_decode($response);
		//echo "<pre>";print_r($response);echo "</pre>";
		$response = $response->results[0];
		return $response;
	}
	function get_inbox_unread($uid = '')
	{
		$this->db->select('cid');
		$q = $this->db->get_where('messages', array('owner_id' => $uid, 'status'=> 0, 'box'=>0));
		return $q->num_rows();
	}
}
?>
