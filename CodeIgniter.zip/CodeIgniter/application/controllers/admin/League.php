<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class League extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
        $this->load->model('states');
        $this->load->model('Leagues');
         $this->load->model('Events');
        $this->load->model('Misc');
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){



	}

	public function scoring(){
		$head = $foot = array();
		$data =  array();
		$this->db->where('admin',1);
		$q = $this->db->get("league_scoring");
		$data['scorings'] = $q->result();

		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/league/scoring',$data);
		$this->load->view(ADMIN_THEME.'/footer',$foot);
	}
	public function auto(){
		$head = $foot = array();
		$data =  array();
		$q = $this->db->get("auto_leagues");
		$data['leagues'] = $q->result();

		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/league/auto',$data);
		$this->load->view(ADMIN_THEME.'/footer',$foot);
	}
	function randomPassword() {
	    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
	    $pass = array(); //remember to declare $pass as an array
	    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
	    for ($i = 0; $i < 8; $i++) {
	        $n = rand(0, $alphaLength);
	        $pass[] = $alphabet[$n];
	    }
	    return implode($pass); //turn the array into a string
	}
	public function create_auto($lid=0){
		$head = $foot = array();
		$head['scripts'] = array(base_url().'/assets/js/datetime_picker.js');
		$head['styles'] = array(base_url().'/assets/css/datetime_picker.css');
		$data =  array();

		//get league from id
		if($lid > 0){
			$data['league'] =  $this->Leagues->get_auto_by_id($lid);
		}
		$this->db->where('admin',1);
		$q = $this->db->get("league_scoring");
		$data['scorings'] = $q->result();







		$this->form_validation->set_rules('type', 'Type', 'required|trim');
		$this->form_validation->set_rules('name', 'Name', 'required|trim');
		$this->form_validation->set_rules('entry_fee', 'Entry', 'required|trim');
		$this->form_validation->set_rules('style', 'Style', 'required|trim');
		$this->form_validation->set_rules('size', 'Size', 'required|trim');
		$this->form_validation->set_rules('scoring', 'Scoring', 'required|trim');
		$this->form_validation->set_rules('fractional', 'Fractional', 'required|trim');
		$this->form_validation->set_rules('p_int_scoring', 'Pass Interference Setting', 'required|trim');
		$this->form_validation->set_rules('in_game_subs', 'In Game Subs', 'required|trim');
		$this->form_validation->set_rules('waivers', 'Waivers', 'required|trim');
		$this->form_validation->set_rules('budget', 'Budget', 'required|trim');
		$this->form_validation->set_rules('in_game_cool', 'Cool Down', 'required|trim');
		$this->form_validation->set_rules('roster_ir', 'Roster IR', 'required|trim');
		$this->form_validation->set_rules('draft_type', 'Draft Type', 'required|trim');
		$this->form_validation->set_rules('idp', 'IDP', 'required|trim');
		$this->form_validation->set_rules('draft_clock', 'Draft Clock', 'required|trim');
		$this->form_validation->set_rules('draft_start', 'Draft Start', 'required|trim');


		if ($this->form_validation->run() == FALSE){

			if(!empty($_POST)){
				$_POST['roster'] = json_encode($_POST['roster']);
				$data['league'] =  (object)$_POST;
			}
		}else{

			$_POST['divisions'] = 0;
			$_POST['divisions_number'] = 0;
			$_POST['draft_env'] = 1;
			$_POST['current_pick'] = 1;
			$_POST['draft_format'] = 1;
			$_POST['season'] = $this->Events->get_season();
			$_POST['public_id'] = "LEAGUE_".time();;
			$_POST['key'] = $this->randomPassword();
			if($_POST['type'] > 1){
				$_POST['is_paid'] = 1;
			}else{
				$_POST['is_paid'] = 0;
			}
			$pyouts = $_POST['payouts'];
			unset($_POST['payouts']);

			$_POST['payouts'] =  json_encode( array('payouts' =>$pyouts, 'honor' => $_POST['honor'])  );
			unset($_POST['honor']);

			$_POST['draft_start'] = strtotime($_POST['draft_start']);
			$_POST['roster'] = json_encode($_POST['roster']);

			if($lid > 0){

				$this->db->where('cid', $lid);
				$this->db->update('auto_leagues', $_POST);
			}else{


				$this->db->insert('auto_leagues', $_POST);
			}

			$this->alert->set('Auto League Saved','success');
			redirect('admin/league/auto');
		}


		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/league/auto_edit',$data);
		$this->load->view(ADMIN_THEME.'/footer',$foot);
	}



	public function scoring_edit($sid){
		$this->db->where('cid',$sid);
		$q = $this->db->get("league_scoring");
		$q = $q->row();
		$data['scoring'] =  json_decode($q->scoring,true);
		$data['name'] =  $q->name;

		$this->form_validation->set_rules('name', 'Name', 'required');

		if ($this->form_validation->run() == FALSE){
		}else{

			$scoring = $this->Leagues->get_create_scoring($_POST['scoring'],$_POST['name'],1);




			redirect(ADMIN_THEME.'/league/scoring');

		}

		$this->load->view(ADMIN_THEME.'/header');
 		$this->load->view(ADMIN_THEME.'/league/scoring_edit',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}
	public function scoring_create(){

		$this->form_validation->set_rules('name', 'Name', 'required');

		if ($this->form_validation->run() == FALSE){
		}else{

			$scoring = $this->Leagues->get_create_scoring($_POST['scoring'],$_POST['name'],1);




			redirect(ADMIN_THEME.'/league/scoring');

		}

		$this->load->view(ADMIN_THEME.'/header');
 		$this->load->view(ADMIN_THEME.'/league/scoring_create');
		$this->load->view(ADMIN_THEME.'/footer');
	}

}
