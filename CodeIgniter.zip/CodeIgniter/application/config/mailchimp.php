<?php defined('BASEPATH') OR exit('No direct script access allowed');
$config['mailchimp_api_key']='REMOVED';
$config['mailchimp_datacenter']='us15';
$config['mailchimp_main_list']='Newsletter';
$config['mailchimp_main_list_id']='REMOVED';
$config['mailchimp_active_lists']=array(
);
