<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Meta extends CI_Controller {

	function __construct() {

        parent::__construct();
    }

	public function pass(){
		$this->db->where('url',$_POST['url']);
		$q = $this->db->get("meta");
		if ($q->num_rows() > 0){
		}else{
			$data = array(
				'url' => $_POST['url'],
               'name' => 'Name',
               'seo' => 'SEO',
               'description' => 'Page Description'
            );

			$this->db->insert('meta', $data);
		}

		$this->db->where('url',$_POST['url']);
		$q = $this->db->get("meta");
		if ($q->num_rows() == 0){
			echo "ERROR"; die;
		}
		$meta = $q->row();
		$data['meta'] =  $meta;

		redirect('/admin/meta/edit/'.$meta->id);

	}
	public function edit($id)
	{

		$this->db->where('id',$id);
		$q = $this->db->get("meta");
		if ($q->num_rows() == 0){
			echo "ERROR"; die;
		}
		$meta = $q->row();
		$data['meta'] =  $meta;

		// set validation rules
		$this->form_validation->set_rules('seo', 'SEO', 'required');
		$this->form_validation->set_rules('name', 'NAME', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');


		if ($this->form_validation->run() === false) {
		}else{


			$this->db->where('id', $meta->id);
			$this->db->update('meta', $_POST);

			$this->load->library('user_agent');
			redirect($meta->url);


		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/meta/edit',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function index(){

		foreach(glob(APPPATH . 'controllers/*php') as $controller)
		{
		   $list[] = str_ireplace(APPPATH.'controllers/', '', $controller);
		}
		$data['list'] =  $list;
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/meta/list',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}
}
