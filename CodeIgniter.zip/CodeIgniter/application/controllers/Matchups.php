<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matchups extends CI_Controller {
	public function __construct() {
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		parent::__construct();


	}
	public function records(){
		// grab all scores
		$q = $this->db->get("golf_players");
		$players = $q->result();


		foreach($players as $player){

			$this->db->order_by('week','DESC');
			$this->db->where('player_id',$player->cid);
			$q = $this->db->get("golf_players_results");
			$q = $q->result();



			foreach($q as $score){

			$this->db->where('week',$score->week);
			$this->db->where('team_1',$player->team_id);

			$this->db->or_where('team_2',$player->team_id);
			$this->db->where('week',$score->week);
			$q = $this->db->get("golf_matchup");
			$matchup = $q->row();


			$scores = json_decode($score->scores);
			$ts = array_sum($scores);

			if($ts == 0){
				continue;
			}


			$this->db->where('cid',$matchup->course_id);
			$q = $this->db->get("golf_courses");
			$course = $q->row();


			foreach(json_decode($score->scores) as $key=>$s){
				$keyscore = 'h'.($key+1);

				$diff = $s - $course->$keyscore;

				if($diff == 0){
					$pstats[$player->cid][$score->week]['par'] ++;
					$pstats[$player->cid]['total']['par'] ++;
				}elseif($diff == 1){
					$pstats[$player->cid][$score->week]['bogey'] ++;
					$pstats[$player->cid]['total']['bogey'] ++;
				}elseif($diff >= 2){
					$pstats[$player->cid][$score->week]['bogey_plus'] ++;
					$pstats[$player->cid]['total']['bogey_plus'] ++;
				}elseif($diff == -1){
					$pstats[$player->cid][$score->week]['birdie'] ++;
					$pstats[$player->cid]['total']['birdie'] ++;
				}elseif($diff <= -2){
					$pstats[$player->cid][$score->week]['birdie_plus'] ++;
					$pstats[$player->cid]['total']['birdie_plus'] ++;
				}

			}






			}
		}



		$maxbirdiesweek=0;
		$maxparsweek=0;
		$maxbirdies=0;
		$maxpars=0;

		$maxbirdieguys = array();
		$maxparguys = array();

		$maxbirdieguysweek = array();
		$maxparguysweek = array();


		$maxeagles=0;
		$maxeaglesguys = array();


		$maxdouble=0;
		$maxdoubleguys = array();

		foreach($pstats as $pid=>$stats){

			if($stats['total']['birdie'] >= $maxbirdies){

				if($stats['total']['birdie'] > $maxbirdies){
					$maxbirdieguys = array();
					$maxbirdieguys[] = $pid;

				}else{
					$maxbirdieguys[] = $pid;
				}

				$maxbirdies = $stats['total']['birdie'];
			}
			if($stats['total']['par'] >= $maxpars){

				if($stats['total']['birdie'] > $maxpars){
					$maxparguys = array();
					$maxparguys[] = $pid;

				}else{
					$maxparguys[] = $pid;
				}

				$maxpars = $stats['total']['par'];
			}


			if($stats['total']['bogey_plus'] >= $maxdouble){


				if($stats['total']['bogey_plus'] > $maxdouble){
					$maxdoubleguys = array();
					$maxdoubleguys[] = $pid;

				}else{
					$maxdoubleguys[] = $pid;
				}

				$maxdouble = $stats['total']['bogey_plus'];
			}



			if($stats['total']['birdie_plus'] >= $maxeagles){

				if($stats['total']['birdie_plus'] > $maxeagles){
					$maxeaglesguys = array();
					$maxeaglesguys[] = $pid;

				}else{
					$maxeaglesguys[] = $pid;
				}

				$maxeagles = $stats['total']['birdie_plus'];
			}



			foreach($stats as $week=>$sarray){

				if($week == 'total'){
					continue;
				}

				if($sarray['birdie'] >= $maxbirdiesweek){

					if($stats['birdie'] > $maxbirdiesweek){
						$maxbirdieguysweek = array();
						$maxbirdieguysweek[$pid] = $pid;

					}else{
						$maxbirdieguysweek[$pid] = $pid;
					}

					$maxbirdiesweek = $sarray['birdie'];
				}
				if($sarray['par'] >= $maxparsweek){

					if($sarray['birdie'] > $maxparsweek){
						$maxparguysweek = array();
						$maxparguysweek[$pid] = $pid;

					}else{
						$maxparguysweek[$pid] = $pid;
					}

					$maxparsweek = $sarray['par'];
				}



			}






		}

		$lowscore = 100;
		$highscore = 0;

		foreach($players as $p){
			$plist[$p->cid] = $p->name;
		}

		$q = $this->db->get("golf_players_results");
		$q = $q->result();






		foreach($q as $s){
			$res[$s->player_id][$s->week] = $s->total;
			$precs[$s->week] = $s->total;


			if($s->total <= $lowscore){
				if($s->total < $lowscore){
					$lowguys = array();
				}
				$lowscore = $s->total;

				$lowguys[$s->player_id] = $s->player_id;

			}

			if($s->total >= $highscore){
				if($s->total > $highscore){
					$highguys = array();
				}
				$highscore = $s->total;

				$highguys[$s->player_id] = $s->player_id;

			}




		}
		$data['players'] =  $plist;
		$data['lowscore'] =  $lowscore;
		$data['lowguys'] =  $lowguys;
		$data['highscore'] =  $highscore;
		$data['highguys'] =  $highguys;

		$data['maxbirdies'] =  $maxbirdies;
		$data['maxbirdiesguys'] =  $maxbirdieguys;

		$data['maxeagles'] =  $maxeagles;
		$data['maxeaglesguys'] =  $maxeaglesguys;

		$data['maxdouble'] =  $maxdouble;
		$data['maxdoubleguys'] =  $maxdoubleguys;

		$data['maxbirdiesweek'] =  $maxbirdiesweek;
		$data['maxbirdiesguysweek'] =  $maxbirdieguysweek;

		$data['maxpars'] =  $maxpars;
		$data['maxparsguys'] =  $maxparguys;

		$data['maxparsweek'] =  $maxparsweek;
		$data['maxparsguysweek'] =  $maxparguysweek;


		$data['results'] =  $res;

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/matchups/records',$data);
		$this->load->view(THEME.'/footer');
	}
	public function handicaps($week='0'){

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		if($week == 0){
			// figure out lats week

			$this->db->order_by('week','DESC');
			$this->db->limit(1);
			$q = $this->db->get("golf_players_handicap");
			$q = $q->row();

			$week = $q->week;
		}

		$data['week'] =  $week;

		$this->db->where('week',$week);
		$q = $this->db->get("golf_players_handicap");
		$q = $q->result();
		foreach($q as $s){
			$hcaps[$s->player_id] = $s->hc;
		}


		$data['hcaps'] =  $hcaps;

		$q = $this->db->get("golf_players");
		$q = $q->result();

		foreach($q as $p){
			$players[$p->cid] = $p;
		}
		$data['players'] =  $players;

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/matchups/handicaps',$data);
		$this->load->view(THEME.'/footer');

	}
	public function scoring(){

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		$this->db->where('team_1_points > ',0);
		$this->db->where('week <',10);
		$this->db->or_where('team_2_points > ',0);
		$this->db->where('week <',10);
		$q = $this->db->get("golf_matchup");
		$q = $q->result();

		foreach($q as $r){

			$weeks[$r->week] = $r->week;
			$standings[$r->team_1][$r->week] = $r->team_1_points;
			$standings[$r->team_1]['total'] += $r->team_1_points;
			$standings[$r->team_1]['tid'] = $r->team_1;


			$standings[$r->team_2][$r->week] = $r->team_2_points;
			$standings[$r->team_2]['total'] += $r->team_2_points;
			$standings[$r->team_2]['tid'] = $r->team_2;
		}

		foreach($standings as $key=>$s){

			$finalstandings[$s['total'].""][] = $s;

		}

		krsort($finalstandings);
		foreach($finalstandings as $af){
			foreach($af as $stds){

				$sendstandings[] = $stds;
				$passumfirst[$stds['tid']] = $stds['total'];
			}
		}

		$finalstandings = $standings = array();
		$this->db->where('team_1_points > ',0);
		$this->db->where('week >',9);
		$this->db->or_where('team_2_points > ',0);
		$this->db->where('week >',9);
		$q = $this->db->get("golf_matchup");
		$q = $q->result();


		foreach($q as $r){

			$weeks[$r->week] = $r->week;
			$standings2[$r->team_1][$r->week] = $r->team_1_points;
			$standings2[$r->team_1]['total'] += $r->team_1_points;
			$standings2[$r->team_1]['tid'] = $r->team_1;


			$standings2[$r->team_2][$r->week] = $r->team_2_points;
			$standings2[$r->team_2]['total'] += $r->team_2_points;
			$standings2[$r->team_2]['tid'] = $r->team_2;
		}

		foreach($standings2 as $key=>$s){

			$finalstandings[$s['total'].""][] = $s;
		}



		krsort($finalstandings);
		foreach($finalstandings as $af){
			foreach($af as $stds){
				$twosendstandings[] = $stds;
			}
		}




		if($week == 0){
			// figure out lats week

			$this->db->order_by('week','DESC');
			$this->db->limit(1);
			$q = $this->db->get("golf_players_handicap");
			$q = $q->row();

			$week = $q->week;
		}
		$this->db->where('week',$week);
		$q = $this->db->get("golf_players_handicap");
		$q = $q->result();
		foreach($q as $s){
			$hcaps[$s->player_id] = $s->hc;
		}



		$data['hcaps'] =  $hcaps;

		$data['standings'] =  $passumfirst;
		$data['twosendstandings'] =  $twosendstandings;
		$data['weeks'] =  $weeks;
		$data['passumfirst'] =  $passumfirst;
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/matchups/scoring',$data);
		$this->load->view(THEME.'/footer');

	}
	public function handicaps_print($week='0'){

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		if($week == 0){
			// figure out lats week

			$this->db->order_by('week','DESC');
			$this->db->limit(1);
			$q = $this->db->get("golf_players_handicap");
			$q = $q->row();

			$week = $q->week;
		}

		$data['week'] =  $week;

		$this->db->where('week',$week);
		$q = $this->db->get("golf_players_handicap");
		$q = $q->result();
		foreach($q as $s){
			$hcaps[$s->player_id] = $s->hc;
		}


		$data['hcaps'] =  $hcaps;

		$q = $this->db->get("golf_players");
		$q = $q->result();

		foreach($q as $p){
			$players[$p->cid] = $p;
		}
		$data['players'] =  $players;

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/matchups/handicaps_print',$data);
		$this->load->view(THEME.'/footer');

	}

	public function week($week='0'){

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		if($week == 0){
			// figure out lats week

			$this->db->order_by('week','DESC');
			$this->db->limit(1);
			$q = $this->db->get("golf_players_handicap");
			$q = $q->row();

			$week = $q->week;
		}
		$this->db->where('week',$week);
		$q = $this->db->get("golf_matchup");
		$q = $q->result();
		$data['matchups'] =  $q;
		$data['week'] =  $week;

		$hweek = $week;
		if($hweek < 3){
			$hweek = 3;
		}
		$this->db->where('week',$hweek);
		$q = $this->db->get("golf_players_handicap");
		$q = $q->result();
		foreach($q as $s){
			$hcaps[$s->player_id] = $s->hc;
		}
		$data['hcaps'] =  $hcaps;

		$this->db->where('week',$week);
		$q = $this->db->get("golf_players_results");
		$q = $q->result();
		foreach($q as $s){
			$savescores[$s->player_id] = $s;
		}
		$data['scores'] =  $savescores;

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/matchups/list',$data);
		$this->load->view(THEME.'/footer');

	}

	public function admin_week($week='0'){

		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);
		if($week == 0){
			// figure out lats week
			$week = 1;
		}
		$this->db->where('week',$week);
		$q = $this->db->get("golf_matchup");
		$q = $q->result();
		$data['matchups'] =  $q;
		$data['week'] =  $week;


		if(isset($_POST['scores'])){
			$week = $_POST['week'];
			foreach($_POST['scores'] as $pid=>$scores){
				$sd = array(
	               'week' => $week,
	               'total' => array_sum($scores),
	               'scores' => json_encode($scores),
	               'player_id' => $pid,
	            );

				$this->db->where('player_id',$pid);
				$this->db->where('week',$week);
				$q = $this->db->get("golf_players_results");
				if ($q->num_rows() > 0){

					$this->db->where('player_id',$pid);
					$this->db->where('week',$week);
					$this->db->update('golf_players_results', $sd);

				}else{

					$this->db->insert('golf_players_results', $sd);

				}



			}



		}



		$this->db->where('week',$week);
		$q = $this->db->get("golf_players_handicap");
		$q = $q->result();
		foreach($q as $s){
			$hcaps[$s->player_id] = $s->hc;
		}
		$data['hcaps'] =  $hcaps;

		$this->db->where('week',$week);
		$q = $this->db->get("golf_players_results");
		$q = $q->result();
		foreach($q as $s){
			$savescores[$s->player_id] = $s;
		}
		$data['scores'] =  $savescores;

/*
		echo "<pre>";
		print_r($savescores);
		echo "</pre>";
		die;
*/

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/matchups/admin_list',$data);
		$this->load->view(THEME.'/footer');

	}

	function run_handicaps($week=1){

		$hcaps = array();
		//$this->db->where('cid',18);
		$q = $this->db->get("golf_players");
		$q = $q->result();

		foreach($q as $player){

			$this->db->limit('4');
			$this->db->where('week <',$week);
			$this->db->order_by('week','DESC');
			$this->db->where('player_id',$player->cid);
			$q = $this->db->get("golf_players_results");
			$q = $q->result();



			foreach($q as $score){

			$this->db->where('team_1',$player->team_id);
			$this->db->or_where('team_2',$player->team_id);
			$q = $this->db->get("golf_matchup");
			$matchup = $q->row();


			$scores = json_decode($score->scores);
			$ts = array_sum($scores);

			if($ts == 0){
				continue;
			}

			$this->db->where('cid',$matchup->course_id);
			$q = $this->db->get("golf_courses");
			$course = $q->row();

			//(Score – Course Rating) x 113 / Slope Rating
			$hc = 0;
			//echo "($ts - ($course->rating/2)) * 113 / ($course->slope)";
			$hc = ($ts - ($course->rating/2)) * 113 / ($course->slope);


 			$hc = $hc *.78;

			if($hc > 18){
				$hc = 18;
			}

			$hcaps[$player->cid][] = round($hc);

			$sample[$player->name][$player->cid] = $ts + $sample[$player->name][$player->cid];

			}


		}
		echo "<pre>";
		print_r($sample);
		echo "</pre>";
		echo "<pre>";
		print_r($hcaps);
		echo "</pre>";

		foreach($hcaps as $pid=>$h){


			$hcu = array(
               'week' => $week,
               'player_id' => $pid,
               'hc' => array_sum($h)/count($h),
            );


			$this->db->where('week',$week);
			$this->db->where('player_id',$pid);
			$q = $this->db->get("golf_players_handicap");
			if ($q->num_rows() > 0){

				$this->db->where('week',$week);
				$this->db->where('player_id',$pid);
				$this->db->update('golf_players_handicap', $hcu);

			}else{
				$this->db->insert('golf_players_handicap', $hcu);
			}

		}



	}
	function run_scoring(){
		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);
		$this->db->order_by('week','ASC');
		$this->db->group_by('week');

		$q = $this->db->get("golf_players_results");
		$q = $q->result();

		foreach($q as $w){
			$weeks[] = $w->week;
		}


		foreach($weeks as $week){

			$results = $matchups = array();

			$this->db->where('week',$week);
			$q = $this->db->get("golf_players_results");
			$q = $q->result();

			foreach($q as $r){
				$results[$r->player_id] = $r->scores;
			}


			if($week < 3){
				$hweek = 3;
			}else{
				$hweek = $week;
			}

			$this->db->where('week',$hweek);
			$q = $this->db->get("golf_players_handicap");
			$q = $q->result();
			foreach($q as $s){
				$hcaps[$s->player_id] = $s->hc;
			}



			$this->db->where('week',$week);
			$q = $this->db->get("golf_matchup");
			$tm = $q->result();


			$courseid = $tm[0]->course_id;
			$coursecaps = array();
			$this->db->where('cid',$courseid);
			$q = $this->db->get("golf_courses");
			$course = $q->row();


			$coursecaps = array(
				$course->hc1 => 1,
				$course->hc2 => 2,
				$course->hc3 => 3,
				$course->hc4 => 4,
				$course->hc5 => 5,
				$course->hc6 => 6,
				$course->hc7 => 7,
				$course->hc8 => 8,
				$course->hc9 => 9,
			);

			ksort($coursecaps);

			foreach($tm as $m){

				$this->db->where('team_id',$m->team_1);
				$q = $this->db->get("golf_players");
				$mem = $q->result();

				$h1 = $hcaps[$mem[0]->cid];
				$h2 = $hcaps[$mem[1]->cid];

				if($h2 < $h1){
					$matchups[$m->cid][1][1] = $mem[1]->cid;
					$matchups[$m->cid][2][1] = $mem[0]->cid;
				}else{
					$matchups[$m->cid][1][1] = $mem[0]->cid;
					$matchups[$m->cid][2][1] = $mem[1]->cid;
				}

				$this->db->where('team_id',$m->team_2);
				$q = $this->db->get("golf_players");
				$mem = $q->result();

				$h1 = $hcaps[$mem[0]->cid];
				$h2 = $hcaps[$mem[1]->cid];

				if($h2 < $h1){
					$matchups[$m->cid][1][2] = $mem[1]->cid;
					$matchups[$m->cid][2][2] = $mem[0]->cid;
				}else{
					$matchups[$m->cid][1][2] = $mem[0]->cid;
					$matchups[$m->cid][2][2] = $mem[1]->cid;
				}



			}

			foreach($matchups as $matchid=>$m){

				$t1score = $t2score = 0;
				// figure out matchup of 1 players
				// recalculate the real score based off handicap
				foreach($m as $group=>$match){
					$this->db->where('cid',$match['1']);
					$q = $this->db->get("golf_players");
					$q1 = $q->row();

					$this->db->where('cid',$match['2']);
					$q = $this->db->get("golf_players");
					$q2 = $q->row();


					$h1 = $h2 = 0;
					$results1 = $results2 = array();

					$results1 = json_decode($results[$match[1]]);
					$results2 = json_decode($results[$match[2]]);
					$h1 = $hcaps[$match[1]];
					$h2 = $hcaps[$match[2]];


					if($h1 > $h2){
						$h1 = $h1 - $h2;
						$h2 = 0;

					}
					if($h2 > $h1){
						$h2 = $h2 - $h1;
						$h1 = 0;

					}

					echo "<h3>".$q1->name." (".$h1.") vs ".$q2->name." (".$h2.") week ".$week."</h3> ";

					if($h1 > 9){
						foreach($results1 as $key=>$r){
							$results1[$key]--;
						}
						$h1 = $h1 - 9;
					}


					foreach($coursecaps as $hole){
						if($h1 == 0){
							continue;
						}

						$results1[$hole-1]--;

						$h1--;
					}

					if($h2 > 9){
						foreach($results2 as $key=>$r){
							$results2[$key]--;
						}
						$h2 = $h2 - 9;
					}


					foreach($coursecaps as $hole){
						if($h2 == 0){
							continue;
						}

						$results2[$hole-1]--;

						$h2--;
					}

					echo "<pre>";
					print_r($results1);
					echo "</pre>";
					echo "<pre>";
					print_r($results2);
					echo "</pre>";


					foreach($results1 as $hole=>$res){
						if($res > $results2[$hole]){
							echo "<h4>".$q2->name." Wins H".($hole+1)."</h4>";
							$t2score++;
						}elseif($res < $results2[$hole]){
							echo "<h4>".$q1->name." Wins H".($hole+1)."</h4>";
							$t1score++;
						}else{
							echo "<h4>Halves</h4>";
							$t1score = $t1score + .5;
							$t2score = $t2score + .5;
						}
					}

					if(array_sum($results1) > array_sum($results2)){
						echo "<h4>".$q2->name." Wins Totals</h4>";
						$t2score++;
					}elseif(array_sum($results1) < array_sum($results2)){
						echo "<h4>".$q1->name." Wins Totals</h4>";
						$t1score++;
					}else{
						echo "<h3>".$q1->name." & ".$q2->name." Split ".$week."</h3> ";
						$t1score = $t1score + .5;
						$t2score = $t2score + .5;
					}

					echo "<pre>";
					print_r($t1score);
					echo "</pre>";

					echo "<pre>";
					print_r($t2score);
					echo "</pre>";





				}

				$updatedata = array(
	               'team_1_points' => $t1score,
	               'team_2_points' => $t2score,
	            );

				$this->db->where('cid', $matchid);
				$this->db->update('golf_matchup', $updatedata);
				echo "<pre>";
				print_r($this->db->last_query());
				echo "</pre>";

			}






		}







	}


}
