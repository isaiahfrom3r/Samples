<?php
class Support_tickets extends CI_Model {

	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	public function get_by_id($ticket_id=''){
		if(!empty($ticket_id)){
			$this->db->where('id',$ticket_id);
			$this->db->limit(1);
			$ticket=$this->db->get('support_ticket');
			if($ticket->num_rows() > 0){
				return $ticket->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	public function get_note_by_id($note_id){
		if(!empty($note_id)){
			$this->db->where('id',$note_id);
			$this->db->limit(1);
			$message=$this->db->get('support_message');
			if($message->num_rows() > 0){
				return $message->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	public function get_list($user_id=0,$status=0,$page_num=0,$per_page=0,$order_by='id',$order_dir='asc'){
		if(!empty($user_id)){
			$this->db->where('assigned_user_id',$user_id);
		}
		if(!empty($status)){
			if(is_array($status)) $this->db->where_in('status',$status);
			else $this->db->where('status',$status);
		}else{
			$this->db->where('status !=',3);
		}
		if(!empty($order_by) && !empty($order_dir)){
			$this->db->order_by($order_by,$order_dir);
		}
		/*if(!empty($per_page) && (!empty($page_num) || $page_num==0)){
			$this->db->limit($per_page,$page_num);
		}*/
		$ticket=$this->db->get('support_ticket');
		if($ticket->num_rows()>0){
			return $ticket->result();
		}else{
			return false;
		}
	}

	public function get_messages_by_ticket($ticket_id=''){
		if(!empty($ticket_id)){
			$this->db->where('ticket_id',$ticket_id);
			$this->db->order_by('timestamp','desc');
			$messages=$this->db->get('support_message');
			if($messages->num_rows()>0){
				return $messages->result();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function add_new($data=''){
		if(!empty($data)){
			$data['timestamp']=time();
			$this->db->insert('support_ticket',$data);
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	public function update($ticket_id='',$data=''){
		if(!empty($ticket_id) && !empty($data)){
			$this->db->where('id',$ticket_id);
			$this->db->limit(1);
			$this->db->update('support_ticket',$data);
			return true;
		}else{
			return false;
		}
	}
	public function delete($ticket_id=''){
		if(!empty($ticket_id)){
			$this->db->where('id',$ticket_id);
			$this->db->limit(1);
			$this->db->delete('support_ticket');
			return true;
		}else{
			return false;
		}
	}
	public function add_note($ticket_id='',$user_id='',$message=''){

		if(!empty($ticket_id) && !empty($user_id) && !empty($message)){
			$insert=array(
				"ticket_id"=>$ticket_id,
				"user_id"=>$user_id,
				"message"=>$message,
				"timestamp"=>time()
			);
			$this->db->insert('support_message',$insert);
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	public function delete_note($note_id=''){
		if(!empty($note_id)){
			$this->db->where('id',$note_id);
			$this->db->limit(1);
			$this->db->delete('support_message');
			return true;
		}else{
			return false;
		}
	}
}
