<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 *
 * @extends CI_Controller
 */
class Funds extends CI_Controller {


	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {

		parent::__construct();

	}


	/*--------------------------------------------------------------------------
		ADD FUNDS
	--------------------------------------------------------------------------*/
	function add(){
		$data['funds'] =  $funds = $this->User_funds->user_balance($this->users->id());
		$this->users->is_loggedin(1);

		if(isset($_GET['error']) && $_GET['error'] == 1){
			$this->alert->set('We encountered an error processing your card. If the problem persists please contact our support staff.','error');
			redirect('funds/add');
		}

/*
		if(!isset($this->session->checkout_league)){
			$this->alert->set('Cart Empty','error');
			redirect('/home/player');
		}
*/

		$amount = $this->session->checkout_league['cost'];

 		$amount = .50;
		$relay_response_url = '/home';
		$api_login_id = $this->options->get('authnet_login_id');
		$transaction_key = $this->options->get('authnet_key');


		$this->load->library('AuthorizeNetResponse');
		$this->load->library('AuthorizeNetSIM');
		$this->load->library('AuthorizeNetDPM');
		$transaction = new AuthorizeNetDPM;
		$form = $transaction->getCreditCardForm($amount, time(), $relay_response_url, $api_login_id, $transaction_key, false, false,$this->users->id());

		$data['card_form'] =  $form;

		$this->users->is_loggedin(1);
		$this->load->model('payments');
		$this->load->model('packages');
		$this->load->model('misc');
		$data['body'] = '';


		$head['scripts'] = array(
			'/assets/js/jquery.payment.js',
			'/assets/js/add_funds.js',
		);
		$foot['scripts'] = array();




		$data['user'] = $this->users->get_user($this->users->id());
		$data['user_state']=$data['user']->state;
		$data['user_id'] = $this->users->id();
		$data['redirect']= base_url().'/league/do_join';

		$data['gambling_resricted_states'] = json_decode($this->options->get('gambling_resricted_states'),true);
		$data['gateway_data_raw'] = $this->payments->get_method_by_id(6);
		$data['gateway_data'] = json_decode($data['gateway_data_raw']->data);
		$data['product']=(object)array(
			'price' => $amount,
		);


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/funds/add',$data);
		$this->load->view(THEME.'/footer',$foot);

	}




	public function withdraw(){
		$this->users->is_loggedin(1);
		// send error to the view

		$data['funds'] =  $funds = $this->User_funds->user_balance($this->users->id());
		$user = $this->users->get_by_id($this->users->id());
		$data['recent_withdrawals'] = $this->user_funds->get_withdrawals(10, 0, array('user_id' => $this->users->id()));
		$this->form_validation->set_rules('amount', 'Amount', 'required|greater_than[0]');
		$this->form_validation->set_rules('method', 'Payment Method', 'required|greater_than[-1]');
		if ($this->form_validation->run() === FALSE)
		{
		}
		else
		{
			$item = array(
				'user_id' => $this->users->id(),
				'amount' => $_POST['amount'],
				'method' => $_POST['method'],
				'req_timestamp' => time(),
				'paypal_email' => $user->email,
			);

			$this->user_funds->create_withdrawal($item);

			$this->alert->set('Withdraw Req','error');
			redirect('funds/add');

		}

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/funds/withdraw',$data);
		$this->load->view(THEME.'/footer');

	}
	public function pending(){




		// send error to the view
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/funds/pending');
		$this->load->view(THEME.'/footer');

	}
	public function history($row_start=0){

		$this->users->is_loggedin(1);

		$data['user'] = $this->users->get($this->users->id());
		$data['funds'] =  $funds = $this->User_funds->user_balance($this->users->id());
		$config['per_page'] = 1000;
		if (!is_numeric($row_start)) $row_start = 0;
		//get recent withdrawals
		$data['transactions'] = $this->user_funds->get_transactions($config['per_page'], $row_start, array('user_id' => $this->users->id()), array('column' => 'source', 'vals' => array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10 , 100)));


		$this->load->library('pagination');

		$config['base_url'] = site_url('my_account/transactions/');
		$config['total_rows'] = $this->user_funds->get_transactions_total(array('user_id' => $this->users->id()), array('column' => 'source', 'vals' => array(1, 2, 3, 4, 5, 6, 7,8,9, 10)));

		$config['uri_segment'] = 3;

		$config['num_links'] =5;
		$config['full_tag_open'] = '<div class="pagination"><ul>';
		$config['full_tag_close'] = '</ul></div>';
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="prev">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="next">';
		$config['next_tag_close'] = '</li>';
		$config['last_link']=false;
		$config['first_link']=false;

		$this->pagination->initialize($config);



		// send error to the view
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/funds/log',$data);
		$this->load->view(THEME.'/footer');

	}

	public function run_auth(){
		echo "<pre>";
		print_r($_POST); echo "test"; die;
		echo "</pre>";
		if($_POST['x_response_code'] != 1){
			echo '<meta http-equiv="refresh" content="0; url='.base_url().'/funds/add?error=1" />';
		}else{
			$this->user_funds->add_payment($_POST['x_user_id'], $_POST['x_amount'], 'AUTH_'.time());
			echo '<meta http-equiv="refresh" content="0; url='.base_url().'/league/do_join" />';
		}

	}
	function thank_you_for_adding_funds(){
		$this->session->set_flashdata('success',"Thank you for adding funds");
		$url = parse_url($_SERVER['REQUEST_URI']);
		parse_str($url['query'], $params);
		$redirect = $params['ref'];
		if(!empty($redirect)) {
		redirect($redirect);
		} else {
		redirect('lobby');
		}
	}
	function check_processed($oid){
		$this->db->where('MerchantTransactionID',$oid);
		$q = $this->db->get("gabmleid_transactions");
		$q = $q->row();

		if($q->used == 1){
			echo 1;
		}else{
			echo 0;
		}
	}
	function sorry(){

		$this->alert->set('We encountered an error. If the problem persists please contact our support staff.','error');
		redirect('lobby');
	}
	function add_session(){



/*
		if(isset($_POST['tc'])){
			if($_POST['tc'] != 1){
				$this->session->set_flashdata('error','Please agree to terms and conditions!');
				redirect('my_account/add_funds');
			}
		}else{
				$this->session->set_flashdata('error','Please agree to terms and conditions!');
			redirect('my_account/add_funds');
		}
*/
/*
		if($create != ""){
			$data['welcome'] = "Welcome to AllInFantasy you have 24 hours to use a new member promo code.";
		}
*/
/*
		$this->load->model('payments');
		$this->load->model('packages');
		$data['theme'] = $this->config->item('theme');
		$data['title'] = vlang('my_account_add_funds_title');
		$data['body'] = '';
*/
/*
		$data['extra_js'] = '<script type="text/javascript" src="'.site_url('assets/common/js/jquery.payment.js?v='.$this->config->item('ftd_version')).'"></script>';
		$data['extra_js'] .= '<script type="text/javascript" src="'.site_url('assets/'.$data['theme'].'/js/add_funds.js?v='.$this->config->item('ftd_version')).'"></script>';

*/
		$data = array();
		if(isset($this->session->templeague)){
			$league = $this->Leagues->get_temp_league($this->session->templeague);
			$data['redirect'] = 1;
		}else{
			$data['redirect'] = 2;
		}
		$data['user'] = $user = $this->users->get_by_id($this->users->id());
		$data['user_state']= $state = $user->state;
		$data['user_address']= $address = $user->address;

// 		$data['redirect']=site_url('my_account/thank_you_for_adding_funds').'?ref='.$data['camefrom'];

// 		$data['gambling_resricted_states'] = json_decode($this->options->get('gambling_resricted_states'),true);


		// Define URL where the form resides
		$form_url = "https://api.gidx-service.in/v3.0/api/WebCashier/CreateSession";

		// This is the data to POST to the form. The KEY of the array is the name of the field. The value is the value posted.
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		    $ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
		    $ip = $_SERVER['REMOTE_ADDR'];
		}

		$data_to_post = array();
		$data_to_post['ApiKey'] = 'osrntbC2rUG6LGlcT1V7QA';
		$data_to_post['MerchantID'] = '8Y6XSU8Na0CqIHK9Z-mqPw';
		$data_to_post['MerchantSessionID'] = 'MSID_12344RY6x051231';
		$oid = time().$this->users->id();
		//Sandbox
		$url = 'https://api.gidx-service.in/v3.0/api/WebCashier/CreateSession';
		//Production
		//$url = 'https://api.gidx-service.com/v2.01/api/WebCashier/CreateSession';
//old 		'MerchantSessionID' => 'MSID_12344RY6x051231',
		$fields = array(
			'ApiKey' => 'osrntbC2rUG6LGlcT1V7QA',
			'MerchantID' => 'XERkXOs3AE26BiiubP-bag',
			'MerchantSessionID' => 'YRLZ'.$this->users->id().time(),
			'MerchantTransactionID' => $oid,
			'MerchantOrderID' => $oid,
			'MerchantCustomerID' => $this->users->id(),
			'CustomerIpAddress'  => $ip,
			'ProductTypeID'		 => 'HYz34CYLO0KiagZ8j11sow',
			'DeviceTypeID'		 => 'L9A12MQ9PUuuvP106gPw7w',
			'ActivityTypeID'	 => 'QH9nT9sM30irBCjwXTPSDg',
			'CallbackURL'		 => base_url().'deposit/add',
			'PayActionCode'		 =>	"PAY",
			'CashierPaymentAmount' => array(
				"PaymentAmount"	=> $_POST['amount'],
				"PaymentAmountOverride" => "true",
				"BonusAmount"	=> 0,
				"PaymentCurreencyCode" => "USD",
			),
			'CustomerRegistration' => array(
				"CustomerIpAddress"		 => $ip,
				"MerchantCustomerID"	 => $this->users->id(),
				"FirstName"				 => $user->first_name,
				"LastName"				 => $user->last_name,
				"FullName"				 => $user->first_name." ".$user->last_name,
				"EmailAddress"			 => $user->email,
				"PhoneNumber"			 => $user->phone,
				"AddressLine1"			 => $address,
				"StateCode"				 =>	$state,
				"CountryCode"			 =>	'USA',
				"ApiKey"				 =>	'osrntbC2rUG6LGlcT1V7QA',
				"MerchantSessionID"		 =>	'YRLZ'.$this->users->id().time(),

			),

		);


		if(!isset($_POST['custom'])){
			$_POST['custom'] = "";
		}

		$gam = array(
           'MerchantTransactionID' => $oid,
           'PaymentAmount' => $_POST['amount'],
           'user_id' => $this->users->id(),
           'item_number' => time(),
           'promo' => 0,
        );

		$this->db->insert('gabmleid_transactions', $gam);
		$data['sendalong'] =  $oid;


		$array = urldecode(http_build_query($fields));

		//open connection
		$ch = curl_init();

		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST, count($array));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $array);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);

		//execute post
		$result = curl_exec($ch);
		$result = json_decode($result);
/*
		echo "<pre>";
		print_r($result);
		echo "</pre>";echo "test"; die;
*/
		//close connection
		curl_close($ch);

		$data['script'] = urldecode($result->SessionURL);
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/funds/add_fundsnew', $data);
		$this->load->view(THEME.'/footer');
	}


}
