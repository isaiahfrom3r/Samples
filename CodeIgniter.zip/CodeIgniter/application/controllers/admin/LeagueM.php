<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class LeagueM extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
        $this->load->model('Leaguesm');
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){

        redirect('admin/leagueM/management');

	}


    public function management($offset= 0) {
        $head = $foot = $data = array();

        $season = $this->Events->get_season();
        $data['seasons'] = $archivedSeasons = $this->Leaguesm->get_archived_seasons();

		$this->load->library('pagination');

		// check if we're searching for a user

        if( !empty($_POST)) {
            $data['filters'] = $filters = $_POST;
        } else {
            $data['filters'] = $filters = array();
        }
        if($offset == 0){
          	$offset = 0;
	        // Set an offset from the query string
			if( !empty($_GET['page'])&&isset($_GET['page']) ){
				$offset = $_GET['page'];
			}else{
				$offset = 0;
			}
		}
		if( !empty($_GET['search'])&&isset($_GET['search']) ){

			$keyword = $_GET['search'];


			$leagues = $this->Leaguesm->get_leagues_by_keyword($season,$keyword, $filters);

            $config["full_tag_open"] = '<ul class="pagination">';
			$config["full_tag_close"] = '</ul>';
			$config["first_link"] = "&laquo;";
			$config["first_tag_open"] = "<li>";
			$config["first_tag_close"] = "</li>";
			$config["last_link"] = "&raquo;";
			$config["last_tag_open"] = "<li>";
			$config["last_tag_close"] = "</li>";
			$config['next_link'] = '&gt;';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '<li>';
			$config['prev_link'] = '&lt;';
			$config['prev_tag_open'] = '<li>';
			$config['prev_tag_close'] = '<li>';
			$config['cur_tag_open'] = '<li class="active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			// needs to be query string also to work properly with search
			$config['page_query_string']    = TRUE;
			$config['query_string_segment']= 'page';
			$config['base_url'] = base_url().'admin/leagueM/management?search='.$keyword;
			$config['total_rows'] = count($leagues);
			$config['per_page'] = 99;
			$this->pagination->initialize($config);
            $lids = $this->Leaguesm->get_leagues_by_keyword_pagi($season, $keyword, $filters);
			$data['leagues'] = $leagues = $this->Leaguesm->limit_leagues($lids,$offset,99);

		}else{
            $num=0;
			$leagues = $this->Leaguesm->get_leagues($season, $filters);
			$config["full_tag_open"] = '<ul class="pagination">';
			$config["full_tag_close"] = '</ul>';
			$config["first_link"] = "&laquo;";
			$config["first_tag_open"] = "<li>";
			$config["first_tag_close"] = "</li>";
			$config["last_link"] = "&raquo;";
			$config["last_tag_open"] = "<li>";
			$config["last_tag_close"] = "</li>";
			$config['next_link'] = '&gt;';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '<li>';
			$config['prev_link'] = '&lt;';
			$config['prev_tag_open'] = '<li>';
			$config['prev_tag_close'] = '<li>';
			$config['cur_tag_open'] = '<li class="active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			$config['page_query_string']    = TRUE;
			$config['query_string_segment']= 'page';
			$config['base_url'] = base_url().'admin/leagueM/management';
			$config['total_rows'] = count($leagues);
			$config['per_page'] = 99;
			$this->pagination->initialize($config);
			echo "<pre>";
			print_r($filters);
			echo "</pre>";
            $lids = $this->Leaguesm->get_leagues_pagi($season, $filters);
            $data['leagues'] = $leagues = $this->Leaguesm->limit_leagues($lids,$offset,99);


		}
        $head['scripts'] =  array('/assets/tablesorter/tablesorter.min.js');
        $head['styles'] = array('/assets/tablesorter/style.css');


        $this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/league/management',$data);
		$this->load->view(ADMIN_THEME.'/footer',$foot);
	}
	public function remove($tid){
			$this->db->where('id',$tid);
			$q = $this->db->get("league_team");
			$tm = $q->row();

			$this->db->where('cid',$tm->league_id);
			$q = $this->db->get("leagues");
			$lg = $q->row();


			$tmuser = $this->users->get_user($tm->user_id);

			$badteams[$tm->id] = array('lid'=> $lg->cid ,'uid'=> $tmuser->id, 'user' => $tmuser->first_name.' '.$tmuser->last_name,'league_name' => $lg->name,'team_name'=> $tm->name, 'email' =>$tmuser->email , 'entry_fee' => $lg->entry_fee);



		foreach($badteams as $bad){
			if($bad['entry_fee'] > 0){
				$this->user_funds->add_transaction($bad['uid'],7,1, $bad['entry_fee'], 'Refund for League name "'.$bad['league_name'].'" ID# '.$bad['lid'], $bad['lid']);

				$this->user_funds->update_balance($bad['uid'], $bad['entry_fee'],1);
			}


	        $subject = "YouRulz - Team Removed";
	        $this->emails->send_mail($bad['email'], 'team_removed', $bad,$subject);

	        $data = array(
               'user_id' => 0,
               'name' => '',
            );

	        $this->db->where('id', $tid);
	        $this->db->update('league_team', $data);


		}
	}
    public function test() {
        ini_set('display_errors', 1);
        error_reporting(E_ALL);
        //	PROFILER
        $this->output->enable_profiler(TRUE);

        $pid = "4b09ab09-1457-4c9d-a99d-6a03d8e76c76";
        $tid = "163";
        $week = "15";
        $season = "2017";

        $team = $this->Leagues->get_team_by_id($tid);
		$league = $this->Leagues->get_league_by_id($team->league_id);
		$lid = $team->league_id;

        $test = $this->Leaguesm->get_team_stat_breakdown($league,$tid,$week,$season);

        echo "<pre>";
        print_r($test);
        echo "</pre>";

	}
}
