<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Funds extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('users');
// 		$this->load->model('pages');
		$this->load->model('user_funds');
		$this->form_validation->set_error_delimiters('<p class="help-block">', '</p>');
		$this->users->is_admin(1);
	}

	function index()
	{
		redirect('admin_user_funds/promo_code');
	}

	function summary_log(){

		$data['active_menu'] = 'reporting';
		$data['title'] = 'Cash Summary';
		$data['body'] = '';

		$data['extra_js'] = "<script type='text/javascript' src='".site_url('assets/common/js/admin/user_funds.js')."'></script>";

		$reports = $this->user_funds->get_all_logs();

		foreach($reports as $r){
			$r->time = date('m/d/y g:ia',$r->timestamp);
			$authorizer = $this->users->get_by_id($r->authorizer_id);
			$user = $this->users->get_by_id($r->user_id);
			$r->authorizer = $authorizer->username;
			$r->user = $user->username;
		}

		$data['reports'] = json_encode($reports);
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/summary_log', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}
	function print_transaction($tid){

		$this->db->where('id',$tid);
		$q = $this->db->get("report_summary");
		$q = $q->row();

		$user = $this->users->get_by_id($q->user_id);
		if($q->debitcredit == 1){
			$dc = 'Added';
			$newb = $q->balance + $q->amount;
		}
		if($q->debitcredit == 0){
			$dc = 'Removed';
			$newb = $q->balance - $q->amount;
		}

		$data['q'] = $q;
		$data['user'] = $user;
		$data['newb'] = $newb;
		$data['html'] = $html;
		$data['dc'] = $dc;
		$this->load->view('admin/user_funds/print_me', $data);
		$this->load->view(ADMIN_THEME.'/footer');

	}
	function check_admin(){
	    $password = $_POST['password'];
	    $user = $_POST['username'];

	    $password_to_use = md5($password.$this->config->item('md5_salt'));


	    $this->db->where('password',$password_to_use);
	    $this->db->where('username',$user);
	    $q = $this->db->get("users");

	    if ($q->num_rows() > 0){
	    	$q = $q->row();

	    	if($q->level == 0){
		    	echo 1;
	    	}else{
		    	echo 2;
	    	}

	    }else{
		    echo 0;
	    }


    }
	function undo_transaction($tid){

		$this->db->where('id',$tid);
		$q = $this->db->get("report_summary");
		$q = $q->row();

		if($q->debitcredit == 1){
			$dc = 0;
		}
		if($q->debitcredit == 0){
			$dc = 1;
		}



		$data = array(
			'amount' => $q->amount,
			'debitcredit' => $dc,
			'type' => $q->type,
			'user_id' => $q->user_id,
			'message' => 'Reversing previous transaction',
		);

		$this->edit_user_funds($data);
	}
	function edit_user_funds($info){
		if(!empty($info) && is_array($info)){
			$_POST = $info;
			$user_id=$info['user_id'];
			$redirect = 1;

		}else{
			$redirect = 0;
			$user_id=$this->uri->segment(3);
		}

		$data['active_menu'] = 'users';
		$data['title'] = 'Edit User Funds';
		$data['body'] = '';

		$data['extra_js'] = "<script type='text/javascript' src='".site_url('assets/common/js/admin/user_funds.js')."'></script>";


		$data['user']=$this->users->get_by_id($user_id);
		if(!$data['user']){
			$this->session->set_flashdata('error','User Not Found');
			redirect('admin_user/list_all');
		}
		$data['balance']=$this->user_funds->user_balance($user_id);

		$this->form_validation->set_rules('debitcredit', 'Action', 'trim|xss_clean');
		$this->form_validation->set_rules('type', 'Type', 'trim|required|xss_clean');
		$this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean|numeric|greater_than[0]');
		$this->form_validation->set_rules('message', 'Amount', 'trim|xss_clean');
		if ($this->form_validation->run() == FALSE){
		}else{

			$ticket_value = 0;
			$amount = 0;
			$bonus_amount = 0;
			$tourney_amount = 0;
			$ticket_amount = 0;
			$ticket_type = 0;

			switch($this->input->post('type')) {

				case 0:
				$amount = $this->input->post('amount');
				//$this->user_funds->update_balance($user_id, $this->input->post('amount'), $this->input->post('debitcredit'),0);
				break;
				case 1:
				$bonus_amount = $this->input->post('amount');
				//$this->user_funds->update_balance($user_id, 0, $this->input->post('debitcredit'), $this->input->post('amount'));
				break;
				case 2:
					$ticket_amount = $this->input->post('amount');
					$ticket_type = $this->input->post('ticket_type');
					for($i=0;$i<$this->input->post('amount');$i++) {
						//add or remove a ticket
						if($this->input->post('debitcredit') == 1) {
							$ticket_type = $this->input->post('ticket_type');
							$insert = array(
									'user_id'=>$user_id,
									'ticket_type'=>$ticket_type,
									'ticket_value'=>0,
									'issued'=>time()
								);
							$this->db->insert('user_tickets',$insert);

						} else {
							//find oldest ticket and redeem it, also find out what it's worth
							$this->db->where('user_id',$user_id);
							$this->db->where('redeemed',0);
							$this->db->where('ticket_type',$this->input->post('ticket_type'));
							$this->db->order_by('issued','asc');
							$this->db->limit(1);

							$ticket = $this->db->get('user_tickets')->row();

							$ticket_value = $ticket_value + $ticket->ticket_value;

							$this->db->where('id',$ticket->id);
							$this->db->update('user_tickets',array('redeemed'=>1,'redeemed_time'=>time()));
						}
					}
				break;
				case 3:
					$tourney_amount = $this->input->post('amount');
				break;

			}
			$message=$this->input->post('message');

			/*
			*  Added name of level 2 admin to the comment
			*
			*  Sean Cleveland
			*
			*  9/5/17
			*/
			$commentName = $this->users->admin_name_trans_comment();

			if($this->input->post('type')==2) {
				$comment=($this->input->post('debitcredit')==1)?"Tickets added to account by ".$commentName:"Tickets removed from account by ".$commentName;
			} else {
				$comment=($this->input->post('debitcredit')==1)?"Funds added to account by ".$commentName:"Funds removed from account by ".$commentName;
			}
			if(!empty($message)) $comment=$comment.": ".$message;
			$money=($this->input->post('type')==0)?$this->input->post('amount'):0;
			$points=($this->input->post('type')==1)?$this->input->post('amount'):0;
			$tourney=($this->input->post('type')==3)?$this->input->post('amount'):0;
			$tickets=($this->input->post('type')==2)?$this->input->post('amount'):0;
			$tickets>0?$ticket_type=$this->input->post('ticket_type'):$ticket_type=0;

			if($_POST['paid'] == 1){
				$this->user_funds->insert_payment($user_id,$this->input->post('debitcredit'),$amount);
			}

			$authorizer = $this->session->userdata('cid');
			$log = array(
				'type'=>$this->input->post('type'),
				'amount'=>$money,
				'bonus_amount'=>$bonus_amount,
				'debitcredit'=>$this->input->post('debitcredit'),
				'authorizer_id'=>$authorizer,
				'user_id'=>$user_id,
				'timestamp'=>time(),
				'balance' => $data['balance']['balance'],
				'bonus_bal' => $data['balance']['bonus_balance'],
			);

			$username = $this->users->get_by_id($user_id);

			$emaildata = array(
				'amount'=>$money,
				'username'=>$username->username,
				'time'=>time(),
				'type'=>$this->input->post('debitcredit'),
			);
			$user=$this->users->get_by_id($user_id);
			$this->users->send_basic_email($user->email,'Balance Updated','add_funds',$emaildata);

			if($_POST['paid'] == 1){
			$this->user_funds->add_transaction($user_id, 8, $this->input->post('debitcredit'), $money, $comment, 0, $points,0,0,$tickets,$ticket_type,$ticket_value, $tourney);
			}

			$this->user_funds->update_balance($user_id, $amount, $this->input->post('debitcredit'), $bonus_amount, $ticket_amount, $ticket_type, $tourney_amount);

			$thetid = $this->user_funds->add_report_log($log);
			if($this->input->post('type')==2) {
			$this->session->set_flashdata('success','User\'s Tickets Updated');
			} else {
			$this->session->set_flashdata('success','User\'s Funds Updated');
			}
			if($_POST['print'] == 1){
				redirect('admin_user_funds/print_transaction/'.$thetid);
			}

			if($redirect == 1){
				redirect('admin_user_funds/summary_log');
			}else{
				redirect('admin_user_funds/edit_user_funds/'.$user_id);
			}
		}
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/edit_user', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function promo_code(){

		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Promo Codes';
		$data['body'] = '';
		//$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/profile_fields.js').'"></script>';

		//load pagination
		$this->load->library('pagination');
		$config['per_page'] = $this->options->get('admin_pagination_per_page');

		$curr_pagenum = $this->uri->segment(3);
		if ($curr_pagenum == '') $curr_pagenum=0;
		$pages_arr = $this->user_funds->get_promo_codes($config['per_page'], $curr_pagenum);

		$data['results'] = $pages_arr;

		//config pagination settings
		$config['base_url'] = site_url('admin_user_funds/promo_code');
		$config['total_rows'] = $this->user_funds->get_promo_codes_total();

		$config['uri_segment'] = '3';
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';

		$this->pagination->initialize($config);
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/promos', $data);
		$this->load->view(ADMIN_THEME.'/footer');

	}

	function edit_spot($ad_spot_id){

		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Create a new ad placement';
		$data['body'] = '';

		$data['spot'] = $this->ads->get_ad_spot_by_id($ad_spot_id);

		$this->form_validation->set_rules('name', 'Placement Name', 'required|xss_clean|max_length[128]');
		$this->form_validation->set_rules('max_banners', 'Max Total Banners', 'required|numeric|xss_clean|max_length[2]');
		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			$ad_spot = array(
							'name' => $this->input->post('name'),
							'max_banners' => $this->input->post('max_banners')
							);
			$this->ads->update_ad_spot($ad_spot_id, $ad_spot);
			$this->session->set_flashdata('success', 'Changes saved.');
			redirect('admin_ads/edit_spot/'.$ad_spot_id);
		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/edit_spot', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function promocode_check($code)
	{
		if (!$this->user_funds->duplicate_promocode_check($code))
		{
			$this->form_validation->set_message('promocode_check', 'Promocode '.$code.' already exists.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

	function promocode_edit_check($code,$current)
	{
		if($current!=$code && !$this->user_funds->duplicate_promocode_check($code)){
			$this->form_validation->set_message('promocode_edit_check', 'Promocode '.$code.' already exists.');
			return FALSE;
		}if($current==$code){
			return TRUE;
		}else{
			return TRUE;
		}
	}

	function create_promo()
	{

		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Create a new promo';
		$data['body'] = '';

		$this->form_validation->set_rules('name', 'Promo Name', 'required|xss_clean|max_length[36]');
		$this->form_validation->set_rules('code', 'Promo Code', 'required|xss_clean|max_length[36]|callback_promocode_check');
		$this->form_validation->set_rules('money', 'Money', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('cash', 'Cash', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('affiliate', 'Affiliate', 'xss_clean|max_length[25]');
		$this->form_validation->set_rules('percentage', 'Percent', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('cash_percentage', 'Cash Percent', 'xss_clean|max_length[12]');
		if ($this->user_funds->get_option('points_on')) $this->form_validation->set_rules('points', 'Points', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('begins', 'Start Date', 'xss_clean|max_length[10]|callback_date_formcheck');
		$this->form_validation->set_rules('expires', 'End Date', 'xss_clean|max_length[10]|callback_date_formcheck');
		$this->form_validation->set_rules('max_per_user', 'Max Uses Per User', 'xss_clean|max_length[10]');
		$this->form_validation->set_rules('requires_min_payment', 'Requires Min Payment of', 'xss_clean|trim|max_length[12]');
		$this->form_validation->set_rules('description','xss_clean');

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{

			$begins_inp = $this->input->post('begins');
			$expires_inp = $this->input->post('expires');
			$begins = 0;
			$expires = 0;
			if (strlen(trim($begins_inp)) > 0) $begins = date('U', strtotime($begins_inp));
			if (strlen(trim($expires_inp)) > 0) $expires = date('U', strtotime($expires_inp));
			$money = $this->input->post('money');
			if (strlen(trim($money)) > 0)
			{
				$money = number_format($money, 2, '.', '');
			}
			else
			{
				$money = '0';
			}
			$cash = $this->input->post('cash');
			if (strlen(trim($cash)) > 0)
			{
				$cash = number_format($cash, 2, '.', '');
			}
			else
			{
				$cash = '0';
			}
			$percentage = $this->input->post('percentage');
			if(strlen(trim($percentage)) > 0)
			{
				if($percentage > 1) $percentage = $percentage/100;
			}
			else
			{
				$percentage = '0';
			}
			$cash_percentage = $this->input->post('cash_percentage');
			if(strlen(trim($cash_percentage)) > 0)
			{
				if($cash_percentage > 1) $cash_percentage = $cash_percentage/100;
			}
			else
			{
				$cash_percentage = '0';
			}
			$requires_min_payment = $this->input->post('requires_min_payment');
			if(strlen(trim($requires_min_payment)) > 0)
			{
				$requires_min_payment = number_format($requires_min_payment, 2, '.', '');
			}
			else
			{
				$requires_min_payment = '0';
			}
			$referral = $this->input->post('referral');
			$affiliate = $this->input->post('affiliate');

			$description = $this->input->post('description');

			if(empty($referral)) {
				$referral = '0';
			} elseif($referral == 1) {
				//clear all other referral bonuses -- there can be only one
				$this->db->where('referral','1');
				$this->db->where('status','1');
				$this->db->update('promo_codes',array('status' => '0'));
			}
			$promo = array(
							'name' => $this->input->post('name'),
							'code' => $this->input->post('code'),
							'money' => $money,
							'cash' => $cash,
							'percentage' => $percentage,
							'cash_percentage' => $cash_percentage,
							/*'points' => $this->input->post('points'),*/
							'begins' => $begins,
							'max_per_user' => $this->input->post('max_per_user'),
							'requires_min_payment' => $requires_min_payment,
							'expires' => $expires,
							'timestamp' => time(),
							'referral' => $referral,
							'affiliate' => $affiliate,
							'status' => 1,
							'description' => $description
							);
			if ($this->user_funds->get_option('points_on')) $promo['points'] = $this->input->post('points');
			$promo_id = $this->user_funds->create_promo_code($promo);
			$this->session->set_flashdata('success', 'New Promo Created.');
			redirect('admin_user_funds/edit_promo/'.$promo_id);
		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/create_promo', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function edit_promo($promo_id){

		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Edit Promo';
		$data['body'] = '';

		$data['promo'] = $this->user_funds->get_promo_code_by_id($promo_id);

		$this->form_validation->set_rules('name', 'Promo Name', 'required|xss_clean|max_length[36]');
		$this->form_validation->set_rules('code', 'Promo Code', 'required|xss_clean|max_length[36]|callback_promocode_edit_check['.$data['promo']->code.']');
		$this->form_validation->set_rules('money', 'Money', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('cash', 'Cash', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('affiliate', 'Affiliate', 'xss_clean|max_length[25]');
		$this->form_validation->set_rules('percentage', 'Percentage', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('cash_percentage', 'Cash Percentage', 'xss_clean|max_length[12]');
		if ($this->user_funds->get_option('points_on')) $this->form_validation->set_rules('points', 'Points', 'xss_clean|max_length[12]');
		$this->form_validation->set_rules('begins', 'Start Date', 'xss_clean|max_length[10]|callback_date_formcheck');
		$this->form_validation->set_rules('expires', 'End Date', 'xss_clean|max_length[10]|callback_date_formcheck');
		$this->form_validation->set_rules('max_per_user', 'Max Uses Per User', 'xss_clean|max_length[10]');
		$this->form_validation->set_rules('requires_min_payment', 'Requires Min Payment of', 'xss_clean|trim|max_length[12]');
		$this->form_validation->set_rules('description','xss_clean');

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{

			$begins_inp = $this->input->post('begins');
			$expires_inp = $this->input->post('expires');
			$begins = 0;
			$expires = 0;
			if (strlen(trim($begins_inp)) > 0) $begins = date('U', strtotime($begins_inp));
			if (strlen(trim($expires_inp)) > 0) $expires = date('U', strtotime($expires_inp));
			$money = $this->input->post('money');
			if (strlen(trim($money)) > 0)
			{
				$money = number_format($money, 2, '.', '');
			}
			else
			{
				$money = '';
			}
			$cash = $this->input->post('cash');
			if (strlen(trim($cash)) > 0)
			{
				$cash = number_format($cash, 2, '.', '');
			}
			else
			{
				$cash = '';
			}
			$percentage = $this->input->post('percentage');
			if(strlen(trim($percentage)) > 0)
			{
				if($percentage > 1) $percentage = $percentage/100;
			}
			else
			{
				$percentage = '';
			}
			$cash_percentage = $this->input->post('cash_percentage');
			if(strlen(trim($cash_percentage)) > 0)
			{
				if($cash_percentage > 1) $cash_percentage = $cash_percentage/100;
			}
			else
			{
				$cash_percentage = '';
			}
			$requires_min_payment = $this->input->post('requires_min_payment');
			if(strlen(trim($requires_min_payment)) > 0)
			{
				$requires_min_payment = number_format($requires_min_payment, 2, '.', '');
			}
			else
			{
				$requires_min_payment = '0';
			}
			$referral = $this->input->post('referral');
			$affiliate = $this->input->post('affiliate');

			$description = $this->input->post('description');

			if(empty($referral)) {
				$referral = '0';
			} elseif($referral == 1 && $this->input->post('status') == 1) {
				//deactivate all other referral bonuses -- there can be only one
				$this->db->where('referral','1');
				$this->db->where('status','1');
				$this->db->update('promo_codes',array('status' => '0'));
			}
			$promo = array(
							'name' => $this->input->post('name'),
							'code' => $this->input->post('code'),
							'money' => $money,
							'cash' => $cash,
							'percentage' => $percentage,
							'cash_percentage' => $cash_percentage,
							'begins' => $begins,
							'expires' => $expires,
							'max_per_user' => $this->input->post('max_per_user'),
							'requires_min_payment' => $requires_min_payment,
							'timestamp' => time(),
							'referral' => $referral,
							'affiliate' => $affiliate,
							'status' => $this->input->post('status'),
							'description' => $description
							);
			if ($this->user_funds->get_option('points_on')) $promo['points'] = $this->input->post('points');
			$this->user_funds->update_promo_code($promo_id, $promo);
			$this->session->set_flashdata('success', 'Promo Updated.');
			//redirect('admin_user_funds/edit_promo/'.$promo_id);
			redirect('admin_user_funds/promo_code');
		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/edit_promo', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function delete_promo_code($promo_id)
	{
		$this->user_funds->delete_promo_code($promo_id);
		$this->session->set_flashdata('success', 'Promo Code Deleted.');
		redirect('admin_user_funds/promo_code');
	}

	function user_transactions($uid)
	{
		$data['user'] =  $user=   $this->users->get_by_id($uid);
		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Transactions';
		$data['body'] = '';
		//$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/profile_fields.js').'"></script>';

		//load pagination
		$this->load->library('pagination');

		$data['page_num']=$curr_pagenum = $this->uri->segment(7);
		if ($curr_pagenum == '') $data['page_num']=$curr_pagenum=0;

		$data['order_by']=$this->uri->segment(5);
		if($data['order_by']=='')$data['order_by']='timestamp';

		$data['order_dir']=$this->uri->segment(6);
		if($data['order_dir']=='')$data['order_dir']='DESC';

		$pages_arr = $this->user_funds->get_transactions(100000000000, $curr_pagenum, null,null,$data['order_by'],$data['order_dir']);

		$data['results'] = $pages_arr;



		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/transactions_user', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}
	function transaction()
	{

		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Transactions';
		$data['body'] = '';
		//$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/profile_fields.js').'"></script>';

		//load pagination
		$this->load->library('pagination');
		$config['per_page'] = 200;

		$data['page_num']=$curr_pagenum = $this->uri->segment(6);
		if ($curr_pagenum == '') $data['page_num']=$curr_pagenum=0;

		$data['order_by']=$this->uri->segment(4);
		if($data['order_by']=='')$data['order_by']='timestamp';

		$data['order_dir']=$this->uri->segment(5);
		if($data['order_dir']=='')$data['order_dir']='DESC';

		$pages_arr = $this->user_funds->get_transactions($config['per_page'], $curr_pagenum, null,null,$data['order_by'],$data['order_dir']);

		$data['results'] = $pages_arr;

		//config pagination settings
		$config['base_url'] = site_url('admin/funds/transaction/'.$data['order_by']."/".$data['order_dir']);
		$config['total_rows'] = $this->user_funds->get_transactions_total();

		$config['uri_segment'] = '6';
		$config["full_tag_open"] = '<ul class="pagination">';
		$config["full_tag_close"] = '</ul>';
		$config["first_link"] = "&laquo;";
		$config["first_tag_open"] = "<li>";
		$config["first_tag_close"] = "</li>";
		$config["last_link"] = "&raquo;";
		$config["last_tag_open"] = "<li>";
		$config["last_tag_close"] = "</li>";
		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '<li>';
		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '<li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';		$config['last_link']=false;
		$config['first_link']=false;

		$this->pagination->initialize($config);

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/transactions', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function withdrawals()
	{

		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Withdrawals';
		$data['body'] = '';
		//$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/profile_fields.js').'"></script>';

		//load pagination
		$this->load->library('pagination');
		$config['per_page'] = $this->options->get('admin_pagination_per_page');

		$curr_pagenum = $this->uri->segment(3);
		if ($curr_pagenum == '') $curr_pagenum=0;
		$search=$this->input->post('search');
		if(!isset($search) || empty($search)){
			$search=null;
		}else{
			$this->db->like('username',$search);
			$this->db->or_like('first_name',$search);
			$this->db->or_like('last_name',$search);
			$sr=$this->db->get('users');
			if($sr->num_rows()>0){
				$user_ids=array();
				foreach($sr->result() as $s) $user_ids[]=$s->id;
				$search=array("user_id"=>$user_ids);
			}
		}

		$data['s_status']=array(0,1,2,3);
		$filter=$this->input->post('status');
		if(isset($filter) && !empty($filter)){
			$data['s_status']=$filter;
			$search['status']=$filter;
		}
		//echo "<pre>".print_r($search,true)."</pre>";
		$pages_arr = $this->user_funds->get_withdrawals($config['per_page'], $curr_pagenum, $search);

		$data['results'] = $pages_arr;

		//config pagination settings
		$config['base_url'] = site_url('admin_user_funds/withdrawals');
		$config['total_rows'] = $this->user_funds->get_withdrawals_total();

		$config['uri_segment'] = '3';
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';

		$this->pagination->initialize($config);
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/withdrawals', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function mark_withdrawal_paid($cid = 0)
	{
		$request = $current_request = $this->user_funds->get_withdrawal_by_id($cid);
		echo "<pre>";
		print_r($request);
		echo "</pre>";
		if ($request !== FALSE)
		{
			//Add the withdrawal to the payment log
			$insert=array(
				'user_id'=>$current_request->user_id,
				'trans_id'=>'',
				'amount'=>$current_request->amount,
				'type'=>0,
				'status'=>1,
				'approval_code'=>'',
				'product_id'=>'',
				'time'=>time(),
				'method_id'=>$current_request->method,
				'raw_return_data'=>json_encode($current_request)
			);

			$this->db->insert('payments',$insert);
			//Mark the withdrawal as paid in the withdrawal table
			$this->db->where('cid', $cid)->limit(1)->update('withdrawals', array('status' => '3', 'paid_timestamp' => time(), 'staff_notes' => date('m/d/Y h:i:s a')." ".$this->session->userdata('username')." marked this request as \"Paid\" \n\n".$request->staff_notes));
			$note_insert=array(
				'user_id'=>$current_request->user_id,
				'withdrawal_id'=>$cid,
				'timestamp' => time(),
				'note' => $this->session->userdata('username')." marked this request as \"Paid\""
			);
			$this->db->insert('withdrawal_notes', $note_insert);
			//record in user balances tbl
			$this->user_funds->add_transaction($current_request->user_id, 3, 0, $current_request->amount, 'Withdrawal of $'.$current_request->amount.' by '.($current_request->method == 0?'paypal '.$current_request->paypal_email:'check'), $current_request->cid);
			$this->user_funds->update_balance($current_request->user_id, $current_request->amount, 0);

			$curr_user = $this->users->get_by_id($current_request->user_id);
			$email_data = array('user' => $curr_user, 'request' => $request);



			$this->users->send_email($current_request->user_id,'withdrawal_fulfilled',$email_data);

			$this->session->set_flashdata('success', 'Withdrawal Marked as Paid.');
			redirect('admin_user_funds/withdrawals');
		}
		else
		{
			$this->session->set_flashdata('error', 'Withdrawal Request Not Found');
			redirect('admin_user_funds/withdrawals');
		}
	}

	function edit_withdrawal($request_id)
	{

		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'Edit Promo';
		$data['body'] = '';

		$data['request'] = $current_request = $this->user_funds->get_withdrawal_by_id($request_id);
		$data['requester'] = $this->users->get_by_id($current_request->user_id);
		//$data['staff_notes'] = null,//$this->user_funds->get_notes_by_user($current_request->user_id);

		$this->form_validation->set_rules('status', 'Request Status', 'required|xss_clean');


		if ($this->form_validation->run() == FALSE){
		}else{
			$request = array(
							'status' => $this->input->post('status')
							);

			$status = $this->input->post('status');
			$staff_note = $this->input->post('note');
			$new_note = '';
			//anything changed?
			if (strlen($staff_note) > 0 || $current_request->status != $status)
			{
				$new_note = $this->session->userdata('username');
				//changed status
				if ($current_request->status != $status){
					$new_note .= " marked this request as \"";
					if ($status == 0){
						$new_note .= "New";
					}
					elseif ($status == 1){
						$new_note .= "Pending Info";
					}
					elseif ($status == 2){
						$new_note .= "Declined";
					}
					elseif ($status == 3){
						$new_note .= "Paid";
					}
					$new_note .= "\"";
				}
				if (strlen($staff_note) > 0 && $current_request->status != $status){
					$new_note .= " and";
				}
				if (strlen($staff_note) > 0){
					$new_note .= " left a note:\n";
					$new_note .= $staff_note;
				}

				//$request['staff_notes'] = $new_note.$current_request->staff_notes;

				//paid_timestamp
				$request['paid_timestamp'] = '';
				$request['amount'] = $current_request->amount;
				$request['method'] = $current_request->method;
				if ($current_request->status != $status && $status == 3){
					//Add the withdrawal to the payment log
					$insert=array(
						'user_id'=>$current_request->user_id,
						'trans_id'=>'',
						'amount'=>$current_request->amount,
						'type'=>0,
						'status'=>1,
						'approval_code'=>'',
						'product_id'=>'',
						'time'=>time(),
						'method_id'=>$current_request->method,
						'raw_return_data'=>json_encode($current_request)
					);
					$this->db->insert('payments',$insert);

					$curr_user = $this->users->get_by_id($current_request->user_id);
					$email_data = array('user' => $curr_user, 'request' => $current_request);
					$this->users->send_email($current_request->user_id,'withdrawal_fulfilled',$email_data);

					$request['paid_timestamp'] = time();
					//record in user balances tbl
					$this->user_funds->add_transaction($current_request->user_id, 3, 0, $current_request->amount, 'Withdrawal of $'.$current_request->amount.' by '.($current_request->method == 0?'paypal '.$current_request->paypal_email:'check'), $current_request->cid);
					$this->user_funds->update_balance($current_request->user_id, $current_request->amount, 0);
				}
				//reversal of withrawal funds (when already marked 'Paid' withrawal goes back to New, Pending or Declined)
				if ($current_request->status != $status && $current_request->status == 3 && $status != 3){
					//record in user balances tbl
					$this->user_funds->add_transaction($current_request->user_id, 3, 1, $current_request->amount, 'Reversal of withdrawal of $'.$current_request->amount.' by '.($current_request->method == 0?'paypal '.$current_request->paypal_email:'check'), $current_request->cid);
					$this->user_funds->update_balance($current_request->user_id, $current_request->amount, 1);
				}
				$this->user_funds->update_withdrawal($request_id, $request);
				$note_insert=array(
					"timestamp"=>time(),
					"withdrawal_id"=>$request_id,
					"user_id"=>$current_request->user_id,
					"note"=>$new_note
				);
				$this->db->insert("withdrawal_notes",$note_insert);
			}

			$this->session->set_flashdata('success', 'Request Updated.');
			//redirect('admin_user_funds/edit_withdrawal/'.$request_id);
			redirect('admin_user_funds/withdrawals/');
		}
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/edit_withdrawal', $data);
		$this->load->view(ADMIN_THEME.'/footer');

	}

	/*function update_notes(){
		$all=$this->db->get('withdrawals')->result();
		foreach($all as $a){
			$notes=explode("\n\n",$a->staff_notes);
			foreach($notes as $n){
				if(!empty($n)){
					$t=explode(" ",$n);
					$timestamp=strtotime($t[0]." ".$t[1].$t[2]);
					unset($t[0]);
					unset($t[1]);
					unset($t[2]);
					$insert=array(
						"user_id"=>$a->user_id,
						"withdrawal_id"=>$a->cid,
						"note"=>implode(" ",$t),
						"timestamp"=>$timestamp
					);
					$this->db->insert("withdrawal_notes",$insert);
					echo "<pre>".print_R($insert,true)."</pre>";
				}
			}
		}
	}*/

	function ytd_earning($year=0){
		$data['year'] =  $year;
		$data['active_menu'] = 'admin_user_funds';
		$data['title'] = 'YTD Earnings';
		$data['body'] = '';

		if($year == 0){
			$year = date('Y');
		}
		$off = 0;
// 		$off=$this->uri->segment(4);
		if(empty($year)) $year=$data['year']=date('Y');
		$year_begin=$data['year_begin']=mktime(0,0,0,1,1,$year);
		$year_end=$data['year_end']=mktime(0,0,0,12,31,$year);

		$this->db->select('user_id,SUM(amount) as total');
		$this->db->where('paid_timestamp >=',$year_begin);
		$this->db->where('paid_timestamp <=',$year_end);
		$this->db->where('status',3);
		$this->db->group_by('user_id');
		$this->db->order_by('total','DESC');
		$withdrawals=$this->db->get('withdrawals');

		$data['transactions']=$data['withdrawals']=array();



		foreach($withdrawals->result() as $w) {
			if(isset($w->user_id)) {
				$data['withdrawals'][$w->user_id] = $w;
			}
		}


		$this->db->select("user_id, SUM(amount) as amount");
		$this->db->where('source',1);
		$this->db->where('timestamp >=',$year_begin);
		$this->db->where('timestamp <=',$year_end);
		$this->db->group_by('user_id');
		$transactions=$this->db->get('user_balance_transactions');

		foreach($transactions->result() as $t){
			if(isset($t->user_id)) {
				$data['transactions'][$t->user_id]=$t;
			}
		}

		//$data['withdrawals']=$withdrawals->result();
 		if($off == "" || $off == 0){
			$off = 0;
		}
		$step = $off- 20;

		$totalc = count($data['withdrawals']);
		$data['withdrawals'] = array_slice($data['withdrawals'],$step+20,$off+20);

		$this->load->library('pagination');
		$config['uri_segment'] = 4;
		$config['base_url'] = base_url().'admin_user_funds/ytd_earning/'.date('Y');
		$config['total_rows'] = $totalc;
		$config['per_page'] = 20;
		$this->pagination->initialize($config);

		$data['pages'] = $this->pagination->create_links();

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/user_funds/ytd_earnings', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	//BOF callback functions
	function date_formcheck( $fecha = '' )
	{
		if (strlen(trim($fecha)) == 0) return TRUE;
		// VALID FORMAT = mm/dd/yyyy
		if (preg_match ("/([0-9]{2})\/([0-9]{2})\/([0-9]{4})/", $fecha, $fecha_array))
		{
			// VALID DATE IN CALENDAR
			if ( checkdate($fecha_array[1],$fecha_array[2],$fecha_array[3]) )
			{
				return TRUE;
			}
			else
			{
				$this->form_validation->set_message('date_formcheck', 'Doesn\'t look like a valid date');
				return FALSE;
			}
		}
		$this->form_validation->set_message('date_formcheck', 'Please enter date in following format: mm/dd/yyyy');
		return FALSE;
	}

	function uploadmain_formcheck() {
	$img_name='image';
	//Upload Config settings
		$config['upload_path'] = './uploads/temp';
		$config['allowed_types'] = 'png|jpg|gif';
		$config['max_size'] = '2500';
		$config['max_width'] = '2600';
		$config['max_height'] = '2600';
		//Load imgs upload library
		$this->load->library('upload');

		//Upload file and return data
		$this->upload->initialize($config);
		if ($this->upload->do_upload($img_name)) {
		$img_data=$this->upload->data();
		$new_imgname=md5(rand(0, 1000000).$img_name).$img_data['file_ext'];
		$new_imgpath=$img_data['file_path'].$new_imgname;
		rename($img_data['full_path'], $new_imgpath);
		//set new image name to pass via session
		$this->session->set_userdata('temp_banner_image', $new_imgname);
		return true;
		} else {
		$this->form_validation->set_message('uploadmain_formcheck', $this->upload->display_errors());
		return false;
		}
	}

	function balance_to_trans(){
		$this->output->enable_profiler(TRUE);
		//$user_id=$this->uri->segment(3);
		$this->db->select('cid');
		$users=$this->db->get('users');
		foreach($users->result() as $u){
			$user_id=$u->cid;
			$this->db->where('user_id',$user_id);
			$dbtrans=$this->db->get('user_balance_transactions');
			if($dbtrans->num_rows()>0){
				$tr=$dbtrans->result();
				$balance=$bonus=0;
				$transactions=array();
				foreach($tr as $t){
					if($t->debit==1){
						$balance=round($balance+round($t->amount,2),2);
						$bonus=round($bonus+round($t->bonus_amount,2),2);
					}else{
						$balance=round($balance-round($t->amount,2),2);
						$bonus=round($bonus-round($t->bonus_amount,2),2);
					}
					$transactions[$t->cid]=array(
						"cid"=>$t->cid,
						"new_balance"=>$balance,
						"new_bonus_balance"=>$bonus
					);
				}

				$real_base_balance=$this->user_funds->user_balance($user_id);
				$real_balance=(float)$real_base_balance['balance'];
				$real_bonus=(float)$real_base_balance['bonus_balance'];
				//echo "<div>MATHED: ".$balance." - REAL: ".$real_balance['balance']."</div>";
				//echo "<div>MATHED: ".$bonus." - REAL: ".$real_balance['bonus_balance']."</div>";
				//echo "<pre>".print_R($transactions,true)."</pre>";
				if((string)$balance==(string)$real_balance){
					$this->db->update_batch('user_balance_transactions',$transactions,'cid');
					//echo "<div style='color:green'>Success: ".$u->cid."</div>";
				}else{
					echo "<div style='color:red'>Failed: ".$u->cid."</div>";
				}
			}
		}
	}

	function balance_to_trans_single(){
		$this->output->enable_profiler(TRUE);
		$user_id=$this->uri->segment(3);
		$this->db->where('user_id',$user_id);
		$this->db->order_by('timestamp','asc');
		$dbtrans=$this->db->get('user_balance_transactions');
		if($dbtrans->num_rows()>0){
			$tr=$dbtrans->result();
			$balance=$bonus=0;
			$transactions=array();
			foreach($tr as $t){
				if($t->debit==1){
					$balance=round($balance+round($t->amount,2),2);
					$bonus=round($bonus+round($t->bonus_amount,2),2);
				}else{
					$balance=round($balance-round($t->amount,2),2);
					$bonus=round($bonus-round($t->bonus_amount,2),2);
				}
				$transactions[$t->cid]=array(
					"cid"=>$t->cid,
					"amount"=>round($t->amount,2),
					"bonus_amount"=>round($t->bonus_amount,2),
					"new_balance"=>$balance,
					"new_bonus_balance"=>$bonus,
				);
			}

			$real_base_balance=$this->user_funds->user_balance($user_id);
			$real_balance=(float)$real_base_balance['balance'];
			$real_bonus=(float)$real_base_balance['bonus_balance'];
			echo "<div>MATHED: ".(float)$balance." - REAL: ".(float)$real_balance."</div>";
			echo "<div>MATHED: ".(float)$bonus." - REAL: ".(float)$real_bonus."</div>";
			echo "<pre>".print_R($transactions,true)."</pre>";
			var_dump($balance);echo "==";var_dump($real_balance);
			if((string)$balance==(string)$real_balance){
				//$this->db->update_batch('user_balance_transactions',$transactions,'cid');
				echo "<div style='color:green'>Success: ".$user_id."</div>";
			}else{
				echo "<div style='color:red'>Failed: ".$user_id."</div>";
			}
		}
	}
}

/* End of file admin_cms.php */
/* Location: ./application/controllers/admin_cms.php */
