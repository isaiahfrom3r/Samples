<div class="card">
    <div class="card-header">
        <h2>Special Content
            <small>Below you will be able to edit special website variables. These are used to edit content on pages that do not have a corresponding CMS page. Some sections contain general website settings or variables such as default email. Creating new variables or content does not mean the website will automatically update, these setting are created by the developer to give the administrative staff ability to make quick adjustments. </small>
        </h2>
    </div>

    <div class="card-body table-responsive">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
				<th>Actions</th>
            </tr>
            </thead>
            <tbody>

	        <?php
		    foreach($groups as $group){ ?>
		    	<tr>
	                <td><?=$group->id?></td>
	                <td><?=$group->name?></td>
	                <td><?=$group->description?></td>
	                <td>
		                <a class="btn btn-success" href="<?=base_url()?>/admin/settings/edit/<?=$group->id?>">Edit</a>
	                </td>
	            </tr>
		    <?php } ?>

                       </tbody>
        </table>
    </div>
</div>
