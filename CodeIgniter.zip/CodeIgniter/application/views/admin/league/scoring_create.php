

<section class="content card">
	<div class="container">

<h4>Choose Your Scoring Settings</h4>




		<hr>

<!-- 		Left out form element, I figured it's better for you to decide where/how to go about this ultimately. -JS -->

	<form action="" class="form-inline" method="post" accept-charset="utf-8">

		<div class="form-group half">
			<label>Name</label>
			<input type="text" step="width:100%;" class="form-control" name="name" value="">
		</div>
		<div class="form-group half">
		</div>
		<div class="clearfix"></div>
		<h4>Passing</h4>

		<div class="form-group fourth">
			<label>Passing TD</label>
			<input type="number" step=".01"  class="form-control" name="scoring[passing_td]" value="4">
		</div>

		<div class="form-group fourth">
			<label>Passing 25yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[passing_25]" value="1">
		</div>

		<div class="form-group fourth">
			<label>Passing INT</label>
			<input type="number" step=".01" class="form-control" name="scoring[passing_int]" value="-1">
		</div>
		<div class="form-group fourth">
			<label>2PT Conversion</label>
			<input type="number" step=".01" class="form-control" name="scoring[2pt]" value="2">
		</div>

		<hr>

		<h4>Rushing</h4>

		<div class="form-group fourth">
			<label>Rushing 10yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[rushing_10]" value="1">
		</div>

		<div class="form-group fourth">
			<label>Rushing TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[rushing_td]" value="6">
		</div>
		<div class="form-group fourth">
			<label>2PT Conversion</label>
			<input type="number" step=".01" class="form-control" name="scoring[rushing_2pt]" value="2">
		</div>

		<hr>

		<h4>Receiving</h4>

		<div class="form-group fourth">
			<label>Receiving 10yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_10]" value="1">
		</div>

		<div class="form-group fourth">
			<label>Reception</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_rec]" value="1">
		</div>

		<div class="form-group fourth">
			<label>Receiving TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>2PT Conversion</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_2pt]" value="2">
		</div>

		<div class="form-group fourth">
			<label>Fumble Lost</label>
			<input type="number" step=".01" class="form-control" name="scoring[fumble_lost]" value="-2">
		</div>

		<div class="form-group fourth">
			<label>Returned TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[return_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>Offensive Fum Returned TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[off_fumble_recovery_td]" value="6">
		</div>

		<hr>

		<h4>Kicking</h4>

		<div class="form-group fourth">
			<label>FG .019yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[fg19]" value="3">
		</div>

		<div class="form-group fourth">
			<label>FG 20-29yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[fg29]" value="3">
		</div>

		<div class="form-group fourth">
			<label>FG 30-39yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[fg39]" value="3">
		</div>

		<div class="form-group fourth">
			<label>FG 40-49yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[fg49]" value="4">
		</div>

		<div class="form-group fourth">
			<label>FG 50+yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[fg50]" value="5">
		</div>

		<div class="form-group fourth">
			<label>Extra Point</label>
			<input type="number" step=".01" class="form-control" name="scoring[fg_xp]" value="1">
		</div>

		<hr>

		<h4>DEF Teams / Special Teams</h4>

		<div class="form-group fourth">
			<label>DEF Sack</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][sack]" value="1">
		</div>

		<div class="form-group fourth">
			<label>DEF INT</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][int]" value="2">
		</div>

		<div class="form-group fourth">
			<label>DEF Rum-Rec</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][fumble]" value="2">
		</div>

		<div class="form-group fourth">
			<label>DEF TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>DEF Safety</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][saftey]" value="2">
		</div>

		<div class="form-group fourth">
			<label>DEF Blocked Kick</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][block]" value="2">
		</div>

		<div class="form-group fourth">
			<label>D/ST Punt Return TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][punt_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>D/ST Kickoff Return TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][kickoff_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>D/ST Punt Return 10yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][punt_return_10]" value="1">
		</div>

		<div class="form-group fourth">
			<label>D/ST Kickoff Return 10yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][kickoff_return_10]" value="1">
		</div>

		<div class="form-group fourth">
			<label>DEF 0pts allowed</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][points_0]" value="10">
		</div>

		<div class="form-group fourth">
			<label>DEF 1-6pts allowed</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][points_6]" value="7">
		</div>

		<div class="form-group fourth">
			<label>DEF 7-13pts allowed</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][points_13]" value="4">
		</div>

		<div class="form-group fourth">
			<label>DEF 14-20pts allowed</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][points_20]" value="1">
		</div>

		<div class="form-group fourth">
			<label>DEF 21-27pts allowed</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][points_27]" value="-1">
		</div>

		<div class="form-group fourth">
			<label>DEF 28-34pts allowed</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][points_34]" value="-4">
		</div>

		<div class="form-group fourth">
			<label>DEF 2PT Conversion (Stop &amp; Return for TD)</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][2pt_stop]" value="2">
		</div>

		<hr>

		<h4>DEF Players</h4>

		<div class="form-group fourth">
			<label>DEF Tackle</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_tackle]" value="1">
		</div>

		<div class="form-group fourth">
			<label>DEF Sack</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_sack]" value="0.2">
		</div>

		<div class="form-group fourth">
			<label>DEF INT</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_int]" value="2">
		</div>

		<div class="form-group fourth">
			<label>DEF Fum-Rec</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_fumble]" value="2">
		</div>

		<div class="form-group fourth">
			<label>DEF TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>DEF Safety</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_saftey]" value="2">
		</div>

		<div class="form-group fourth">
			<label>DEF Blocked Kick</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_blocked]" value="2">
		</div>

		<div class="form-group fourth">
			<label>D/ST Punt Return TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_punt_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>D/ST Kickoff Return TD</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_kick_td]" value="6">
		</div>

		<div class="form-group fourth">
			<label>D/ST Punt Return 10yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_punt_10]" value="1">
		</div>

		<div class="form-group fourth">
			<label>D/ST Kickoff Return 10yds</label>
			<input type="number" step=".01" class="form-control" name="scoring[def_kick_10]" value="1">
		</div>

		<div class="form-group fourth">
			<label>DEF 2PT Conversion (Stop &amp; Return for TD)</label>
			<input type="number" step=".01" class="form-control" name="scoring[def][2pt_stop]" value="2">
		</div>

		<hr>

		<h4>Passing Bonus</h4>

		<div class="form-group fourth">
			<label>Passing YDS 300+</label>
			<input type="number" step=".01" class="form-control" name="scoring[passing_300]" value="2">
		</div>

		<div class="form-group fourth">
			<label>Passing YDS 400+</label>
			<input type="number" step=".01" class="form-control" name="scoring[passing_400]" value="5">
		</div>

		<div class="form-group fourth">
			<label>Passing YDS 500+</label>
			<input type="number" step=".01" class="form-control" name="scoring[passing_500]" value="6">
		</div>

		<hr>

		<h4>Rushing Bonus</h4>

		<div class="form-group fourth">
			<label>Rushing YDS 100+</label>
			<input type="number" step=".01" class="form-control" name="scoring[rushing_100]" value="2">
		</div>

		<div class="form-group fourth">
			<label>Rushing YDS 150+</label>
			<input type="number" step=".01" class="form-control" name="scoring[rushing_150]" value="3">
		</div>

		<div class="form-group fourth">
			<label>Rushing YDS 200+</label>
			<input type="number" step=".01" class="form-control" name="scoring[rushing_200]" value="4">
		</div>

		<hr>

		<h4>Receiving Bonus</h4>

		<div class="form-group fourth">
			<label>Receiving YDS 100+</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_100]" value="2">
		</div>

		<div class="form-group fourth">
			<label>Receiving YDS 150+</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_150]" value="3">
		</div>

		<div class="form-group fourth">
			<label>Receiving YDS 200+</label>
			<input type="number" step=".01" class="form-control" name="scoring[receiving_200]" value="4">
		</div>



		<div style="clear:both;"></div> <br>

		<hr>

		<div class="text-center">
			<button type="submit" class="btn btn-success" >Submit</button>
		</div>

		<div class="clearfix"></div><br><br>
	</form>

	</div>
</section>
