<div class="row-fluid card" >
	<div class="card-header">

		<h3>Advertisement Placements</h3>
		<small>
		Simply creating an Ad placement will not make it show on the front end. Any new placements will have to be added by your development staff. These locations can be used to designate where ads will appear on the front end.
		</small>
		<a href="<?php echo base_url(); ?>admin/Advertisement/create_spot" class="btn btn-info pull-right">Create Placement</a>
	</div>
<!--END Information block -->

	<div class="portlet box green">

		<div class="portlet-body">
			<div id="pager">
				<?php echo $this->pagination->create_links(); ?>
			</div>
			<div class="table-responsive">
				<table class="table table-bordered table-striped tablesorter" data-options='{"sortList":[[0,0]],"headers":{"2":{"sorter":false}}}'>
					<thead>
						<tr>
							<th>Placement Name</th>
							<th width="60px">Max Banners</th>
							<th width="60px">Action</th>
							<th width="60px"></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($results as $spot): ?>
						<tr>
							<td><a href="<?=site_url('admin/Advertisement/edit_spot/'.$spot->cid);?>"><?=$spot->name;?></a></td>
							<td align="center"><?=$spot->max_banners;?></td>
							<td>
									<a class="btn btn-ifno" href="<?=site_url('admin/Advertisement/edit_spot/'.$spot->cid);?>" title="Edit page"><i class="zmdi zmdi-edit" ></i></a>


							</td>
							<td>
								<a class="btn btn-danger" href="javascript: if (confirm('Are you sure you want to delete this ad placement and all banners in it?')) { window.location='<?=site_url('admin/Advertisement/delete_spot/'.$spot->cid);?>' };" title="Delete page"><i class="zmdi zmdi-delete"></i></a>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div id="pager">
					<?php echo $this->pagination->create_links(); ?>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
