<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class Desk extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
        $this->load->model('Desks');
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){
		redirect('admin/desk/list');
	}



	public function list(){

		$data['pages']=$this->Desks->get_desks();

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view('admin/desks/list',$data);
		$this->load->view(ADMIN_THEME.'/footer');

	}


	public function form($id=''){

		if(isset($_POST['id'])){

			$data = array(
               'name' => $_POST['name'],
               'slug' => $_POST['slug']
            );

            if($_POST['id'] != "new"){
	            $this->db->where('id', $_POST['id']);
	            $this->db->update('desks', $data);
            }else{

	            $this->db->insert('desks', $data);

            }



            $this->alert->set('Your desk has been created.','success');


			redirect('admin/desk');





		}else{


			if($id==""){
				$data['id'] =  'new';
				$data['desk'] =  array();
			}else{
				$data['id']=$id;
				$data['desk']=$desk=$this->Desks->get($id);
			}


		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/desks/form',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}


	public function delete($id=""){

		if($id != ""){
			$this->db->where('id', $id);
			$this->db->delete('desks');
		}

		$this->alert->set('Service Desk Delete','success');
		redirect('admin/desk');
	}




}
