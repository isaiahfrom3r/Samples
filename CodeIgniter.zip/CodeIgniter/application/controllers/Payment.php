<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->model('Articles');
		$this->load->model('Leagues');
		$this->load->model('Players');
		$this->load->model('Events');
	}


	public function do_one_time(){
		$data['league'] = $league = $this->Leagues->get_temp_league($this->session->templeague);



		if($_POST['x_response_code'] == 1){
			$info = array(
				'is_paid' => 1,
			);
			$this->Leagues->update_temp($info,$league->cid);
			$this->alert->set('Payment Succeded','success');
			redirect('/league/create2');
		}else{

			$this->alert->set('Payment Failed','error');
			redirect('/league/create1');

		}

	}


}
