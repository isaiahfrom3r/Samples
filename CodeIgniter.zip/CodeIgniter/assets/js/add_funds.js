jQuery(document).ready(function($){
	$(document.body).on('click','.apply_promo',function(){
		$("#addfunderror").fadeOut('fast');
		$('#promocode').removeClass('error');
		$('#promocode').removeClass('success');
		var promo=$('#promocode input').val();
		//reset all of the custom fields
		var custom_fields = $('.promo_code');
		for(var i = 0;i < custom_fields.length;i++){
			var datadefault=$(custom_fields[i]).attr('data-default');
			$(custom_fields[i]).val(datadefault);
		}
		//do the ajax
		console.log(HOST_NAME+"my_account/check_promo_code");
		$.ajax({
			url:HOST_NAME+"my_account/check_promo_code",
			data:"promo="+promo,
			type:'POST'
		}).done(function(html){
			obj=$.parseJSON(html);
			console.log(obj);
			if(obj.status=="tiptop"){
				$('#promocode').addClass('success');
				var custom_fields = $('.promo_code');
				if(obj.payment_required == 'Y') {
					for(var i = 0;i < custom_fields.length;i++){
						var datadefault=$(custom_fields[i]).attr('data-default');
						$(custom_fields[i]).val(datadefault+'|'+obj.promo);
					}
				}
				$('#promocode_field').val(obj.promo);
				$("#addfundsuccess span").text(obj.message);
				$("#addfundsuccess").fadeIn('slow');
				$("#addfunderror").fadeOut('fast');
			}else{
				$('#promocode').addClass('error');
				$("#addfunderror span").text(obj.message);
				$("#addfunderror").fadeIn('slow');
				$("#addfundsuccess").fadeOut('fast');
			}
		});
	});

	var cards=$('.cards div'),
	supported_cards=new Array();
	for(var i=0;i<cards.length;i++){
		supported_cards.push($(cards[i]).attr('class'));
	}
	$('input.cc_num').payment('formatCardNumber');
	$('input.cc_exp').payment('formatCardExpiry');
	$('input.cc_cvc').payment('formatCardCVC');

	$(document.body).on('click','.payment_toggle',function(e){
		e.preventDefault();
		var amt=$(this).attr('data-amount'),
		item_id=$(this).attr('data-item-id'),
		modal_id=$(this).attr('href');
		$('#depositamount').text('$'+amt);
		$('#depositamount_field').val(amt);
		$('#item_id_field').val(item_id);
		$(modal_id).modal('show');
	});

	$(document.body).on('keyup','#custom_amount',function(){
		var val=parseFloat($(this).val(),10);
		if(val=="NaN") val=1;
		$('#custom_payment_btn').attr('data-amount',val);
	});

	$(document.body).on('click','#custom_payment_btn',function(e){
		var val=parseFloat($('#custom_amount').val(),10);
		if(isNaN(val)) {
			e.preventDefault();
			alert('You have entered an invalid amount');
		} else if(val < 5.5) {
			e.preventDefault();
			alert('Minimum custom deposit is $5.50');
		}
	});

	$(document.body).on('keyup','#cc_number',function(){
		var cc_num=$('#cc_number').val();
		if(cc_num !=""){
			var type=$.payment.cardType(cc_num);
			console.log(type);
			for(var i=0;i<cards.length;i++){
				if(!$(cards[i]).hasClass(type)){
					$(cards[i]).addClass('off');
				}else{
					if($(cards[i]).hasClass('off')) $(cards[i]).removeClass('off')
				}
			}
			//console.log('CC type: '+result.card_type.name+'\nLength validation: '+ result.length_valid+'\nLuhn validation: + result.luhn_valid');
		}else{
			$('.cards div').removeClass('off');;
		}
	});

	$(document.body).on('submit','#payment_form',function(){
		$('#payment_form .control-group').removeClass('error');
		$('#payment_form .help-inline').remove();
		var fields=$('#payment_form input'),
		errors=0;
		for(var i=0;i<fields.length;i++){
			var field=$(fields[i]);
			if(field.attr('type')!="hidden"){
				if(field.val()==""){
					field.closest('.control-group').addClass('error');
					field.after('<span class="help-inline">Required</span>');
					errors++;
				}else if(field.hasClass('cc_num') && !$.payment.validateCardNumber(field.val())){
					field.closest('.control-group').addClass('error');
					field.after('<span class="help-inline">Invalid Card Number</span>');
					errors++;
				}else if(field.hasClass('cc_num') && $.inArray($.payment.cardType(field.val()),supported_cards)==-1){
					field.closest('.control-group').addClass('error');
					field.after('<span class="help-inline">Invalid Card Type</span>');
					errors++;
				}else if(field.hasClass('cc_cvc') && !$.payment.validateCardCVC(field.val())){
					field.closest('.control-group').addClass('error');
					field.after('<span class="help-inline">Invalid Security Code</span>');
					errors++;
				}else if(field.hasClass('cc_exp') && !$.payment.validateCardExpiry(field.payment('cardExpiryVal'))){
					field.closest('.control-group').addClass('error');
					field.after('<span class="help-inline">Invalid Expiration</span>');
					errors++;
				}
			}
		}
		if(errors>0){
			return false;
		}
	});
});
