
	</div>
		<?php
			if(isset($scripts) && !empty($scripts)){
				$this->load->view(ADMIN_THEME.'/assets/eqscripts.php',array('items'=>$scripts));
			}
		?>
		<?php
			if(isset($styles) && !empty($styles)){
				$this->load->view(ADMIN_THEME.'/assets/eqstyles.php',array('items'=>$styles));
			}
		?>

</html>
