<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Twitter extends CI_Controller {
	/* show link to connect to Twiiter */
	public function index() {
		$this->load->library('twconnect');
		redirect(base_url() . 'twitter/redirect');
		exit;

		// use this as debug.
		echo '<p><a href="' . base_url() . 'twitter/redirect">Connect to Twitter</a></p>';
		echo '<p><a href="' . base_url() . 'twitter/clearsession">Clear session</a></p>';
		echo 'Session data:<br/><pre>';
		print_r($this->session->all_userdata());
		echo '</pre>';
	}
	/* redirect to Twitter for authentication */
	public function redirect() {
		$this->load->library('twconnect');
		/* twredirect() parameter - callback point in your application */
		/* by default the path from config file will be used */
		$ok = $this->twconnect->twredirect('twitter/callback');
		if (!$ok) {
			echo 'Could not connect to Twitter. Refresh the page or try again later.';
		}
	}
	/* return point from Twitter */
	/* you have to call $this->twconnect->twprocess_callback() here! */
	public function callback() {
		$this->load->library('twconnect');
		$ok = $this->twconnect->twprocess_callback();

		if ( $ok ) { redirect('twitter/success'); }
			else redirect ('twitter/failure');
	}
	/* authentication successful */
	/* it should be a different function from callback */
	/* twconnect library should be re-loaded */
	/* but you can just call this function, not necessarily redirect to it */
	public function success() {
		$this->load->model('users');
		//echo 'Twitter connect succeded<br/>';
		//echo '<p><a href="' . base_url() . 'twitter/clearsession">Do it again!</a></p>';
		$this->load->library('twconnect');
		// saves Twitter user information to $this->twconnect->tw_user_info
		// twaccount_verify_credentials returns the same information
		$this->twconnect->twaccount_verify_credentials();

		$user = $this->twconnect->tw_user_info;



		$user->uid = $user->id;
		$user = json_decode(json_encode($user), true);
		$user['provider'] = 'twitter';
		$this->session->social = $user;

		$link_user=$this->users->get_by_protocal_id($user['uid'],'twitter_id');
		//$email_user=$this->users->get_by_email($user['email']);

		if($this->users->is_loggedin()){
			$user_id=$this->users->id();
			if($link_user===false || $link_user->id == $user_id){
				//update their account with new facebook info

				$update=array(
					'twitter_id'=>$user['uid']
				);

				$this->db->where('id',$user_id);
				$this->db->update('users',$update);

				$this->users->update_usermeta($user_id,$provider_data['usermeta_key'],json_encode($user));
				$this->alert->set('Account Linked','success');

				redirect('account');
			}else{
				$this->alert->set('Unknown Error','error');
				redirect('register');
			}
		}else{

			//check if the id is in use for an account
			if($link_user===false){
				if($email_user!==false){
					$this->db->where('id',$email_user->id);

					$this->db->update('users',array($provider_data['user_table_column']=>$user['uid']));
					$this->users->update_usermeta($email_user->id,$provider_data['usermeta_key'],json_encode($user));

					$this->users->forcelogin($email_user->id);
					$this->alert->set($this->options->get('start_welcome'),'success');
					redirect('/home/player');
				}else{
					//send them to registration
					$this->session->set_userdata('link_protocal','twitter');


					unset($user['status']);
					unset($user['entities']);

					$this->session->set_userdata('link_data',$user);
					$this->alert->set('Account Linked please complete registration','success');
					redirect('register');
				}
			}else{
				//Log them in
				$this->alert->set($this->options->get('start_welcome'),'success');
				$this->users->forcelogin($link_user->id);
				redirect('/home/player');
			}



		}




	}
	/* authentication un-successful */
	public function failure() {
		echo '<p>Twitter connect failed</p>';
		echo '<p><a href="' . base_url() . 'twitter/clearsession">Try again!</a></p>';
	}
	/* clear session */
	public function clearsession() {
		$this->session->sess_destroy();
		redirect('/twitter');
	}
}
