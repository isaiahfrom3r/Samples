<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Advertisement extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('users');
		$this->load->model('ads');
		$this->form_validation->set_error_delimiters('<p class="help-block">', '</p>');

	}

	function index()
	{
		redirect('admin/Advertisement/spots');
	}

	function spots()
	{

		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Ad Spots';
		$data['body'] = '';
		//$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/profile_fields.js').'"></script>';

		//load pagination
		$this->load->library('pagination');
		$config['per_page'] = $this->options->get('admin_pagination_per_page');

		$curr_pagenum = $this->uri->segment(3);
		if ($curr_pagenum == '') $curr_pagenum=0;
		$pages_arr = $this->ads->get_ad_spots($config['per_page'], $curr_pagenum);

		$data['results'] = $pages_arr;

		//config pagination settings
		$config['base_url'] = site_url('admin/Advertisement/spots');
		$config['total_rows'] = $this->ads->get_ad_spots_total();

		$config['uri_segment'] = '3';
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';

		$this->pagination->initialize($config);

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/spots', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function edit_spot($ad_spot_id)
	{

		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Create a new ad placement';
		$data['body'] = '';

		$data['spot'] = $this->ads->get_ad_spot_by_id($ad_spot_id);

		$this->form_validation->set_rules('name', 'Placement Name', 'required|max_length[128]');
		$this->form_validation->set_rules('max_banners', 'Max Total Banners', 'required|numeric');
		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			$ad_spot = array(
							'name' => $this->input->post('name'),
							'max_banners' => $this->input->post('max_banners')
							);
			$this->ads->update_ad_spot($ad_spot_id, $ad_spot);
			$this->alert->set('Changes Saved','success');
			redirect('admin/Advertisement/spots');
		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/edit_spot', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function create_spot()
	{

		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Create a new ad placement';
		$data['body'] = '';



		$this->form_validation->set_rules('name', 'Placement Name', 'required|max_length[128]');
		$this->form_validation->set_rules('max_banners', 'Max Total Banners', 'required|numeric|max_length[2]');
		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			$ad_spot = array(
							'name' => $this->input->post('name'),
							'max_banners' => $this->input->post('max_banners')
							);
			$ad_spot_id = $this->ads->create_ad_spot($ad_spot);
			$this->alert->set('New Ad Placement Created','success');
			redirect('admin/Advertisement/edit_spot/'.$ad_spot_id);
		}


		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/create_spot', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function delete_spot($spot_id)
	{
		$this->ads->delete_ad_spot($spot_id);
		$this->alert->set('Ad Placement Deleted','success');
		redirect('admin/Advertisement/spots');
	}

	function create_banner()
	{


		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Create a new ad banner';
		$data['body'] = '';
		$data['extra_js'] = '<script type="text/javascript" src="'.site_url('assets/admin/js/date_picker.js').'"></script>';

		$data['spots'] = $this->ads->get_ad_spots(10000);


		$this->form_validation->set_rules('name', 'Placement Name', 'required|max_length[128]');
// 		$this->form_validation->set_rules('spot_id', 'Banner Placement', 'required|numeric|max_length[3]');
// 		$this->form_validation->set_rules('type', 'Banner Type', 'required|numeric|max_length[1]');
		if ($this->input->post('type') == '0')
		{
			$this->form_validation->set_rules('code', 'Placement Name', 'required');
		}
		else
		{
			$this->form_validation->set_rules('image', 'Banner Image', 'callback_uploadmain_formcheck');
// 			$this->form_validation->set_rules('url', 'Url', 'required');

		}
		$this->form_validation->set_rules('max_impressions', 'Max Impressions Booked', 'xss_clean');
		$this->form_validation->set_rules('max_clicks', 'Max Clicks Booked', 'xss_clean');

		if ($this->input->post('type') == '0')
		{
			$data['type'] = '0';
		}
		elseif ($this->input->post('type') == '1')
		{
			$data['type'] = '1';
		}

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			$ad_banner = array(
							'name' => $this->input->post('name'),
							'spot_id' => $this->input->post('spot_id'),
							'type' => $this->input->post('type'),
							'max_impressions' => $this->input->post('max_impressions'),
							'max_clicks' => $this->input->post('max_clicks'),
							'status' => $this->input->post('status'),
							'timestamp' => time()
							);

			if ($this->input->post('start_date') != '')
			{
				$ad_banner['start_date'] = strtotime($this->input->post('start_date'));
			}
			if ($this->input->post('end_date') != '')
			{
				$ad_banner['end_date'] = strtotime($this->input->post('end_date'));
			}

			if ($data['type'] == '0')
			{
				$code = $this->input->post('code');
				$ad_banner['code'] = str_replace("\r\n", "", $code);
			}
			else
			{
				$ad_banner['url'] = $this->input->post('url');
				$image = $this->session->userdata('temp_banner_image');
				copy(FCPATH.'uploads/temp/'.$image, FCPATH.'uploads/fun/'.$image);
				unlink(FCPATH.'uploads/temp/'.$image);
				$ad_banner['image'] = $image;
				$this->session->unset_userdata('temp_banner_image');
			}
			$ad_banner_id = $this->ads->create_ad_banner($ad_banner);
			$this->alert->set('New Ad Banner Created','success');
			redirect('admin/Advertisement/ads');
		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/create_banner', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function edit_banner($banner_id)
	{

		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Edit ad banner';
		$data['body'] = '';
		$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/date_picker.js').'"></script>';

		$data['spots'] = $this->ads->get_ad_spots(10000);
		$data['banner'] = $this->ads->get_ad_banner_by_id($banner_id);

		$this->form_validation->set_rules('name', 'Placement Name', 'required|max_length[128]');
		$this->form_validation->set_rules('spot_id', 'Banner Placement', 'required|numeric|max_length[3]');
		$this->form_validation->set_rules('type', 'Banner Type', 'required|numeric|max_length[1]');
		if ($this->input->post('type') == '0')
		{
			$this->form_validation->set_rules('code', 'Placement Name', 'required');
		}
		else
		{
			if(!empty($_FILES) && $_FILES['image']['size'] != 0){
				$this->form_validation->set_rules('image', 'Banner Image', 'callback_uploadmain_formcheck');
			}
// 			$this->form_validation->set_rules('url', 'Url', 'required');

		}
		$this->form_validation->set_rules('max_impressions', 'Max Impressions Booked', 'xss_clean');
		$this->form_validation->set_rules('max_clicks', 'Max Clicks Booked', 'xss_clean');

		if ($this->input->post('type') === '0')
		{
			$data['type'] = '0';
		}
		elseif ($this->input->post('type') === '1')
		{
			$data['type'] = '1';
		}
		else
		{
			$data['type'] = $data['banner']->type;
		}

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			$ad_banner = array(
							'name' => $this->input->post('name'),
							'spot_id' => $this->input->post('spot_id'),
							'type' => $this->input->post('type'),
							'max_impressions' => $this->input->post('max_impressions'),
							'max_clicks' => $this->input->post('max_clicks'),
							'status' => $this->input->post('status')
							);



			if ($this->input->post('start_date') != '')
			{
				$ad_banner['start_date'] = strtotime($this->input->post('start_date'));
			}
			if ($this->input->post('end_date') != '')
			{
				$ad_banner['end_date'] = strtotime($this->input->post('end_date'));
			}

			if ($data['type'] == '0')
			{
				$code = $this->input->post('code');
				$ad_banner['code'] = str_replace("\r\n", "", $code);
			}
			else
			{

				$ad_banner['url'] = $this->input->post('url');
				$image = $this->session->userdata('temp_banner_image');
				if (!empty($image))
				{
					copy(FCPATH.'uploads/temp/'.$image, FCPATH.'uploads/fun/'.$image);
					unlink(FCPATH.'uploads/temp/'.$image); //delete temp image
					unlink(FCPATH.'uploads/fun/'.$data['banner']->image);		//delete old image
					$ad_banner['image'] = $image;
					$this->session->unset_userdata('temp_banner_image');
				}
			}

			$this->ads->update_ad_banner($banner_id, $ad_banner);

			$this->alert->set('Banner Changes Saved','success');
			redirect('admin/Advertisement/ads');
		}


		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/edit_banner', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function ads()
	{

		$data['active_menu'] = 'ads_manager';
		$data['title'] = 'Banner Ads';
		$data['body'] = '';
		//$data['extra_js'] = '<script type="text/javascript" src="'.site_url('js/admin/profile_fields.js').'"></script>';

		//load pagination
		$this->load->library('pagination');
		$config['per_page'] = $this->options->get('admin_pagination_per_page');

		$curr_pagenum = $this->uri->segment(3);
		if ($curr_pagenum == '') $curr_pagenum=0;
		$pages_arr = $this->ads->get_ad_banners($config['per_page'], $curr_pagenum);

		$data['results'] = $pages_arr;

		//config pagination settings
		$config['base_url'] = site_url('admin/Advertisement/ads');
		$config['total_rows'] = $this->ads->get_ad_banners_total();

		$config['uri_segment'] = '3';
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';

		$this->pagination->initialize($config);
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/ads/ads', $data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	function delete_banner($ad_id)
	{
		$this->ads->delete_ad_banner($ad_id);
		$this->alert->set('Ad Banner Deleted','success');
		redirect('admin/Advertisement/ads');
	}



	function uploadmain_formcheck() {
	$img_name='image';
	//Upload Config settings
		$config['upload_path'] = './uploads/temp';
		$config['allowed_types'] = 'png|jpg|gif';
/*
		$config['max_size'] = '2500';
		$config['max_width'] = '2600';
		$config['max_height'] = '2600';
*/
		//Load imgs upload library
		$this->load->library('upload');

		//Upload file and return data
		$this->upload->initialize($config);
		if ($this->upload->do_upload($img_name)) {
		$img_data=$this->upload->data();
		$new_imgname=md5(rand(0, 1000000).$img_name).$img_data['file_ext'];
		$new_imgpath=$img_data['file_path'].$new_imgname;
		rename($img_data['full_path'], $new_imgpath);
		//set new image name to pass via session
		$this->session->set_userdata('temp_banner_image', $new_imgname);
		return true;
		} else {
		$this->form_validation->set_message('uploadmain_formcheck', $this->upload->display_errors());
		return false;
		}
	}


}

/* End of file admin_cms.php */
/* Location: ./application/controllers/admin_cms.php */
