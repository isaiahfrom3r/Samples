<!DOCTYPE html>
<html lang="en">
	<?php $user = $this->users->get_user($this->users->admin_id()); ?>
	<script>
		var HOST_NAME = "<?=base_url()?>";
	</script>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<?php $this->load->view(ADMIN_THEME.'/assets/meta.php'); ?>
		<?php $this->load->view(ADMIN_THEME.'/assets/scripts.php'); ?>
		<?php $this->load->view(ADMIN_THEME.'/assets/styles.php');  ?>
		<?php

			if(isset($scripts) && !empty($scripts)){
				$this->load->view(ADMIN_THEME.'/assets/eqscripts.php',array('items'=>$scripts));
				unset($scripts);
			}
		?>
		<?php

			if(isset($styles) && !empty($styles)){
				$this->load->view(ADMIN_THEME.'/assets/eqstyles.php',array('items'=>$styles));
				unset($styles);
			}
		?>


		<?php $this->load->view(ADMIN_THEME.'/assets/alerts.php');  ?>

	</head>

	<body>

	<?php
		if(!isset($user->level)){
			$this->alert->set('Please Login','error');
			redirect('/login');
		}
		if($user->level == 3){
			$this->load->view(ADMIN_THEME.'/nav_content.php');
		}else{
			$this->load->view(ADMIN_THEME.'/nav.php');
		}
	?>

	<div class="container">
