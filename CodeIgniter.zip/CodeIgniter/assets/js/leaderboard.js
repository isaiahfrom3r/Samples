jQuery( document ).ready(function($) {
    console.log('ready');
    $(document).on('click', ".set_my_team", function() {

		$('.set_my_team').toggleClass('active');
		$('.not-user').toggle();


	});

});
