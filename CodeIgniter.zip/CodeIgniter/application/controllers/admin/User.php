<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class User extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){
		redirect('admin/user/list_all');
	}

	public function list_all($num=0){
		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);
		$this->load->library('pagination');

		// check if we're searching for a user
		if( !empty($_GET['search'])&&isset($_GET['search']) ){

			$keyword = $_GET['search'];

			// Set an offset from the query string
			if( !empty($_GET['page'])&&isset($_GET['page']) ){
				$offset = $_GET['page'];
			}else{
				$offset = 0;
			}

			$users =  $this->users->get_users_by_keyword($keyword);
			$config["full_tag_open"] = '<ul class="pagination">';
			$config["full_tag_close"] = '</ul>';
			$config["first_link"] = "&laquo;";
			$config["first_tag_open"] = "<li>";
			$config["first_tag_close"] = "</li>";
			$config["last_link"] = "&raquo;";
			$config["last_tag_open"] = "<li>";
			$config["last_tag_close"] = "</li>";
			$config['next_link'] = '&gt;';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '<li>';
			$config['prev_link'] = '&lt;';
			$config['prev_tag_open'] = '<li>';
			$config['prev_tag_close'] = '<li>';
			$config['cur_tag_open'] = '<li class="active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			// needs to be query string also to work properly with search
			$config['page_query_string']    = TRUE;
			$config['query_string_segment']= 'page';
			$config['base_url'] = base_url().'admin/user/list_all?search='.$keyword;
			$config['total_rows'] = count($users);
			$config['per_page'] = 99;
			$this->pagination->initialize($config);
			$data['users'] =  $this->users->get_users_by_keyword_pagi($keyword,$offset,99);

		}else{
			$users =  $this->users->get_users();
			$config["full_tag_open"] = '<ul class="pagination">';
			$config["full_tag_close"] = '</ul>';
			$config["first_link"] = "&laquo;";
			$config["first_tag_open"] = "<li>";
			$config["first_tag_close"] = "</li>";
			$config["last_link"] = "&raquo;";
			$config["last_tag_open"] = "<li>";
			$config["last_tag_close"] = "</li>";
			$config['next_link'] = '&gt;';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '<li>';
			$config['prev_link'] = '&lt;';
			$config['prev_tag_open'] = '<li>';
			$config['prev_tag_close'] = '<li>';
			$config['cur_tag_open'] = '<li class="active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			$config['base_url'] = base_url().'admin/user/list_all';
			$config['total_rows'] = count($users);
			$config['per_page'] = 99;
			$this->pagination->initialize($config);
			$data['users'] =  $this->users->get_users_pagi($num,99);
		}

		$head['scripts'] = array('/assets/admin/js/users.js');

		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/user/list',$data);
		$this->load->view(ADMIN_THEME.'/footer',array('scripts'=>'','styles'=>''));

	}

/*
	public function list_all($num=0){

		$this->load->library('pagination');
		$users =  $this->users->get_users();


		$config["full_tag_open"] = '<ul class="pagination">';
		$config["full_tag_close"] = '</ul>';
		$config["first_link"] = "&laquo;";
		$config["first_tag_open"] = "<li>";
		$config["first_tag_close"] = "</li>";
		$config["last_link"] = "&raquo;";
		$config["last_tag_open"] = "<li>";
		$config["last_tag_close"] = "</li>";
		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '<li>';
		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '<li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['base_url'] = base_url().'admin/user/list_all';
		$config['total_rows'] = count($users);
		$config['per_page'] = 99;

		$this->pagination->initialize($config);

		$data['users'] =  $this->users->get_users_pagi($num,99);

		$head['scripts'] = array('/assets/admin/js/users.js');

		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/user/list',$data);
		$this->load->view(ADMIN_THEME.'/footer',array('scripts'=>'','styles'=>''));

	}
*/


	// AJAX CRAP

	public function update_user(){

		// set validation rules
		$this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_numeric|min_length[4]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');

		if ($this->form_validation->run() === false) {
			echo 0;
		}else{
			$pass = $_POST['filedforp'];
			unset($_POST['filedforp']);

			$this->users->update($_POST['id'],$_POST);

			if(strlen($pass) > 2){
				$this->users->update_password($_POST['id'],$pass);
				echo 2;
			}else{
				echo 1;
			}
		}





	}
	public function active_user($id='',$status){
		$this->users->update($id,array('active'=>$status));
		$this->alert->set('Status Updated.','success');
		redirect('/admin/user/list_all');

	}

	public function login_as($id=''){
		$user = $this->users->get_user($id);

		$sesdata = array(
			'id'			=> (int)$user->id,
			'username'		=> (string)$user->username,
			'email'			=> $user->email,
			'first_name'	=> $user->first_name,
			'last_name'		=> $user->last_name,
			'level'			=> $user->level,
			'admin'			=> $user->level,
		);

		if($user->level == 2){
			$this->alert->set('Login as is only available for regular users','error');
			redirect('admin/user/list_all');
		}else{
			$this->session->set_userdata('user',$sesdata);
			$this->alert->set('Status Updated.','success');
			redirect('/');
		}



	}

	public function login_as_redirect($id='',$redirect=''){
		$user = $this->users->get_user($id);

		$sesdata = array(
			'id'			=> (int)$user->id,
			'username'		=> (string)$user->username,
			'email'			=> $user->email,
			'first_name'	=> $user->first_name,
			'last_name'		=> $user->last_name,
			'level'			=> $user->level,
			'admin'			=> $user->level,
		);

        $this->session->set_userdata('user',$sesdata);
        $this->alert->set('Status Updated.','success');
        redirect('/league/'.$redirect);



	}

    public function remove($id=''){

	}





}
