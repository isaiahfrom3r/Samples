

<section class="content card">
	<div class="container">

<h4>Choose Your Scoring Settings</h4>




		<hr>

<!-- 		Left out form element, I figured it's better for you to decide where/how to go about this ultimately. -JS -->

	<form action="" class="form-inline" method="post" accept-charset="utf-8">

		<div class="form-group half">
			<label>Name</label>
			<input type="text" step="width:100%;" class="form-control" name="name" value="<?=$name?>">
		</div>
		<div class="form-group half">
		</div>
		<div class="clearfix"></div>
<hr>

	<h4>Passing</h4>

	<div class="form-group fourth">
		<label>Passing TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[passing_td]" value="<?=$scoring['passing_td']?>">
	</div>

	<div class="form-group fourth">
		<label>Passing 25yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[passing_25]" value="<?=$scoring['passing_25']?>">
	</div>

	<div class="form-group fourth">
		<label>Passing INT</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[passing_int]" value="<?=$scoring['passing_int']?>">
	</div>
	<div class="form-group fourth">
		<label>2PT Conversion</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[2pt]" value="<?=$scoring['2pt']?>">
	</div>

	<hr>

	<h4>Rushing</h4>

	<div class="form-group fourth">
		<label>Rushing 10yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[rushing_10]" value="<?=$scoring['rushing_10']?>">
	</div>

	<div class="form-group fourth">
		<label>Rushing TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[rushing_td]" value="<?=$scoring['rushing_td']?>">
	</div>
	<div class="form-group fourth">
		<label>2PT Conversion</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[rushing_2pt]" value="<?=$scoring['rushing_2pt']?>">
	</div>

	<hr>

	<h4>Receiving</h4>

	<div class="form-group fourth">
		<label>Receiving 10yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_10]" value="<?=$scoring['receiving_10']?>">
	</div>

	<div class="form-group fourth">
		<label>Reception</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_rec]" value="<?=$scoring['receiving_rec']?>">
	</div>

	<div class="form-group fourth">
		<label>Receiving TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_td]" value="<?=$scoring['receiving_td']?>">
	</div>

	<div class="form-group fourth">
		<label>2PT Conversion</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_2pt]" value="<?=$scoring['receiving_2pt']?>">
	</div>

	<div class="form-group fourth">
		<label>Fumble Lost</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fumble_lost]" value="<?=$scoring['fumble_lost']?>">
	</div>

	<div class="form-group fourth">
		<label>Returned TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[return_td]" value="<?=$scoring['return_td']?>">
	</div>

	<div class="form-group fourth">
		<label>Offensive Fum Returned TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[off_fumble_recovery_td]" value="<?=$scoring['off_fumble_recovery_td']?>">
	</div>

	<hr>

	<h4>Kicking</h4>

	<div class="form-group fourth">
		<label>FG 0-19yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fg19]" value="<?=$scoring['fg19']?>">
	</div>

	<div class="form-group fourth">
		<label>FG 20-29yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fg29]" value="<?=$scoring['fg29']?>">
	</div>

	<div class="form-group fourth">
		<label>FG 30-39yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fg39]" value="<?=$scoring['fg39']?>">
	</div>

	<div class="form-group fourth">
		<label>FG 40-49yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fg49]" value="<?=$scoring['fg49']?>">
	</div>

	<div class="form-group fourth">
		<label>FG 50+yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fg50]" value="<?=$scoring['fg50']?>">
	</div>

	<div class="form-group fourth">
		<label>Extra Point</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[fg_xp]" value="<?=$scoring['fg_xp']?>">
	</div>

	<hr>

	<h4>DEF Teams / Special Teams</h4>

	<div class="form-group fourth">
		<label>DEF Sack</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][sack]" value="<?=$scoring['def']['sack']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF INT</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][int]" value="<?=$scoring['def']['int']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Rum-Rec</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][fumble]" value="<?=$scoring['def']['fumble']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][td]" value="<?=$scoring['def']['td']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Safety</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][saftey]" value="<?=$scoring['def']['saftey']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Blocked Kick</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][block]" value="<?=$scoring['def']['block']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][punt_td]" value="<?=$scoring['def']['punt_td']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][kickoff_td]" value="<?=$scoring['def']['kickoff_td']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return 10yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][punt_return_10]" value="<?=$scoring['def']['punt_return_10']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return 10yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][kickoff_return_10]" value="<?=$scoring['def']['kickoff_return_10']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 0pts allowed</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][points_0]" value="<?=$scoring['def']['points_0']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 1-6pts allowed</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][points_6]" value="<?=$scoring['def']['points_6']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 7-13pts allowed</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][points_13]" value="<?=$scoring['def']['points_13']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 14-20pts allowed</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][points_20]" value="<?=$scoring['def']['points_20']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 21-27pts allowed</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][points_27]" value="<?=$scoring['def']['points_27']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 28-34pts allowed</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][points_34]" value="<?=$scoring['def']['points_34']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF 2PT Conversion (Stop &amp; Return)</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def][2pt_stop]" value="<?=$scoring['def']['2pt_stop']?>">
	</div>

	<hr>

	<h4>DEF Players</h4>

	<div class="form-group fourth">
		<label>DEF Tackle</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_tackle]" value="<?=$scoring['def_tackle']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Sack</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_sack]" value="<?=$scoring['def_sack']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF INT</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_int]" value="<?=$scoring['def_int']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Fum-Rec</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_fumble]" value="<?=$scoring['def_fumble']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_td]" value="<?=$scoring['def_td']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Safety</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_saftey]" value="<?=$scoring['def_saftey']?>">
	</div>

	<div class="form-group fourth">
		<label>DEF Blocked Kick</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_blocked]" value="<?=$scoring['def_blocked']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_punt_td]" value="<?=$scoring['def_punt_td']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return TD</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_kick_td]" value="<?=$scoring['def_kick_td']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Punt Return 10yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_punt_10]" value="<?=$scoring['def_punt_10']?>">
	</div>

	<div class="form-group fourth">
		<label>D/ST Kickoff Return 10yds</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[def_kick_10]" value="<?=$scoring['def_kick_10']?>">
	</div>

	<hr>

	<h4>Passing Bonus</h4>

	<div class="form-group fourth">
		<label>Passing YDS 300+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[passing_300]" value="<?=$scoring['passing_300']?>">
	</div>

	<div class="form-group fourth">
		<label>Passing YDS 400+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[passing_400]" value="<?=$scoring['passing_400']?>">
	</div>

	<div class="form-group fourth">
		<label>Passing YDS 500+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[passing_500]" value="<?=$scoring['passing_500']?>">
	</div>

	<hr>

	<h4>Rushing Bonus</h4>

	<div class="form-group fourth">
		<label>Rushing YDS 100+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[rushing_100]" value="<?=$scoring['rushing_100']?>">
	</div>

	<div class="form-group fourth">
		<label>Rushing YDS 150+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[rushing_150]" value="<?=$scoring['rushing_150']?>">
	</div>

	<div class="form-group fourth">
		<label>Rushing YDS 200+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[rushing_200]" value="<?=$scoring['rushing_200']?>">
	</div>

	<hr>

	<h4>Receiving Bonus</h4>

	<div class="form-group fourth">
		<label>Receiving YDS 100+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_100]" value="<?=$scoring['receiving_100']?>">
	</div>

	<div class="form-group fourth">
		<label>Receiving YDS 150+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_150]" value="<?=$scoring['receiving_150']?>">
	</div>

	<div class="form-group fourth">
		<label>Receiving YDS 200+</label>
		<input  type="number" step="0.01" class="form-control" name="scoring[receiving_200]" value="<?=$scoring['receiving_200']?>">
	</div>
		<div class="clearfix"></div><br>
		<div class="text-center">
			<button type="submit" class="btn btn-success" >Save</button>
		</div>

		<div class="clearfix"></div><br><br>
	</form>

	</div>
</section>
