<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Support extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('users');
		$this->load->model('support_tickets');
		$lang=$this->session->userdata('lang');
		$this->form_validation->set_error_delimiters('<p class="help-block">', '</p>');
	}

	function index()
	{

		$data['user'] = $this->users->get_user($this->users->id());
		$data['content'] =  $content  = $this->options->get_grouped_options('support',1);
		//process new contact form submission
		$this->form_validation->set_rules('name', 'Name', 'required|max_length[128]');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|max_length[256]');
		$this->form_validation->set_rules('phone', 'Phone #', 'required|max_length[50]');
		$this->form_validation->set_rules('subject', 'Subject','required|max_length[256]');
		$this->form_validation->set_rules('message', 'Message', 'required|max_length[2000]');

		if ($this->form_validation->run() == FALSE){
		}else{
			//email message
			$email_data['name'] = $this->input->post('name');
			$email_data['email'] = $this->input->post('email');
			$email_data['phone'] = $this->input->post('phone');
			$email_data['message'] = $this->input->post('message');
			$subject = 'Support: '.$this->input->post('subject');
			$db_data=$email_data;
			$db_data['message']=htmlspecialchars($this->input->post('message'));
			$db_data['subject']=htmlspecialchars($this->input->post('subject'));
			$ticket_id=$this->support_tickets->add_new($db_data);
			//$this->users->send_admin_email($email_data['email'],$subject,'support_ticket',$email_data);
			$this->emails->send_mail($this->options->get('admin_email'), 'support_ticket', $email_data,$subject);
			$this->alert->set($content['support_thanks'],'success');
			redirect('support');
		}

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/support',$data);
		$this->load->view(THEME.'/footer');
	}

	function check_captcha($val) {
	  if ($this->recaptcha->check_answer($this->input->ip_address(),$this->input->post('recaptcha_challenge_field'),$val)) {
	    return TRUE;
	  } else {
	    $this->form_validation->set_message('check_captcha',$this->lang->line('recaptcha_incorrect_response'));
	    return FALSE;
	  }
	}

}

/* End of file blog.php */
/* Location: ./application/controllers/blog.php */
