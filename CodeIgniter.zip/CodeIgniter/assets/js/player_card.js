$( document ).ready(function() {


    $(document).on('click', ".playerCardClick", function() {

		var pid = $(this).attr('data-pid');
		var lid = $(this).attr('data-league');
		var URL = HOST_NAME+"league/get_card/"+pid+"/"+lid;
		console.log(URL);
		$.ajax({
		    url: URL,
		    success: function (data) {
				$('#playercard').modal('show');

				$('.player_content').html(data);

		    }
		});



	});


});
