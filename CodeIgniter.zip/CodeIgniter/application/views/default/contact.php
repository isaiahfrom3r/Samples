<section class="light-gray-bg top-section">

    <div class="container white-bg">

		<div class="row">

			<div class="col-md-8">

				<h1 class="title"><?=$content['contact_title'];?></h1>

				<?=$content['contact_text']?>

				<form action="" method="post" class="form-horizontal">

					<div class="form-group<?$e=form_error('name'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Name</label>
						<div class="controls">
							<input type="text" class='form-control' name="name" value="<?=set_value('name');?>" />
							<?=form_error('name');?>
						</div>
					</div>

					<div class="form-group<?$e=form_error('company'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Company</label>
						<div class="controls">
							<input type="text" class='form-control' name="company" value="<?=set_value('company');?>" />
							<?=form_error('company');?>
						</div>
					</div>

					<div class="form-group<?$e=form_error('email'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Email</label>
						<div class="controls">
							<input type="text" class='form-control' name="email" <?=set_value('email');?> />
							<?=form_error('email');?>
						</div>
					</div>

					<div class="form-group<?$e=form_error('phone'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Phone</label>
						<div class="controls">
							<input type="text" class='form-control' name="phone" <?=set_value('phone');?> />
							<?=form_error('phone');?>
						</div>
					</div>

<!--
					<div class="control-group<?$e=form_error('subject'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Subject</label>
						<div class="controls">
							<select name="subject" class="form-control">
								<option value="Sales" <?php echo set_select('subject','Sales',TRUE); ?>>Sales</option>
								<option value="Service" <?php echo set_select('subject','Service'); ?>>Service</option>
								<option value="Feedback" <?php echo set_select('subject','Feedback'); ?>>Feedback</option>
								<option value="Support" <?php echo set_select('subject','Support'); ?>>Support</option>
								<option value="Media/Press" <?php echo set_select('subject','Media/Press'); ?>>Media/Press</option>
								<option value="General" <?php echo set_select('subject','General'); ?>>General</option>
								<option value="Other" <?php echo set_select('subject','Other'); ?>>Other</option>
							</select>
							<?=form_error('subject');?>
						</div>
					</div>
-->

					<div class="form-group <?$e=form_error('message'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Message</label>
						<div class="controls">
							<textarea class="form-control" name="message"><?=set_value('message');?></textarea>
							<?=form_error('message');?>
						</div>
					</div>

					<div style="clear:both;"></div>

					<div class="form-group text-center">
						<input type="submit" class="btn btn-default btn-red" value="Submit" />
					</div>

				</form>

			</div>

			<div class="col-md-4 sidebar">

				<?=$this->load->view(THEME.'/page/sidebar');?>

			</div>

		</div>

	</div>

</section>
