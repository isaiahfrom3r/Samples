jQuery.fn.flash = function(color, duration) {
	console.log("hit");
	var current = this.css('color');
	this.animate({
		color: 'rgb(' + color + ')'
	}, duration / 2);
	this.animate({
		color: current
	}, duration / 2);
}
jQuery(document).on('click','.chat_remove',function (e){

 	var uid  = jQuery(this).attr('data-user');
 	var time = jQuery(this).attr('data-time');
 	var lid  = jQuery(this).attr('data-league');
 	console.log(uid);
 	console.log(time);
 	console.log(lid);

 	console.log(HOST_NAME+'chat/delete_chat/'+uid+'/'+time+'/'+lid);

 	jQuery.ajax({
		url: HOST_NAME+'chat/delete_chat/'+uid+'/'+time+'/'+lid,
		success: function(data) {



		}

	});


});

jQuery(document).on('click','#chat_tab',function (e){
	console.log('bing bong');
 		var el;
		if ((el = document.getElementById('messages'))
		&& ('undefined' != typeof el.scrollTop))
		{
			var height = document.getElementById('messages').scrollHeight;
			el.scrollTop = 0;
			el.scrollTop = height;
		}


});
function scrollDiv()
	{
		var el;
		if ((el = document.getElementById('messages'))
		&& ('undefined' != typeof el.scrollTop))
		{
			var height = document.getElementById('messages').scrollHeight;
			el.scrollTop = 0;
			el.scrollTop = height;
		}
	}

	window.onload = scrollDiv;
jQuery('.chat_submit').prop("disabled",false);
jQuery(document).ready(function() {
	var chatl = jQuery('.chat_block').length;

	if(chatl > 0){
		jQuery('.noti').show();
		jQuery('.noti').text(chatl);
	}


	window.setInterval(function(){
		jQuery('#chat_message').attr('maxlength',240);
		jQuery('#chat_app').scope().save();

 		var chatl = jQuery('.chat_block').length;

 		if(chatl > 0){
	 		jQuery('.noti').show();
	 		jQuery('.noti').text(chatl);
 		}



	}, 2000);

	jQuery(function() {
		var frm = jQuery('#chat_form');

		frm.submit(function(ev) {
			jQuery('.chat_submit').prop("disabled",true);
			var str = jQuery("#chat_message").val();

			var danger = 0;

			if (str.toLowerCase().indexOf(";") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf(">") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("<") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf(":") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("}") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("{") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("[") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("]") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("~") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("/") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("|") >= 0){
				jQuery("#chat_message").val('');
				danger = 1;
			}
			if(danger == 1){
				jQuery("#chat_message").css( "border-color", "red" ).delay('1000');


				setTimeout(function(){
				  jQuery("#chat_message").css( "border-color", "#cccccc" );
				}, 500);

			}


			jQuery.ajax({
				type: frm.attr('method'),
				url: frm.attr('action'),
				data: frm.serialize(),
				success: function(data) {
					jQuery("#chat_message").val('').delay('1000');
					jQuery('#chat_app').scope().save();
					jQuery('.chat_submit').prop("disabled",false);
				}
			});
			ev.preventDefault();
		});
	});
	jQuery(function() {
		var frm = jQuery('#chat_form2');

		frm.submit(function(ev) {
			jQuery('.chat_submit').prop("disabled",true);
			var str = jQuery("#chat_message2").val();

			var danger = 0;

			if (str.toLowerCase().indexOf(";") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf(">") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("<") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf(":") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("}") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("{") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("[") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("]") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("~") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("/") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if (str.toLowerCase().indexOf("|") >= 0){
				jQuery("#chat_message2").val('');
				danger = 1;
			}
			if(danger == 1){
				jQuery("#chat_message2").css( "border-color", "red" ).delay('1000');


				setTimeout(function(){
				  jQuery("#chat_message2").css( "border-color", "#cccccc" );
				}, 500);

			}


			jQuery.ajax({
				type: frm.attr('method'),
				url: frm.attr('action'),
				data: frm.serialize(),
				success: function(data) {
					jQuery("#chat_message2").val('').delay('1000');
					jQuery('#chat_app').scope().save();
					jQuery('.chat_submit').prop("disabled",false);
				}
			});
			ev.preventDefault();
		});
	});
});

