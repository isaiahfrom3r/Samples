<!-- https://github.com/charlesmudy/responsive-html-email-template/blob/master/index.html -->

<?=$body;?>
