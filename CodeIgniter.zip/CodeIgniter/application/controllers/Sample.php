<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sample extends CI_Controller {
	public function __construct() {


		parent::__construct();
		$this->load->model('Articles');
		$this->load->model('Leagues');
	}

	public function svg(){
		$head = $foot = $data = array();


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/sample/svg',$data);
		$this->load->view(THEME.'/footer',$foot);


	}


}
