<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class shops extends CI_Model {

	public function __construct()
    {
    	parent::__construct();
	}

	public function get_all(){
		$shops=$this->db->get('shops');
		if($shops->num_rows()>0){
			return $shops->result();
		}else{
			return false;
		}
	}

	public function get_by_id($id=0){
		if(!empty($id)){
			$this->db->where('id',$id);
			$this->db->limit(1);
			$shop=$this->db->get('shops');
			if($shop->num_rows()>0){
				return $shop->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function get_by_slug($slug=0){
		if(!empty($slug)){
			$this->db->where('slug',$slug);
			$this->db->limit(1);
			$shop=$this->db->get('shops');
			if($shop->num_rows()>0){
				return $shop->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function get_shops($category='',$limit=1,$offset=0, $total=false){
		if(!$this->users->is_loggedin()){
			$this->db->where('shops.visibility','public');
		}
		$this->db->where('shops.status','published');
		$this->db->where('shops.post_date <', time());
		$this->db->order_by('shops.post_date','DESC');
		if(!$total){
			$this->db->limit($limit,$offset);
		}
		if(!empty($category)){
			$this->db->where('shop_category_relation.category_id',$category);
			$this->db->from('shop_category_relation');
			$this->db->join('shops','shops.id = shop_category_relation.shop_id');
			$shop=$this->db->get();
		}else{
			$shop=$this->db->get('shops');
		}

		if($shop->num_rows()>0){
			if(!$total){
				if($limit==1){
					return $shop->row();
				}else{
					return $shop->result();
				}
			}else{
				return $shop->num_rows();
			}
		}else{
			return false;
		}
	}

	public function get_shop_categories($id=0){
		if(!empty($id)){
			$this->db->where('shop_id',$id);
			$shop=$this->db->get('shop_category_relation');
			if($shop->num_rows()>0){
				$categories=array();
				foreach($shop->result() as $a){
					$categories[]=$a->category_id;
				}
				return $categories;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function get_category_by_id($cat_id=""){
		if(!empty($cat_id)){
			$this->db->where('id',$cat_id);
			$this->db->limit(1);
			$cat=$this->db->get('shop_categories');
			if($cat->num_rows()>0){
				return $cat->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function get_category_by_slug($cat_slug=''){
		if(!empty($cat_slug)){
			$this->db->where('slug',$cat_slug);
			$this->db->limit(1);
			$cat=$this->db->get('shop_categories');
			if($cat->num_rows()>0){
				return $cat->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function get_categories($cat_id=0,$nested=true){
		if($nested){
			$this->db->where('parent_id',$cat_id);
			$cats=$this->db->get('shop_categories');
			if($cats->num_rows()>0){
				$categories=array();

				foreach($cats->result() as $c){
					//$children=$this->get_categories($c->id);
					$categories[]=array(
						'id'=>$c->id,
						'label'=>$c->label,
						'slug'=>$c->slug,
						'children'=>''
					);
				}

				return $categories;
			}else{
				return false;
			}
		}else{
			$cats=$this->db->get('shop_categories');
			return $cats->result();
		}
	}

	public function show_categories($categories, $default_cats=array()){



		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		echo "<div class='unstyled category_list'>";
		foreach($categories as $c):?>
			<span class="col-md-12"><span><?=$c['label']?><input class="form-control pull-right" type="checkbox" name="categories[]"

			<?=(isset($default_cats) && in_array($c['id'],$default_cats))?"checked='checked'":""?> value="<?=$c['id']?>"/>

			</span>
				<?if($c['children']):?>
					<?=$this->show_categories($c['children']);?>
				<?endif;?>
			</span><br>
		<?endforeach;
		echo "</ul>";
	}

}
