<!-- Push Wrapper -->
<?php $positions = array('QB'=>'QB','RB'=>'RB','WR'=>'WR','TE'=>'TE','K'=>'K','D/ST'=>'D/ST','D'=>'D');?>
<div class="mp-pusher" id="mp-pusher">
	<nav id="draft-menu" class="mp-menu">
		<div class="mp-level">
			<ul>
				<li>
					<a href="#"><i class="fa fa-caret-left"></i> Draft Results</a>
					<div class="mp-level">
						<h3>Draft Results</h3>
						<div class="draft-results mobile">
							<div class="team-select">
								<form action="">
									<select class="form-control">
										<option value="" selected="">My Team</option>
									</select>
								</form>
							</div>
							<div class="table-responsive">
								<table class="table player-list">
									<tbody>
										<tr>
											<td>
												<div class="player-det">
													<p>Player Name</p>
													<p>Team Name</p>
												</div>
												<div>
													Round #1 | Pos: <?=array_rand($positions);?> | Bye: <?=rand(1,6);?>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="player-det">
													<p>Player Name</p>
													<p>Team Name</p>
												</div>
												<div>
													Round #2 | Pos: <?=array_rand($positions);?> | Bye: <?=rand(1,6);?>
												</div>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</li>
				<li class="mobile-queue">
					<a href="#"><i class="fa fa-hourglass"></i> Queue</a>
					<div class="mp-level">
						<h3>Queue</h3>
						<div class="table-responsive">
							<table class="table player-list">
								<tbody>
									<tr>
										<td>
											<div class="player-det">
												<p>Player Name</p>
												<p>Team Name</p>
											</div>
											<div>
												Rank #5 | Pos: <?=array_rand($positions);?> | Bye: <?=rand(1,6);?>
											</div>
											<div class="draft-buttons">
												<button class="btn btn-default btn-small draft">Draft</button>
												<button class="btn btn-default btn-small queue">Remove</button>
												<div style="clear:both;"></div>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div class="player-det">
												<p>Player Name</p>
												<p>Team Name</p>
											</div>
											<div>
												Rank #10 | Pos: <?=array_rand($positions);?> | Bye: <?=rand(1,6);?>
											</div>
											<div class="draft-buttons">
												<button class="btn btn-default btn-small draft">Draft</button>
												<button class="btn btn-default btn-small queue">Remove</button>
												<div style="clear:both;"></div>
											</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</li>
				<li><a href="#"><i class="fa fa-comments-o"></i> Chat</a>
					<div class="mp-level">
						<h3>Chat</h3>
						<div class="chat mobile">
							<div class="chat-window">
								<p class="admin"><strong>12:38pm player has drafted Player Name.</strong></p>
								<p><strong>12:42pm mccringleberry</strong>: Good choice.</p>
								<p class="admin"><strong>12:45pm mccringleberry has drafted Player Name.</strong></p>
								<p><strong>12:46pm player</strong>: Throwin shade.</p>
							</div>
							<form>
								<div class="input-group">
									<input type="text" class="form-control" placeholder="Say something...">
									<span class="input-group-btn">
										<button class="btn btn-default" type="button"><i class="fa fa-send"></i></button>
									</span>
							    </div>
							</form>
						</div>
					</div>
				</li>
				<li><a href="#"><i class="fa fa-desktop"></i> Auto-Draft (On)</a></li>
				<li><a href="#"><i class="fa fa-table"></i> Draft Board</a></li>
				<li><a href="#" onclick="alert('Are you sure you want to close the draft?');"><i class="fa fa-times"></i> Close Draft</a></li>
			</ul>
		</div>
	</nav>




