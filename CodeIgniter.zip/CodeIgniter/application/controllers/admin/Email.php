<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class Email extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
        $this->load->model('Emails');
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){
		redirect('admin/email/email_templates');
	}



	public function email_templates(){
		$data['pages']=$this->Emails->get_all_email_templates();

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view('admin/email/email_templates_list',$data);
		$this->load->view(ADMIN_THEME.'/footer');

	}


	public function email_template_form($page_id=''){

		$data['page_id']=$page_id;



		$data['page']=$page=$this->Emails->get_email_template_by_id($page_id);

		$data['page_templates']=array();
		$data['page_templates']['default']='default';

		if($page!=false){
			$data['subject']=json_decode($page->subject);
			$data['content']=json_decode($page->body);

		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/email/email_templates',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function email_template_save($page_id=''){

		$post=$this->input->post();
		$langs[] = 'english';
		$body=array();

		foreach($langs as $l){
			$body[$l]=$post['content'][$l];
		}

		$update=array(
			'slug'=>$this->input->post('slug'),
			'subject'=>json_encode($this->input->post('subject')),
			'body'=>json_encode($body),
			'rule'=>$this->input->post('rule'),
		);

		if(!empty($page_id)){
			$this->db->where('id',$page_id);
			$this->db->update('email_templates',$update);
			$this->alert->set('Email Template Saved','success');
			redirect('admin/email/email_templates');
		}else{

			$this->db->insert('email_templates',$update);
			$page_id=$this->db->insert_id();

			$this->alert->set('Email Template Created','success');

			redirect('admin/email/email_templates');
		}
	}

	public function delete_email_template($page_id=""){

		$page=$this->Emails->get_email_template_by_id($page_id);
		if($page!=false){
			$this->db->where('id',$page_id);
			$this->db->limit(1);
			$this->db->delete('email_templates');
			$this->alert->set('Email Template Deleted.','success');
			redirect('admin/email/email_templates');
		}else{
			$this->alert->set('Page not found.','success');
			redirect('admin/email/email_templates');
		}
	}



}
