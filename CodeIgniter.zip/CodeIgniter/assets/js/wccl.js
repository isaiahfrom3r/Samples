$( document ).ready(function() {
    console.log( "document loaded" );
});
