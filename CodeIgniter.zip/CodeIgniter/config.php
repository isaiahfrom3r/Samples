<?php
	ini_set('display_errors', 1); // set to 0 for production version
	error_reporting(E_ALL);
//Database details
define ('DB_HOST', 'mariadb-034.wc1.lan3.stabletransit.com');
//Username
define ('DB_USERNAME', '952661_reports');
//Pass
define ('DB_PASS', '(IArn66)');
//Database Name
define ('DB_NAME', '952661_reports');
//Base URL
define ('BASE_URL', 'http://internalstuff.pathfind.com/reports/');
//Email/Cookie URL
?>
