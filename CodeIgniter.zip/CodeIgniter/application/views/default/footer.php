
	<footer>

		<?php
		if(isset($scripts) && !empty($scripts)){
			$this->load->view(ADMIN_THEME.'/assets/eqscripts.php',array('items'=>$scripts));
		}?>

		<?php
		if(isset($styles) && !empty($styles)){
			$this->load->view(ADMIN_THEME.'/assets/eqstyles.php',array('items'=>$styles));
		}?>

		<div class="container">

			<div class="row flex-column">

				<ul class="footer-nav d-flex">

					<?php
					$menu = $this->menus->display(185);
					foreach($menu['menu'] as $m){ ?>

					   	<li>

					        <a href="<?=$m['details']['url']?>"><?=$m['details']['name']?></a>

					    </li>

					<?php } ?>

				</ul>

				<div class="copyright">
				<span class="">

				<a href="<?=$this->options->get('twitter')?>"><i style="font-size: 20px;" class="fa fa-twitter" aria-hidden="true"></i></a>
				&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
				<a href="<?=$this->options->get('facebook')?>"><i style="font-size: 20px;" class="fa fa-facebook" aria-hidden="true"></i></a>


				</span>

				</div>

			</div>

		</div>

	</footer>

	<div id="playercard" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body player_content">


				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default grey" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">

		$(document).ready(function(){

			var navheight = $('.navbar.navbar-expand-md').height();

			$('li.nav-item').css('height',navheight + 'px');
			$('section.top-section').css('margin-top',navheight + 'px');

			var url = window.location;
	        $('.navbar .navbar-nav a.nav-link[href="'+ url +'"]').parent().addClass('active');
	        $('.navbar .navbar-nav a.nav-link').filter(function() {
	             return this.href == url;
	        }).parent().addClass('active');

		});

	</script>

</body>

</html>
