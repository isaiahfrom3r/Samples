<?php
ini_set('display_errors', 0); // set to 0 for production version
error_reporting(-1);
?>
<div class="card">
	<div class="card-header"><h3>Help Desk Form <?php if(isset($desk->name)){ echo " -".$desk->name;} ?></h3>

	</div>
<form method="post" action="" id="page_form" class="<?=true?" code_edit":""?> col-md-12">
<input type="hidden" name="page_id" id="page_id" value="<?=$page_id?>" />
<div class="row-fluid">
	<div class="portlet box blue">
		<div class="portlet-title">
			<div class="caption">
				<i class="fa fa-gift"></i>
			</div>
			<div class="tools">
				<a href="javascript:;" class="collapse">
				</a>
				<a href="#portlet-config" data-toggle="modal" class="config">
				</a>
			</div>
		</div>
		<div class="portlet-body">
			<div class="tabbable-custom nav-justified">


				<div class="tab-content">
					<div class="tab-pane active" id="tab_1_1_1">
						<?$count=1?>
						<div class="form-group">
							<label class="control-label"><strong>Name</strong></label>
							<input type="text" name="name" id="name" class="form-control" value="<?=set_value('name]',(isset($desk->name))?$desk->name:'')?>"/>
							<?=form_error('name')?>
						</div>
						<div class="form-group<? $e=form_error('slug');echo (!empty($e))?' error':'';?>">
							<label class="control-label"><strong>Slug</strong></label>
							<small>* This is the helpdesk URL. Must contain only letters and no special characters. </small>
							<input type="text" name="slug" id="slug" class="form-control" value="<?=set_value('slug',(isset($desk->slug))?$desk->slug:'')?>"/>
							<?=form_error('slug')?>
						</div>





						<input  type="hidden" name="id" value="<?=$id?>">

					</div>


				</div>
			</div>
			<div class="tabbable-custom tabs-below nav-justified">
				<div class="form-actions">
					<?/*<input type="submit" name="submit" value="Save Changes" class="btn btn-primary" />
						<a href="#" id="save" class="btn btn-primary">Save</a>*/?>
					<button id="save" class="btn btn-primary">Save <span id="loading" class="save_hide"><i class="icon-spinner icon-spin"></i></span></button>
				</div>
			</div>
		</div>
	</div>
</div>
</form>
<div class="clearfix"></div><br>

</div>


<?//="<pre>".print_r($this->scripts->default_scripts,true)."</pre>"?>
