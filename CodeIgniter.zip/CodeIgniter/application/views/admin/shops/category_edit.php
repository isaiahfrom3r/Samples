<div class="card">
<div class="row-fluid">
	<div class="col-md-12">
		<h3>Categories</h3>
		<!--Information block -->
		<div class="portlet box yellow-casablanca">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-info-circle"></i>Instructions
				</div>
			</div>
			<div class="portlet-body">
				<!--Insert information block here-->
				<div class="note note-success">
					<p>
						Create new blog/shop categories here or click to edit existing ones. Remember - the slug should not contain spaces as this is for the shops URL.
					</p>
				</div>
			</div>
		</div>
		<!--END Information block -->
		<div class="pull-right">
			<a href="<?=site_url('admin/shop/categories')?>" class="btn green" class="btn btn-small confirm">Create New Category</a>
		</div>
		<div class="clearfix"></div>
		<div class="portlet box green">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-file-o"></i>Edit Category
				</div>
			</div>
			<div class="clearfix"></div><br>
			<div class="portlet-body form">
				<div class="form-body">
					<form method="post" class="form-inline" action="<?=site_url('admin/shop/edit_category/'.$cat_id)?>">
					<div class="form-group">

							<div class="control-group<?$e=form_error('label');echo (!empty($e)?" error":"")?>">
								<label class="col-md-3 control-label">Label</label>
								<div class="col-md-9">
									<input style="width: 100%;" class="form-control" type="text" name="label" id="label" value="<?=set_value('label',(isset($category->label)&& !empty($category->label))?$category->label:"");?>" placeholder="Label"/>
									<?=form_error('label')?>
								</div>
							</div>
							</div>
							<div class="form-group">
								<div class="control-group<?$e=form_error('title');echo (!empty($e)?" error":"")?>">
									<label class="col-md-3 control-label">Title</label>
									<div class="col-md-9">
										<input class="form-control" type="text" name="title" id="title" value="<?=set_value('title',(isset($category->title)&& !empty($category->title))?$category->title:"");?>" placeholder="Title"/>
										<?=form_error('title')?>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="control-group<?$e=form_error('slug');echo (!empty($e)?" error":"")?>">
									<label class="col-md-3 control-label">Slug</label>
									<div class="col-md-9">
										<input class="form-control" type="text" name="slug" id="slug" value="<?=set_value('slug',(isset($category->slug)&& !empty($category->slug))?$category->slug:"");?>" placeholder="Slug"/>
										<?=form_error('slug')?>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="control-group<?$e=form_error('parent');echo (!empty($e)?" error":"")?>">
									<label class="col-md-3 control-label">Parent</label>
									<div class="col-md-9">
										<select class="form-control" name="parent" id="parent">
											<option value="0" <?=set_select('parent',0,(isset($category->parent_id)&& !empty($category->parent_id) && $category->parent_id==0)?TRUE:FALSE);?>>No Parent</option>
											<?if(!empty($all_categories)):?>
											<?foreach($all_categories as $ac):?>
											<option value="<?=$ac->id?>" <?=set_select('parent',$ac->id,(isset($category->parent_id)&& !empty($category->parent_id) && $category->parent_id==$ac->id)?TRUE:FALSE);?>><?=$ac->label?></option>
											<?endforeach;?>
											<?endif;?>
										</select>
										<?=form_error('parent')?>
									</div>
								</div>
							</div>
					</div>
					<div class="form-actions">
					<input type="submit" class="btn btn green" value="Edit Category" />
					</div>
					</form>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<br>
</div>
