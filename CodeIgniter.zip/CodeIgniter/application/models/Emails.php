<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * Advance_menu_model model
 *
 * This class model is used for manage menu.
 */
class Emails extends CI_Model {

    public function __construct() {
        parent::__construct();
    }


	public function get_all_email_templates(){
			$pages=$this->db->get('email_templates');
			return $pages->result();
		}
	public function get_email_template_by_id($id=''){
		if(!empty($id)){
			$this->db->where('id',$id);
			$this->db->limit(1);
			$page=$this->db->get('email_templates');
			if($page->num_rows()>0){
				return $page->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	public function get_content_page_by_id($id=''){
		if(!empty($id)){
			$this->db->where('id',$id);
			$this->db->limit(1);
			$page=$this->db->get('content_pages');
			if($page->num_rows()>0){
				return $page->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function get_template($slug=''){
		if(!empty($slug)){
			$template=$this->db->where('slug',$slug)->limit(1)->get('email_templates');
			if($template->num_rows()>0){
				return $template->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function send_mail($to='',$slug='',$emaildata=array(),$subject='',$admin_email=false){
		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);

		if(!empty($to) && !empty($slug)){
			$template=$this->get_template($slug);
			if($admin_email || (!$admin_email && $template )){
				$body=json_decode($template->body);
				$body=$this->render($body->english,$emaildata);
				$body=$this->load->view(THEME.'/email',array('body'=>$body),true);

				//echo $body;exit;

				if(empty($subject)){

					$subject=json_decode($template->subject);
					$subject = $subject->english;
					$subject=$this->render($subject,$emaildata);
				}

				$admin_email=$this->options->get('admin_email');

				$this->load->library('email');
				$this->email->clear(TRUE);
				$config['mailtype']='html';
				$config['crlf']= "\n";
				$config['newline'] = "\n";
				$config['useragent']           = "CodeIgniter";
                $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
                $config['charset']  = 'utf-8';
                $config['wordwrap'] = TRUE;

                $config['protocol']="smtp";
				$config['smtp_host']="smtp.mailgun.org";
				$config['smtp_user']="postmaster@mg.mipickem.com";
				$config['smtp_pass']="85885ddc9dcc2bdc9983d79973fd9939-2b4c5a6c-6b678cb0";
				$config['smtp_port']=587;
				$config['smtp_crypto']='tls';
				$config['mailtype']="html";
				$config['crlf']="\n";
				$config['newline']="\n";
				$this->email->initialize($config);
				$this->email->from($admin_email);
				$this->email->to($to);
				$this->email->subject($subject);
				$this->email->message($body);

				$headers = "From: ".$admin_email."" . "\r\n";

				//mail($to,$subject,$body,$headers);
				if($this->email->send()){

					$this->email->print_debugger();
					return true;
				}else{

//  					echo $this->email->print_debugger();exit;
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	/*--------------------------------------------------------------------------
		RENDER EMAIL BODY
			This is a super simple templating engine that just drops element
			from the data array into the template using {{}} like a simple
			implementation of the mustache engine:
			http://mustache.github.io/

			Later if it needs to be more robust we can grab that library and
			actually use it but this should be good for now.
	--------------------------------------------------------------------------*/
	public function render($template='',$data=''){
		if(!empty($template)){
			if(!empty($data)){
				foreach($data as $k=>$v){

					$template=str_replace('&quot;', '"', $template);
					$template=str_replace('{{'.$k.'}}', $v, $template);
				}
			}
			return $template;
		}else{
			return false;
		}
	}

}
