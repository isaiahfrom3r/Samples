<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Menu Display Sample - Easy Menu Manager</title>
		<meta name="viewport" content="width=device-width; initial-scale=1.0">
		<link rel="shortcut icon" href="/favicon.ico">
		<link rel="shortcut icon" href="favicon.ico" />

		<link rel="stylesheet" href="<?php echo base_url('assets/css/quickmenu_display_global.css')?>"    media="screen" />
		<link rel="stylesheet" href="<?php echo base_url('assets/css/quickmenu_display_nb-style.css')?>" media="screen" />
		<link rel="stylesheet" href="<?php echo base_url('assets/css/quickmenu_display.css')?>"   media="screen" />
		<link rel="stylesheet" href="<?php echo base_url('assets/css/quickmenu_display_responsive.css')?>"   media="screen" />
		<script src="<?php echo base_url('assets/js/quickmenu_jquery-1.11.1.min.js')?>" type="text/javascript"></script>
		<script src="<?php echo base_url('assets/js/quickmenu_display.js')?>" type="text/javascript"></script>
	</head>

	<body>
		<?php
		$data=$this->display_menu_model->get_menu_effect_single(75,'class="header-nav clearfix"');
		if($data)
		{
		$effect_color=$data['effect_color'];
		?>
		<div class="page">
			<header id="header">
				<div class="page-container">
					<h2>Link Effect First</h2>
					<div class="<?php if($effect_color){ echo $effect_color->effect." ".$effect_color->color;}?>">
						<div class="toggle-row clearfix">
							<div class="toggle">
								<span>&nbsp;</span>
							</div>
							Menu
						</div>

						<nav class="header-navigation cl-<?php if($effect_color){ echo  $effect_color->effect;}?>">
						<?php echo $data['menu'];?>
						</nav>
					</div>

					<h2>Link Effect Second</h2>
					<div class="<?php if($effect_color){ echo 'effect-2 '.$effect_color->color;}?>">
						<div class="toggle-row clearfix">
							<div class="toggle">
								<span>&nbsp;</span>
							</div>
							Menu
						</div>

						<nav class="header-navigation cl-<?php if($effect_color){ echo  'effect-2 ';}?>">
						<?php echo $data['menu'];?>
						</nav>
					</div>

				<h2>Link Effect Third</h2>
					<div class="<?php if($effect_color){ echo 'effect-3 '.$effect_color->color;}?>">
						<div class="toggle-row clearfix">
							<div class="toggle">
								<span>&nbsp;</span>
							</div>
							Menu
						</div>

						<nav class="header-navigation cl-<?php if($effect_color){ echo  'effect-3 ';}?>">
						<?php echo $data['menu'];?>
						</nav>
					</div>

					<h2>Link Effect Fourth</h2>
					<div class="<?php if($effect_color){ echo 'effect-4 '.$effect_color->color;}?>">
						<div class="toggle-row clearfix">
							<div class="toggle">
								<span>&nbsp;</span>
							</div>
							Menu
						</div>

						<nav class="header-navigation cl-<?php if($effect_color){ echo  'effect-4 ';}?>">
						<?php echo $data['menu'];?>
						</nav>
					</div>

				<h2>Link Effect Fifth</h2>
					<div class="<?php if($effect_color){ echo 'effect-5 '.$effect_color->color;}?>">
						<div class="toggle-row clearfix">
							<div class="toggle">
								<span>&nbsp;</span>
							</div>
							Menu
						</div>

						<nav class="header-navigation cl-<?php if($effect_color){ echo  'effect-5 ';}?>">
						<?php echo $data['menu'];?>
						</nav>
					</div>



				</div>
			</header>
		</div>
	<?php }?>
	<div class="footer-copy-right">
                    <span>Copyrights &copy; 2016 Quick menu management. All Rights Reserved.</span>
     </div>
	</body>
</html>
