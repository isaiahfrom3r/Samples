<?php

if ( !isset($_REQUEST['action']) ) { die(); }

if ( $_POST['action'] == 'update' ) {

	if ( get_magic_quotes_gpc() ) {
		$_POST['value'] = stripslashes($_POST['value']);
	}

	file_put_contents( 'data/' . $_POST['name'] . '.txt', $_POST['value'] );

	$file_text = file_get_contents('data/' . $_POST['name'] . '.txt');
	echo $$file_text;
}

?>
