<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_user_log extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('users');
		$this->form_validation->set_error_delimiters('<span class="help-inline error">', '</span>');
		$this->users->auth_check();
		$this->users->is_admin_or_moderator_check();
	}

	function index()
	{
		redirect('admin_users/list_users');
	}

	public function view(){
		$this->load->library('pagination');
		$data['admin_theme'] = $this->options->get('admin_theme');
		$data['active_menu'] = 'users';
		$this->config->load('godraft');
		$data['tickets'] = $this->config->item('ticket_types');
		$data['user_id']=$this->uri->segment(3);
		if(empty($data['user_id'])) redirect('admin_users/list_users');

		$data['action']=$action=$this->uri->segment(4);
		if(empty($action)) redirect('admin_user_log/view/'.$data['user_id']."/leagues");

		$data['order_by']=$this->uri->segment(5);
		if($data['order_by']=='')$data['order_by']='timestamp';

		$data['order_dir']=$this->uri->segment(6);
		if($data['order_dir']=='')$data['order_dir']='DESC';

		$config['per_page']=100;
		$data['page_num']=$curr_pagenum = $this->uri->segment(7);
		if ($curr_pagenum == '') $data['page_num']=$curr_pagenum=0;

		$data['user']=$user=$this->users->get_by_id($data['user_id']);
		if(!$data['user_id']) redirect('admin_users/list_users');

		$data['title'] = "User Log: <a href='".site_url('admin_users/edit_user/'.$data['user_id'])."'>".$user->username."</a>";


		if($action=="leagues"){
			$this->db->select('league_team.created,league.name,league.cid,league.commissioner_id');
			$this->db->where('league_team.user_id',$data['user_id']);
			$this->db->from('league_team');
			$this->db->join('league','league.cid=league_team.league_id');
			$data['leagues']=$this->db->get()->result();
		}elseif($action=="transactions"){
			$this->db->where('user_id',$data['user_id']);
			$data['total_transactions']=$this->db->count_all_results('user_balance_transactions');

			$this->db->where('user_id',$data['user_id']);
			if($data['order_by']=='amount'){
				$this->db->order_by("CAST(amount as decimal)",$data['order_dir']);
			}else{
				$this->db->order_by($data['order_by'],$data['order_dir']);
			}
			$this->db->limit($config['per_page'],$data['page_num']);
			$data['deposits']=$this->db->get('user_balance_transactions')->result();

			$config['base_url'] = site_url('admin_user_log/view/'.$data['user_id'].'/'.$data['action'].'/'.$data['order_by']."/".$data['order_dir']);
			$config['total_rows'] = $data['total_transactions'];
			$config['num_links'] =5;
			$config['uri_segment'] = '7';
			$config['full_tag_open'] = '<div class="pagination"><ul>';
			$config['full_tag_close'] = '</ul></div>';
			$config['cur_tag_open'] = '<li class="active"><a>';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			$config['prev_tag_open'] = '<li class="prev">';
			$config['prev_tag_close'] = '</li>';
			$config['next_tag_open'] = '<li class="next">';
			$config['next_tag_close'] = '</li>';
			$config['last_link']=false;
			$config['first_link']=false;
			$this->pagination->initialize($config);
		}else{
			redirect('admin_users/list_users');
		}

		$data['all_online'] = $this->users->all_online();
		$this->load->view($data['admin_theme'].'/user_log/view', $data);
	}
}
