<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Team extends CI_Controller {
	public function __construct() {
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		parent::__construct();
		$this->load->model('Leagues');
		$this->load->model('Misc');
		$this->load->model('Teams');
		$this->load->model('Events');
		$this->load->model('Players');
		$this->load->model('Drafts');
		$this->users->is_loggedin(1);

	}


	public function index($week='',$stype=1){

		$user = $this->users->get_user($this->users->id());
		$tid = $user->team_id;

		if($week == ""){
			$week = $this->Events->get_week();
		}

		if($week > $this->Events->get_week()){
			$this->alert->set('Week is greater than current schedule!','error');
			redirect('/team/'.$this->Events->get_week());
		}

		$data['stage'] = $stage = $this->Leagues->get_stage();
		$foot['scripts'] = array();
		$head['scripts'] = array('/assets/js/manage.js');
		$data['week'] =  $week;
		$data['team'] = $this->Leagues->get_team_by_id($tid);
		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['season'] = $season = $data['league']->season;
		$data['record'] =  $this->Leagues->get_record($tid);
		$data['season_stats'] =  $this->Leagues->get_season_points($tid);
		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);

		$league = $data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['roster'] = $this->Leagues->get_manage_roster($tid,$week);
		$data['stype'] =  $stype;
		$data['pstats'] =  $this->Teams->get_projected_stats($data['roster'],$week,$season);
		$data['projected'] =  $this->Teams->get_projected_points($data['pstats']);
		$data['matchup'] =  $this->Leagues->get_matchup($tid,$week);


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/team/manage',$data);
		$this->load->view(THEME.'/footer',$foot);

	}
	public function check($week='',$tid){

		if($week == ""){
			$week = $this->Events->get_week();
		}

		if($week > $this->Events->get_week()){
			$this->alert->set('Week is greater than current schedule!','error');
			redirect('/team/'.$tid.'/'.$this->Events->get_week());
		}

		$data['stage'] = $stage = $this->Leagues->get_stage();
		$foot['scripts'] = array();
		$head['scripts'] = array('/assets/js/manage_check.js');
		$data['week'] =  $week;
		$data['team'] = $this->Leagues->get_team_by_id($tid);
		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['season'] = $season = $data['league']->season;
		$data['record'] =  $this->Leagues->get_record($tid);
		$data['season_stats'] =  $this->Leagues->get_season_points($tid);
		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);

		$league = $data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['roster'] = $this->Leagues->get_manage_roster($tid,$week);
		$data['stype'] =  $stype;
		$data['pstats'] =  $this->Teams->get_projected_stats($data['roster'],$week,$season);
		$data['projected'] =  $this->Teams->get_projected_points($data['pstats']);
		$data['matchup'] =  $this->Leagues->get_matchup($tid,$week);


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/team/check',$data);
		$this->load->view(THEME.'/footer',$foot);

	}
	public function update_rosters_cron(){
		set_time_limit ( 10000 );
		ini_set('memory_limit','1000M');
		$week = $this->Events->get_week();
		$week = 2;
		$season = $this->Events->get_season();
		$this->db->where('season',$season);
		//$this->db->limit(10);
		//$this->db->where('id',4);
		$q = $this->db->get("leagues");

		$q = $q->result();

		foreach($q as $league){
			$this->db->where('league_id',$league->id);
			//$this->db->where('user_id','');
			$q = $this->db->get("league_team");
			$q = $q->result();

			foreach($q as $tm){
				if($tm->user_id != ""){
					$this->Leagues->get_manage_roster($tm->id,$week);
				}else{
					$cmd = 'wget -O /dev/null -q '.base_url().'team/cpu_auto_roster/'.$tm->id.'/'.$week.'/1';
					$this->cpu_auto_roster($tm->id,$week,1);
				}

			}


		}


	}
	public function cpu_auto_roster($tid,$week,$magic=0){



		$data['team'] = $this->Leagues->get_team_by_id($tid);
		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['season'] = $season = $data['league']->season;


		$roster = $this->Leagues->cpu_get_manage_roster($tid,$week);
		$player_array = array();

		foreach($roster as $ros){
			foreach($ros as $pos=>$p){
				foreach($p as $pid){

					if(strlen($pid)  == 1){
						continue;
					}
					if(strlen($pid) > 4){
						$pts = $this->Teams->get_proj_row($pid,$week,$season);
						$player = $this->Players->get_by_id($pid);
						$player_array[$pid] = $player;
						$matchup = $this->Players->get_matchup($player,$week,$season);
					}else{
						$pts = $this->Teams->get_proj_row($pid,$week,$season);
			    		$player = $this->Teams->get_by_id($pid);
			    		$player_array[$pid] = $player;
			    		$matchup = $this->Teams->get_matchup($player,$week,$season);
					}
					$tpoints = 0;
					if($matchup['start'] < time() && isset($matchup['start'])){


						if($status == "start"){
							$pts->points = 1000;
						}
					}

					if(isset($pts->points)){
						$tpoints = $pts->points ;
					}

					$team[$player->position][$pid] = $tpoints;
				}
			}
		}

		$default = array('QB','RB','RB','WR','WR','TE','FLEX','K','DEF','FLEX');

		foreach($default as $def){

			if($def == 'FLEX'){
				foreach($team as $t){
					foreach($t as $key=>$tt){
						$pool[$key] = $tt;
					}

				}
			}else{
				$pool = $team[$def];
			}


			arsort($pool);


			foreach($pool as $pid=>$pts){
				$guy = $pid;
				break;
			}

			$newroster[$def][] = $guy;

			if(strlen($guy) > 4){
				$player = $player_array[$guy];
			}else{
	    		$player = $player_array[$guy];
			}

			unset($team[$player->position][$guy]);

		}



		$finalrost['start'] = $newroster;

		foreach($team as $pos=>$blah){
			foreach($blah as $thisid=>$asdf){
				$bench[$pos][] = $thisid;
			}
		}

		$finalrost['bench'] = $bench;

		$data = array(
           'roster' => json_encode($finalrost),
        );


		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);

        $this->db->where('team_id', $tid);
		$this->db->where('week', $week);
		$this->db->update('league_team_rosters', $data);
		echo "<pre>";
		print_r($this->db->last_query());
		echo "</pre>";
		if($magic == 0){

			$this->alert->set('Auto Roster Generated','success');
			$this->load->library('user_agent');
			redirect($this->agent->referrer());

		}
	}
	public function auto_roster($tid,$week,$magic=0){
		$data['team'] = $this->Leagues->get_team_by_id($tid);
		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['season'] = $season = $data['league']->season;


		$roster = $this->Leagues->get_manage_roster($tid,$week);
		if($data['team']->auto == 1){
			$dainfo = array(
               'id' => $data['team']->id,
               'auto' => 0,
            );

			$this->db->where('id', $data['team']->id);
			$this->db->update('league_team', $dainfo);

			$this->alert->set('Auto Roster Paused','success');
			$this->load->library('user_agent');
			redirect($this->agent->referrer());
		}

		foreach($roster as $status=>$ros){
			foreach($ros as $pos=>$p){
				foreach($p as $pid){
					unset($pts);
					if(strlen($pid)  == 1){
						continue;
					}

					$matchup = $this->Teams->get_matchup($player,$week,$season);

					if(strlen($pid) > 4){
						$pts = $this->Teams->get_proj_row($pid,$week,$season);
						$player = $this->Players->get_by_id($pid);
						$matchup = $this->Players->get_matchup($player,$week,$season);
					}else{
						$pts = $this->Teams->get_proj_row($pid,$week,$season);
			    		$player = $this->Teams->get_by_id($pid);
			    		$matchup = $this->Teams->get_matchup($player,$week,$season);
					}


					if($matchup['start'] < time() && isset($matchup['start'])){


						if($status == "start"){
							$pts->points = 1000;
						}
					}

					$tpoints = 0;
					if(isset($pts->points)){
						$tpoints = $pts->points ;
					}

					$team[$player->position][$pid] = $tpoints;
				}
			}
		}

		$default = array('QB','RB','RB','WR','WR','TE','FLEX','K','DEF','FLEX');

		foreach($default as $def){

			if($def == 'FLEX'){
				foreach($team as $t){
					foreach($t as $key=>$tt){
						$pool[$key] = $tt;
					}

				}
			}else{
				$pool = $team[$def];
			}


			arsort($pool);


			foreach($pool as $pid=>$pts){
				$guy = $pid;
				break;
			}

			$newroster[$def][] = $guy;

			if(strlen($guy) > 4){
				$player = $this->Players->get_by_id($guy);
			}else{
	    		$player = $this->Teams->get_by_id($guy);
			}

			unset($team[$player->position][$guy]);

		}



		$finalrost['start'] = $newroster;

		foreach($team as $pos=>$blah){
			foreach($blah as $thisid=>$asdf){
				$bench[$pos][] = $thisid;
			}
		}

		$finalrost['bench'] = $bench;

		$dainfo = array(
           'roster' => json_encode($finalrost),
        );


        $this->db->where('team_id', $tid);
		$this->db->where('week', $week);
		$this->db->update('league_team_rosters', $dainfo);

		if($magic == 0){

			$this->alert->set('Auto Roster Generated','success');
			$this->alert->set('Auto Roster Activated','success');
			if($data['team']->auto == 0){

				$dainfo = array(
	               'id' => $data['team']->id,
	               'auto' => 1,
	            );

				$this->db->where('id', $data['team']->id);
				$this->db->update('league_team', $dainfo);


			}


			$this->load->library('user_agent');
			redirect($this->agent->referrer());

		}
	}
	public function newsmodal($pid){

		$data['player'] =  $this->Players->get_by_id($pid);
		$data['news'] =  $this->Players->get_news($pid);
		$this->load->view(THEME.'/team/manage_news',$data);
	}
	public function update_roster(){


		$week = $_POST['week'];
		$tid = $_POST['tid'];
		$pid = $_POST['pid'];
		$npos = $_POST['npos'];

/*
		$npos = 'WR1';
		$pid = 'b84fb536-9705-45a9-b652-92a33578ac48';
		$week = 7;
		$tid = 1345;
*/

		$posnum = substr($npos, -1);

		if($posnum >= 0 && is_numeric($posnum)){
			$npos = str_ireplace($posnum, '',$npos);
		}
		$posnum = $posnum -1;


		if(strlen($pid) > 4){
			$player = $this->Players->get_by_id($pid);
		}else{
    		$player = $this->Teams->get_by_id($pid);
		}


		$roster = $this->Leagues->get_manage_roster($tid,$week);

		foreach($roster as $ss=>$ros){
			foreach($ros as $pos=>$rost){
				foreach($rost as $key=>$id){
					if($id != $pid){
						$newroster[$ss][$pos][$key] = $id;
					}
				}
			}
		}

		$addtobench = '';

		if($npos == 'BN'){
			$newroster['bench'][$player->pos][] = $pid;
			$addtobench = $pid;
		}else{
			if(isset($newroster['start'][$npos][$posnum])){
				$addtobench = $newroster['start'][$npos][$posnum];
				$newroster['start'][$npos][$posnum] = $pid;
			}else{

				$newroster['start'][$npos][$posnum] = $pid;
			}

		}

		if($addtobench != ""){
			if(strlen($addtobench) > 4){
				$addben = $this->Players->get_by_id($addtobench);
			}else{
	    		$addben = $this->Teams->get_by_id($addtobench);
			}
		}
		if(isset($addben)){
			$newroster['bench'][$addben->position][] = $addben->cid;
		}
		$default = array('QB1','RB1','RB2','WR1','WR2','TE1','FLEX1','FLEX2','K1','DEF1');

		foreach($default as $d){
			$posnum = substr($d, -1);

			$npos = str_ireplace($posnum, '',$d);
			$posnum = $posnum -1;

			if(!isset($newroster['start'][$npos][$posnum])){
				$newroster['start'][$npos][$posnum] = 0;
			}

			$finalrost['start'][$npos][$posnum] = $newroster['start'][$npos][$posnum] ;


		}
		$finalrost['bench'] = $newroster['bench'];
		unset($finalrost['bench']['']);

		$data = array(
           'roster' => json_encode($finalrost),
        );
/*
        echo "<pre>";
        print_r($data);
        echo "</pre>";
		echo "<pre>";
		print_r($finalrost);
		echo "</pre>";echo "test"; die;
*/
		$this->db->where('team_id', $tid);
		$this->db->where('week', $week);
		$this->db->update('league_team_rosters', $data);



	}


}
