<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = 'page/notfound';
$route['translate_uri_dashes'] = FALSE;

//admin
$route['admin'] = 'admin/admin';

// User Routes

$route['login'] = 'user/login';
$route['register'] = 'user/register';
$route['join'] = 'user/register';
$route['logout'] = 'user/logout';
$route['account'] = 'user/my_account';
$route['dashboard'] = 'home/player';

//menu stuff
$route['managemenu'] = "admin/managemenu/menu";
$route['preview/(:any)'] = "admin/displaymenu/preview/$1";

// blog stuff
$route['news'] = "article";
$route['news/all'] = "article/all";
$route['news/view/(:any)'] = "article/view/$1";
$route['news/category/(:any)'] = "article/category/$1";


$route['team/(:num)'] = "team/index/$1";
$route['team/(:num)/(:num)'] = "team/index/$1/$2";
$route['team/(:num)/(:num)/(:num)'] = "team/index/$1/$2/$3";
$route['view/(:any)'] = "page/view/$1";

// lobby stuff
$route['mlobby'] = "lobby/mlobby";
$route['lobby'] = "lobby/lobby";
$route['league/invite'] = "league/create8";

$route['live'] = "mock/draft_board/4806";
