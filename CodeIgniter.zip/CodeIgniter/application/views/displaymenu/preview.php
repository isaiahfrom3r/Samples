<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Menu Display Sample - Quick menu Management</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/quickmenu_menu.css')?>">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
$(function() {
	$('.vertical li:has(ul)').addClass('parent');
	$('.horizontal li:has(ul)').addClass('parent');
});
</script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<h1>Quick Menu Manager</h1>
		<h2 id="link"><a href="<?php echo base_url('/managemenu/menu/'.$id)?>">View Admin</a></h2>
	</div>

	<div id="main">

		<h3>Example 1</h3>
		<?php echo $simple_menu;?>
		<h4>Output:</h4>

		<h3>Example 2</h3>

		<h4>Output:</h4>
		<?php echo $horizontal;?>


		<h3>Example 3</h3>
		<h4>Output:</h4>
		<?php echo $vertical;?>


	</div>


</div>
</body>
</html>
