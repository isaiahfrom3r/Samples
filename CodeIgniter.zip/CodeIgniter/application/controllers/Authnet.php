<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Authnet extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('users');
		$this->load->model('payments');
		$lang=$this->session->userdata('lang');
		$this->lang->load('general', (!empty($lang))?$lang:$this->options->get('default_language'));
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');

	}
	function index(){
		redirect('my_account/add_funds');
	}

	function proccess(){
		$this->load->model('tracked_events');
		$this->load->library('authnet_aim');
		$post_data=$this->input->post();
		$user_id=$this->input->post('user_id');
		if(!empty($post_data)){
			//echo "<pre>".print_R($post_data,true)."</pre>";
			$gateway=$this->payments->get_gateway_by_system_name('authnet');
			$method=$this->payments->get_method_by_gateway_id($gateway->cid);
			$methodx=json_decode($method->data);

			$payment_data=array(
				"x_login"=>$methodx->api_login,
				"x_tran_key"=>$methodx->api_key,
				"x_type"=>"AUTH_CAPTURE",
				"x_amount"=>$this->input->post('amount'),
				"x_card_num"=>str_replace(" ","",$this->input->post('cc_num')),
				"x_exp_date"=>str_replace(" ","",$this->input->post('cc_exp')),
				"x_card_code"=>$this->input->post('cc_security'),
				"x_description"=>"Deposit $".$this->input->post('amount'),
				"x_first_name"=>$this->input->post('first_name'),
				"x_last_name"=>$this->input->post('last_name'),
				"x_address"=>$this->input->post('address'),
				"x_city"=>$this->input->post('city'),
				"x_state"=>$this->input->post('state'),
				"x_zip"=>$this->input->post('zip'),
			);
			//echo "<pre>".print_R($payment_data,true)."</pre>";
			foreach($payment_data as $k=>$v) $this->authnet_aim->add_field($k,$v);
			//$this->authnet_aim->set_test();
			$response_id=$this->authnet_aim->process();

			if($response_id == 1){
				$response=$this->authnet_aim->response;

				//Add transaction to the payment log
				$payment_log=array(
					'user_id'=>$user_id,
					'trans_id'=>$response['Transaction ID'],
					'amount'=>$response['Amount'],
					'type'=>1,
					'status'=>1,
					'approval_code'=>$response['Approval Code'],
					'product_id'=>$this->input->post('item_id'),
					'time'=>time(),
					'method_id'=>$method->cid,
					'raw_return_data'=>json_encode($response)
				);

				$this->db->insert('payments',$payment_log);
				$payment_id = $this->db->insert_id();

				//integrate with user_funds plugin
				$this->load->model('user_funds');
				//add transaction
				//$product_data=json_decode($product->extradata);
				$this->user_funds->add_payment($user_id, $response['Amount'], $payment_id);
				$this->user_funds->apply_sign_up_promos($user_id, $response['Amount']);
				//add promo code stuff
				$promo_code=$this->input->post('promo_code');
				if(isset($promo_code) && !empty($promo_code)){
					if($debug) $debug_mail.="made it to the model function with ".$user_id.",".$promo_code.",".$response['Amount']."\n\n";
					$this->user_funds->apply_promo($user_id,$promo_code,$response['Amount']);
				}

				if( ! $this->tracked_events->check(3, $this->users->id()) ) {
					$this->tracked_events->tracked(3, $this->users->id());
					Analytics::track( $this->users->id(), "First time added funds", array('revenue' => $response['Amount']) );
				}else {
					$this->tracked_events->add(4, $this->users->id());
					Analytics::track( $this->users->id(), "Other time added funds", array('revenue' => $response['Amount']) );
				}

				$this->session->set_userdata('amount_deposit', $response['Amount']);
				$this->session->set_flashdata('success','Deposit Successful');
				redirect('my_account/add_funds/complete');
			}else{
				$response_reason=$this->authnet_aim->get_response_reason_text();
				$this->session->set_flashdata('error',$response_reason);
				redirect('my_account/add_funds');
			}
		}else{
			$this->session->set_flashdata('error','There was an error proccessing your payment, please try again.');
			redirect('my_account/add_funds');
		}
	}

	function process_ajax(){
		$this->load->model('tracked_events');
		$this->load->library('authnet_aim');
		$post_data=$this->input->post();
		$user_id=$this->input->post('user_id');
		if(!empty($post_data)){
			//echo "<pre>".print_R($post_data,true)."</pre>";
			$gateway=$this->payments->get_gateway_by_system_name('authnet');
			$method=$this->payments->get_method_by_gateway_id($gateway->cid);
			$methodx=json_decode($method->data);

			$payment_data=array(
				"x_login"=>$methodx->api_login,
				"x_tran_key"=>$methodx->api_key,
				"x_type"=>"AUTH_CAPTURE",
				"x_amount"=>$this->input->post('amount'),
				"x_card_num"=>str_replace(" ","",$this->input->post('cc_num')),
				"x_exp_date"=>str_replace(" ","",$this->input->post('cc_exp')),
				"x_card_code"=>$this->input->post('cc_security'),
				"x_description"=>"Deposit $".$this->input->post('amount'),
				"x_first_name"=>$this->input->post('first_name'),
				"x_last_name"=>$this->input->post('last_name'),
				"x_zip"=>$this->input->post('zip'),
			);
			//echo "<pre>".print_R($payment_data,true)."</pre>";
			foreach($payment_data as $k=>$v) $this->authnet_aim->add_field($k,$v);
			//$this->authnet_aim->set_test();
			$response_id=$this->authnet_aim->process();

			if($response_id == 1){
				$response=$this->authnet_aim->response;

				//Add transaction to the payment log
				$payment_log=array(
					'user_id'=>$user_id,
					'trans_id'=>$response['Transaction ID'],
					'amount'=>$response['Amount'],
					'type'=>1,
					'status'=>1,
					'approval_code'=>$response['Approval Code'],
					'product_id'=>$this->input->post('item_id'),
					'time'=>time(),
					'method_id'=>$method->cid,
					'raw_return_data'=>json_encode($response)
				);

				$this->db->insert('payments',$payment_log);
				$payment_id = $this->db->insert_id();

				//integrate with user_funds plugin
				$this->load->model('user_funds');
				//add transaction
				//$product_data=json_decode($product->extradata);
				$this->user_funds->add_payment($user_id, $response['Amount'], $payment_id);
				$this->user_funds->apply_sign_up_promos($user_id, $response['Amount']);
				//add promo code stuff
				$promo_code=$this->input->post('promo_code');
				if(isset($promo_code) && !empty($promo_code)){
					if($debug) $debug_mail.="made it to the model function with ".$user_id.",".$promo_code.",".$response['Amount']."\n\n";
					$this->user_funds->apply_promo($user_id,$promo_code,$response['Amount']);
				}

				if( ! $this->tracked_events->check(3, $this->users->id()) ) {
					$this->tracked_events->tracked(3, $this->users->id());
					Analytics::track( $this->users->id(), "First time added funds", array('revenue' => $response['Amount']) );
				}else {
					$this->tracked_events->add(4, $this->users->id());
					Analytics::track( $this->users->id(), "Other time added funds", array('revenue' => $response['Amount']) );
				}

				$this->session->set_userdata('amount_deposit', $response['Amount']);
				echo json_encode(array("status"=>"tiptop"));
			}else{
				$response_reason=$this->authnet_aim->get_response_reason_text();
				$this->session->set_flashdata('error',$response_reason);
				echo json_encode(array("status"=>"bogus","message"=>$response_reason));
			}
		}else{
			$this->session->set_flashdata('error','There was an error proccessing your payment, please try again.');
			echo json_encode(array("status"=>"bogus","message"=>"There was an error proccessing your payment, please try again."));
		}
	}
	/******************************************************
		CHECKOUT

	*******************************************************/
	function checkout()
	{
		$gateway = $this->registrations->get_payment_gateway('authnet');
		/*$pkgs = json_decode($gateway->packages);
		$data['pkgs'] = $pkgs;*/
		$this->load->model('packages');
		$data['packages']=$this->packages->get_all(true);

		$data['theme'] = $this->options->get('theme');
		$data['title'] = vlang('registration_payment_title');
		$data['body'] = '';
		$reg_step_data = $this->registrations->get_step_by_name('Payment Information');
		$this->load->library('authnet_arb');

		$this->form_validation->set_rules('package', 'Package', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('first_name', 'First Name', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('cc_number', 'Credit Card', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('cc_exp_month', 'Expiration month', 'required|min_length[2]|max_length[2]|xss_clean');
		$this->form_validation->set_rules('cc_exp_year', 'Expiration year', 'required|min_length[4]|max_length[4]|xss_clean');
		$this->form_validation->set_rules('cc_ccv', 'CCV is required', 'required|max_length[4]|xss_clean');
		$this->form_validation->set_rules('cc_address', 'Billing street address', 'required|max_length[128]|xss_clean');
		$this->form_validation->set_rules('cc_city', 'Billing city', 'required|max_length[128]|xss_clean');
		$this->form_validation->set_rules('cc_state', 'Billing state', 'required|max_length[2]');
		$this->form_validation->set_rules('cc_zip', 'Billing zip', 'required|max_length[8]|xss_clean');
		$this->form_validation->set_rules('checkbox_terms', 'Terms and Conditions', 'required|xss_clean');
		$this->form_validation->set_rules('checkbox_approval', 'Approval', 'required|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			//Get Method Info
			$method_id=$this->uri->segment(3);
			$method=$this->payments->get_method_by_id($method_id);
			$methodx=json_decode($method->data);

			if($methodx->test_mode==1){
				$this->authnet_arb->set_test();
			}

			$package=$this->packages->get_by_id($this->input->post('package'));
			$pkg_extra=json_decode($package->extradata);
			//Put data into an array
			$payment_data=array(
				"loginname"=>$methodx->api_login,
				"transactionkey"=>$methodx->api_key,
				"amount"=>round($package->price / ($pkg_extra->duration_months-$pkg_extra->trialOccurrences),2),
				"refId"=>$package->cid,
				"name"=>$package->name,
				"length"=>$pkg_extra->length,
				"unit"=>$pkg_extra->unit,
				"startDate"=>date('Y-m-d',time()),
				"totalOccurrences"=>$pkg_extra->duration_months,
				"trialOccurrences"=>$pkg_extra->trialOccurrences,
				"trialAmount"=>$pkg_extra->trialAmount,
				"cardNumber"=>$this->input->post('cc_number'),
				"expirationDate"=>$this->input->post('cc_exp_year')."-".$this->input->post('cc_exp_month'),
				"cardCode"=>$this->input->post('cc_ccv'),
				"firstName"=>$this->input->post('first_name'),
				"lastName"=>$this->input->post('last_name'),
				"address"=>$this->input->post('cc_address'),
				"city"=>$this->input->post('cc_city'),
				"state"=>$this->input->post('cc_state'),
				"zip"=>$this->input->post('cc_zip'),
			);

			$result = $this->authnet_arb->create_subscription($payment_data);

			if (!$result['success'])
			{
				if(isset($result['text']) && !empty($result['text'])){
					$this->session->set_flashdata('error',$result['text']);
				}else{
					$this->session->set_flashdata('error','Could not process transaction');
				}
				redirect('authnet/checkout/'.$method_id);
			}
			else
			{
				//echo '<pre>'.print_r($this->authnet_aim->response,true).'</pre>';exit;

				$reg_data = array();
				$reg_data = $this->session->userdata('reg_data');
				unset($reg_data[$reg_step_data->name]);

				$reg_data[$reg_step_data->name]['transaction']['trans_id'] = $result['subscription_id'];
				$reg_data[$reg_step_data->name]['transaction']['amount'] = $package->price;
				$reg_data[$reg_step_data->name]['transaction']['status'] = 'p';
				$reg_data[$reg_step_data->name]['transaction']['approval_code'] = $this->authnet_aim->response['Approval Code'];
				$reg_data[$reg_step_data->name]['transaction']['time'] = time();
				$reg_data[$reg_step_data->name]['transaction']['method_id'] = $method_id;
				$reg_data[$reg_step_data->name]['transaction']['billing_firstname'] = $this->input->post('first_name');
				$reg_data[$reg_step_data->name]['transaction']['billing_lastname'] = $this->input->post('last_name');
				$reg_data[$reg_step_data->name]['transaction']['billing_address'] = $this->input->post('cc_address');
				$reg_data[$reg_step_data->name]['transaction']['billing_address2'] = null;
				$reg_data[$reg_step_data->name]['transaction']['billing_city'] = $this->input->post('cc_city');
				$reg_data[$reg_step_data->name]['transaction']['billing_state'] = $this->input->post('cc_state');
				$reg_data[$reg_step_data->name]['transaction']['billing_zip'] = $this->input->post('cc_zip');
				$reg_data[$reg_step_data->name]['transaction']['card_type'] = $this->check_cc($this->input->post('cc_number'));
				$reg_data[$reg_step_data->name]['transaction']['last4'] = substr($this->input->post('cc_number'),-4,4);


				$package=$this->packages->get_by_id($this->input->post('package'));
				$pkg_extra=json_decode($package->extradata);

				$subscription_data=array(
					"subscription_id"=>(int)$result['subscription_id'],
					"start_date"=>(int)strtotime($payment_data["startDate"]),
					"num_occurances"=>$payment_data["totalOccurrences"],
				);
				$reg_data[$reg_step_data->name]['subscription'] = json_encode($subscription_data);
				$reg_data[$reg_step_data->name]['free_account'] = 0;
				$reg_data[$reg_step_data->name]['status'] = 1;
				$reg_data[$reg_step_data->name]['pay_method'] = $method_id;
				$reg_data[$reg_step_data->name]['membership_package'] = $package->cid;
				$reg_data[$reg_step_data->name]['expires'] = date('U', strtotime('+ '.$pkg_extra->duration_months.' months'));

				//replace with new reg data
				$this->session->unset_userdata('reg_data');
				$this->session->set_userdata('reg_data', $reg_data);
				//get the next in order step for redirect
				$next_step = $this->registrations->get_next_step($reg_step_data->order);
				redirect($next_step->url_handler);
			}
		}
		$data['payfields']=array('package','first_name','last_name','cc_number','cc_exp_month','cc_exp_year',
		'cc_ccv','cc_address','cc_city','cc_state','cc_zip','checkbox_terms','checkbox_approval');

		$this->load->view($data['theme'].'/registration/payment', $data);
	}

	/******************************************************
		SETUP METHOD

	*******************************************************/
	function setup(){
		$this->users->auth_check();
		$this->users->is_admin_check();
		$data['admin_theme'] = $this->options->get('admin_theme');
		$data['active_menu'] = 'payment';
		$data['title'] = 'Setup Authorize.net ARB';
		$data['body'] = '';
		$data['all_online'] = $this->users->all_online();

		$data['fields']=array(
			"name"=>array(
						"label"=>"Name",
						"type"=>"text",
						"default"=>"Authorize.net",
						"required"=>1
					),
			"description"=>array(
						"label"=>"Description",
						"type"=>"textarea",
						"default"=>"Authorize.net",
						"required"=>0
					),
			"api_login"=>array(
						"label"=>"API Login",
						"type"=>"text",
						"default"=>"",
						"required"=>1
					),
			"api_key"=>array(
						"label"=>"API Key",
						"type"=>"text",
						"default"=>"",
						"required"=>1
					),
			"test_mode"=>array(
						"label"=>"Test Mode",
						"type"=>"select",
						"default"=>"",
						"required"=>1,
						"values"=>array(0=>"Off",1=>"On"),
					),
		);

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('description', 'Description','');
		$this->form_validation->set_rules('api_login', 'API Login', 'required');
		$this->form_validation->set_rules('api_key', 'API Key', 'required');
		$this->form_validation->set_rules('test_mode', 'Test Mode', 'required');

		if ($this->form_validation->run() == FALSE)
		{
		}
		else
		{
			$paypal_pro_id=$this->payments->get_gateway_by_sys_name('authnet');
			$paypal_pro_id=$paypal_pro_id->cid;
			$data=array(
				'api_login'=>$this->input->post('api_login'),
				'api_key'=>$this->input->post('api_key'),
				'test_mode'=>$this->input->post('test_mode'),
			);
			$insert=array(
				'name'=>$this->input->post('name'),
				'description'=>$this->input->post('description'),
				'type_id'=>$paypal_pro_id,
				'data'=>json_encode($data)
			);
			$this->payments->create_method($insert);

			$this->session->set_flashdata('success','Payment Method Created');
			redirect('admin_payment/show_gateways');
		}

		$this->load->view($data['admin_theme'].'/payments/method_setup', $data);
	}
	/******************************************************
		EDIT METHOD PROPERTIES

	*******************************************************/
	function edit(){
		$this->users->auth_check();
		$this->users->is_admin_check();
		$data['admin_theme'] = $this->options->get('admin_theme');
		$data['active_menu'] = 'payment';
		$data['title'] = 'Setup Authorize.net AIM';
		$data['body'] = '';
		$data['all_online'] = $this->users->all_online();

		$id=$this->uri->segment(3);

		$data['method_data']=$this->payments->get_method_by_id($id);
		$data['method_extradata']=json_decode($data['method_data']->data);

		$data['fields']=array(
			"name"=>array(
						"label"=>"Name",
						"type"=>"text",
						"default"=>$data['method_data']->name,
						"required"=>1
					),
			"description"=>array(
						"label"=>"Description",
						"type"=>"textarea",
						"default"=>$data['method_data']->description,
						"required"=>0
					),
			"api_login"=>array(
						"label"=>"API Login",
						"type"=>"text",
						"default"=>$data['method_extradata']->api_login,
						"required"=>1
					),
			"api_key"=>array(
						"label"=>"API Key",
						"type"=>"text",
						"default"=>$data['method_extradata']->api_key,
						"required"=>1
					),
			"test_mode"=>array(
						"label"=>"Test Mode",
						"type"=>"select",
						"default"=>$data['method_extradata']->test_mode,
						"required"=>1,
						"values"=>array(0=>"Off",1=>"On"),
					),
		);

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('description', 'Description','');
		$this->form_validation->set_rules('api_login', 'API Login', 'required');
		$this->form_validation->set_rules('api_key', 'API Key', 'required');
		$this->form_validation->set_rules('test_mode', 'Test Mode', 'required');

		if ($this->form_validation->run() == FALSE){
		}else{
			$paypal_pro_id=$this->payments->get_gateway_by_sys_name('authnet');
			$paypal_pro_id=$paypal_pro_id->cid;
			$data=array(
				'api_login'=>$this->input->post('api_login'),
				'api_key'=>$this->input->post('api_key'),
				'test_mode'=>$this->input->post('test_mode'),
			);
			$insert=array(
				'name'=>$this->input->post('name'),
				'description'=>$this->input->post('description'),
				'type_id'=>$paypal_pro_id,
				'data'=>json_encode($data)
			);
			$this->payments->update_method($id,$insert);

			$this->session->set_flashdata('success','Payment Method Edited');
			redirect('admin_payment/show_gateways');
		}
		$this->load->view($data['admin_theme'].'/payments/method_setup', $data);
	}
	/******************************************************
		CHECK CC
		takes in a a credit card number returns type of credit
		card if it is a known type, or false if it's invalid.

	*******************************************************/
	function check_cc($cc, $extra_check = false){
		$cards = array(
			"visa" => "(4\d{12}(?:\d{3})?)",
			"amex" => "(3[47]\d{13})",
			"discover" => "(6(?:011|5[0-9]{2})[0-9]{12})",
			"jcb" => "((?:2131|1800|35\d{3})\d{11})",
			"maestro" => "((?:5020|5038|6304|6579|6761)\d{12}(?:\d\d)?)",
			"solo" => "((?:6334|6767)\d{12}(?:\d\d)?\d?)",
			"mastercard" => "(5[1-5]\d{14})",
			"switch" => "(?:(?:(?:4903|4905|4911|4936|6333|6759)\d{12})|(?:(?:564182|633110)\d{10})(\d\d)?\d?)",
		);
		$names = array("Visa", "Amex","Discover", "JCB", "Maestro", "Solo", "MasterCard", "Switch");
		$matches = array();
		$pattern = "#^(?:".implode("|", $cards).")$#";
		$result = preg_match($pattern, str_replace(" ", "", $cc), $matches);
		if($extra_check && $result > 0){
			$result = (validatecard($cc))?1:0;
		}
		return ($result>0)?$names[sizeof($matches)-2]:false;
	}
	/******************************************************
		RENEW
		Allows the user to renew their subscription

	*******************************************************/
	function renew(){
		$data['theme'] = $this->options->get('theme');
		$data['title'] = vlang('settings_payment_title');
		$data['body'] = '';
		$data['user'] = $this->users->build_from_session();
		$this->load->library('authnet_arb');

		$user_id=$data['user']['cid'];
		$user_email=$data['user']['email'];

		$this->load->model('packages');
		$data['packages']=$this->packages->get_all(true);
		$this->db->where('user_id',$data['user']['cid']);
		$data['payment_profile']=$this->db->get('payment_profile');
		$data['payment_profile']=$data['payment_profile']->row();

		$this->form_validation->set_rules('package', 'Package', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('first_name', 'First Name', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('cc_number', 'Credit Card', 'required|max_length[256]|xss_clean');
		$this->form_validation->set_rules('cc_exp_month', 'Expiration month', 'required|min_length[2]|max_length[2]|xss_clean');
		$this->form_validation->set_rules('cc_exp_year', 'Expiration year', 'required|min_length[4]|max_length[4]|xss_clean');
		$this->form_validation->set_rules('cc_ccv', 'CCV is required', 'required|max_length[4]|xss_clean');
		$this->form_validation->set_rules('cc_address', 'Billing street address', 'required|max_length[128]|xss_clean');
		$this->form_validation->set_rules('cc_city', 'Billing city', 'required|max_length[128]|xss_clean');
		$this->form_validation->set_rules('cc_state', 'Billing state', 'required|max_length[2]');
		$this->form_validation->set_rules('cc_zip', 'Billing zip', 'required|max_length[8]|xss_clean');

		if ($this->form_validation->run() == FALSE){

		}else{
			//Get Method Info
			$method_id=$this->uri->segment(3);
			$method=$this->payments->get_method_by_id($method_id);
			$methodx=json_decode($method->data);

			$user=$this->users->get_by_id($this->users->ID());
			$expires=$user->expires;
			$subscription_details=json_decode($user->subscription,true);

			if($methodx->test_mode==1){
				$this->authnet_arb->set_test();
			}

			$package=$this->packages->get_by_id($this->input->post('package'));
			$pkg_extra=json_decode($package->extradata);
			//Put data into an array
			$payment_data=array(
				"loginname"=>$methodx->api_login,
				"transactionkey"=>$methodx->api_key,
				"amount"=>round($package->price / ($pkg_extra->duration_months-$pkg_extra->trialOccurrences),2),
				"refId"=>$package->cid,
				"name"=>$package->name,
				"cardNumber"=>$this->input->post('cc_number'),
				"expirationDate"=>$this->input->post('cc_exp_year')."-".$this->input->post('cc_exp_month'),
				"cardCode"=>$this->input->post('cc_ccv'),
				"firstName"=>$this->input->post('first_name'),
				"lastName"=>$this->input->post('last_name'),
				"address"=>$this->input->post('cc_address'),
				"city"=>$this->input->post('cc_city'),
				"state"=>$this->input->post('cc_state'),
				"zip"=>$this->input->post('cc_zip'),
			);
			//If there's an existing subscription add some occurances, otherwise set up a new subscription.
			if($expires<time() || !isset($subscription_details->subscription_id)){
				//If the trial is the for new signup only adjust some stuff
				if($pkg_extra->trialfirstrunonly==1){
					$payment_data["totalOccurrences"]=$pkg_extra->duration_months-$pkg_extra->trialOccurrences;
					$payment_data["trialOccurrences"]=0;
					$payment_data["trialAmount"]=0;
				}else{
					$payment_data["totalOccurrences"]=$pkg_extra->duration_months;
					$payment_data["trialOccurrences"]=$pkg_extra->trialOccurrences;
					$payment_data["trialAmount"]=$pkg_extra->trialAmount;
				}
				$payment_data["length"]=$pkg_extra->length;
				$payment_data["unit"]=$pkg_extra->unit;
				$payment_data["startDate"]=date('Y-m-d',time());
				$result = $this->authnet_arb->create_subscription($payment_data);
			}else{
				$subscription=json_decode($user->subscription);
				$payment_data["totalOccurrences"]=$subscription->num_occurances+($pkg_extra->duration_months-$pkg_extra->trialOccurrences);
				$payment_data["subscriptionId"]=$subscription->subscription_id;
				//echo "<pre>".print_R($payment_data,true)."</pre>";exit();
				$result = $this->authnet_arb->update_subscription($payment_data);
			}
			//Run it!


			if (!$result['success'])
			{
				if(isset($result['text']) && !empty($result['text'])){
					$this->session->set_flashdata('error',$result['text']);
				}else{
					$this->session->set_flashdata('error','Could not process transaction');
				}
				redirect('authnet/renew/'.$method_id);
			}
			else
			{
				//Add transaction to the payment log
				$trans_data['user_id'] = $this->users->ID();
				$trans_data['product_id'] = $this->input->post('package');
				$trans_data['trans_id'] = $result['subscription_id'];
				$trans_data['amount'] = $package->price;
				$trans_data['status'] = 'p';
				$trans_data['approval_code'] = $result['subscription_id'];
				$trans_data['time'] = time();
				$trans_data['method_id'] = $method_id;
				$trans_data['billing_firstname'] = $this->input->post('first_name');
				$trans_data['billing_lastname'] = $this->input->post('last_name');
				$trans_data['billing_address'] = $this->input->post('cc_address');
				$trans_data['billing_address2'] = null;
				$trans_data['billing_city'] = $this->input->post('cc_city');
				$trans_data['billing_state'] = $this->input->post('cc_state');
				$trans_data['billing_zip'] = $this->input->post('cc_zip');
				$trans_data['card_type'] = $this->check_cc($this->input->post('cc_number'));
				$trans_data['last4'] = substr($this->input->post('cc_number'),-4,4);

				$this->db->insert('payments',$trans_data);

				//Set package and update expiration in user table
				$package=$this->packages->get_by_id($this->input->post('package'));
				$pkg_extra=json_decode($package->extradata);

				$subscription_details=json_decode($user->subscription,true);

				if($expires<time() || !isset($subscription_details->subscription_id)){
					$subscription_data=array(
						"subscription_id"=>(int)$result['subscription_id'],
						"start_date"=>(int)strtotime($payment_data["startDate"]),
						"num_occurances"=>$payment_data["totalOccurrences"],
					);
					if($pkg_extra->trialfirstrunonly==1){
						$expires= time() + ((((($pkg_extra->duration_months-$pkg_extra->trialOccurrences)*$pkg_extra->length)*24)*60)*60);
					}else{
						$expires= time() + ((((($pkg_extra->duration_months)*$pkg_extra->length)*24)*60)*60);
					}
				}else{
					$subscription_data=json_decode($user->subscription,true);
					if($pkg_extra->trialfirstrunonly==1){
						$expires+=((((($pkg_extra->duration_months-$pkg_extra->trialOccurrences)*$pkg_extra->length)*24)*60)*60);
						$subscription_data["num_occurances"]+=($pkg_extra->duration_months-$pkg_extra->trialOccurrences);
					}else{
						$expires+=((((($pkg_extra->duration_months)*$pkg_extra->length)*24)*60)*60);
						$subscription_data["num_occurances"]+=$pkg_extra->duration_months;
					}
				}

				$userdata['membership_package'] = $package->cid;
				$userdata['expires'] = $expires;
				$userdata['pay_method'] = $method_id;

				$userdata['subscription'] = json_encode($subscription_data);

				$this->db->where('cid',$this->users->ID());
				$this->db->update('users',$userdata);

				$this->session->set_flashdata('success',vlang('setting_payment_renew_success'));
				redirect('setting/payment_details');
			}
		}
		$data['payfields']=array('package','first_name','last_name','cc_number','cc_exp_month','cc_exp_year',
		'cc_ccv','cc_address','cc_city','cc_state','cc_zip');

		$this->load->view($data['theme'].'/registration/payment_renew', $data);
	}
	/******************************************************
		UNSUBSCRIBE
		Allows the user to cancel their subscription

	*******************************************************/
	function unsubscribe(){
		$this->load->model('packages');
		$this->load->library('authnet_arb');
		//Get A Bunch of Info
		$method_id=$this->uri->segment(3);
		$method=$this->payments->get_method_by_id($method_id);
		$methodx=json_decode($method->data);

		if($methodx->test_mode==1){
			$this->authnet_arb->set_test();
		}

		$user=$this->users->get_by_id($this->users->ID());
		$subscription=json_decode($user->subscription);
		$package=$this->packages->get_by_id($user->membership_package);
		$package_xtra=json_decode($package->extradata);


		//Deal with authnet
		$payment_data=array(
				"loginname"=>$methodx->api_login,
				"transactionkey"=>$methodx->api_key,
				"subscriptionId"=>$subscription->subscription_id
		);

		$result=$this->authnet_arb->cancel_subscription($payment_data);

		if (!$result['success']){
			$this->session->set_flashdata('error', $result['text']);
			redirect('setting/payment_details');
		}else{
			//Get the new expiration date (just before next payment)
			$newexpiration=0;
			for($i=1;$i<=$subscription->num_occurances;$i++){
				$tempexpiration = $subscription->start_date + ($i * $package_xtra->length * 24*60*60);
				if($tempexpiration > time() && $newexpiration==0){
					$newexpiration=$tempexpiration;
				}
			}
			//Update user data
			$userdata=array(
				'subscription'=>json_encode(array()),
				'expires'=>$newexpiration
			);
			$this->db->limit(1);
			$this->db->where('cid',$this->users->ID());
			$this->db->update('users', $userdata);

			$this->session->set_flashdata('success', 'You\'re Unsubscribed!');
			redirect('setting/payment_details');
		}
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
