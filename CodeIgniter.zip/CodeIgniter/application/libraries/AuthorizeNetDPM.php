<?php
/**
 * Demonstrates the Direct Post Method.
 *
 * To implement the Direct Post Method you need to implement 3 steps:
 *
 * Step 1: Add necessary hidden fields to your checkout form and make your form is set to post to AuthorizeNet.
 *
 * Step 2: Receive a response from AuthorizeNet, do your business logic, and return
 *         a relay response snippet with a url to redirect the customer to.
 *
 * Step 3: Show a receipt page to your customer.
 *
 * This class is more for demonstration purposes than actual production use.
 *
 *
 * @package    AuthorizeNet
 * @subpackage AuthorizeNetDPM
 */

/**
 * A class that demonstrates the DPM method.
 *
 * @package    AuthorizeNet
 * @subpackage AuthorizeNetDPM
 */
class AuthorizeNetDPM extends AuthorizeNetSIM_Form
{

    const LIVE_URL = 'https://secure2.authorize.net/gateway/transact.dll';
    const SANDBOX_URL = 'https://test.authorize.net/gateway/transact.dll';

    /**
     * Implements all 3 steps of the Direct Post Method for demonstration
     * purposes.
     */
    public static function directPostDemo($url, $api_login_id, $transaction_key, $amount = "0.00", $md5_setting = "")
    {

        // Step 1: Show checkout form to customer.
        if (!count($_POST) && !count($_GET))
        {
            $fp_sequence = time(); // Any sequential number like an invoice number.
            echo AuthorizeNetDPM::getCreditCardForm($amount, $fp_sequence, $url, $api_login_id, $transaction_key);
        }
        // Step 2: Handle AuthorizeNet Transaction Result & return snippet.
        elseif (count($_POST))
        {
            $response = new AuthorizeNetSIM($api_login_id, $md5_setting);
            if ($response->isAuthorizeNet())
            {
                if ($response->approved)
                {
                    // Do your processing here.
                    $redirect_url = $url . '?response_code=1&transaction_id=' . $response->transaction_id;
                }
                else
                {
                    // Redirect to error page.
                    $redirect_url = $url . '?response_code='.$response->response_code . '&response_reason_text=' . $response->response_reason_text;
                }
                // Send the Javascript back to AuthorizeNet, which will redirect user back to your site.
                echo AuthorizeNetDPM::getRelayResponseSnippet($redirect_url);
            }
            else
            {
                echo "Error -- not AuthorizeNet. Check your MD5 Setting.";
            }
        }
        // Step 3: Show receipt page to customer.
        elseif (!count($_POST) && count($_GET))
        {
            if ($_GET['response_code'] == 1)
            {
                echo "Thank you for your purchase! Transaction id: " . htmlentities($_GET['transaction_id']);
            }
            else
            {
              echo "Sorry, an error occurred: " . htmlentities($_GET['response_reason_text']);
            }
        }
    }

    /**
     * A snippet to send to AuthorizeNet to redirect the user back to the
     * merchant's server. Use this on your relay response page.
     *
     * @param string $redirect_url Where to redirect the user.
     *
     * @return string
     */
    public static function getRelayResponseSnippet($redirect_url)
    {
        return "<html><head><script language=\"javascript\">
                <!--
                window.location=\"{$redirect_url}\";
                //-->
                </script>
                </head><body><noscript><meta http-equiv=\"refresh\" content=\"1;url={$redirect_url}\"></noscript></body></html>";
    }

    /**
     * Generate a sample form for use in a demo Direct Post implementation.
     *
     * @param string $amount                   Amount of the transaction.
     * @param string $fp_sequence              Sequential number(ie. Invoice #)
     * @param string $relay_response_url       The Relay Response URL
     * @param string $api_login_id             Your API Login ID
     * @param string $transaction_key          Your API Tran Key.
     * @param bool   $test_mode                Use the sandbox?
     * @param bool   $prefill                  Prefill sample values(for test purposes).
     *
     * @return string
     */
    public static function getCreditCardForm($amount, $fp_sequence, $relay_response_url, $api_login_id, $transaction_key, $test_mode = true, $prefill = true,$uid=0)
    {
        $time = time();
        $fp = self::getFingerprint($api_login_id, $transaction_key, $amount, $fp_sequence, $time);
        $sim = new AuthorizeNetSIM_Form(
            array(
            'x_amount'        => $amount,
            'x_fp_sequence'   => $fp_sequence,
            'x_fp_hash'       => $fp,
            'x_fp_timestamp'  => $time,
            'x_relay_response'=> "TRUE",
            'x_relay_url'     => $relay_response_url,
            'x_login'         => $api_login_id,
            )
        );
        $hidden_fields = $sim->getHiddenFieldString();
        $post_url = ($test_mode ? self::SANDBOX_URL : self::LIVE_URL);

        $form = '
        <style>
               </style>
        <form method="post" action="'.$post_url.'">
                '.$hidden_fields.'
            <fieldset>
                <div class="col-md-12">
                    <label>Credit Card Number</label>
                    <input type="hidden" class="text form-control"  placeholder="Card Number" name="x_user_id" value="'.$uid.'"></input>
                    <input type="text" class="text form-control"  placeholder="Card Number" name="x_card_num" value="'.($prefill ? '6011000000000012' : '').'"></input>
                </div>
                <div class="col-md-6">
                    <label>Exp.</label>
                    <input type="text" class="text form-control"  name="x_exp_date" placeholder="MM/YY" value="'.($prefill ? '04/17' : '').'"></input>
                </div>
                <div class="col-md-6">
                    <label>CCV</label>
                    <input type="text" class="text form-control"  name="x_card_code" placeholder="CVC" value="'.($prefill ? '782' : '').'"></input>
                </div>
            </fieldset>
            <fieldset>
                <div class="col-md-6">
                    <label>First Name</label>
                    <input type="text" class="text form-control"  name="x_first_name" placeholder="First" value="'.($prefill ? 'John' : '').'"></input>
                </div>
                <div class="col-md-6">
                    <label>Last Name</label>
                    <input type="text" class="text form-control"  name="x_last_name" placeholder="Last" value="'.($prefill ? 'Doe' : '').'"></input>
                </div>
            </fieldset>
            <fieldset>
                <div class="col-md-6">
                    <label>Address</label>
                    <input type="text" class="text form-control"  name="x_address" placeholder="Address" value="'.($prefill ? '123 Main Street' : '').'"></input>
                </div>
                <div class="col-md-6">
                    <label>City</label>
                    <input type="text" class="text form-control"  name="x_city" placeholder="City" value="'.($prefill ? 'Boston' : '').'"></input>
                </div>
            </fieldset>
            <fieldset>
                <div class="col-md-6">
                    <label>State</label>
                    <input type="text" class="text form-control"  name="x_state" placeholder="State" value="'.($prefill ? 'MA' : '').'"></input>
                </div>
                <div class="col-md-6">
                    <label>Zip Code</label>
                    <input type="text" class="text form-control"  name="x_zip" placeholder="Zip" value="'.($prefill ? '02142' : '').'"></input>
                </div>
                <div class="col-md-12">
                    <label>Country</label>
                    <input type="text" class="text form-control"  name="x_country" placeholder="Country" value="'.($prefill ? 'US' : '').'"></input>
                </div>
            </fieldset>
            <br>
            <input type="submit" value="BUY" class="submit  form-controll buy btn btn-info">
        </form>';
        return $form;
    }

}
