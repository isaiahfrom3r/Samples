<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->model('Teams');
		$this->load->model('Users');
		$this->load->model('Leagues');
		$this->load->model('Brackets');
	}
	public function score_director(){

		$season = $this->options->get('season');
		$this->db->where('season',$season);
		$q = $this->db->get("leagues");
		$q = $q->result();

		foreach($q as $lg){
			$this->score_league($lg->cid);
		}

	}
	public function score_league($lid=0){

		if($lid == 0){
			echo "No League Selected"; return ;
		}
		$data['league'] =  $league = $this->Leagues->get_league_by_id($lid);
		$data['bracket'] =  $bracket =  $this->Brackets->get_bracket();
		$data['bracket'] =  $bracket =  json_decode($bracket->bracket,true);





		foreach($bracket as $group=>$b){
			foreach($b as $round=>$bb){
				foreach($bb as $key=>$game){
					$seeds[$game['home']] = $game['home_team_seed'];
					$seeds[$game['away']] = $game['away_team_seed'];
/*
					if($round != 1  ){
						$bracket[$group][$round][$key]['home'] = "";
						$bracket[$group][$round][$key]['home_team_score'] = "";
						$bracket[$group][$round][$key]['away_team_score'] = "";
						$bracket[$group][$round][$key]['away'] = "";
						$bracket[$group][$round][$key]['away_team_seed'] = "";
						$bracket[$group][$round][$key]['home_team_seed'] = "";
					}
*/

				}
			}
		}



		foreach($bracket as $group=>$b){
			foreach($b as $round=>$bb){
				foreach($bb as $key=>$m){

				if($m['final'] == 1){
					if($m['home_team_score'] > $m['away_team_score']){
						$winner = $m['home'];
					}else{
						$winner = $m['away'];
					}
				}else{
					$winner = "";
				}

				$results[$group][$round][$key] = $winner;


				}
			}
		}



		// grab all brackets first set the duds
/*
		$this->db->where('LENGTH(picks) < ', 1, FALSE);
		$this->db->where('league_id',$league->cid);
		$this->db->or_where('league_id',$league->cid);
		$this->db->where('picks',NULL);
		$q = $this->db->get("league_team");
		$teams = $q->result();
*/

/*
		foreach($teams as $tm){
			if($tm->picks == ""){


				$this->Leagues->save_default_picks($league,$bracket,$tm->user_id);

			}
		}
*/


		// get the rest now
		$this->db->where('picks != ',"");
		$this->db->where('picks != ',null);
		$this->db->where('league_id',$league->cid);
		$q = $this->db->get("league_team");
		$teams = $q->result();


		$scoring = array(
			'1' => 1,
			'2' => 2,
			'3' => 4,
			'4' => 8,
			'5' => 16,
			'6' => 32,
		);

		$champ = $bracket['finals'][6][0];
		$act_tbpts = $this->options->get('total_points_tb');
		$act_tbrbds = $this->options->get('total_rebounds_tb');
		// total_points_tb   --   total_rebounds_tb
		$points = array();
		foreach($teams as $tm){
			$upicks = json_decode($tm->picks,true);
			$points[$tm->id]['total'] = 0;

			foreach($upicks as $group=>$b){
				foreach($b as $round=>$bb){
					// error prevention
					if(!isset($points[$tm->id][$round])){
						$points[$tm->id][$round] = 0;
					}
					foreach($bb as $key=>$m){


						if($results[$group][$round][$key] != ""){
							if($m == $results[$group][$round][$key]){
								$val = $scoring[$round];
							}else{
								$val = 0;
							}



							$points[$tm->id][$round] += $val;
							$points[$tm->id]['total'] += $val;
						}




					}
				}
			}





			if($champ['final'] == 1){


				$tbpts = $act_tbpts - $tm->tb1;
				$tbrbds = $act_tbrbds - $tm->tb2;


				// don't care about possitive or negative;
				if($tbpts < 0){
					$tbpts = $tbpts * -1;
				}

				if($tbrbds < 0){
					$tbrbds = $tbrbds * -1;
				}



			}else{
				$tbpts = 0;
				$tbrbds = 0;
			}



			$total =  $points[$tm->id]['total'];

			$finals[$total][$tbpts][$tbrbds][$tm->id] = $points[$tm->id];

		}

		if(empty($finals)){
			return ;
		}
		krsort($finals);

		foreach($finals as $total=>$fpoints){


			ksort($fpoints);
			$finals[$total] = $fpoints;
			foreach($fpoints as $key1=>$next){
				ksort($next);
				$finals[$total][$key1] = $next;
				foreach($next as $key2=>$people){
					ksort($people);
					$finals[$total][$key1][$key2] = $people;


				}
			}
		}
		$rank =1;
		foreach($finals as $total=>$fpoints){
			foreach($fpoints as $key1=>$next){
				foreach($next as $key2=>$people){
					foreach($people as $tid=>$p){

						$standings_update = array(
							'score' => $p['total'],
							'rank' => $rank,
						);
						$rank++;



						$this->db->where('team_id', $tid);
						$this->db->where('league_id', $league->cid);
						$this->db->update('league_standings', $standings_update);

					}

				}
			}
		}





	}

	public function create_fluf_scoring() {
	echo "test"; die;
			$q = $this->db->get("leagues");
			$q = $q->result();

			foreach($q as $lg){
				$field =  $this->Leagues->get_league_teams($lg->cid);

				$count = 0;
				foreach($field as $rank=>$tm){

					$count++;
					$data = array(
		               'rank' => $count,
		               'score' => rand(33,190),
		               'team_id' => $tm->id,
		               'league_id' => $lg->cid,
		            );


					$this->db->insert('league_standings', $data);

				}
			}


	}

}
