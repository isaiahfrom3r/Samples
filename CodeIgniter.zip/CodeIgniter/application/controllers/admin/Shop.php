<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shop extends CI_Controller {

	public function __construct()
	{

		parent::__construct();
		$this->users->is_admin(1);
		$this->load->model('users');
		$this->load->model('shops');

		$this->load->helper('post_thumbnail');
		$this->form_validation->set_error_delimiters('<p class="help-block">', '</p>');
	}

	public function index(){
		redirect('admin/shop/list_all');
	}

	public function list_all(){
		$data['title']="All shops";
		$head['scripts'] = array('/assets/admin/js/list_shops.js');
		$data['shops']=$this->shops->get_all();

		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/shops/list_all',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function edit($shop_id=""){
		$foot['styles'] = array('//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css');
		$foot['scripts'] = array('//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js','//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js','/assets/admin/js/edit_shop.js');
		$head = array();

		$this->db->where('is_admin','1');
		$users=$this->db->get('users');

		$data['users']=$users->result();
		$data['categories']=$this->shops->get_categories();
		$data['shop'] = array();
		if(!empty($shop_id)){
			$data['edit_page']=$data['shop']=$this->shops->get_by_id($shop_id);
			$data['shop_cats']=$this->shops->get_shop_categories($shop_id);
			$data['edit_page']->seo_desc = $data['edit_page']->meta_description ;
			$data['edit_page']->seo_keywords = $data['edit_page']->meta_keywords ;
		}else{
			$data['shop_cats']=array();
		}



		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/shops/shop_form',$data);
		$this->load->view(ADMIN_THEME.'/footer',$foot);
	}

	public function delete($shop_id=''){


		$this->db->where('id',$shop_id);
		$this->db->delete('shops');

		$this->db->where('shop_id',$shop_id);
		$this->db->delete('shop_category_relation');


		$this->alert->set('shop Deleted','success');


		redirect(ADMIN_THEME."/shop/list_all");
	}

	public function categories(){

		$data['active_menu'] = 'cms';
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="help-block">', '</p>');
		$data['title']="Categories";
		$data['menu_parent']="shops";

		$head['scripts'] = array('assets/admin/js/list_shops.js');
		$data['categories']=$this->shops->get_categories();
 		$data['all_categories']=$this->shops->get_categories(null,false);

		$this->form_validation->set_rules('label', 'Label', 'required|trim');
		$this->form_validation->set_rules('title', 'Title', 'required|trim');
		$this->form_validation->set_rules('slug', 'Slug', 'required|trim|alpha_dash');
		$this->form_validation->set_rules('parent', 'Parent', 'required|trim');
		if ($this->form_validation->run() == FALSE){
		}else{
			$insert=array(
				"label"=>$this->input->post("label"),
				"title"=>$this->input->post("title"),
				"slug"=>$this->input->post("slug"),
				"parent_id"=>$this->input->post("parent"),
			);
			$this->db->insert('shop_categories',$insert);

			$this->alert->set('Category Created','success');
			redirect(ADMIN_THEME.'/shop/categories');
		}
		$this->load->view(ADMIN_THEME.'/header',$head);
		$this->load->view(ADMIN_THEME.'/shops/category_manager',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function delete_category($cat_id=''){
		$this->db->where('id',$cat_id);
		$this->db->delete('shop_categories');
		$this->db->where('category_id',$cat_id);
		$this->db->delete('shop_category_relation');

		$this->alert->set('Category Deleted','success');
		redirect(ADMIN_THEME."/shop/categories");
	}

	public function edit_category($cat_id=''){

		$data['cat_id']=$cat_id;
		$data['category']=$this->shops->get_category_by_id($cat_id);
		$data['all_categories']=$this->shops->get_categories(null,false);

		$this->form_validation->set_rules('label', 'Label', 'required|trim');
		$this->form_validation->set_rules('title', 'Title', 'required|trim');
		$this->form_validation->set_rules('slug', 'Slug', 'required|trim|alpha_dash');
		if ($this->form_validation->run() == FALSE){
		}else{

			$update=array(
				"label"=>$this->input->post("label"),
				"title"=>$this->input->post("title"),
				"slug"=>$this->input->post("slug"),
				"parent_id"=>$this->input->post("parent"),
			);
			$this->db->where('id',$cat_id);
			$this->db->update('shop_categories',$update);

			$this->alert->set('Category Updated','success');
			redirect('admin/shop/categories');
		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/shops/category_edit',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function save_shop(){

		if($this->input->post()){
			$allow_comments=$this->input->post('allow_comments');
			if(!isset($allow_comments) || empty($allow_comments)){
				$allow_comments=0;
			}
			$meta_keywords=$this->input->post('seo_keywords');
			if(!isset($meta_keywords) || empty($meta_keywords)){
				$meta_keywords=array();
			}
			$meta_description=$this->input->post('seo_desc');
			if(!isset($meta_description) || empty($meta_description)){
				$meta_description=array();
			}
			if($this->input->post('remove') !=""){
				$shop_data=array(
					"label"=>$this->input->post('label'),
					"title"=>$this->input->post('title'),
					"slug"=>$this->input->post('slug'),
					"author_id"=>$this->input->post('author_id'),
					"post_date"=>strtotime($this->input->post('post_date')." ".$this->input->post('post_date_hours').":".$this->input->post('post_date_mins')),
					"content"=>$this->input->post('content'),
					"allow_comments"=>$allow_comments,
					"excerpt"=>$this->input->post('excerpt'),
					"thumbnail"=> "",
					"status"=>$this->input->post('status'),
					"visibility"=>$this->input->post('visibility'),
					"meta_keywords"=>$this->input->post('seo_keywords'),
					"meta_description"=>$this->input->post('seo_desc'),
					"buy_link"=>$this->input->post('buy_link'),
					"price"=>$this->input->post('price'),
				);
			}
			else{
				$shop_data=array(
					"label"=>$this->input->post('label'),
					"title"=>$this->input->post('title'),
					"slug"=>$this->input->post('slug'),
					"author_id"=>$this->input->post('author_id'),
					"post_date"=>strtotime($this->input->post('post_date')." ".$this->input->post('post_date_hours').":".$this->input->post('post_date_mins')),
					"content"=>$this->input->post('content'),
					"allow_comments"=>$allow_comments,
					"excerpt"=>$this->input->post('excerpt'),
					//"featured_image_url"=>
					"status"=>$this->input->post('status'),
					"visibility"=>$this->input->post('visibility'),
					"meta_keywords"=>$this->input->post('seo_keywords'),
					"meta_description"=>$this->input->post('seo_desc'),
					"buy_link"=>$this->input->post('buy_link'),
					"price"=>$this->input->post('price'),
				);
			}

			$shop_id=$this->input->post('shop_id');
			if(!isset($shop_id) || empty($shop_id)) {
				//check slug
				$this->db->where('slug',$this->input->post('slug'));
				$slug_check=$this->db->get('shops');

				if($slug_check->num_rows()==0){

					$this->db->insert('shops',$shop_data);
					$shop_id=$this->db->insert_id();
				}else{
/*
					echo json_encode(array("status"=>"Bogus","message"=>"Slug must be unique."));exit();
*/

					$this->alert->set('Slug must be unique.','error');
					$_SESSION['data'] = $shop_data;
					redirect(ADMIN_THEME.'/shop/edit/'.$shop_id."");
				}
			}else{
				//check slug
				$this->db->where('slug',$this->input->post('slug'));
				$this->db->where('id !=',$shop_id);
				$slug_check=$this->db->get('shops');
				if($slug_check->num_rows()>0){
/*
					echo json_encode(array("status"=>"Bogus","message"=>"Slug must be unique."));exit();
*/

					$this->alert->set('Slug must be unique.','error');
					redirect(ADMIN_THEME.'/shop/edit/'.$shop_id);
				}
			}
			//Update categories
			$this->db->where('shop_id',$shop_id);
			$this->db->delete('shop_category_relation');
			$categories=$this->input->post('categories');
			if(!empty($categories)){
				foreach($categories as $c){
					$this->db->insert('shop_category_relation',array('shop_id'=>$shop_id,"category_id"=>$c));
				}
			}else{
				$this->db->insert('shop_category_relation',array('shop_id'=>$shop_id,"category_id"=>1));
			}

			if (strlen($_FILES["featureimage"]["name"])>0)
			{
				$config['upload_path'] = './uploads/media/';
				$config['allowed_types'] = '*';
				$config['max_size']	= '1000000000000';
				$this->load->library('upload', $config);
				if ($this->upload->do_upload('featureimage')) {
					$img_data=$this->upload->data();
					$new_imgname='shopthumbnail'.md5(time()).$img_data['file_ext'];
					$new_imgpath=$img_data['file_path'].$new_imgname;
					rename($img_data['full_path'], $new_imgpath);
					$shop_data['thumbnail']='/uploads/media/'.$new_imgname;
				}else{
					$this->alert->set($this->upload->display_errors(),'error');
					redirect(ADMIN_THEME.'/shop/edit/'.$shop_id);
				}
			}

			if(isset($shop_id) && !empty($shop_id)){
				$this->db->where('id',$shop_id);
				$this->db->update('shops',$shop_data);
			}

			//Success Message
			$this->alert->set('shop Updated.','success');
			redirect(ADMIN_THEME.'/shop/edit/'.$shop_id);

		}else{
			echo json_encode(array("status"=>"Bogus","message"=>"No Post Data Found"));
			$this->alert->set('shop Updated.','success');
			redirect(ADMIN_THEME.'/shop/edit/'.$shop_id);
		}
	}

}
