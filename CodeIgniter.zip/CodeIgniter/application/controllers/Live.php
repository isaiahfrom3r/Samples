<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Live extends CI_Controller {
	public function __construct() {
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		parent::__construct();
		$this->load->model('Leagues');
		$this->load->model('Misc');
		$this->load->model('Teams');
		$this->load->model('Events');
		$this->load->model('Players');
		$this->load->model('Drafts');
		$this->users->is_loggedin(1);

	}


	public function matchup($week=''){
		$user = $this->users->get_user($this->users->id());
		$tid = $user->team_id;
		if($week == ""){
			$week = $this->Events->get_week();
		}

		if($week > $this->Events->get_week()){
			$this->alert->set('Week is greater then current week!','error');
			redirect('/team/'.$tid.'/'.$this->Events->get_week());
		}


		$foot['scripts'] = array();
		$head['scripts'] = array('/assets/js/livescore.js','/assets/js/jquery.downCount.js');
		$data['week'] =  $week;
		$data['stage'] = $stage = $this->Leagues->get_stage($week);

		$data['team'] = $this->Leagues->get_team_by_id($tid);
		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['record'] =  $this->Leagues->get_record($tid);
		$data['teams'] =  $teams = $this->Leagues->get_my_leagues();
		$data['season'] = $season = $data['league']->season;
		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);


		$league = $data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['roster'] = $this->Leagues->get_manage_roster($tid,$week);
		$data['pstats'] =  $this->Teams->get_projected_stats($data['roster'],$week,$season);
		$data['projected'] =  $this->Teams->get_projected_points($data['pstats']);
		$data['matchup'] = $match = $this->Leagues->get_matchup($tid,$week);


		if(!is_array($data['roster'])){
			$this->alert->set('Live scoring is currently unavailable for this team.','error');
			redirect('/dashboard');

		}
		$data['opp_record'] =  $this->Leagues->get_record($match['id']);



		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/live/live',$data);
		$this->load->view(THEME.'/footer',$foot);

	}
	public function mobile_update_opp($tid,$week='',$bench){
		if($week == ""){
			$week = $this->Events->get_week();
		}

		if($week > $this->Events->get_week()){
			$this->alert->set('Week is greater then current week!','error');
			redirect('/team/'.$tid.'/'.$this->Events->get_week());
		}

		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);

		$tid = $data['week_matchup']->opp_id;

		$foot['scripts'] = array();
		$head['scripts'] = array('/assets/js/livescore.js');
		$data['week'] =  $week;
		$data['team'] = $this->Leagues->get_team_by_id($tid);

		if($data['team']->user_id > 0){
			$data['user'] = $this->users->get_user($data['team']->user_id);
		}

		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);


		$data['record'] =  $this->Leagues->get_record($tid);
		$data['teams'] =  $teams = $this->Leagues->get_my_leagues();
		$data['season'] = $season = $data['league']->season;
		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);


		$league = $data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['roster'] = $this->Leagues->get_manage_roster($tid,$week);
		$data['pstats'] =  $this->Teams->get_projected_stats($data['roster'],$week,$season);
		$data['projected'] =  $this->Teams->get_projected_points($data['pstats']);
		$data['matchup'] = $match = $this->Leagues->get_matchup($tid,$week);



		$data['opp_record'] =  $this->Leagues->get_record($match->id);



		$this->load->view(THEME.'/live/live_mobile',$data);

	}
	public function mobile_update($tid,$week=''){
		if($week == ""){
			$week = $this->Events->get_week();
		}

		if($week > $this->Events->get_week()){
			$this->alert->set('Week is greater than current week!','error');
			redirect('/team/'.$tid.'/'.$this->Events->get_week());
		}


		$foot['scripts'] = array();
		$head['scripts'] = array('/assets/js/livescore.js');
		$data['week'] =  $week;
		$data['team'] = $this->Leagues->get_team_by_id($tid);
		$data['bench'] =  $bench;
		if($data['team']->user_id > 0){
			$data['user'] = $this->users->get_user($data['team']->user_id);
		}

		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);


		$data['record'] =  $this->Leagues->get_record($tid);
		$data['teams'] =  $teams = $this->Leagues->get_my_leagues();
		$data['season'] = $season = $data['league']->season;
		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);


		$league = $data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['roster'] = $this->Leagues->get_manage_roster($tid,$week);
		$data['pstats'] =  $this->Teams->get_projected_stats($data['roster'],$week,$season);
		$data['projected'] =  $this->Teams->get_projected_points($data['pstats']);
		$data['matchup'] = $match = $this->Leagues->get_matchup($tid,$week);



		$data['opp_record'] =  $this->Leagues->get_record($match->id);



		$this->load->view(THEME.'/live/live_mobile',$data);

	}
	public function main_update($tid,$week='',$bench){
		if($week == ""){
			$week = $this->Events->get_week();
		}

		if($week > $this->Events->get_week()){
			$this->alert->set('Week is greater then current week!','error');
			redirect('/team/'.$tid.'/'.$this->Events->get_week());
		}

		$data['stage'] = $stage = $this->Leagues->get_stage($week);

		$foot['scripts'] = array();
		$head['scripts'] = array('/assets/js/livescore.js');
		$data['week'] =  $week;
		$data['bench'] =  $bench;
		$data['team'] = $this->Leagues->get_team_by_id($tid);

		if($data['team']->user_id > 0){
			$data['user'] = $this->users->get_user($data['team']->user_id);
		}

		$data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);


		$data['record'] =  $this->Leagues->get_record($tid);
		$data['teams'] =  $teams = $this->Leagues->get_my_leagues();
		$data['season'] = $season = $data['league']->season;
		$data['week_matchup'] =  $this->Leagues->get_week_matchup($tid, $week);


		$league = $data['league'] =  $this->Leagues->get_league_by_id($data['team']->league_id);
		$data['roster'] = $this->Leagues->get_manage_roster($tid,$week);
		$data['pstats'] =  $this->Teams->get_projected_stats($data['roster'],$week,$season);
		$data['projected'] =  $this->Teams->get_projected_points($data['pstats']);
		$data['matchup'] = $match = $this->Leagues->get_matchup($tid,$week);



		$data['opp_record'] =  $this->Leagues->get_record($match->id);



		$this->load->view(THEME.'/live/live_main',$data);

	}

	public function do_swap(){
		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);
		$dev = false;
		$this->load->library('user_agent');
		$data['user'] = $user  = $this->users->get();
		$data['league'] = $league = $this->Leagues->get_league_by_id($user->team_id);
		$team = $this->Leagues->get_my_league_team($user->team_id);
		$data['myteam'] =  $id = $this->Leagues->get_my_league_team($user->team_id);

		$coolcheck = time() - $team->swap_time;
		if($dev == true){$coolcheck = 100000;}


		if($coolcheck < $league->cooldown){
			if($dev == true){echo "Cooldown Not Ready"; die;}
			$this->alert->set('Please wait for live swap cool down','error');
			redirect($this->agent->referrer());
		}


		// check for any rosters in swap table
		$rostercount = $this->Leagues->check_swap_rosters($_POST['team_id'],$_POST['week'],$_POST['season']);


		// if none go ahead and insert the main roster in as the rosters with timestamps of 0 because they were starters
		if($rostercount == 0){

			$this->Leagues->move_regular_roster($_POST['team_id'],$_POST['week'],$_POST['season']);

		}


		// go ahead and update the default rosters for now

		$nr['start'] = $_POST['start'];
		$nr['bench'] = $_POST['bench'];
		$roster = json_encode($nr);

		$this->Leagues->update_week_roster_nore($_POST['week'],$_POST['season'],$_POST['league_id'],$_POST['team_id'],$roster);

		//insert the swap roster with the game seconds and timestamps


		$this->Leagues->insert_week_roster_swap($_POST['week'],$_POST['season'],$_POST['league_id'],$_POST['team_id'],$roster);



		$this->Leagues->update_cooldown($team,$league);

		if($dev == true){echo "Swap Reset"; die;}


		// send them back to live scoring.
		$this->alert->set('Live Roster Updated','success');
		redirect($this->agent->referrer());


	}
	public function timeline($tid,$pid,$week){

		$data['team'] = $team = $this->Leagues->get_team_by_id($tid);
		$data['league'] = $league = $this->Leagues->get_league_by_id($team->league_id);
		$lid = $team->league_id;
		$guy = $pid;
		$data['week'] =  $week ;

		if(strlen($guy) > 5){
			$player = $this->Players->get_by_id($guy);
			$news = $this->Players->get_news($player->cid);

			$team = $this->Teams->get_by_id($player->team_id);
			$projections = $this->Teams->get_proj_row($player->cid,$week,$league->season,$league);
			$pts = $this->Players->get_season_pts_league($player->cid,'',$league);
			if($pts == 0 || $week == 0){
				$avg = 0;
			}else{
				$avg = $pts / ($this->Events->get_week() - 1) ;
			}
			if($week == 1){
				$avg = $pts;
			}
			$matchup = $this->Teams->get_matchup($team->cid,$week,$league->season);
			$playerscore = $this->Players->get_player_score_swap($player->cid,$matchup,$league);

				$wkpts = $this->Players->get_player_score($player->cid,$matchup,$league);
		}else{
			$news = array();
			$player = $this->Teams->get_by_id($guy);
			$player->first_name = $player->city;
			$player->last_name = $player->name;
			$player->position = 'DEF';
			$team = $player;
			$projections = $this->Teams->get_proj_row($player->cid,$week,$league->season,$league);
			$pts = $this->Teams->get_season_pts($player->cid);
			if($pts == 0 || $week == 0){
				$avg = 0;
			}else{
				$avg = $pts / ($this->Events->get_week() - 1) ;
			}
			if($week == 1){
				$avg = $pts;
			}

			$matchup = $this->Teams->get_matchup($team->cid,$week,$league->season);
			$playerscore = $this->Teams->get_team_score_swap($player->cid,$matchup,$league);
			$wkpts = $this->Teams->get_team_score($player->cid,$matchup,$league);
		}

		$data['news'] =  $news;
		$data['player'] =  $player;
		$data['matchup'] =  $matchup;
		$data['wkpts'] =  $wkpts;
		$data['projections'] =  $projections;
		$data['team'] =  $team;
		$data['active_score'] =  $playerscore;
		$data['pts'] =  $pts;
		$data['avg'] =  $avg;
		$data['week'] =  $week;
		$data['uteam'] = $uteam = $this->Leagues->get_my_league_team($lid);

		$data['information'] = $info =  $this->Leagues->get_team_stat_breakdown($league,$tid,$week,$league->season);

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		if(!isset($info['gaps'][$player->cid])){
			$data['gaps'] =  'nope';
			$data['bads'] =  $info['bad'][$player->cid];
		}else{
			$data['gaps'] =  $info['gaps'][$player->cid];
			$data['bads'] =  $info['bad'][$player->cid];

		}

		$roster = $data['roster'] = $this->Leagues->get_manage_roster($tid,$week);

		$starters = $roster['start'];

		if(in_array($player->cid, $starters)){
			$data['active'] =  'Active';
		}else{
			$data['active'] =  'Benched';
		}

		$this->load->view(THEME.'/live/timeline',$data);
	}




}
