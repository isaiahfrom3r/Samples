<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User_model class.
 *
 * @extends CI_Model
 */
class States extends CI_Model {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {

		parent::__construct();
		$this->load->database();

	}

	// get user id from session
	public function update_add_state($state,$val=1){
		$this->db->where('state',$state);
		$q = $this->db->get("states");
		if ($q->num_rows() > 0){

			$data = array(
               'state' => $state,
               'col_a' => $val['col_a'],
               'col_b' => $val['col_b'],
               'col_c' => $val['col_c'],
               'col_d' => $val['col_d'],
               'col_e' => $val['col_e'],
            );
			$this->db->where('state', $state);
			$this->db->update('states', $data);

		}else{

			$data = array(
               'state' => $state,
               'status' => $val,
            );
			$this->db->insert('states', $data);

		}
	}
	public function get_country_info($countries){
		$season = $this->Events->get_season();
		$season = 2017;
		foreach($countries as $ckey=>$c){

			$this->db->where('country',$ckey);
			$q = $this->db->get("users");

			$q = $q->result();
			$allguys = array();
			foreach($q as $guy){
				$allguys[] = $guy->id;
			}
			if(empty($allguys)){
				continue;
			}

			$this->db->where('season',$season);
			$this->db->where_in('owner',$allguys);
			$q = $this->db->get("leagues");

			$cinfo[$ckey] = $q->num_rows();

		}

		return $cinfo;
	}
	public function get_all_info($states){
		$season = $this->Events->get_season();
		$season = 2017;

		$this->db->where('type',2);
		$this->db->where('season',$season);
		$q = $this->db->get("competitions");
		$q = $q->result();

		foreach($q as $st){
			$res[$st->state] = $st;
		}

		foreach($states as $key=>$s){
			if(isset($res[$key]->id)){
				$this->db->where('state',$res[$key]->id);
				$q = $this->db->get("leagues");


				$news[$key] = $q->num_rows();
			}else{
				$news[$key] = 0;
			}
		}
		return $news;
	}
	public function get_state($state){
		$this->db->where('state',$state);
		$q = $this->db->get("states");
		$q = $q->row();

		return $q;
	}
	public function get_all_status(){
		$q = $this->db->get("states");
		$q = $q->result();
		foreach($q as $s){
			$ret[$s->state] = $s;
		}
		return $ret;
	}

}
