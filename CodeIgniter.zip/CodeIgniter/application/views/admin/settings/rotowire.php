<div class="card">
    <div class="card-header">
        <h2> RotoWire Standings  </h2>
        <span>were last updated on <?=date('F jS Y',$time)?> at <?=date('g:i a',$time)?></span>
    </div>


</div>
