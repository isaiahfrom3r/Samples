<!-- Yea this is grows so I just made its own file.  -->
<?php $this->load->view(ADMIN_THEME.'/admin/users_chart_script'); ?>
<div class="block-header">
    <h2>Dashboard</h2>
</div>
<div class="card hide">
	<div class="card">
        <div class="card-header">
            <h2>Users By Month</h2>

        </div>

        <div class="card-body">

            <div class="chart-edge hide">
                <div id="curved-line-chart" class="flot-chart "></div>
            </div>


        </div>


    </div>
 </div>

 <div class="card">
	<div class="card">



        <div class="card-header col-md-3">
            <h2>Round 1 <small><?=$this->options->get('round_1')?></small></h2>

        </div>

        <div class="card-header col-md-3">
            <h2>Round 2 <small> <?=$this->options->get('round_2')?></small></h2>

        </div>

        <div class="card-header col-md-3">
            <h2>Round 3 <small> <?=$this->options->get('round_3')?></small></h2>

        </div>

        <div class="card-header col-md-3">
            <h2>Round 4 <small><?=$this->options->get('round_4')?></small></h2>

        </div>

        <div class="card-header col-md-3">
            <h2>Round 5 <small><?=$this->options->get('round_5')?></small></h2>

        </div>

        <div class="card-header col-md-3">
            <h2>Round 6 <small> <?=$this->options->get('round_6')?></small></h2>

        </div>


        <div class="card-body">





        </div>
        <div class="clearfix"></div>
    </div>
 </div>
