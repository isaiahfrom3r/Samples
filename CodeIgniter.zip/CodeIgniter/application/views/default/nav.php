<?php
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

/*
if($ip != "68.48.182.89"){
	echo "Your IP address is not on the approved ip list"; exit;
}
*/
?>

<nav class="navbar navbar-expand-md navbar-light fixed-top">

    <div class="container-fluid">

		<a class="navbar-brand" href="<?=base_url();?>index.php">

			<img src="<?=base_url();?>assets/img/logo.png" alt="<?=$this->options->get('site_name');?>" />

		</a>

		<button class="toggle-menu menu-left"><i class="fa fa-bars"></i></button>

		<ul class="navbar-nav ml-auto">

			<?php
	        if($this->users->is_loggedin()){
	        	$menu = $this->menus->display(207);
	        }else{
	         	$menu = $this->menus->display(141);
	        }

	        foreach($menu['menu'] as $m){ ?>

	        	<?php if(isset($m['sub'])){?>

	        		<li class="nav-item dropdown">

						<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Home <span class="glyphicon glyphicon-triangle-bottom"></span></a>

						<div class="dropdown-menu">

							<?php foreach($m['sub'] as $s){ ?>

								<a class="dropdown-item" href="<?php echo base_url();?><?=$s['details']['url']?>"><?=$s['details']['name']?></a>
							<?php } ?>

						</div>

					</li>

	        	<?php }else{?>

		        	<li class="nav-item">

		                <a class="nav-link" href="<?=base_url()?><?=$m['details']['url']?>"><?=$m['details']['name']?></a>

		            </li>

	            <?php }?>

	        <?php } ?>
	       <?php if(!empty($profile)){ ?>
	       <span class="profile_in_nav">
	       		<h4>Welcome - <?=$profile->full_name?></h4>
	       		<img src="<?=$profile->photo_path?>"></img>
	       </span>
	       <?php } ?>

		</ul>

	</div>

</nav>


<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">
	<h3>Menu</h3>
	<?php
    if($this->users->is_loggedin()){
    	$menu = $this->menus->display(222);
    }else{
     	$menu = $this->menus->display(141);
    }
    foreach($menu['menu'] as $m){ ?>

	    <?php if(isset($m['sub'])){?>

			<?php foreach($m['sub'] as $s){ ?>

				<a class="dropdown-item" href="<?php echo base_url();?><?=$s['details']['url']?>"><?=$s['details']['name']?></a>
			<?php } ?>

    	<?php }else{?>

            <a href="<?=$m['details']['url']?>"><?=$m['details']['name']?></a>

        <?php }?>

    <?php } ?>
</nav>
