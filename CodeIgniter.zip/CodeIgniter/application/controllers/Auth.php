<?
class Auth extends CI_Controller
{
    public function connect($provider){
	    $magicname = $provider;
	    ini_set('display_errors',1); // set to 0 for production version
		$mobile=$this->uri->segment(4);
        $this->load->helper('url_helper');
        $this->load->library('OAuth2');
		$provider_data=json_decode($this->options->get('linked_account_provider_data'),true);

		$provider_data=$provider_data[$provider];
		$provider_name=$provider;

        $provider = $this->oauth2->provider($provider, array(
            'id' => $provider_data['id'],
            'secret' => $provider_data['secret'],
        ));

		if(isset($provider_data['scope']) && $provider_data['scope']!==false){
			$provider->scope=$provider_data['scope'];
		}
		//echo "<pre>".print_r($provider,true)."</pre>";exit;
        if ( ! $this->input->get('code')){
            // By sending no options it'll come back here

            $provider->authorize();
        }else{
            try{

                $token = $provider->access($_GET['code']);
                $user = $provider->get_user_info($token);

                $user['provider'] = $magicname;
				$this->session->social = $user;

                // Here you should use this information to A) look for a user B) help a new user sign up with existing data.
                // If you store it all in a cookie and redirect to a registration page this is crazy-simple.
                //echo "<pre>User Info: ";var_dump($user);echo "</pre>";
                //echo "<pre>Logged In: ";var_dump($this->users->is_loggedin());echo "</pre>";

				$link_user=$this->users->get_by_protocal_id($user['uid'],$provider_data['user_table_column']);
				$email_user=$this->users->get_by_email($user['email']);
				if($this->users->is_loggedin()){
					$user_id=$this->users->id();
					if($link_user===false || $link_user->id == $user_id){
						//update their account with new facebook info
						$update=array(
							$provider_data['user_table_column']=>$user['uid']
						);

						$this->db->where('id',$user_id);
						$this->db->update('users',$update);

						$this->alert->set('Social Account Linked','success');


						//
						redirect('account');
					}else{
						$this->alert->set('Social Account Linked! Please complete entire registration.','success');
						redirect('register');
					}
				}else{
					//check if the id is in use for an account
					if($link_user===false){
						if($email_user!==false){
							$this->db->where('id',$email_user->id);

							$this->db->update('users',array($provider_data['user_table_column']=>$user['uid']));
							$this->alert->set($this->options->get('start_welcome'),'success');
							$this->users->forcelogin($email_user->id);
							redirect('/home/player');
						}else{
							//send them to registration
							$this->alert->set('Social Account Linked! Please complete entire registration.','success');
							redirect('register');
						}
					}else{

						$this->users->forcelogin($link_user->id);

						$this->alert->set($this->options->get('start_welcome'),'success');

						redirect('/home/player');
					}
				}

            }catch (OAuth2_Exception $e){
                //show_error('That didnt work: '.$e);
				redirect('/');
            }
        }
    }
    public function update_friends($provider,$uid){

		$mobile=$this->uri->segment(4);
        $this->load->helper('url_helper');
        $this->load->library('OAuth2');
		$provider_data=$this->config->item('linked_account_provider_data');
		$provider_data=$provider_data[$provider];
		$provider_name=$provider;

        $provider = $this->oauth2->provider($provider, array(
            'id' => $provider_data['id'],
            'secret' => $provider_data['secret'],
        ));

		if(isset($provider_data['scope']) && $provider_data['scope']!==false){
			$provider->scope=$provider_data['scope'];
		}
		//echo "<pre>".print_r($provider,true)."</pre>";exit;
        if ( ! $this->input->get('code')){
            // By sending no options it'll come back here

            $provider->authorize();
        }else{
            try{

                $token = $provider->access($_GET['code']);
                $user = $provider->get_user_info($token);

				$data = array(
	               'facebook_friends' => $user['facebook_friends'],
	               'facebook_update'  => time(),
	            );
				$this->db->where('id',$uid);
				$this->db->update('users', $data);
				$this->session->set_flashdata('success','Facebook Friends Updated');
				redirect(base_url().'user/search');

            }catch (OAuth2_Exception $e){
            }
        }
    }

	public function unlink($provider){
		$provider_data=$this->config->item('linked_account_provider_data');
		$provider_data=$provider_data[$provider];
		$user_id=$this->users->id();
		$this->db->where('id',$user_id);
		$this->db->update('users',array($provider_data['user_table_column']=>0));

		$this->users->delete_usermeta($user_id,$provider_data['usermeta_key']);
		$this->session->set_flashdata('success',vlang('social_link_unlink_success'));
		redirect('registration/basic_info_edit');
	}
}
