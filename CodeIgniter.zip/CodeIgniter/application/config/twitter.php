<?php
/**
 * twconnect library configuration
 */

$config = array(
  'consumer_key'    => 'ncVLzQaSVOSLUzsjpBUNzHWFg',
  'consumer_secret' => 'bOTrORNsWUQvsFtsvXoico5dNj8pTnueAxakkpNeC2pEF6o5CS',
  'oauth_callback'      => '/twiiter/callback' // Default callback application path
);

?>
