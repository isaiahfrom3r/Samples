<!-- Yea this is grows so I just made its own file.  -->
<?php $this->load->view(ADMIN_THEME.'/admin/users_chart_script'); ?>

<div class="card">
	<div class="card">
        <div class="card-header">
            <h2>State Info</h2>
            <h5></h5>


        </div>

        <div class="card-body">
	        <table class="table">
                <thead>
	                <tr>
	                    <th>Country</th>
	                    <th>Teams</th>

	                </tr>
                </thead>
                <tbody>
	                <?php foreach($c_info as $key=>$s){ ?>

		                <tr>
		                    <td><?=$countries[$key]?></td>
		                    <td><?=$s?></td>

		                </tr>


	                <?php } ?>
                </tbody>
            </table>
            <table class="table">
                <thead>
	                <tr>
	                    <th>State</th>
	                    <th>Teams</th>

	                </tr>
                </thead>
                <tbody>
	                <?php foreach($states as $key=>$s){ ?>
	                	<?php if($s==''){continue;} ?>

		                <tr>
		                    <td><a target="_blank" href="<?php echo base_url(); ?>/leaderboard/state/<?=$key?>"><?=$s?></a></td>
		                    <td><?=$comp_info[$key]?></td>

		                </tr>


	                <?php } ?>
                </tbody>
            </table>

        </div>
    </div>
 </div>
