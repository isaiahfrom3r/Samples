<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['theme'] = 'default';
define('THEME', 'default');
define('TEMPLATE', 'cms_templates');
define('ADMIN_THEME', 'admin');
// leave '' to not load a theme  Themes can be found at https://bootswatch.com/ and can be saved to assets/themes/
define('BootTheme', 'superhero');

