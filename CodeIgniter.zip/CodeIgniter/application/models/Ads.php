<?php

class Ads extends CI_Model {


	public $used_cids = array();

	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();

    }

	function get_ad_spot_by_id($id = '')
	{
		$this->db->limit(1);
		$this->db->where(array(
								'cid' => $id
								));
		$this->db->from('ad_spots');
		if ($this->db->count_all_results() > 0)
		{
			$q = $this->db->get_where('ad_spots', array(
													'cid' => $id
													));
			$res = $q->result();
			$fun_spot = $res[0];
			return $fun_spot;

		}
		else
		{
			return false;
		}
	}

	function get_ad_spots($per_page = '10', $page_num = '0')
	{
		$this->db->order_by('name', 'asc');
		$this->db->limit($per_page, $page_num);
		$q = $this->db->get('ad_spots');
		return $q->result();
	}

	function get_ad_spots_total()
	{
		return $this->db->count_all_results('ad_spots');
	}

	function update_ad_spot($fun_spot_id = '', $fun_spot)
	{
		$this->db->limit(1);
		$this->db->where('cid', $fun_spot_id);
		$this->db->update('ad_spots', $fun_spot);
	}

	function create_ad_spot($fun_spot)
	{
		$this->db->insert('ad_spots', $fun_spot);
		return $this->db->insert_id();
	}

	function delete_ad_spot($fun_spot_id = '')
	{
		//delete all banners within the spot
		$this->db->where('spot_id', $fun_spot_id);
		$this->db->delete('ad_banners');

		$this->db->limit(1);
		$this->db->where('cid', $fun_spot_id);
		$this->db->delete('ad_spots');
	}

	function get_ad_banner_by_id($id = '')
	{
		$this->db->limit(1);
		$this->db->where(array(
								'cid' => $id
								));
		$this->db->from('ad_banners');
		if ($this->db->count_all_results() > 0)
		{
			$q = $this->db->get_where('ad_banners', array(
													'cid' => $id
													));
			$res = $q->result();
			$fun_banner = $res[0];
			return $fun_banner;
		}
		else
		{
			return false;
		}
	}

	function get_ad_banners($per_page = '10', $page_num = '0')
	{
		$this->db->order_by('name', 'asc');
		$this->db->limit($per_page, $page_num);
		$q = $this->db->get('ad_banners');
		return $q->result();
	}

	function get_ad_banners_total()
	{
		return $this->db->count_all_results('ad_banners');
	}

	function update_ad_banner($fun_banner_id = '', $fun_banner)
	{
		$this->db->limit(1);
		$this->db->where('cid', $fun_banner_id);
		$this->db->update('ad_banners', $fun_banner);
	}

	function create_ad_banner($fun_banner)
	{
		$this->db->insert('ad_banners', $fun_banner);
		return $this->db->insert_id();
	}

	function delete_ad_banner($fun_banner_id = '')
	{
		//delete banner image if any
		$banner = $this->get_ad_banner_by_id($fun_banner_id);
		if (!empty($banner->image))
		{
			@unlink(dirname(dirname(dirname(__FILE__))).'/uploads/ads/'.$banner->image);
		}

		$this->db->limit(1);
		$this->db->where('cid', $fun_banner_id);
		$this->db->delete('ad_banners');
	}

	function spot($id,$used=array())
	{
		//$this->used_cids[] = 'smth else';
		//check if spot exists
		$spot = $this->get_ad_spot_by_id($id);
		$not_in_sql = '';

// 		$this->db->where('spot_id',$id);
		$this->db->where('last_loaded',1);
		$q = $this->db->get("ad_banners");
		$q = $q->result();


		foreach($q as $no){
			$nots[] = $no->cid;
		}


		if(!empty($used)){
			$this->db->where_in('url',$used);
			$q = $this->db->get("ad_banners");
			$q = $q->result();
			foreach($q as $no){
				$nots[] = $no->cid;
			}

		}


		if (!$spot)
		{
			return '';
		}
		else
		{
			if (count($this->used_cids) > 0)
			{

				$not_in_sql = " AND cid NOT IN (".implode(', ', $nots).") ";
			}


			$sql = "SELECT * FROM ".$this->db->dbprefix('ad_banners')." WHERE status = '1' AND (start_date = '0' OR start_date > '".time()."') AND (end_date = '0' OR end_date > '".time()."') AND (max_impressions = '0' OR max_impressions > impressions) AND (max_clicks = '0' OR max_clicks > clicks) AND spot_id = '".$id."' ".$not_in_sql." ORDER BY RAND() LIMIT ".$spot->max_banners;


			//exit($sql);
			$q = $this->db->query($sql);
			$res = $q->result();

			$uaray = array(
				'last_loaded' => 0,
			);

			$this->db->where('spot_id', $id);
			$this->db->update('ad_banners', $uaray);

			foreach($res as $r){
				$r->last_loaded = 1;
				$this->db->where('cid',$r->cid);
				$this->db->update('ad_banners', $r);
			}


			if (count($res) > 0)
			{
				$fun_string = '<div class="fun_spot fun_spot_'.$spot->cid.'">';
				foreach($res as $ad)
				{
					$useing[$ad->cid] = $ad->url;
					if($ad->url == ""){
						$ad->url = "#";
					}
					//build ad html
					$fun_string .= '<div class="fun_banner_wrap" id="fun_'.$ad->cid.'" onclick="javascript: click_ad(\''.$ad->cid.'\');">';
					if ($ad->type == '0')
					{
						$fun_string .= $ad->code;
					}
					else
					{
						$fun_string .= '<a href="'.$ad->url.'" target="_new"><img src="'.site_url('uploads/fun/'.$ad->image).'" border="0" /></a>';
					}
					$fun_string .= '</div>';

					//add banner id to the used_cids var
					$this->used_cids[] = $ad->cid;

					//update impressions counter
					$sql = "UPDATE ".$this->db->dbprefix('ad_banners')." SET impressions = impressions + 1 WHERE cid = '".$ad->cid."' LIMIT 1";
					$this->db->query($sql);
				}
				$fun_string .= '</div>';
				if(count($res) > 1){
					$fun_string .= '<script>jQuery(".fun_spot_'.$id.' > div:gt(0)").hide();

					setInterval(function() {
					  jQuery(".fun_spot_'.$id.' > div:first")
					    .hide()
					    .next()
					    .show()
					    .end()
					    .appendTo(".fun_spot_'.$id.'");
					},  10000);</script>';

				}
				$return['funstring'] = $fun_string;
				$return['used'] = $useing;
				return $return;
			}
		}
	}

	function impression($fun_id = '')
	{
		$sql = "UPDATE ".$this->db->dbprefix('ad_banners')." SET clicks = clicks + 1 WHERE cid = '".$fun_id."' LIMIT 1";
		$this->db->query($sql);
	}






}
?>
