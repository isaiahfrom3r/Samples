<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shop extends CI_Controller {
	public $language='';
	public function __construct()
	{
		parent::__construct();
		$this->language=$this->session->userdata('lang');
		$this->load->model("shops");
		$this->load->helper("post_thumbnail");
	}

	public function index(){
		redirect('shop/all');
	}

	public function all(){
		$data['title']="All shops";
			$data['user'] = $this->users->get_user($this->users->id());

		$offset=$this->uri->segment(3);
		if(empty($offset)){
			$offset=0;
		}
		$data['cateogry'] = $this->shops->get_categories();
		//load pagination
		$this->load->library('pagination');
		$page_limit = $config['per_page'] = 5;

		$data['shops']=$this->shops->get_shops(null,$page_limit,$offset);

		//config pagination settings
		$config['base_url'] = site_url('shop/all/');
		$data['total_shops'] = $config['total_rows'] = $this->shops->get_shops(null,null,null,true);
		$config['num_links'] =5;
		$config['uri_segment'] = '3';
		$config['full_tag_open'] = '<div class="pagination"><ul>';
		$config['full_tag_close'] = '</ul></div>';
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="prev">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="next">';
		$config['next_tag_close'] = '</li>';
		$config['last_link']=false;
		$config['first_link']=false;

		$this->pagination->initialize($config);
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/shops/archive',$data);
		$this->load->view(THEME.'/footer');

	}

	public function category(){

		$data['user'] = $this->users->get_user($this->users->id());

		$category_slug=$this->uri->segment(3);

		$data['category']=$category=$this->shops->get_category_by_slug($category_slug);
		if(!$category) redirect('news/all');
		$data['title']=$category->title;

		$offset=$this->uri->segment(4);
		if(empty($offset)){
			$offset=0;
		}
		$data['cateogry'] = $this->shops->get_categories();
		//load pagination
		$this->load->library('pagination');
		$page_limit = $config['per_page'] = 5;

		$data['shops']=$this->shops->get_shops($category->id,$page_limit,$offset);

		if(empty($data['shops'])){
			$this->alert->set('No posts in this category','error');
			redirect('shop/all');
		}
		//config pagination settings
		$config['base_url'] = site_url('shop/all/');
		$data['total_shops'] = $config['total_rows'] = $this->shops->get_shops($category->id,null,null,true);
		$config['num_links'] =5;
		$config['uri_segment'] = '4';
		$config['full_tag_open'] = '<div class="pagination"><ul>';
		$config['full_tag_close'] = '</ul></div>';
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="prev">';
		$config['prev_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li class="next">';
		$config['next_tag_close'] = '</li>';
		$config['last_link']=false;
		$config['first_link']=false;

		$this->pagination->initialize($config);
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/shops/archive',$data);
		$this->load->view(THEME.'/footer');
	}

	public function view(){

		$data['user'] = $this->users->get_user($this->users->id());

		$shop_slug=$this->uri->segment(3);
		$data['cateogry'] = $this->shops->get_categories();
		$data['shop']=$shop=$this->shops->get_by_id($shop_slug);
		if(empty($shop)){
			$data['shop']=$shop=$this->shops->get_by_slug($shop_slug);
		}
		$lang=$this->language;

		if(!empty($shop->meta_description)){
			$meta_desc=json_decode($shop->meta_description);
			if(isset($meta_desc->$lang)) $data['seo_description']=$meta_desc->$lang;
			else $data['seo_description']="";
		}
		if(!empty($shop->meta_keywords)){
			$meta_keywords=json_decode($shop->meta_keywords);
			if(isset($meta_keywords->$lang)) $data['seo_keywords']=$meta_keywords->$lang;
			else $data['seo_keywords']="";
		}
		if(!empty($shop->title)){
			$title=json_decode($shop->title);
			if(isset($title->$lang)) $data['title']=$title->$lang;
			else $data['title']=$title;
		}
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/shops/single',$data);
		$this->load->view(THEME.'/footer');
	}
}
