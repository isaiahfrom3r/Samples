<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>


<div class="card">
			<div class="card-header">
				<h2><?=strtoupper($meta->name)?> - URL: <?=$meta->url?>
					<small>
						Edit Meta

					</small>
				</h2>
			</div>
					<div class="card-padding card-body">

			<?=form_open() ?>


				<div class="form-group">
					<label for="seo">SEO Keywords</label>
					<input type="text" class="form-control" name="seo" placeholder="SEO Keywords" value="<?=$meta->seo?>">
				</div>

				<div class="form-group">
					<label for="name">Page Name / Title</label>
					<input type="text" class="form-control" name="name" placeholder="Page Name / Title" value="<?=$meta->name?>">
				</div>
				<div class="form-group">
					<label for="name">SEO Page Description</label>
					<textarea name="description" class="form-control" placeholder="SEO Page Description"><?=$meta->description?></textarea>
				</div>



				<div class="form-group">
					<input type="submit" class="btn btn-default" value="Save">
				</div>


			</form>


		</div>
	</div><!-- .row -->
</div><!-- .container -->
