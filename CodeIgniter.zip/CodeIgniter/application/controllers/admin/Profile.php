<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->users->is_admin(1);
		$this->load->model('Profiles');
		$this->users->is_admin(1);

	}
	public function index(){
		// header stuff
		$head['styles'] = array('/assets/admin/css/profile.css');
		$head['scripts'] = array(
			'/assets/admin/js/profile.js',
			'//code.jquery.com/ui/1.11.4/jquery-ui.js'
		);
		$this->load->view(ADMIN_THEME.'/header',$head);

		$data['fields'] = $fields = $this->Profiles->get_fields();
		$data['cats'] = $cats = $this->Profiles->get_cats();

		$this->load->view(ADMIN_THEME.'/profile/list',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}
	public function add_category(){
		$this->Profiles->add_category($this->input->post('name'));
		$this->alert->set('Category Added','success');
		redirect('admin/profile');
	}
	public function delete_cat($id=''){
		$this->Profiles->delete_cat($id);
		$this->alert->set('Category Deleted','success');
		redirect('admin/profile');
	}
	public function create($id){
		if($id != 0){
			$data['field'] = (array)$field = $this->Profiles->get_field_by_id($id);
		}else{
			$data['field'] = array("id"=>0,"name"=>"","slug"=>"","type"=>"text","category"=>"","options"=>'[""]');
		}
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('slug', 'Slug', 'trim|required');
		if ($this->form_validation->run() === false) {
			// validation not ok, send validation errors to the view
		} else {
			$this->load->dbforge();
				// table doesn't exist lets do this
				if (!$this->db->field_exists($_POST['slug'], 'users_profile')){

					$_POST['options'] = explode("\n", $_POST['data']);
					$_POST['slug'] = str_ireplace(' ', '', $_POST['slug']);
					$fields = array(
	                    $_POST['slug'] => array('type' => 'TEXT'),
					);
					$this->dbforge->add_column('users_profile', $fields);

					$this->Profiles->insert_update_field($_POST);
					$this->load->library('user_agent');
					$this->alert->set('Field Added','success');
					redirect(base_url().'admin/profile');
				}else{
					// update it
					if($id != 0){

						$fields = array(
	                    	$field->slug => array('type' => 'TEXT', 'name'=> $_POST['slug']),
						);

						$this->dbforge->modify_column('users_profile', $fields);

						$opts = explode("\n", trim($_POST['data']));
						foreach($opts as $ops){
							$_POST['options'][] = trim($ops);
						}
						$_POST['slug'] = str_ireplace(' ', '', $_POST['slug']);
						$this->Profiles->insert_update_field($_POST);
						$this->load->library('user_agent');
						$this->alert->set('Field Updated','success');
						redirect(base_url().'admin/profile');

					}else{

						$this->load->library('user_agent');
						$this->alert->set('DB field already exists','error');
						redirect($this->agent->referrer());

					}



				}


			$this->alert->set('Field Added','success');
		}

		$data['cats'] = $cats = $this->Profiles->get_cats();
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/profile/create',$data);
		$this->load->view(ADMIN_THEME.'/footer');

	}
	public function remove($slug){
		$this->load->dbforge();
		$this->dbforge->drop_column('users_profile', $slug);

		$this->Profiles->remove_field($slug);

		$this->alert->set('Field Removed','success');
		redirect(base_url().'admin/profile');
	}


}
