	$( document ).ready(function() {

		$( ".filter_toggle" ).click(function() {
		    $('.filter_toggle').toggleClass('shift_filter');
		    $('.calfilters').toggleClass('shift_class');
		    jQuery('#magic_cover').toggle();
		});
		$( "#magic_cover" ).click(function() {
		    $('.filter_toggle').removeClass('shift_filter');
		    $('.calview').removeClass('shift_class_left');
		    $('.calfilters').removeClass('shift_class');
		});

		$( ".user_select" ).click(function() {
		    var uid = $(this).attr('data-uid');

		    if($(this).hasClass( "activeuser" )){
			    console.log('uncheck');
				$('#checkbox_'+uid).prop( "checked", false );
			    $(this).removeClass( "activeuser" );
		    }else{
			    $('#checkbox_'+uid).prop( "checked", true );
			    $(this).addClass( "activeuser" );
		    }

		});
		$( ".gobutton" ).click(function() {
			$( "#filter_form" ).submit();
		});


		$( ".cal_bubble" ).click(function() {
		    $('.calview').toggleClass('shift_class_left');
		    jQuery('#magic_cover').toggle();


		    var tid = $(this).attr('data-task');
		    console.log(HOST_NAME+'calendar/info/'+tid);
		    jQuery.ajax({
				url: HOST_NAME+'calendar/info/'+tid,
				success: function(data) {

					$('.info_box').html(data);

				}

			});

		});

		$( ".studio_video" ).click(function() {

			 $('.abox').prop( "checked", false );
			 $('.user_select').removeClass( "activeuser" );


			 $('.studio4 .abox').prop( "checked", true );
			 $('.studio4 .user_select').addClass( "activeuser" );

		});

		$( ".studio_social" ).click(function() {

			 $('.abox').prop( "checked", false );
			 $('.user_select').removeClass( "activeuser" );


			 $('.studio1 .abox').prop( "checked", true );
			 $('.studio1 .user_select').addClass( "activeuser" );

		});

		$( ".studio_print" ).click(function() {

			 $('.abox').prop( "checked", false );
			 $('.user_select').removeClass( "activeuser" );


			 $('.studio2 .abox').prop( "checked", true );
			 $('.studio2 .user_select').addClass( "activeuser" );

		});

		$( ".studio_digital" ).click(function() {

			 $('.abox').prop( "checked", false );
			 $('.user_select').removeClass( "activeuser" );


			 $('.studio3 .abox').prop( "checked", true );
			 $('.studio3 .user_select').addClass( "activeuser" );

		});

		$( ".studio_clear" ).click(function() {

			 $('.abox').prop( "checked", false );
			 $('.user_select').removeClass( "activeuser" );


		});

		$(".searchname").bind("keyup change", function(e) {
		    var textval = $('.searchname').val();
		    console.log(textval);

		    $(".ausertab").each(function() {

			   	var html = $(this).find('.user_select span').html().toLowerCase();

			   	if (html.indexOf(textval) >= 0){


				     $(this).show();
			     }else{
				     $(this).hide();

			     }
			 });

		});




	});







