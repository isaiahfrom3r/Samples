<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * Advance_menu_model model
 *
 * This class model is used for manage menu.
 */
class Desks extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

	public function get_desks(){
		$q = $this->db->get("desks");
		$q = $q->result();
		return $q;
	}

	public function get($id=""){
		$this->db->where('id',$id);
		$q = $this->db->get("desks");
		$q = $q->row();
		return $q;
	}

}
