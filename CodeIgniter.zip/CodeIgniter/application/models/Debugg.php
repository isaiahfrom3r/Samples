<?php
class debugg extends CI_Model {

	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }




	function debug($text, $truncate = FALSE)
	{
		$fp = fopen(dirname(dirname(dirname(__FILE__))).'/debugg.txt', 'a+');
		if ($truncate)
		{
			ftruncate($fp, 0);
		}
		fwrite($fp, $text);
		fclose($fp);
	}


}
?>
