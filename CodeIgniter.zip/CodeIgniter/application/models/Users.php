<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User_model class.
 *
 * @extends CI_Model
 */
class Users extends CI_Model {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {

		parent::__construct();
		$this->load->database();

	}

	// get user id from session
	public function id()
	{
		if(isset($this->session->userdata['user']['id'])){
			$id = $this->session->userdata['user']['id'];
		}
		if (isset($id) && $id != ''){
			return $id;
		}
		else{
			return '';
		}
	}
	public function check_team(){
		$user =  $this->get($this->id());
		$league = $this->Leagues->get_league_by_id($user->team_id);

		if($user->team_id < 1 || empty($league)){
			$this->db->where('user_id',$user->id);
			$q = $this->db->get("league_team");
			$q = $q->row();
			$data = array(
               'team_id' => $q->league_id,
            );

			$this->db->where('id', $user->id);
			$this->db->update('users', $data);

		}
	}
	function email_exists($email = '')
	{
		$this->db->limit(1);
		$this->db->where('email', $email);
		if ($this->db->count_all_results('users') > 0)
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	public function get_by_protocal_id($id,$protocal_col){
		if(!empty($id)){
			$this->db->where($protocal_col,$id);
			$this->db->limit(1);
			$user=$this->db->get('users');
			if($user->num_rows()>0){
				return $user->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	public function admin_id()
	{
		if(isset($this->session->userdata['admin']['id'])){
			$id = $this->session->userdata['admin']['id'];
		}
		if (isset($id) && $id != ''){
			return $id;
		}
		else{
			return '';
		}
	}
	public function get_full($id){

	}
	public function get_month_array(){
		$start = strtotime('- 12 months');


		$end = strtotime('- 1 months');
		$month = $start;
		while($month <= $end) {
		  $month = strtotime("+1 month", $month);

		  $month_start = strtotime('first day of this month', $month);
		  $month_end = strtotime('last day of this month', $month);

		  $this->db->where('join_date >', $month_start);
		  $this->db->where('join_date <', $month_end);
		  $q = $this->db->get("users");
		  $months[] = $q->num_rows();


		}

		return $months;
	}

	/**
	 * create_user function.
	 *
	 * @access public
	 * @param mixed $username
	 * @param mixed $email
	 * @param mixed $password
	 * @return bool true on success, false on failure
	 */
	public function create_user($data) {



		$this->db->insert('users', $data);
		$id = $this->db->insert_id();

		$user = $this->get_user($id);


		$sesdata = array(
			'id'		=> (int)$user->id,
			'username'	=> (string)$user->username,
			'email'		=> $user->email,
			'level'		=> $user->level,
			'active'	=> 1,
		);


		$this->session->set_userdata('user',$sesdata);

		return TRUE;

	}
	public function check_ref_count($uid,$rid){
		$user = $this->get();
		$ref = $this->get_user($rid);

		$this->db->where('user_id',$uid);
		$this->db->where('refer_profit_id',$ref->username);
		$q = $this->db->get("user_balance_transactions");
		return $q->num_rows();

	}

	public function get_users(){

// 		$this->db->where('active','1');
		$q = $this->db->get("users");
		$q = $q->result();

		return $q;
	}

	public function get_users_by_keyword($keyword){
		if(!empty($keyword)){

			$this->db->like('username',$keyword);
			$this->db->or_like('email',$keyword);
			$this->db->or_like('first_name',$keyword);
			$this->db->or_like('last_name',$keyword);

			$q = $this->db->get("users");
			$q = $q->result();
			return $q;
		}
	}

	public function get_users_by_keyword_pagi($keyword,$offset,$per_page){
		if(!empty($keyword)){

			$this->db->like('username',$keyword);
			$this->db->or_like('email',$keyword);
			$this->db->or_like('first_name',$keyword);
			$this->db->or_like('last_name',$keyword);
			$this->db->limit($per_page,$offset);
			$q = $this->db->get("users");
			$q = $q->result();
			return $q;
		}
	}

	public function get_users_pagi($num,$limit){

		$this->db->limit($limit,$num);
		$q = $this->db->get("users");
		$q = $q->result();

		return $q;
	}

	/**
	 * resolve_user_login function.
	 *
	 * @access public
	 * @param mixed $username
	 * @param mixed $password
	 * @return bool true on success, false on failure
	 */
	public function resolve_user_login($username, $password) {

		$this->db->select('password');
		$this->db->from('users');
		$this->db->where('username', $username);
		$this->db->or_where('email',$username);
		$hash = $this->db->get()->row('password');

		return $this->verify_password_hash($password, $hash);

	}

	/**
	 * get_user_id_from_username function.
	 *
	 * @access public
	 * @param mixed $username
	 * @return int the user id
	 */
	public function get_user_id_from_username($username) {

		$this->db->select('id');
		$this->db->from('users');
		$this->db->where('username', $username);
		$this->db->or_where('email',$username);

		return $this->db->get()->row('id');

	}

	/**
	 * get_user function.
	 *
	 * @access public
	 * @param mixed $user_id
	 * @return object the user object
	 */
	public function get_user($user_id) {

		$this->db->from('users');
		$this->db->where('id', $user_id);
		$user = $this->db->get()->row();
		unset($user->password);
		return $user;

	}
	/**
	 * get_user function.
	 *
	 * @access public
	 * @param mixed $user_id
	 * @return object the user object
	 */
	public function get_user_by_mail($user_id) {

		$this->db->from('users');
		$this->db->where('email', $user_id);
		$user = $this->db->get()->row();
		unset($user->password);
		return $user;

	}
	/**
	 * get function.
	 *
	 * @access public
	 * @param mixed $user_id
	 * @return object the user object
	 */
	public function get() {
		$user_id = $this->users->id();
		$this->db->from('users');
		$this->db->where('id', $user_id);
		$user = $this->db->get()->row();
		unset($user->password);
		return $user;

	}
	public function get_by_id($user_id) {
		$this->db->from('users');
		$this->db->where('id', $user_id);
		$user = $this->db->get()->row();
		unset($user->password);
		return $user;

	}

	// update user info
	public function update($id='',$post){
		unset($post['dob']);
		unset($post['gender']);

		$this->db->where('id', $id);
		$this->db->update('users', $post);
	}

	// save hash string to DB
	public function update_password($id,$string=''){
		if($string == '' || $id == ''){
			return ;
		}else{

			$data['password'] = $pass = $this->hash_password($string);



			$this->db->where('id', $id);
			$this->db->update('users', $data);

		}
	}
	/**
	 * hash_password function.
	 *
	 * @access private
	 * @param mixed $password
	 * @return string|bool could be a string on success, or bool false on failure
	 */
	public function hash_password($password) {

		return password_hash($password, PASSWORD_BCRYPT);

	}

	/**
	 * verify_password_hash function.
	 *
	 * @access private
	 * @param mixed $password
	 * @param mixed $hash
	 * @return bool
	 */
	private function verify_password_hash($password, $hash) {

		return password_verify($password, $hash);

	}

	public function is_loggedin($redirect=0)
	{

		if (strlen($this->session->user['email']) == 0) {
			if($redirect == 1){


				$camefrom = uri_string();
				$_SESSION['camefrom'] = $camefrom;

				$this->alert->set('This page is for members only','error');
				redirect('/login');
			}
			return FALSE;
		}
		else {
			return TRUE;
		}
	}

	public function is_admin($redirect=0) {

		if(isset($this->session->admin['email'])){

			if ($this->session->admin['email'] && $this->session->admin['level'] < 2) {
				if($redirect == 1){
					$this->alert->set('This page is for admins only','error');
					redirect('/');
				}
				return FALSE;
			}
			else {
				return TRUE;
			}


		}else{
			if($redirect == 1){
				$this->alert->set('This page is for admins only','error');
				redirect('/');
			}
			return FALSE;
		}

	}

	function avatar($user_id = '0', $size = 'big', $mobile=false)
	{
		$this->db->limit(1);
		$q = $this->db->get_where('users', array('id' => $user_id));
		$res = $q->result();

		/*echo '<pre>';
		print_r($res);
		echo '</pre>';*/

		if (count($res) > 0 && ($res[0]->avatar == '' || strlen(trim($res[0]->avatar)) == 0))
		{
			if ($size == 'big')
			{
				return ($mobile?"../":"/").'assets/'.$this->options->get('theme').'/img/glogo.png';
			}
			elseif ($size == 'medium')
			{
				return ($mobile?"../":"/").'assets/'.$this->options->get('theme').'/img/glogo.png';
			}
			else
			{
				return ($mobile?"../":"/").'assets/'.$this->options->get('theme').'/img/glogo.png';
			}
		}
		elseif (count($res) > 0)
		{
			if ($size == 'big')
			{
				return ($mobile?"../":"/").'uploads/avatar_big/'.$res[0]->avatar;
			}
			elseif ($size == 'medium')
			{
				return ($mobile?"../":"/").'uploads/avatar_medium/'.$res[0]->avatar;
			}
			else
			{
				return ($mobile?"../":"/").'uploads/avatar_small/'.$res[0]->avatar;
			}
		}
		else
		{
			return '/uploads/avatars/player.png';
		}

	}
	function save_picture($user_id, $reg_data, $new_user = FALSE)
	{
		if (isset($reg_data['big_avatar']))
		{
			//create medim and small thumbnails for avatar

			$this->load->model('images');
			$this->images->neatresize('./uploads/temp/'.$reg_data['big_avatar'], $this->options->get('avatar_small_width'), $this->options->get('avatar_small_height'), './uploads/avatar_small', $user_id);
			$this->images->neatresize('./uploads/temp/'.$reg_data['big_avatar'], $this->options->get('avatar_medium_width'), $this->options->get('avatar_medium_height'), './uploads/avatar_medium', $user_id);
			$pathinfo=pathinfo($reg_data['big_avatar']);
			copy('./uploads/temp/'.$reg_data['big_avatar'], './uploads/avatar_big/'.$user_id.'.'.$pathinfo['extension']);
			unlink('./uploads/temp/'.$reg_data['big_avatar']);
			$this->db->where('id', $user_id)->limit(1);
			$this->db->update('users', array('avatar' => $user_id.'.'.$pathinfo['extension']));
			$this->session->set_userdata('avatar',$user_id.'.'.$pathinfo['extension']);

			//now put these images on all the servers
			$ips = $this->config->item('master_ip');
			$fields=array();

			$fields['src_big'] = '@./uploads/avatar_big/'.$user_id.'.'.$pathinfo['extension'].';type=image/'.$pathinfo['extension'];
			$fields['src_med'] = '@./uploads/avatar_medium/'.$user_id.'.'.$pathinfo['extension'].';type=image/'.$pathinfo['extension'];
			$fields['src_sml'] = '@./uploads/avatar_small/'.$user_id.'.'.$pathinfo['extension'].';type=image/'.$pathinfo['extension'];

			$curl_handle = curl_init();
			$api_url = 'http://'.$ips.'/index.php/upload/master_avatar';
			curl_setopt($curl_handle, CURLOPT_URL, $api_url);
			curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl_handle, CURLOPT_POST, true);
			curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $fields);

			$result = curl_exec($curl_handle);



		}
	}
	public function get_my_referals(){
		$me = $this->get_user($this->id());
		$this->db->where('refer',$me->username);
		$q = $this->db->get("users");
		$q = $q->result();

		return $q;


	}
	public function get_by_email($email=''){
		if(!empty($email)){
			$this->db->where('email',$email);
			$this->db->limit(1);
			$user=$this->db->get('users');
			if($user->num_rows()>0){
				return $user->row();
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	public function forcelogin($id=''){
		$user = $this->users->get_user($id);

		$sesdata = array(
			'id'			=> (int)$user->id,
			'username'		=> (string)$user->username,
			'email'			=> $user->email,
			'first_name'	=> $user->first_name,
			'last_name'		=> $user->last_name,
			'level'			=> $user->level,
			'admin'			=> $user->level,
		);

		$this->session->set_userdata('user',$sesdata);


	}

}
