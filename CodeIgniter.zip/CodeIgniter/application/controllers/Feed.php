<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feed extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->model('Teams');
		$this->load->model('Leagues');
		$this->load->model('Brackets');
	}

	// Dev Trial -- public $apikey = '2ae4e94e0c794d909a28bb0bdd2eb485';
	public $apikey = "40c64f13345d4d7eaf963b35216065be";


	public function dreamco_curl($url, $sport){
    ini_set('display_errors', 1); // set to 0 for production version
    error_reporting(E_ALL);



	    //$apiKey = 'e4454a313cf74a50a8bdebad19de34bc';
	    $apiKey = $this->apikey;

	    if($apiKey == ''){
		echo "api key for $sport is not set in admin site settings";
		die();
	    }

	    $curl = curl_init();
		 curl_setopt_array($curl, array(
		    CURLOPT_URL => $url,
		    CURLOPT_RETURNTRANSFER => true,
		    CURLOPT_ENCODING => "",
		    CURLOPT_MAXREDIRS => 10,
		    CURLOPT_TIMEOUT => 30,
		    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		    CURLOPT_CUSTOMREQUEST => "GET",
		    CURLOPT_HTTPHEADER => array(
		      "cache-control: no-cache",
		      "ocp-apim-subscription-key: ".$apiKey
		    ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  return "cURL Error #:";
		} else {
		  return $response;
		}
	}
	public function get_part($string, $part, $num="",$key="/"){
	/*
	*  get_part
	*
	*  gets the part of the id string passed by sports data
	*
	*  @Peram: $strng, $part or the array, $only a number, $what do you wnat to explode by
	*  @Return: $part
	*
	*  IsaiahArnold
	*
	*  9/29/14
	*/
		$pieces = explode($key, $string);
		//echo $string; echo "<br>"; // debug helper
		$return = $pieces[$part];

		if($num !=""){
			$return = preg_replace("/[^0-9]/","",$return);
			return $return;
		}
		else{
			return $return;
		}

	}
	public function update_teams(){

		$feed = $this->dreamco_curl('https://api.fantasydata.net/v3/cbb/scores/JSON/teams', "cbb");

		$json    = json_decode($feed,true);


		foreach($json as $j){

			$group =array(
				'cid' => $j['GlobalTeamID'],
				'active' => $j['Active'],
				'rank' => $j['ApRank'],
				'alias' => $j['Key'],
				'subname' => $j['Name'],
				'name' => $j['School'],
				'win' => $j['Wins'],
				'loss' => $j['Losses'],
				'conf_win' => $j['ConferenceWins'],
				'conf_loss' => $j['ConferenceLosses'],
				'sport' => 'CBB',
				'conference' => $j['Conference'],
				'image' => $j['TeamLogoUrl'],

			);

			$this->Teams->insert_update_team($group);

			echo "<pre>";
			print_r($this->db->last_query());
			echo "</pre>";

		}



	}
	public function tournament_feed($seasonname='0'){
		if($seasonname == 0){
			$seasonname = $this->options->get('season');
		}
		echo "<pre>";
		print_r($seasonname);
		echo "</pre>";

		$feed = $this->dreamco_curl('https://api.fantasydata.net/v3/cbb/scores/json/Tournament/'.$seasonname, "cbb");

		$json    = json_decode($feed,true);
		echo "<pre>";
		print_r(count($json['Games']));
		echo "</pre>";
		foreach($json['Games'] as $key=>$g){
			$pool_ids[$g['GlobalGameID']] = $g['GlobalHomeTeamID']."~".$g['GlobalAwayTeamID'];
		}

		echo "<pre>";
		print_r($pool_ids);
		echo "</pre>";
		echo "<pre>";
		print_r($json['Games']);
		echo "</pre>";
		$roundcheck = array(
			1 => 1,
			2 => 1,
			3 => 1,
			4 => 1,
			5 => 1,
			6 => 1,
		);

		$roundfinal_count = array(
			1 => 0,
			2 => 0,
			3 => 0,
			4 => 0,
			5 => 0,
			6 => 0,

		);


		foreach($json['Games'] as $key=>$g){

			if($g['TimeRemainingMinutes'] == ""){
				$g['TimeRemainingMinutes'] = 0;
			}
			if($g['TimeRemainingSeconds'] == ""){
				$g['TimeRemainingSeconds'] = 0;
			}

			if($g['HomeTeamScore'] == ""){
				$g['HomeTeamScore'] = 0;
			}
			if($g['AwayTeamScore'] == ""){
				$g['AwayTeamScore'] = 0;
			}
			if($g['Period'] == ""){
				$g['Period'] = 'Q1';
			}elseif($g['Period'] != "F" || $g['Period'] != "F/O"){
				$g['Period'] = "Q".$g['Period'];
			}

			if($g['Round'] == ""){

				continue;
			}

			if($g['Status'] == "Final" || $g['Status'] == "F/OT" || $g['Status'] == "Canceled" || $g['Status'] == "Postponed"){
				$final = 1;

				$roundfinal_count[$g['Round']]++;

			}else{
				$final = 0;

				$roundcheck[$g['Round']] = 0;
			}


/*
			if($key ==24){
				$g['GlobalAwayTeamID'] = "";
			}
*/
			if($g['Round'] == 1){
				if($g['GlobalAwayTeamID'] == ""){
					if($g['AwayTeamPreviousGlobalGameID'] != ""){
						$g['GlobalAwayTeamID'] = $pool_ids[$g['AwayTeamPreviousGlobalGameID']];
					}
				}

				if($g['GlobalHomeTeamID'] == ""){
					if($g['HomeTeamPreviousGlobalGameID'] != ""){
						$g['GlobalHomeTeamID'] = $pool_ids[$g['HomeTeamPreviousGlobalGameID']];
					}
				}
			}


			$group = array(
				'final' => $final,
				'cid' => $g['GlobalGameID'],
				'season' => $g['Season'],
				'sport' => 'CBB',
				'gamestart' => strtotime($g['DateTime']),
				'game_type' => $g['SeasonType'],
				'status' => $g['Status'],
				'home' => $g['GlobalHomeTeamID'],
				'away' => $g['GlobalAwayTeamID'],
				'home_team_score' => $g['HomeTeamScore'],
				'away_team_score' => $g['AwayTeamScore'],
				'segment_num' => $g['Period'],
				'spread' => $g['PointSpread'],
				'over_under' => $g['OverUnder'],
				'away_money_line' => $g['AwayTeamMoneyLine'],
				'home_money_line' => $g['HomeTeamMoneyLine'],
				'minutes' => $g['TimeRemainingMinutes'],
				'seconds' => $g['TimeRemainingSeconds'],
				'round' => $g['Round'],
				'home_team_seed' => $g['HomeTeamSeed'],
				'away_team_seed' => $g['AwayTeamSeed'],
				'bracket' => $g['Bracket'],
				'tourney' => $g['TournamentID'],

			);



			$this->db->where('cid',$group['cid']);
			$q = $this->db->get("sport_event");

			if ($q->num_rows() > 0){

				$this->db->where('cid',$group['cid']);
				$this->db->update('sport_event', $group);

			}else{

				$this->db->insert('sport_event', $group);

			}
		}

		$newround = 0;
		foreach($roundcheck as $round=>$val){
			if($val == 1){
				$newround = $round;
			}
		}
		$newround = $newround + 1;

		$roundupatedata = array(
           'value' => $newround,
        );

		$this->db->where('cid', 81);
		$this->db->update('options', $roundupatedata);

		echo "<pre>";
		print_r($this->db->last_query());
		echo "</pre>";


		if($roundfinal_count[1] == 32){

			$data = array(
	           'open' => 1,
	        );

			$this->db->where('round', 2);
			$this->db->update('leagues', $data);

			echo "<pre>";
			print_r($this->db->last_query());
			echo "</pre>";

		}


		if($roundfinal_count[2] == 16){

			$data = array(
	           'open' => 1,
	        );

			$this->db->where('round', 3);
			$this->db->update('leagues', $data);

			echo "<pre>";
			print_r($this->db->last_query());
			echo "</pre>";

		}





		$this->db->where('cid',$g['TournamentID']);
		$q = $this->db->get("sport_bracket");
		$q = $q->row();



		$this->build_bracket($json['TournamentID'], json_decode($q->bracket,true) );

	}
	public function build_bracket($tid,$compbracke){
		$this->db->where('tourney',$tid);
		$q = $this->db->get("sport_event");
		$q = $q->result();

		foreach($q as $g){
			$season = $g->season;
			if($g->bracket != ""){
				$grouped[$g->bracket][$g->round][] = $g;
			}else{
				$grouped['finals'][$g->round][] = $g;
			}
		}

		$group = array(
			'cid' => $tid,
			'season' => $season,
			'bracket' => json_encode($grouped),
		);



		$playinupdate = array();

		foreach($compbracke as $key1=>$b){
			foreach($b as $key2=>$bb){
				foreach($bb as $key3=>$m){


					if (strpos($m['away'],'~') !== false) {

					    if (strpos($grouped[$key1][$key2][$key3]->away,'~') === false) {

					        $playinupdate[$m['away']] = $grouped[$key1][$key2][$key3]->away;

					    }


					}

					if (strpos($m['home'],'~') !== false) {

					    if (strpos($grouped[$key1][$key2][$key3]->away,'~') === false) {

					        $playinupdate[$m['home']] = $grouped[$key1][$key2][$key3]->away;

					    }


					}


				}
			}
		}

		$this->update_users_picks($playinupdate);


		$this->db->where('cid',$group['cid']);
		$q = $this->db->get("sport_bracket");

		if ($q->num_rows() > 0){

			$this->db->where('cid',$group['cid']);
			$this->db->update('sport_bracket', $group);

		}else{

			$this->db->insert('sport_bracket', $group);

		}


		$fillcount = 0;
		foreach($grouped as $key1=>$b){
			foreach($b as $key2=>$bb){

				if($key2 == 1){

					foreach($bb as $key3=>$thing){


						if($thing->away != "" && $thing->home != ""){
							$fillcount++;
						}


					}

				}
			}
		}

		if($fillcount == 32){
			$data = array(
	           'open' => 1,
	        );

			$this->db->where('round', 1);
			$this->db->update('leagues', $data);

			echo "<pre>";
			print_r($this->db->last_query());
			echo "</pre>";
		}

	}
	public function update_users_picks($updates){
		if(empty($updates)){
			return ;
		}

		$q = $this->db->get("leagues");
		$q = $q->result();

		foreach($q as $lg){
			$leagues[$lg->cid] = $lg;
		}


		$q = $this->db->get("league_team");
		$q = $q->result();


		$bracket =  $this->Brackets->get_bracket();
		$bracket =  json_decode($bracket->bracket,true);

		foreach($q as $tm){
			if($tm->picks == ""){

				$league = $leagues[$tm->league_id];
				$this->Leagues->save_default_picks($league,$bracket,$tm->user_id);

			}
		}



		$q = $this->db->get("league_team");
		$q = $q->result();


		foreach($q as $tm){
			$brack = json_decode($tm->picks,true);
			$changed = 0;
			foreach($brack as $key1=>$b){
				foreach($b as $key2=>$bb){

					foreach($bb as $key3=>$m){

							if($m == ""){
								continue;
							}
							if (strpos($m,'~') !== false) {

							    if(isset($updates[$m])){
								    $changed = 1;

								    $brack[$key1][$key2][$key3] = $updates[$m];

							    }


							}



					}
				}
			}


			if($changed == 1){

				$tm->picks = json_encode($brack);
				$this->db->where('id', $tm->id);
				$this->db->update('league_team', $tm);

			}


		}



	}
	public function update_events(){
		$feed = $this->dreamco_curl('https://api.fantasydata.net/v3/cbb/scores/JSON/Games/2018', "cbb");

		$json    = json_decode($feed,true);


		foreach($json as $g){



			if($g['TimeRemainingMinutes'] == ""){
				$g['TimeRemainingMinutes'] = 0;
			}
			if($g['TimeRemainingSeconds'] == ""){
				$g['TimeRemainingSeconds'] = 0;
			}

			if($g['HomeTeamScore'] == ""){
				$g['HomeTeamScore'] = 0;
			}
			if($g['AwayTeamScore'] == ""){
				$g['AwayTeamScore'] = 0;
			}
			if($g['Period'] == ""){
				$g['Period'] = 'Q1';
			}elseif($g['Period'] != "F" || $g['Period'] != "F/O"){
				$g['Period'] = "Q".$g['Period'];
			}

			if($g['Status'] == "Final" || $g['Status'] == "F/OT" || $g['Status'] == "Canceled" || $g['Status'] == "Postponed"){
				$final = 1;
			}else{
				$final = 0;
			}

			$group = array(
				'final' => $final,
				'cid' => $g['GlobalGameID'],
				'season' => $g['Season'],
				'sport' => 'CBB',
				'gamestart' => strtotime($g['DateTime']),
				'game_type' => $g['SeasonType'],
				'status' => $g['Status'],
				'home' => $g['GlobalHomeTeamID'],
				'away' => $g['GlobalAwayTeamID'],
				'home_team_score' => $g['HomeTeamScore'],
				'away_team_score' => $g['AwayTeamScore'],
				'segment_num' => $g['Period'],
				'spread' => $g['PointSpread'],
				'over_under' => $g['OverUnder'],
				'away_money_line' => $g['AwayTeamMoneyLine'],
				'home_money_line' => $g['HomeTeamMoneyLine'],
				'minutes' => $g['TimeRemainingMinutes'],
				'seconds' => $g['TimeRemainingSeconds'],

			);

			$this->db->where('cid',$group['cid']);
			$q = $this->db->get("sport_event");

			if ($q->num_rows() > 0){

				$this->db->where('cid',$group['cid']);
				$this->db->update('sport_event', $group);

			}else{

				$this->db->insert('sport_event', $group);

			}

		}

	}
	public function get_headshots(){
		ini_set('display_errors', 1); // set to 0 for production version
		ini_set('allow_url_fopen', 1);
		error_reporting(E_ALL);
		ini_set('memory_limit','9000M');

		$season = "2016-2017";

		$url =  "https://api.sportradar.us/nfl-images-p3/ap/headshots/players/2017/manifest.xml?api_key=9nwnw5nbpg5rd89xjqsu2vt7";

		$xmli = file_get_contents($url);
		$data = new SimpleXMLElement($xmli);

		$data = json_decode(json_encode($data), true);

		foreach($data['asset'] as $d){

			$image[] =  array(
				'id' => $d['@attributes']['player_id'],
				'link' => $d['links']['link'][8]['@attributes']['href'],
			);

		}

		if (!file_exists($_SERVER['DOCUMENT_ROOT'].'/headshots')) {
		    mkdir($_SERVER['DOCUMENT_ROOT'].'/headshots', 0777, true);
		}



		foreach($image as $key=>$i){



			$file = "https://api.sportradar.us/nfl-images-p3/ap".$i['link']."?api_key=9nwnw5nbpg5rd89xjqsu2vt7";
			echo $file;  echo "<br>";
			copy($file, $_SERVER['DOCUMENT_ROOT'].'/headshots/'.$i['id'].'.jpg');


		}



	}



}
