<input  type="hidden" class="pool" value="0">
<style type="text/css" media="screen">
	.fg-line{
		width: 100% !important;
	}
	.rad .fg-line{
		width: auto !important;
	}
	input.red {
		border: 2px solid red;
		border-radius: 5px;
		color: red;
	}
	label.red {

		color: red;
	}

</style>

<section class="content card">
	<div class="container">
	<h2>Auto League</h2>
	<hr>
<!-- 	<?=validation_errors();?> -->

	<form class="pForm" action="" method="post" accept-charset="utf-8">
	<h4>Choose League Type</h4>


<!-- 	LEAGUE TYPE -->
	<p class="rad">
   		<input type="radio" <?php if(isset($league->type) && $league->type == 1){echo "checked='checked'";} ?>  id="type1" name="type" value="1">
   		<label for="type1">Free League</label>
    </p>
    <p class="rad">
    	<input type="radio" <?php if(isset($league->type) && $league->type == 2){echo "checked='checked'";} ?>  id="type2" name="type" value="2">
    	<label for="type2">Premium</label>
    </p>
    <p class="rad">
    	<input type="radio" <?php if(isset($league->type) && $league->type == 3){echo "checked='checked'";} ?>  id="type3" name="type" value="3">
		<label for="type3">Paid Entry League</label>
    </p>


	<hr>
	<h4>Choose League Size & Format</h4>

			<div class="form-group half ">
				<label>League Name</label>
				<input type="text" class="form-control" placeholder="League Name" name="name" value="<?php if(isset($league->name)){echo $league->name;} ?>">
			</div>

			<div class="form-group half payrelated">
				<label>Entry Fee Per User</label>
				<?php if(!isset($league->entry_fee) || $league->entry_fee == ""){$league->entry_fee = 0;} ?>
				<input type="text" class="form-control entry" name="entry_fee" value="<?php if(isset($league->entry_fee)){echo $league->entry_fee;} ?>">
			</div>

			<div class="form-group  payrelated">
				<label>Rake</label>

				<input type="text" class=" form-control entry rakenum" name="rake" placeholder="0.00"  value="<?php if(isset($league->rake)){echo $league->rake;}else{echo $this->options->get('rake');} ?>">
			</div>

			<div class="form-group half">
				<label>League Format</label>
				<select class="form-control" name="style">
					<option <?php if(isset($league->style) && $league->style == 1){echo "selected='selected'";} ?> value="1">Head to Head (H2H)</option>
					<option <?php if(isset($league->style) && $league->style == 2){echo "selected='selected'";} ?> value="2">Points Only</option>
					<option <?php if(isset($league->style) && $league->style == 3){echo "selected='selected'";} ?> value="3">Points with H2H Playoffs</option>
				</select>
			</div>

			<div class="form-group half">
				<label>League Size</label>
				<select class="form-control league_size" name="size">
					<option <?php if(isset($league->league_size) && $league->league_size == 6){echo "selected='selected'";} ?> value="6">6</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 8){echo "selected='selected'";} ?> value="8">8</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 10){echo "selected='selected'";} ?> value="10">10</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 12){echo "selected='selected'";} ?> value="12">12</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 14){echo "selected='selected'";} ?> value="14">14</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 16){echo "selected='selected'";} ?> value="16">16</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 18){echo "selected='selected'";} ?> value="18">18</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 20){echo "selected='selected'";} ?> value="20">20</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 22){echo "selected='selected'";} ?> value="22">22</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 24){echo "selected='selected'";} ?> value="24">24</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 26){echo "selected='selected'";} ?> value="26">26</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 28){echo "selected='selected'";} ?> value="28">28</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 30){echo "selected='selected'";} ?> value="30">30</option>
					<option <?php if(isset($league->league_size) && $league->league_size == 32){echo "selected='selected'";} ?> value="32">32</option>
				</select>
			</div>

			<div class="form-group half">
				<label>Playoff Teams (If applicable)</label>
				<select class="form-control league_size" name="playoff_teams">
					<option <?php if(isset($league->playoff_teams) && $league->playoff_teams == 2){echo "selected='selected'";} ?> value="2">2</option>
					<option <?php if(isset($league->playoff_teams) && $league->playoff_teams == 4){echo "selected='selected'";} ?> value="4">4</option>
					<option <?php if(isset($league->playoff_teams) && $league->playoff_teams == 6){echo "selected='selected'";} ?> value="6">6</option>
					<option <?php if(isset($league->playoff_teams) && $league->playoff_teams == 8){echo "selected='selected'";} ?> value="8">8</option>
				</select>
			</div>

			<div class="form-group half">
				<label>Playoff Start Week (If applicable)</label>
				<select class="form-control league_size" name="playoff_week">
					<option <?php if(isset($league->playoff_week) && $league->playoff_week == 10){echo "selected='selected'";} ?> value="10">10</option>
					<option <?php if(isset($league->playoff_week) && $league->playoff_week == 11){echo "selected='selected'";} ?> value="11">11</option>
					<option <?php if(isset($league->playoff_week) && $league->playoff_week == 12){echo "selected='selected'";} ?> value="12">12</option>
					<option <?php if(isset($league->playoff_week) && $league->playoff_week == 13){echo "selected='selected'";} ?> value="13">13</option>
					<option <?php if(isset($league->playoff_week) && $league->playoff_week == 14){echo "selected='selected'";} ?> value="14">14</option>
					<option <?php if(isset($league->playoff_week) && $league->playoff_week == 15){echo "selected='selected'";} ?> value="15">15</option>

				</select>
			</div>

			<div style="clear:both;"></div>
			<div class="payout_group <?php if(isset($league->type) && $league->type == 3){ }else{echo "hide";} ?>">

			<hr>


			<h4>Payout Settings</h4>

			<label>$<span class="available"></span> Total Prize Pool  |  <span class="remlable">$<span class="remainging"></span> Remaining</span></label>

			<div class="row">
			<?php

				$payouts = json_decode($league->payouts,true);

				$x = 0;
			while($x < 6){ ?>
				<div class="form-group half">
					<div class="col-sm-2">
						<label>Rank <?=$x+1?></label>
					</div>
					<div class="col-sm-10">
						<input type="number" min="0" class="form-control place payamount" placeholder="0" name="payouts[<?=$x+1?>]" value="<?php if(isset($payouts['payouts'][$x+1])){echo $payouts['payouts'][$x+1];}else{echo 0; } ?>">
					</div>
				</div>

			<?php $x++; } ?>
		</div>

		<hr>

<!-- 		<div class="checkbox"><label><input type="checkbox" value="1" name="honor"> <strong>Enable Honor Players</strong></label></div> -->
		<p>Honor players are the top fantasy point earners per position. You can issue prize money to the team owners who have the highest point earner for each position. (not available for DEF players)</p>

		<br>
		<div class="row">
			<div class="form-group half">
				<div class="col-sm-2">
					<label>QB</label>
				</div>
				<div class="col-sm-10">
					<input type="number" min="0" class="form-control honor payamounthonor" placeholder="0" name="honor[QB]" value="<?php if(isset($payouts['honor']['QB'])){echo $payouts['honor']['QB'];}else{echo 0; } ?>">
				</div>
			</div>
			<div class="form-group half">
				<div class="col-sm-2">
					<label>RB</label>
				</div>
				<div class="col-sm-10">
					<input type="number" min="0" class="form-control honor payamounthonor" placeholder="0" name="honor[RB]" value="<?php if(isset($payouts['honor']['RB'])){echo $payouts['honor']['RB'];}else{echo 0; } ?>">
				</div>
			</div>
			<div style="clear:both;"></div>

			<div class="form-group half">
				<div class="col-sm-2">
					<label>WR</label>
				</div>
				<div class="col-sm-10">
					<input type="number" min="0" class="form-control honor payamounthonor" placeholder="0" name="honor[WR]" value="<?php if(isset($payouts['honor']['WR'])){echo $payouts['honor']['WR'];}else{echo 0; } ?>">
				</div>
			</div>
			<div class="form-group half">
				<div class="col-sm-2">
					<label>TE</label>
				</div>
				<div class="col-sm-10">
					<input type="number" min="0" class="form-control honor payamounthonor" placeholder="0" name="honor[TE]" value="<?php if(isset($payouts['honor']['TE'])){echo $payouts['honor']['TE'];}else{echo 0; } ?>">
				</div>
			</div>
			<div style="clear:both;"></div>

			<div class="form-group half">
				<div class="col-sm-2">
					<label>K</label>
				</div>
				<div class="col-sm-10">
					<input type="number" min="0" class="form-control honor payamounthonor" placeholder="0" name="honor[K]" value="<?php if(isset($payouts['honor']['K'])){echo $payouts['honor']['K'];}else{echo 0; } ?>">
				</div>
			</div>
			<div class="form-group half">
				<div class="col-sm-2">
					<label>D/ST</label>
				</div>
				<div class="col-sm-10">
					<input type="number" min="0" class="form-control honor payamounthonor" placeholder="0" name="honor[D]" value="<?php if(isset($payouts['honor']['D'])){echo $payouts['honor']['D'];}else{echo 0; } ?>">
				</div>
			</div>
			<div style="clear:both;"></div>

		</div>

		</div>

		<hr>


			<hr>
			<h4>Scoring Setting</h4>

			<div class="form-group third">
				<label>Scoring Settings</label>

				<select class="form-control " name="scoring">
					<?php foreach($scorings as $score){ ?>
						<option <?php if(isset($league->scoring) && $league->scoring == $score->cid){echo "selected='selected'";} ?> value="<?=$score->cid?>"><?=$score->name?></option>
					<?php } ?>
				</select>

			</div>

			<div class="form-group third">
				<label>Fractional Scoring</label>
				<select class="form-control " name="fractional">
					<option <?php if(isset($league->fractional) && $league->fractional == 0){echo "selected='selected'";} ?> value="0">Off</option>
					<option <?php if(isset($league->fractional) && $league->fractional == 1){echo "selected='selected'";} ?> value="1">On</option>
				</select>
			</div>

			<div class="form-group third">
				<label>Pass Interference Scoring</label>
				<select class="form-control " name="p_int_scoring">
					<option <?php if(isset($league->p_int_scoring) && $league->p_int_scoring == 0){echo "selected='selected'";} ?> value="0">Off</option>
					<option <?php if(isset($league->p_int_scoring) && $league->p_int_scoring == 1){echo "selected='selected'";} ?> value="1">On</option>
				</select>
			</div>

			<div class="form-group half">
				<label>Live In-Game Substitutions</label>
				<select class="form-control " name="in_game_subs">
					<option <?php if(isset($league->in_game_subs) && $league->in_game_subs == 0){echo "selected='selected'";} ?> value="0">Off</option>
					<option <?php if(isset($league->in_game_subs) && $league->in_game_subs == 1){echo "selected='selected'";} ?> value="1">On</option>
				</select>
			</div>



			<div class="form-group half">
				<label>Waiver Type</label>
				<select class="form-control" name="waivers">
					<option <?php if(isset($league->waivers) && $league->waivers == 1){echo "selected='selected'";} ?> value="1" >Blind Bidding</option>
					<option <?php if(isset($league->waivers) && $league->waivers == 2){echo "selected='selected'";} ?> value="2">First Come First Serve Waivers</option>
					<option <?php if(isset($league->waivers) && $league->waivers == 3){echo "selected='selected'";} ?> value="3">Reverse Standings | Standard Waivers</option>
				</select>
			</div>

			<div class="form-group half">
				<label>Waiver Budget (FAB league only)</label>
				<input type="number" step="1" class="form-control" name="budget" value="<?php if(isset($league->budget)){echo $league->budget;}else{echo "500";} ?>">
			</div>


			<div class="form-group half">
				<label>Live In-Game Substitutions Cooldown</label>
				<select class="form-control" name="in_game_cool">
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 60){echo "selected='selected'";} ?> value="60" >1 minute</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 120){echo "selected='selected'";} ?> <?php if(!isset($league)){ ?>selected="" <?php } ?> value="120">2 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 300){echo "selected='selected'";} ?> value="300">5 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 600){echo "selected='selected'";} ?> value="600">10 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 900){echo "selected='selected'";} ?> value="900">15 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 1800){echo "selected='selected'";} ?> value="1800">30 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 3600){echo "selected='selected'";} ?> value="3600">60 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 7200){echo "selected='selected'";} ?> value="7200">120 minutes</option>
					<option <?php if(isset($league->in_game_cool) && $league->in_game_cool == 14400){echo "selected='selected'";} ?> value="14400">240 minutes</option>
				</select>
			</div>


			<hr>
			<h4>Roster Settings</h4>

<!-- 		Left out form element, I figured it's better for you to decide where/how to go about this ultimately. -JS -->

		<div class="form-group full">
			<label>Total Roster Size</label>
			<div class="small">Roster size, total # of starters, and total # on bench update automatically as you adjust the values below.</div>
			<input type="text" class="form-control total" readonly="" name="" value="" />
			<input type="hidden"class="form-control total" readonly="" name="roster_size" value="" />

		</div>

		<div class="form-group third">
			<label>Total # of Starters</label>
			<input type="number" min="1" max="9" readonly="" class="form-control starters" name="" value="" />

		</div>

		<div class="form-group third">
			<label>Total # on Bench</label>
			<input type="number" min="1" max="6" readonly="" class="form-control bench" name="" value="" />

		</div>

		<div class="form-group third">
			<label>Total # of IR Spots</label>
			<input type="number" min="0" max="2" class="form-control" name="roster_ir" value="<?php if(isset($league->roster_ir)){echo $league->roster_ir;}else{echo "2";} ?>" />
		</div>

		<hr>

		<h4>Starting Offensive &amp; Team Positions</h4>
		<?php
		if(isset($league->roster)){
			$roster = json_decode($league->roster,true);
		}else{
			$roster = array();
		}
		foreach($roster as $key=>$ros){
			if($ros == ""){
				$roster[$key] = 0;
			}
		}
		?>
		<div class="form-group fourth">
			<label>QB</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[QB]" value="<?php if(isset($roster['QB'])){echo $roster['QB'];}else{echo "1";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>RBs</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[RB]" value="<?php if(isset($roster['RB'])){echo $roster['RB'];}else{echo "2";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>WRs</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[WR]" value="<?php if(isset($roster['WR'])){echo $roster['WR'];}else{echo "2";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>TE</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[TE]" value="<?php if(isset($roster['TE'])){echo $roster['TE'];}else{echo "1";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>FLEX (RB/WR/TE)</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[FLEX]" value="<?php if(isset($roster['FLEX'])){echo $roster['FLEX'];}else{echo "1";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>K</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[K]" value="<?php if(isset($roster['K'])){echo $roster['K'];}else{echo "1";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>Team DEF/ST</label>
			<input type="number" min="0" class="form-control tplayer" name="roster[DEF]" value="<?php if(isset($roster['DEF'])){echo $roster['DEF'];}else{echo "1";} ?>" />
		</div>

		<div class="form-group fourth">
			<label>Bench (Any Pos)</label>
			<input type="number" min="0" class="form-control tbench" name="roster[BENCH]" value="<?php if(isset($roster['BENCH'])){echo $roster['BENCH'];}else{echo "6";} ?>" />
		</div>

		<hr>

		<div class="form-group">
			<label>Do you want to Enable IDP (Individual Defensive Players?)</label>
			<div class=""><label><input <?php if(isset($league->idp) && $league->idp == 0){echo "checked='checked'";} ?>  type="radio" value="0" name="idp" checked> Disabled</label></div>
			<div class=""><label><input <?php if(isset($league->idp) && $league->idp == 1){echo "checked='checked'";} ?>  type="radio" value="1" name="idp"> Enabled</label></div>
		</div>


		<div class="idp" style="display: none;">

			<hr>
			<h4>Starting IDP Positions</h4>
			<div class="small">
				You may elect to select IDP positions or use the Standard option to allow all IDP positions.<br>

				Please note, since defensive players often switch official positions, they are grouped accordingly:<br>

				<strong>(DL)</strong> – defensive lineman; including defensive ends, defensive tackles, nose tackles, and any lineman<br>

				<strong>(DB)</strong> – defensive backs; including cornerbacks, free safeties, and strong safeties<br>

				<strong>(LB)</strong> – defensive linebackers; including inside linebackers, outside linebackers, and middle linebackers<br>
			</div>

			<br><div class="clearfix"></div><br>
			<ul class="nav nav-tabs">
			  <li class="active atab"><a data-toggle="tab" href="#home">Standard</a></li>
			  <li class="atab"><a data-toggle="tab" href="#menu1">Positional</a></li>
			</ul>

			<div class="tab-content">
				<br>
			  <div id="home" class="tab-pane fade in active">
			    	<div class="form-group fourth">
						<label>IDP (All Positions)</label>
						<input type="number" min="0" class="form-control idptplayer" name="roster[IDP]" value="<?php if(isset($roster['IDP'])){echo $roster['IDP'];}else{echo "0";} ?>" />
					</div>


			  </div>
			  <div id="menu1" class="tab-pane fade">
			  		<div class="form-group fourth ">
						<label>DL</label>
						<input type="number" min="0" class="form-control idptplayer" name="roster[DL]" value="<?php if(isset($roster['DL'])){echo $roster['DL'];}else{echo "0";} ?>" />
					</div>

					<div class="form-group fourth ">
						<label>DB</label>
						<input type="number" min="0" class="form-control idptplayer" name="roster[DB]" value="<?php if(isset($roster['DB'])){echo $roster['DB'];}else{echo "0";} ?>" />
					</div>

					<div class="form-group fourth ">
						<label>LB</label>
						<input type="number" min="0" class="form-control idptplayer" name="roster[LB]" value="<?php if(isset($roster['LB'])){echo $roster['LB'];}else{echo "0";} ?>" />
					</div>


			  </div>
			</div>


		</div>
		<h4>Draft Settings</h4>
		<div class="form-group half ">
			<label>Draft Type</label>
			<select class="form-control" name="draft_type" id="draft_type">
				<option <?php if(isset($_POST['draft_type']) && $_POST['draft_type'] == 1){echo "selected";} ?>  value="1" >Snake Draft</option>
				<option <?php if(isset($_POST['draft_type']) && $_POST['draft_type'] == 2){echo "selected";} ?>  value="2">Straight Round</option>

			</select>
		</div>

		<div class="form-group hiders half">
			<label><i class="fa fa-clock-o"></i> Draft Clock (Seconds)</label>
			<input class="form-control" type="number" value="<?php if(isset($_POST['draft_clock'])){echo $_POST['draft_clock'];}else{echo '60';} ?>" name="draft_clock" min="0">
		</div>

		<div class="form-group hiders full">
			<label><i class="fa fa-calendar"></i> Draft Date &amp; Time (EST)</label>
			<?php
			if(isset($league->draft_start)){
				if (strpos($league->draft_start,'/') !== false || $league->draft_start == "") {
				    $time = $league->draft_start;
				}else{
					$time = date('Y/m/d G:i ',$league->draft_start);
				}
			}else{
				$time = "";
			}
			?>
			<input class="form-control" type="text" value="<?=$time?>" name="draft_start" id="draft_date">
		</div>




		<div class="clearfix"></div><br>
		<hr>


		<div class="text-center">
			<button type="submit" class="btn btn-success" >Submit</button>
		</div>



		<div class="clearfix"></div><br>


	</form>

	</div>
</section>


<script type="text/javascript">
	$(document).ready(function(){

		$('#draft_date').datetimepicker({
			minDate: 0,
		});

		$('#offline_info').hide();
		$('#draft_date').on('change',function(){
			var time = $(this).val();
			var date = new Date(time);
			var datum = Date.parse(date);
			var it =  datum/1000;

			var comp = $('#cutoff').val();

			if(it > comp){
				$('#draft_date_notice').show();
			}else{
				$('#draft_date_notice').hide();
			}


		});
		$('#draft_env').on('change',function(){
			var divisions = $(this).val();
			if(divisions === '1'){
				$('#offline_info').hide();
				$('.hiders').show();
			}
			if(divisions === '2'){
				$('.hiders').hide();
				$('#offline_info').show();
			}


		});
		$('#draft_format').on('change',function(){
			var divisions = $(this).val();
			if(divisions === '1'){
				$('#keeper_info').hide();
			}
			if(divisions === '2'){
				$('#keeper_info').show();
			}


		});
/*
		$('#draft_type').on('change',function(){
			var divisions = $(this).val();
			if(divisions === '3'){
				$('.hiders').hide();
				$('#offline_info').show();
			}else{
				$('#offline_info').hide();
			}
			if(divisions === '4'){
				$('.hiders').hide();
				$('#keeper_info').show();
			}else{
				$('#keeper_info').hide();
			}
			if(divisions === '1'){
				$('.hiders').show();
			}
			if(divisions === '2'){
				$('.hiders').show();
			}

		});
*/
	});
</script>

<script>
	$(document).ready(function() {
	    $('input[type=radio][name=idp]').change(function() {
		    if (this.value == '') {
			    console.log('boom');
				this.value = 0;
			}
	        if (this.value == '1') {
	            $('.idp').show();
	        }
	        else if (this.value == '0') {
	            $('.idp').hide();
	        }
	        run_tallies();
	    });
	    $( ".atab" ).click(function() {
	        $( ".idptplayer" ).val(0);
	    });
	    $('input').change(function() {

	       console.log('chane');
	       if (this.value == '') {
			    console.log('boom');
				this.value = 0;
			}

			 run_tallies();
			 payouts_show();
			 calculate_pool();
			 run_tallies2();
	    });

	    calculate_pool();
	    payouts_show();

	    function getNum(val) {
		   if (isNaN(val)) {
		     return 0;
		   }
		   return val;
		}
	    function calculate_pool(){

			var size = parseFloat($('.league_size').val());
			var amount = parseFloat($('input[name=entry_fee]').val());

			var pool = size * amount;
			pool = getNum(pool);

			amount = getNum(amount);

			var rake = parseFloat($('.rakenum').val());
			rake = (rake -1) * -1;
			var avail = pool * rake;
			$('.pool').val(avail);
			$('.available').html(avail);
			run_tallies2();

		}
	    function payouts_show(){
		    $('.payout_group').removeClass('hide');
		    if ($('#type3').is(':checked')) {
			    $('.payout_group').show();
			    $('.payrelated').show();
			}else{
				$('.payamounthonor').val(0);
				$('.payamount').val(0);
				$('.payout_group').hide();
				$('.payrelated').hide();
			}

		}
	    function run_tallies(){
		    var sum = 0;
		    $('.tplayer').each(function(i, obj) {
			    sum = parseInt(sum) + parseInt($(this).val());
			});


			console.log($('input[name=idp]:checked').val());
			if($('input[name=idp]:checked').val() == 1){
				$('.idptplayer').each(function(i, obj) {
			   		sum = parseInt(sum) + parseInt($(this).val());
				});
			}

			var bench = parseInt($('.tbench').val());

			$('.starters').val(sum);
			$('.total').val(parseInt(bench) + parseInt(sum));
			$('.bench').val(bench);


	    }

	    run_tallies();

	});




	console.log("payout");
$("input").change(function(){
	console.log('update1');
	run_tallies2();
});
var fstop = 0;
run_tallies2();
 function run_tallies2(){
	 console.log('in');
    var amount = parseInt($('.pool').val());
    console.log(amount);
	var sum = 0;

	$( ".payamount" ).each(function() {
		var num =  parseInt($(this).val());
		if (num > 0) {
			sum = sum + num;
		}

	});
	$( ".payamounthonor" ).each(function() {

		var num =  parseInt($(this).val());
		if (num > 0) {
			sum = sum + num;
		}

	});
	var rem = parseInt(amount - sum);

	$('.remlable').removeClass('paygreen');
	$('.remlable').removeClass('payred');

	if(rem >= 0){
		$('.remlable').addClass('paygreen');
	}else{
		$('.remlable').addClass('payred');
	}
	console.log(rem);
	console.log(amount);
	$('.remainging').html(rem);


}


$(".pForm").submit(function(e){
	console.log(fstop);
	if(fstop == 0){
    	e.preventDefault();

	    var amount = parseInt($('.pool').val());
		var sum = 0;

		$( ".payamount" ).each(function() {
			var num =  parseInt($(this).val());
			if (num > 0) {
				sum = sum + num;
			}

		});
		$( ".payamounthonor" ).each(function() {

			var num =  parseInt($(this).val());
			if (num > 0) {
				sum = sum + num;
			}

		});
		var rem = parseInt(amount - sum);

	    if(rem == 0){
		    fstop = 1;
		    $('form').unbind('submit').submit();
	    }else if(rem > 0){
		    alert("Payouts are to low!");
	    }else{
		    alert("Payouts are to high!");
	    }

     }else{
	    $(".pForm").removeClass('pForm');
	    $( "form" ).submit();
    }

});
</script>

<?php
	$errors = $this->form_validation->error_array();

	foreach($errors as $key=>$error){
		?>

		<script>
			$('input[name=<?=$key?>]').addClass('red');
			$('input[name=<?=$key?>]').next().addClass('red');
		</script>



	<?php } ?>
