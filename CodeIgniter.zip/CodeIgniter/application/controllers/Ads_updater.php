<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ads_updater extends CI_Controller {
	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();

    }

	public function click_count($cid){
		$this->db->where('cid',$cid);
		$q = $this->db->get("ad_banners");
		$q = $q->row();


		$q->clicks = $q->clicks + 1;



		$this->db->where('cid', $cid);
		$this->db->update('ad_banners', $q);


	}

}
