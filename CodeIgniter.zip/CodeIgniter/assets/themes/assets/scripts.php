<!-- Scripts -->

<script type="text/javascript" src="assets/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/jPushMenu.js"></script>
<script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/modernizr.custom.js"></script>
<script type="text/javascript" src="assets/js/lobby.js"></script>
<script type="text/javascript" src="assets/tablesorter/tablesorter.min.js"></script>
<script type="text/javascript" src="assets/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/js/classie.js"></script>
<script type="text/javascript" src="assets/js/mlpushmenu.js"></script>
<script type="text/javascript" src="assets/js/datetime_picker.js"></script>

<script type="text/javascript">
	jQuery(document).ready(function($) {

		$('.toggle-menu').jPushMenu();
		jQuery( ".toggle-menu" ).click(function() {
			jQuery('#magic_cover').toggle();
		});
		jQuery( "#magic_cover" ).click(function() {
			jQuery('#magic_cover').toggle();
		});
		jQuery( ".cbp-spmenu-top a" ).click(function(){
			jQuery('#magic_cover').toggle();
		});

	});
</script>
