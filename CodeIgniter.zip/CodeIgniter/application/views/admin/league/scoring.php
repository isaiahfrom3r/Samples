<div class="card">
	<div class="card-header">
		<h3>Scoring</h3>
		Edit scoring settings that are usable in the auto league process.
	</div>
<div class="row-fluid col-md-12">



	<!--END Information block -->
	<div class="pull-right">
	<a href="<?=site_url(ADMIN_THEME.'/league/scoring_create')?>" class="btn btn-info" class="btn btn-small confirm">Create New Scoring Settings</a>
	</div>
	<div class="clearfix"></div><br>
	<div class="clearfix"></div>

		<?//="<pre>".print_r($articles,true)."</pre>";?>
		<div class="portlet box green">

		<div class="portlet-body">
			<div class="table-responsive">
		<table class="table table-condensed table-striped table-bordered tablesorter" data-options='{"sortList":[[1,0]],"headers":{"0":{"sorter":false},"6":{"sorter":false}}}'>
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?if(!empty($scorings)):?>
					<?foreach($scorings as $s):?>
						<tr>
							<td><?=$s->cid?></td>
							<td><?=$s->name?></td>

							<td>
								<a class="btn btn-info" href="<?=site_url(ADMIN_THEME."/league/scoring_edit/".$s->cid)?>" rel="tooltip" title="Edit"><i class="zmdi zmdi-edit"></i></a>
							</td>
						</tr>
					<?endforeach;?>
				<?else:?>
					<tr><td colspan="6">No Scoring Found</td></tr>
				<?endif;?>
			</tbody>
		</table>
		<div class="clearfix"></div><br>

	</div>
</div>
</div>
</div>
 <div class="clearfix"></div></div>


