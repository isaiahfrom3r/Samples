<h4>Set League Divisions</h4>

<form method="" action="">

	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Team</th>
					<th class="text-center">Division 1</th>
					<th class="text-center">Division 2</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>The Shadowknights</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
				</tr>
				<tr>
					<td>Footballers</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
				</tr>
				<tr>
					<td>Jefferson Starship Troopers</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
				</tr>
				<tr>
					<td>The Winning Team</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
				</tr>
				<tr>
					<td>Sparklers</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
				</tr>
				<tr>
					<td>Quarterback Experience</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
				</tr>
				<tr>
					<td>The Fortress</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
				</tr>
				<tr>
					<td>Smooth's Army</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
				</tr>
				<tr>
					<td>No Romo</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
				</tr>
				<tr>
					<td>Winning Is My Forte</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
				</tr>
				<tr>
					<td>Yo Belichick Yo Self</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
				</tr>
				<tr>
					<td>U Mad Bro?</td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name="" checked></label></div></td>
					<td align="center"><div class="checkbox"><label><input type="checkbox" name=""></label></div></td>
				</tr>
			</tbody>
		</table>
	</div>

	<br>

	<div class="text-center">
		<button class="btn btn-default" type="submit">Update</button>
	</div>

</form>
