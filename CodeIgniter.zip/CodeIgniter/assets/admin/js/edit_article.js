jQuery(document).ready(function($){
	$.ctrl = function(key, callback, args) {
		$(document).keydown(function(e) {
			if(!args) args=[]; // IE barks when args is null
			if(e.keyCode == key.charCodeAt(0) && e.ctrlKey) {
				callback.apply(this, args);
				return false;
			}
		});
	};
/*

	$("#article_form").validate({
		errorElement: "p",
		errorClass: "help-block",
		highlight: function(element, errorClass) {
			 $(element).parent().parent().addClass('error');
		  },
		unhighlight: function(element, errorClass) {
			 $(element).parent().parent().removeClass('error');
		  }
	});

*/
	$(document.body).on("change","#label",function(e){
		if($('#article_id').val()==""){
			var slug=$(this).val().toLowerCase();
			slug=slug.replace(/ /g, "_");
			slug=slug.replace("'", "");
			slug=slug.replace("\"", "");
			slug=slug.replace(";", "");
			slug=slug.replace(":", "");
			$('#slug').val(slug);
		}
		if($('.title').val()==""){
			$('.title').val($(this).val());
		}
	});
	function save(){
		//tinyMCE.triggerSave(true,true);
		if($("#article_form").valid()){
			$('#loading').fadeIn('slow');
			var values=$('#article_form').serializeArray();
			$.ajax({
				type: "POST",
				url:HOST_NAME+'/admin/article/save_article/',
				data: values
			}).done(function(response){
				var obj = jQuery.parseJSON(response);
				if(obj.status=="TipTop"){
					$('#loading').fadeOut('slow');
					$('#article_id').val(obj.article_id);
				}else{
					$('#loading').fadeOut('slow');
					alert(obj.message);
				}
			});
		}
	}

	$('#save').click(function(e){
		console.log("save");
		e.preventDefault();
		save();
	});

	$.ctrl('S', function() {
		save();
		return false;
	});




	$('#post_date').datetimepicker();
    $(function () {
        $('#datetimepicker1').datetimepicker();
    });

});
