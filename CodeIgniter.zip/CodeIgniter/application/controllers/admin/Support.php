<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Support extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Support_tickets');
		$this->users->is_admin(1);
	}

	public function index(){
		redirect('admin/support/browse');
	}

	public function browse($filter='',$status='',$page_num='',$order_by='',$order_dir=''){

		$this->db->where('level',2);
		$admin_users=$this->db->get('users');
		$data['admin_users']=array();
		foreach($admin_users->result() as $a){
			$data['admin_users'][$a->id]=$a;
		}

		if($filter=="my")$filter=$this->users->admin_id();
		else $filter=0;
		$data['filter']=$filter==0?"all":"my";
		$statuses=$data['statuses']=array('incomplete','pending','proccessing','complete');
		$data['status_badges']=array('','badge-info','badge-warning','badge-success');
		if(empty($status)){
			$status=0;
		}else {
			$status=array_search($status,$statuses);
		}
		$data['status']=$statuses[$status];
		$per_page=25;
		if(empty($page_num)) $page_num=0;
		$data['page_num']=$page_num;

		if(empty($order_by)) $order_by='id';
		$data['order_by']=$order_by;

		if(empty($order_dir)) $order_dir='asc';
		$data['order_dir']=$order_dir;

		$data['tickets'] = $this->Support_tickets->get_list($filter,$status,$page_num,$per_page,$order_by,$order_dir);
		//$data['tickets']=array();
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/support/browse',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function view($ticket_id=''){
		$user_id=$this->users->admin_id();

		$ticket=$data['ticket']=$this->Support_tickets->get_by_id($ticket_id);

		$this->db->where('level',2);
		$admin_users=$this->db->get('users');
		$data['admin_users']=array();
		foreach($admin_users->result() as $a){
			$data['admin_users'][$a->id]=$a;
		}

		$data['notes']=$this->Support_tickets->get_messages_by_ticket($ticket_id);
		$statuses=$data['statuses']=array('','pending','proccessing','complete');

		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');

		$this->form_validation->set_rules('status', 'Status', 'trim');
		$this->form_validation->set_rules('assigned_user_id', 'Assigned User', 'trim');

		if ($this->form_validation->run() == FALSE){
		}else{
			$update=array(
				"status"=>$this->input->post("status"),
				"assigned_user_id"=>$this->input->post("assigned_user_id"),
			);
			$this->Support_tickets->update($ticket_id,$update);
			if($ticket->assigned_user_id != $this->input->post("assigned_user_id")){
				$this->Support_tickets->add_note($ticket_id,$user_id,"Assigning ticket to ".$data['admin_users'][$this->input->post("assigned_user_id")]->username);
			}
			if($ticket->status != $this->input->post("status")){
				$this->Support_tickets->add_note($ticket_id,$user_id,"Setting ticket status to ".ucfirst($statuses[$this->input->post("status")]));
			}
			$this->alert->set('Ticket Updated','success');
			redirect('admin/support/view/'.$ticket_id);
		}


		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view('admin/support/view',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}

	public function add_note($ticket_id=''){
		$message=$this->input->post('message');
		if(!empty($ticket_id) && !empty($message)){
			$user_id=$this->users->admin_id();

			$this->Support_tickets->add_note($ticket_id,$user_id,$message);
			$this->alert->set('Note added','success');
			redirect('admin/support/view/'.$ticket_id);
		}else{
			$this->alert->set('No note added','error');
			redirect('admin/support/view/'.$ticket_id);
		}
	}
	public function delete_note($note_id='',$ticket_id=''){

		$note=$this->Support_tickets->get_note_by_id($note_id);
		if($note){
			$this->Support_tickets->delete_note($note_id);
			$this->alert->set('Note removed','success');
			redirect('admin/support/view/'.$ticket_id);
		}else{
			$this->alert->set('Note not found','error');
			redirect('admin/support/view/'.$ticket_id);
		}
	}
	public function set_status($ticket_id='',$status=''){

		$update=array(
			"status"=>$status
		);
		$this->Support_tickets->update($ticket_id,$update);
		$statuses=array('all','pending','proccessing','complete');
		$this->Support_tickets->add_note($ticket_id,$this->users->admin_id(),"Setting ticket status to ".ucfirst($statuses[$status]));

        if($status == 3) {
            $ticket = $this->Support_tickets->get_by_id($ticket_id);

            $email_data = array(
                'ticket_subect' => $ticket->subject,
            );
            $subject = "YouRulz - Support Ticket Processed";
            $this->emails->send_mail($this->input->post('email'), 'support_ticket_processed', $email_data,$subject);
        }
		$this->alert->set('Ticket Updated','success');
		redirect('admin/support/browse');
	}
	public function delete($ticket_id=''){
		$this->Support_tickets->delete($ticket_id);
		$this->alert->set('Ticket Removed','success');
		redirect('admin/support/browse');
	}
}
