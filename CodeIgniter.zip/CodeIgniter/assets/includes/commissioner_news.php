<h4>Current Commissioner News</h4>

<p><strong><?php echo date('m/d/Y');?> - 1:00pm:</strong> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut facilisis eu ipsum fermentum vulputate. Fusce sed orci et est sollicitudin ultrices eu sit amet purus. Nulla ultricies aliquet metus eu ullamcorper. Integer sit amet risus ut lectus ultricies egestas. Morbi mauris ligula, congue nec mollis at, rutrum non ipsum. Vivamus feugiat rhoncus maximus. Nulla facilisi.</p>

<hr>

<form method="post" action="">
	<div class="form-group">
		<label>Commissioner News</label>
		<textarea class="form-control" name=""></textarea>
	</div>

	<hr>

	<div class="text-center">
		<button class="btn btn-default" type="submit">Update</button>
	</div>

</form>
