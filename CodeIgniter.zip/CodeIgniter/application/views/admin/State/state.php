<!-- Yea this is grows so I just made its own file.  -->
<?php $this->load->view(ADMIN_THEME.'/admin/users_chart_script'); ?>

<div class="card">
	<div class="card">
        <div class="card-header">
            <h2>State Settings</h2>
            <h5></h5>
			<span>A) Teams (paid or free) are permitted in the World Competition? </span><br>
			<span>B) Player can participate in Private Competitions? </span><br>

			<span>C) Private Competition teams are entered automatically into the World Competition and the players's State/Country Competition? </span><br>
			<span>D) Player can participate in FFE 'Less than Season' Competitions? </span><br>
			<span>E) Player can participate in Private 'Less than Season' Competitions? </span>

        </div>

        <div class="card-body">
	        <form action="" method="post">
            <table class="table">
                <thead>
	                <tr>
	                    <th>State</th>
	                    <th>A</th>
	                    <th>B</th>
	                    <th>C</th>
	                    <th>D</th>
	                    <th>E</th>
	                </tr>
                </thead>
                <tbody>
	                <?php foreach($states as $key=>$s){ ?>
	                	<?php if($s==''){continue;} ?>

		                <tr>
		                    <td><?=$s?></td>
		                    <td><input type="checkbox" <?php if($status[$key]->col_a == 1 ){ ?> checked="" <?php }  ?> name="<?=$key?>[col_a]" value="1"></td>
		                    <td><input type="checkbox" <?php if($status[$key]->col_b == 1 ){ ?> checked="" <?php }  ?>  name="<?=$key?>[col_b]" value="1"></td>
		                    <td><input type="checkbox" <?php if($status[$key]->col_c == 1 ){ ?> checked="" <?php }  ?>  name="<?=$key?>[col_c]" value="1"></td>
		                    <td><input type="checkbox" <?php if($status[$key]->col_d == 1 ){ ?> checked="" <?php }  ?>  name="<?=$key?>[col_d]" value="1"></td>
		                    <td><input type="checkbox" <?php if($status[$key]->col_e == 1 ){ ?> checked="" <?php }  ?>  name="<?=$key?>[col_e]" value="1"></td>
		                </tr>


	                <?php } ?>
                </tbody>
            </table>
            <div class="col-md-12">
	            <br>
            	<button type="submit" class="btn pull-right btn-success">Save State Changes</button>
            </div>
	        </form>

        </div>
    </div>
 </div>
