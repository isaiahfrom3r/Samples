<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class League extends CI_Controller {

	public function __construct() {

		parent::__construct();
		$this->load->model('Leagues');
		$this->load->model('Misc');
		$this->load->model('Teams');
		$this->load->model('Brackets');
		//$this->load->model('Players');
		$this->load->model('States');
        $this->load->model('Chats');

		$this->users->is_loggedin(1);


	}

	public function home(){
		$teams = $this->Leagues->get_my_leagues($this->users->id());
		foreach($teams as $tm){
			$tm->league = $this->Leagues->get_league_by_id($tm->league_id);
		}
		$data['teams'] =  $teams;
        ini_set('display_errors', 1);
        error_reporting(E_ALL);

        $data['user'] = $user  = $this->users->get();

		$this->load->view(THEME.'/header');
 		$this->load->view(THEME.'/league/home',$data);
		$this->load->view(THEME.'/footer');
	}
/*
	public function shoot_eamil(){
		$to      = 'isaiahfrom3r@gmail.com';
$subject = 'Sup Dummy ';
$message = 'hello';
$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
	}
*/
	public function join2($lid = 0){

		if($lid != 0){

			$league = $this->Leagues->get_league_by_id($lid);



			$this->db->where('league_id',$lid);
			$this->db->where('user_id',$this->users->id());
			$q = $this->db->get("league_team");

			if ($q->num_rows() == 0){

				$isfull = $this->Leagues->is_full($lid);



				if($isfull == 1){
					$this->alert->set('League Already Full','warning');
					redirect('/league/join');

				}
				$team = array(
					'user_id' => $this->users->id(),
					'league_id' => $lid,

				);

				$this->Leagues->create_team($team);



				$data['league'] =  $league = $this->Leagues->get_league_by_id($lid);
				$data['bracket'] =  $bracket =  $this->Brackets->get_bracket();
				$data['bracket'] =  $bracket =  json_decode($bracket->bracket,true);


				$this->Leagues->save_default_picks($league,$bracket,$tm->user_id);



				$this->alert->set('League Joined','success');
				redirect('/league/home');

			}else{
				$this->alert->set('League Already Joined','warning');
				redirect('/league/home');
			}

		}else{
			$this->alert->set('League not Found','danger');
			redirect('/league/home');
		}
	}
	public function join($lid=0){

		if($lid != 0){

			$league = $this->Leagues->get_league_by_id($lid);



			if($league->public == 1){

				$this->db->where('league_id',$lid);
				$this->db->where('user_id',$this->users->id());
				$q = $this->db->get("league_team");
				if ($q->num_rows() == 0){

					$isfull = $this->Leagues->is_full($lid);



					if($isfull == 1){

						$this->alert->set('League Already Full','warning');
						redirect('/league/join');

					}

					$team = array(
						'user_id' => $this->users->id(),
						'league_id' => $lid,

					);

					$this->Leagues->create_team($team);

					$data['league'] =  $league = $this->Leagues->get_league_by_id($lid);
					$data['bracket'] =  $bracket =  $this->Brackets->get_bracket();
					$data['bracket'] =  $bracket =  json_decode($bracket->bracket,true);


					$this->Leagues->save_default_picks($league,$bracket,$tm->user_id);

					$this->alert->set('League Joined','success');
					redirect('/league/home');

				}else{
					$this->alert->set('League Already Joined','warning');
					redirect('/league/home');
				}

			}
		}


		$this->form_validation->set_rules('id', '', 'required');
		$this->form_validation->set_rules('key', '', 'required');

		if ($this->form_validation->run() == FALSE){
		}else{

			$this->db->where('key',$_POST['key']);
			$this->db->where('public_id',$_POST['id']);
			$q = $this->db->get("leagues");
			if ($q->num_rows() > 0){
				$q = $q->row();
				redirect('league/join2/'.$q->cid);

			}

		}


		$this->load->view(THEME.'/header');
 		$this->load->view(THEME.'/league/join',$data);
		$this->load->view(THEME.'/footer');

	}

	public function create(){
		$user  = $this->users->get();
		$data['key'] =  $this->Leagues->randomPassword();
		if(isset($_POST['name'])){
			if(strtoupper($_POST['use_real_name'] ) == "YES"){
				$name = $user->first_name." ".$user->last_name;

			}else{
				$name = $user->username;
			}

			unset($_POST['use_real_name']);

			$_POST['owner'] = $this->users->id();


			$email_data = array(
				'message' => $_POST['invite_message'],
				'name' 	=> $name,
				'id'	=> $_POST['public_id'],
				'key' 	=> $_POST['key'],
				'url'	=> base_url(),
			);

			foreach($_POST['invite_email'] as $e){
				$this->emails->send_mail($e,'invite_to_league', $email_data);
			}
			unset($_POST['invite_email']);
			unset($_POST['invite_message']);


			$lid = $this->Leagues->create_league($_POST);

			$team = array(
				'user_id' => $this->users->id(),
				'league_id' => $lid,

			);

			$this->Leagues->create_team($team);


			$this->alert->set('League Created','success');
			redirect('/league/home');

		}else{

		}

		$this->load->view(THEME.'/header');
 		$this->load->view(THEME.'/league/create',$data);
		$this->load->view(THEME.'/footer');
	}

    public function history() {

		$head['scripts'] = array();
		$foot['scripts'] = array();

		$user  = $this->users->get();
		$data['league'] = $league = $this->Leagues->get_league_by_id($user->team_id);



		$lcount = 1;
		$check = 0;
		$league_ids[$league->cid] = $league->cid;
		$leagues[$league->cid] = $league;
		while($check == 0){

			$this->db->where_in('cid',$league_ids);
			$this->db->or_where_in('link_id',$league_ids);
			$q = $this->db->get("leagues");
			$num = $q->num_rows();


			$q = $q->result();

			foreach($q as $res){
				$league_ids[$res->cid] = $res->cid;
				$leagues[$res->cid] = $res;
			}


			if(count($league_ids) == $lcount){
				$check++;
			}

			$lcount = $num;


		}
		$data['leagues'] =  $leagues;

        $this->load->view(THEME.'/header',$head);
 		$this->load->view(THEME.'/league/history',$data);
		$this->load->view(THEME.'/footer',$foot);

    }

    public function league_history($lid) {


		$head['scripts'] = array();
		$foot['scripts'] = array();

        $this->load->view(THEME.'/header',$head);
 		$this->load->view(THEME.'/league/manage',$data);
		$this->load->view(THEME.'/footer',$foot);

    }
	public function standings($lid = 0){
		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);
		if($lid == 0){
			$lid = $this->options->get('default_league');
		}

		$data['league'] =  $league =  $this->Leagues->get_league_by_id($lid);


		$lcount = $this->Leagues->get_count($lid);
		$teams = $this->Leagues->get_my_leagues($this->users->id());

		foreach($teams as $tm){
			$tm->league = $this->Leagues->get_league_by_id($tm->league_id);
		}
		$data['teams'] =  $teams;

		if(isset($_GET['page'])){
			$pagenum = $_GET['page'];
		}else{
			$pagenum = $_GET['page'] = 1;
		}
		$user  = $this->users->get();
		$limit = 100;
		$offset = ($limit * $pagenum ) - 100;

 		$data['standings'] = $standings = $this->Leagues->get_standings($league,$limit,$offset);

		$data['field'] =  $field =  $this->Leagues->get_league_teams($league->cid);

		$this->load->library("pagination");


		$config['full_tag_open'] = '<nav aria-label="Page navigation example"> <ul class="pagination">';
		$config['full_tag_close'] = '</ul></nav><!--pagination-->';
		$config['first_link'] = '&laquo; First';
		$config['first_tag_open'] = '<li class="prev page page-item">';
		$config['first_tag_close'] = '</li>' . "\n";
		$config['last_link'] = 'Last &raquo;';
		$config['last_tag_open'] = '<li class="next page page-item">';
		$config['last_tag_close'] = '</li>' . "\n";
		$config['next_link'] = 'Next &rarr;';
		$config['next_tag_open'] = '<li class="next page page-item">';
		$config['next_tag_close'] = '</li>' . "\n";
		$config['prev_link'] = '&larr; Previous';
		$config['prev_tag_open'] = '<li class="prev page page-item">';
		$config['prev_tag_close'] = '</li>' . "\n";
		$config['cur_tag_open'] = '<li class="active page-item" ><a class="active page-link" href="">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li class="page page-item"">';
		$config['num_tag_close'] = '</li>' . "\n";
		$config['attributes'] = array('class' => 'page-link');



		// needs to be query string also to work properly with search
		$config['page_query_string']    = TRUE;
		$config['query_string_segment']= 'page';
		$config['total_rows'] = count($field);
		$config['per_page'] = 100;
		$this->pagination->initialize($config);



		//EDIT THIS:

		if(isset($lid)){
			$config["base_url"] = site_url( "league/standings/".$lid);
		}else{
			$config["base_url"] = site_url( "league/standings");
		}

		//EDIT THIS (to get a count of number of rows. Might have to add in a criteria (category etc)
		$config["total_rows"] = count($field);
		//EDIT THIS
		$config["uri_segment"] = 3;
		//EDIT THIS:
	    $config["per_page"] = $limit;
	    $choice = $config["total_rows"] / $config["per_page"];
	    $config["num_links"] = round($choice);
		$config['use_page_numbers'] = true; // use page numbers, or use the current row number (limit offset)



		$this->pagination->initialize($config);
		$data["pagination"] = $this->pagination->create_links();



		foreach($field as $f){
			$ids[$f->user_id] = $f->user_id;
		}

		$this->db->where_in('id',$ids);
		$q = $this->db->get("users");
		$q = $q->result();

		foreach($q as $u){
			$data['users'][$u->id] =  $u;
		}
		$this->load->view(THEME.'/header');
 		//$this->load->view(THEME.'/league/add_players',$data);
 		$this->load->view(THEME.'/league/devstandings',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
/*
	public function standings($lid = 0){
		if($lid == 0){
			$lid = $this->options->get('default_league');
		}

		$data['league'] =  $league =  $this->Leagues->get_league_by_id($lid);



		$teams = $this->Leagues->get_my_leagues($this->users->id());

		foreach($teams as $tm){
			$tm->league = $this->Leagues->get_league_by_id($tm->league_id);
		}
		$data['teams'] =  $teams;

		$user  = $this->users->get();

// 		$data['standings'] = $standings = $this->Leagues->get_standings($league->cid);
		$data['field'] =  $field =  $this->Leagues->get_league_teams($league->cid);

		foreach($field as $f){
			$ids[$f->user_id] = $f->user_id;
		}

		$this->db->where_in('id',$ids);
		$q = $this->db->get("users");
		$q = $q->result();

		foreach($q as $u){
			$data['users'][$u->id] =  $u;
		}
		$this->load->view(THEME.'/header');
 		//$this->load->view(THEME.'/league/add_players',$data);
 		$this->load->view(THEME.'/league/standings',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
*/
	public function bracket($lid=0){
		if($lid == 0){
			$this->alert->set('No League Selected','warning');
			redirect('/lobby');
		}
		$data['league'] =  $league = $this->Leagues->get_league_by_id($lid);
		$head['scripts'] = array(base_url().'assets/js/bracket.js');
		$foot['scripts'] = $foot['styles'] = array();
		$data['bracket'] =  $bracket =  $this->Brackets->get_bracket();
		$data['bracket'] =  $bracket =  json_decode($bracket->bracket,true);
		$data['team'] =  $team = $this->Leagues->get_my_team($lid);
		$teams = $this->Teams->get_all();

		$myPicks = $this->Leagues->get_my_picks($lid);
/*
		if(empty($myPicks)){
			$this->Leagues->save_default_picks($league,$bracket);
			$myPicks = $this->Leagues->get_my_picks($lid);
		}
*/

		$data['mypicks'] =  $myPicks;

		foreach($teams as $t){
			$passteams[$t->cid] = $t;
		}
		$count = 0;
		ksort($bracket);
		foreach($bracket as $b){
			foreach($b as $round=>$bb){
				if($round != 1){
					continue;
				}
				foreach($bb as $bbb){


				$torder[$bbb['home']] = $count;
				$count++;
				$torder[$bbb['away']] = $count;
				$count++;

				}
			}
		}

		$data['torder'] =  $torder;
		$data['tms'] =  $passteams;



		foreach($bracket as $group=>$b){
			foreach($b as $round=>$bb){
				foreach($bb as $key=>$game){
					$seeds[$game['home']] = $game['home_team_seed'];
					$seeds[$game['away']] = $game['away_team_seed'];
					if($round != 1  ){
						$bracket[$group][$round][$key]['home'] = "";
						$bracket[$group][$round][$key]['home_team_score'] = "";
						$bracket[$group][$round][$key]['away_team_score'] = "";
						$bracket[$group][$round][$key]['away'] = "";
						$bracket[$group][$round][$key]['away_team_seed'] = "";
						$bracket[$group][$round][$key]['home_team_seed'] = "";
					}

					$bracket[$group][$round][$key]['final'] = 0;
				}
			}
		}

		$data['seeds'] =  $seeds;
		$data['bracket'] = $bracket;
 		//$this->load->view(THEME.'/league/add_players',$data);
 		$this->load->view(THEME.'/header',$head);
 		$this->load->view(THEME.'/league/bracket',$data);
 		$this->load->view(THEME.'/footer',$foot);
	}
	public function update_tb($lid=0,$tb1,$tb2){

		if($lid == 0){
			$this->alert->set('No League Selected','warning');
			redirect('/lobby');
		}
		$data['league'] =  $league = $this->Leagues->get_league_by_id($lid);
		$head['scripts'] = array(base_url().'assets/js/bracket.js');
		$foot['scripts'] = $foot['styles'] = array();
		$data['bracket'] =  $bracket =  $this->Brackets->get_bracket();
		$data['bracket'] =  $bracket =  json_decode($bracket->bracket,true);


		$data['team'] =  $team = $this->Leagues->get_my_team($lid);

		$team->tb1 = $tb1;
		$team->tb2 = $tb2;

		$this->Leagues->update_team($team,$team->id);



	}
	public function update_bracket($lid=0,$twin,$round,$group,$gkey){

		if($lid == 0){
			$this->alert->set('No League Selected','warning');
			redirect('/lobby');
		}
		$data['league'] =  $league = $this->Leagues->get_league_by_id($lid);
		$head['scripts'] = array(base_url().'assets/js/bracket.js');
		$foot['scripts'] = $foot['styles'] = array();
		$data['bracket'] =  $bracket =  $this->Brackets->get_bracket();
		$data['bracket'] =  $bracket =  json_decode($bracket->bracket,true);
		$data['team'] =  $team = $this->Leagues->get_my_team($lid);

		if($league->locked == 1){
			echo 0; die;
		}

		$myPicks = $this->Leagues->get_my_picks($lid);


/*
		if(empty($myPicks)){
			$this->Leagues->save_default_picks($lid,$bracket);
			$myPicks = $this->Leagues->get_my_picks($lid);
		}

*/

		if(isset($myPicks[$group][$round][$gkey])){

			// check if diff

			if($myPicks[$group][$round][$gkey] != $twin){

				foreach($myPicks as $cgroup=>$picks){

					foreach($picks as $cround=>$p){

						if($cround > $round){

							foreach($p as $cgid => $ps){

								if($ps == $myPicks[$group][$round][$gkey]){
									$myPicks[$cgroup][$cround][$cgid] = "";
								}


							}

						}

					}

				}

			}


		}


		$myPicks[$group][$round][$gkey] = $twin;
		$this->Leagues->save_picks($lid,$myPicks);


		$data['mypicks'] =  $myPicks;

		$teams = $this->Teams->get_all();
		foreach($teams as $t){
			$passteams[$t->cid] = $t;
		}
		$count = 0;
		ksort($bracket);
		foreach($bracket as $b){
			foreach($b as $round=>$bb){
				if($round != 1){
					continue;
				}
				foreach($bb as $bbb){


				$torder[$bbb['home']] = $count;
				$count++;
				$torder[$bbb['away']] = $count;
				$count++;

				}
			}
		}

		$data['torder'] =  $torder;
		$data['tms'] =  $passteams;



		foreach($bracket as $group=>$b){
			foreach($b as $round=>$bb){
				foreach($bb as $key=>$game){
					$seeds[$game['home']] = $game['home_team_seed'];
					$seeds[$game['away']] = $game['away_team_seed'];
					if($round != 1){
						$bracket[$group][$round][$key]['home'] = "";
						$bracket[$group][$round][$key]['home_team_score'] = "";
						$bracket[$group][$round][$key]['away_team_score'] = "";
						$bracket[$group][$round][$key]['away'] = "";
						$bracket[$group][$round][$key]['away_team_seed'] = "";
						$bracket[$group][$round][$key]['home_team_seed'] = "";
					}
					$bracket[$group][$round][$key]['final'] = 0;
				}
			}
		}
		$data['seeds'] =  $seeds;

		$data['bracket'] = $bracket;

 		//$this->load->view(THEME.'/league/add_players',$data);
 		ini_set('display_errors', 0); // set to 0 for production version
 		error_reporting(-1);
 		$this->load->view(THEME.'/league/bracket',$data);

	}
	public function team_card($tid){
		$season = 2018;
		$data['team'] =  $team = $this->Teams->get_by_id($tid);

		$this->db->order_by('gamestart','DESC');
		$this->db->where('home',$team->cid);
		$this->db->where('season',$season);
		$this->db->where('final',1);
		$this->db->or_where('away',$team->cid);
		$this->db->where('season',$season);
		$this->db->where('final',1);
		$q = $this->db->get("sport_event");
		$q = $q->result();

		$data['games'] =  $games = $q;



		$data['data'] =  array();
		$this->load->view(THEME.'/league/team_card',$data);

	}

}
