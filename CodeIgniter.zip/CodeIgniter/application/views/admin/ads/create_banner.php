<?php if(!isset($type)){$type = 0;} ?>
<div class="card">
	<div class="card-header">
		<h3 id="adduser">New Advertisement</h3>
		<?php echo validation_errors(); ?>
		<small>

			If you don't intend to use the max impressions feature or time frames feel free to leave them empty. Leaving the restrictive fields empty will bypass that feature.

		</small>
	</div>
	<div class="span12">

		<?php
			//show error/success messages
			if ($this->session->flashdata('success') != '')
			{
				echo '<div class="alert fade in alert-success"><a class="close" data-dismiss="alert" href="#">&times;</a>'.$this->session->flashdata('success').'</div>';
			}
			if ($this->session->flashdata('error') != '')
			{
				echo '<div class="alert fade in alert-error"><a class="close" data-dismiss="alert" href="#">&times;</a>'.$this->session->flashdata('error').'</div>';
			}
			?>
		<!--END Information block -->
		<div class="portlet box green ">
			<div class="portlet-title">
				<div class="caption">

					<fieldset id="personal">
				</div>
			</div>

			<?php echo form_open_multipart('admin/Advertisement/create_banner', array('id' => 'form')); ?>
			<div class="portlet-body form">
			<div class="form-body">
			<div class="form-group">
			<div class="control-group<?$e=form_error('name');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Name:</label>
			<div class="col-md-9">
			<input class="form-control" placeholder="Enter text" name="name" id="name" type="text" value="<?=set_value('name');?>" />
			<p class="help-block"></p>
			<?=form_error('name');?>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div class="control-group<?$e=form_error('spot_id');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Banner Placement:</label>
			<div class="col-md-9">
			<select name="spot_id" class="form-control">
			<?php foreach($spots as $spot): ?>
			<option value="<?=$spot->cid;?>" <?=set_select('spot_id', $spot->cid);?>><?=$spot->name;?> &nbsp;</option>
			<?php endforeach; ?>
			</select>
			<?=form_error('spot_id');?>
			<p class="help-block"></p>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group" >
			<div class="control-group<?$e=form_error('type');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Banner Type:</label>
			<div class="col-md-9">
			<select class="form-control" name="type" onchange="javascript: if (this.value == '0') {document.getElementById('paste_banner_wrap').style.display = 'block'; document.getElementById('upload_banner_wrap').style.display = 'none';} else {document.getElementById('paste_banner_wrap').style.display = 'none'; document.getElementById('upload_banner_wrap').style.display = 'block';}">
			<option value="1" <?=set_select('type', '1');?>>Upload Banner &nbsp;</option>
			<option value="0" <?=set_select('type', '0');?>>Paste Banner Code &nbsp;</option>
			</select>
			<?=form_error('type');?>
			<p class="help-block"></p>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div id="paste_banner_wrap" style="<?=((isset($type) && $type == '1') || (!isset($type))?'display: block;':'display: none;');?>">
			<div class="control-group<?$e=form_error('code');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Paste Banner Code:</label>
			<div class="col-md-9">
			<textarea class="form-control" rows="3" name="code"><?=set_value('code');?></textarea>
			<?=form_error('code');?>
			<p class="help-block"></p>
			</div>
			</div>
			</div>
			</div>

			<div class="clearfix"></div>
			<div class="form-group">
			<div id="upload_banner_wrap" style="<?=((isset($type) && $type == '0')?'display: block;':'display: none;');?>">
			<div class="control-group<?$e=form_error('name');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Upload Banner Image:</label>
			<div class="col-md-9">
			<input  class="form-control"type="file" name="image" />
			<?=form_error('image');?>
			<p class="help-block"></p>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="control-group<?$e=form_error('url');echo (!empty($e))?' error':''?>">
			<label class="control-label col-md-3">Banner Url:</label>
			<div class="col-md-9">
			<input class="form-control" type="text" name="url" value="<?=set_value('url');?>" />
			<?=form_error('url');?>
			<p class="help-block"></p>

			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div class="control-group<?$e=form_error('max_impressions');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Max Impressions Booked:</label>
			<div class="col-md-9">
			<input class="form-control" name="max_impressions" id="max_impressions" type="text" value="<?=set_value('max_impressions');?>" />
			<p class="help-block">0 or empty for unlimited</p>
			<?=form_error('max_impressions');?>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div class="control-group<?$e=form_error('max_clicks');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Max Clicks Booked:</label>
			<div class="col-md-9">
			<input class="form-control" name="max_clicks" id="max_clicks" type="text" value="<?=set_value('max_clicks');?>" />
			<p class="help-block">0 or empty for unlimited</p>
			<?=form_error('max_clicks');?>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div class="control-group<?$e=form_error('start_date');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Start Date:</label>
			<div class="col-md-9">
			<input class="form-control" placeholder="m/d/y"  name="start_date" id="start_date" type="text" value="<?=set_value('start_date');?>" class="datepicker" />
			<p class="help-block">0 or empty to start immediately</p>
			<?=form_error('start_date');?>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div class="control-group<?$e=form_error('end_date');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">End Date:</label>
			<div class="col-md-9">
			<input class="form-control" placeholder="m/d/y"  name="end_date" id="end_date" type="text" value="<?=set_value('end_date');?>" class="datepicker" />
			<p class="help-block">0 or empty for no end date</p>
			<?=form_error('end_date');?>
			</div>
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="form-group">
			<div class="control-group<?$e=form_error('status');echo (!empty($e))?' error':''?>">
			<label class="col-md-3 control-label">Status:</label>
			<div class="col-md-9">
			<select class="form-control" name="status">
			<option value="1" <?=set_select('status', '1');?>>Enabled &nbsp;</option>
			<option value="0" <?=set_select('status', '0');?>>Paused &nbsp;</option>
			</select>
			<?=form_error('status');?>
			</div>
			</div>
			</div>
			</div>
			</fieldset>
			<div class="clearfix"></div><br>
			<div class="form-actions col-md-12">

			<input id="button1" type="submit" class="btn btn-success pull-right" value="Save" />
			</div>
			<div class="clearfix"></div><br>
			</form>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
</div>
</div>
