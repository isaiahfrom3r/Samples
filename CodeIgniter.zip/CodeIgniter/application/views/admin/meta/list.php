<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="card">
			<div class="card-header">
				<h2>Site Meta
					<small>
						Edit or Update Site Meta

					</small>
				</h2>
			</div>
					<div class=" card-body">


			<table class="table table-hover table-striped">
			<thead>
				<tr>
					<th>Page Name</th>
					<th>Update Included Pages</th>
					<th>Edit</th>
				</tr>
			</thead>
		    <tbody>
			<?php foreach($list as $l){ ?>

				<tr>
					<td><?=str_ireplace('.php', '', $l)?></td>
					<td><a class="btn btn-info">Update</a></td>
					<td><a href="/meta/edit/<?=str_ireplace('.php', '', $l)?>" class="btn btn-warning">Edit</a></td>
				</tr>

			<?php } ?>

		    </tbody>
		  </table>


		</div>
	</div><!-- .row -->
</div><!-- .container -->


