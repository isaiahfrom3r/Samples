<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class Admin extends CI_Controller {

    function __construct() {

        parent::__construct();

        $this->users->is_admin(1);
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){
		redirect('admin//user/list_all');

/*
		$head['scripts'] = array(
			'/assets/admin/js/flot.js',
			'/assets/admin/js/flot.resize.js',
			'/assets/admin/js/curvedLines.js',
		);
*/


		$this->load->view(ADMIN_THEME.'/header');
        $this->load->view(ADMIN_THEME.'/admin/dashboard',$data);
        $this->load->view(ADMIN_THEME.'/footer');
	}






}
