<?php
class Payments extends CI_Model {

	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	//returns most recent payment by user id
	function get_by_user_id($user_id)
	{
		$this->db->limit(1);
		$this->db->order_by('time', 'desc');
		$q = $this->db->get_where('payments', array('user_id' => $user_id));
		$res = $q->result();
		if (count($res) == 1)
		{
			return $res[0];
		}
		else
		{
			return FALSE;
		}
	}
	/****************************************
	GETTERS
	****************************************/
	function get_all_payments($per_page=10, $page_num =0, $when = 0){
		if(isset($when) && !empty($when)) {
			$this->db->where('time >',$when);
		}
		$this->db->limit($per_page, $page_num);
		$this->db->order_by('cid','desc');
		$payments=$this->db->get('payments');
		$payments=$payments->result();
		return $payments;
	}
	function get_payments_total($when = 0){
		if(!empty($when)){
			$this->db->where('time >',$when);
		}
		$payments=$this->db->count_all_results('payments');
		return $payments;
	}

	function get_payments_inc_total(){
		$this->db->select('SUM(amount) as incoming');
		$this->db->where('type',1);
		$inc=$this->db->get('payments')->row();
		return $inc->incoming;
	}
	function get_payments_by_month($type=1,$num_months=12){
		$inc_arr=array();
		$this_month=date('m');
		for($i=($this_month-($num_months-1));$i<=$this_month;$i++){
			$m=($i<1?(12+$i):($i));
			$y=($i<1?date('Y')-1:date('Y'));
			$month_begin=mktime(0,0,0,$m,1,$y);
			//echo $m."/".$y." - ".$month_begin."<br />";
			$n=$i+1;
			$m=($n<1?(12+$n):($n));
			$y=($n<1?date('Y')-1:date('Y'));
			$begin_of_next_month=mktime(0,0,0,$m,1,$y);
			$this->db->select('SUM(amount) as amount');
			$this->db->where('type',$type);
			$this->db->where("time >=",$month_begin);
			$this->db->where("time <",$begin_of_next_month);
			$inc=$this->db->get('payments')->row();
			$inc_arr[]=(float)($type==1?$inc->amount:($inc->amount*-1));

			//echo $m."/".$y." - ".date('m/d/Y G:i',$month_begin)." - ".date('m/d/Y G:i',$begin_of_next_month)." === ".number_format($inc->incoming,2)."<br />";
		}
		return $inc_arr;
	}
	function get_league_num_by_day(){
		$leagues=array();
		for($i=0;$i<7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			//$this->db->select('cid,feat_game_data,prize_structure,entry_fee,size,total_prize');
			$this->db->where('first_game_cutoff >',$starttime);
			$this->db->where('first_game_cutoff <',$endtime);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->count_all_results('league');
			$leagues[]=$query;
		}
		return $leagues;
	}
	function get_revenue_by_day(){
		$revenue_arr=array();
		$company_take=$this->options->get('company_take');
		for($i=0;$i<7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			$this->db->select('cid,feat_game_data,prize_structure,entry_fee,size,total_prize,custom_prize');
			$this->db->where('first_game_cutoff >',$starttime);
			$this->db->where('first_game_cutoff <',$endtime);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$total_total_prize=0;
				foreach($query->result() as $l){
					$total_total_prize+=$this->leagues->get_total_revenue($l);
				}

				$revenue_arr[] = round($total_total_prize,2);
			}else{
				$revenue_arr[]=0;
			}
		}
		return $revenue_arr;
	}
	function get_revenue_by_month($num_months=12){
		$revenue_arr=array();
		$company_take=$this->options->get('company_take');
		for($i=$num_months;$i>0;$i--){
			$month_start=mktime(0,0,0,(date('n')-(1*$i)),1,date('Y'));
			$month_end=mktime(0,0,0,(date('n',$month_start)+1),1,date('Y',$month_start))-1;
			$this->db->select('cid,feat_game_data,prize_structure,entry_fee,size,total_prize,custom_prize');
			$this->db->where('first_game_cutoff >',$month_start);
			$this->db->where('first_game_cutoff <',$month_end);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$total_total_prize=0;
				foreach($query->result() as $l){
					$total_total_prize+=$this->leagues->get_total_revenue($l);
				}

				$revenue_arr[] = round($total_total_prize,2);
			}else{
				$revenue_arr[]=0;
			}
		}
		return $revenue_arr;
	}
	function get_prizes_by_day(){
		$prize_arr=array();
		$company_take=$this->options->get('company_take');
		for($i=0;$i<7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			$this->db->select('cid,feat_game_data,prize_structure,entry_fee,size,total_prize,custom_prize');
			$this->db->where('first_game_cutoff >',$starttime);
			$this->db->where('first_game_cutoff <',$endtime);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$total_total_prize=0;
				foreach($query->result() as $l){
					$total_total_prize+=$this->leagues->get_total_prizes($l,$company_take,false);
				}

				$prize_arr[] = round($total_total_prize,2);
			}else{
				$prize_arr[]=0;
			}
		}
		return $prize_arr;
	}
	function get_prizes_by_month($num_months=12){
		$prize_arr=array();
		$company_take=$this->options->get('company_take');
		for($i=$num_months;$i>0;$i--){
			$month_start=mktime(0,0,0,(date('n')-(1*$i)),1,date('Y'));
			$month_end=mktime(0,0,0,(date('n',$month_start)+1),1,date('Y',$month_start))-1;
			$this->db->select('cid,feat_game_data,prize_structure,entry_fee,size,total_prize,custom_prize');
			$this->db->where('first_game_cutoff >',$month_start);
			$this->db->where('first_game_cutoff <',$month_end);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$total_total_prize=0;
				foreach($query->result() as $l){
					$total_total_prize+=$this->leagues->get_total_prizes($l,$company_take,false);
				}

				$prize_arr[] = round($total_total_prize,2);
			}else{
				$prize_arr[]=0;
			}
		}
		return $prize_arr;
	}

	function get_affiliates_by_month($num_months=12) {
		$aff_arr=array();
		for($i=$num_months;$i>0;$i--){
			$month_start=mktime(0,0,0,(date('n')-(1*$i)),1,date('Y'));
			$month_end=mktime(0,0,0,(date('n',$month_start)+1),1,date('Y',$month_start))-1;
			//echo "<div>".date('m/d/Y g:ia',$month_start)." - ".date('m/d/Y g:ia',$month_end)."</div>";
			$this->db->select('cid,first_game_cutoff');
			$this->db->where('first_game_cutoff >',$month_start);
			$this->db->where('first_game_cutoff <',$month_end);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			//echo "<div>".print_r($this->db->last_query(),true)."</pre>";
			if($query->num_rows()>0){
				$league_ids=array();
				foreach($query->result() as $l){$league_ids[]=$l->cid;}
				$this->db->select('SUM(amount) as amount');
				$this->db->where_in('league_id',$league_ids);
				$aff=$this->db->get('affiliates_transactions')->row();
				//echo "<div>".print_r($this->db->last_query(),true)."</pre>";
				//echo "<div style='margin-left:3em;'>".count($league_ids)." - ".round(($aff->amount*-1),2)."</div>";
				$aff_arr[] = round(($aff->amount*-1),2);
			}else{
				$aff_arr[]=0;
			}
		}
		//exit;
		return $aff_arr;
	}

	function get_affiliates_by_day() {
		$aff_arr=array();
		for($i=0;$i<7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			$this->db->select('cid');
			$this->db->where('first_game_cutoff >',$starttime);
			$this->db->where('first_game_cutoff <',$endtime);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$league_ids=array();
				foreach($query->result() as $l){$league_ids[]=$l->cid;}
				$this->db->select('SUM(amount) as amount');
				$this->db->where_in('league_id',$league_ids);
				$aff=$this->db->get('affiliates_transactions')->row();

				$aff_arr[] = round(($aff->amount*-1),2);
			}else{
				$reward_arr[]=0;
			}
		}

		return $aff_arr;
	}

	public function get_league_rake($league_id=''){
		if(!empty($league_id)){
			//$this->db->select('`custom` as league_id,`source`,SUM(`amount`) as amount,SUM(`bonus_amount`) as bonus_amount');
			$this->db->select('custom as league_id, source, amount, bonus_amount');
			$this->db->where('custom',$league_id);
			//$this->db->group_by('source');
			$trans=$this->db->get('user_balance_transactions');
			$league=$this->leagues->get_by_id($league_id);
			$orig_rake=$this->options->get('company_take')*100;
			if(!empty($league->feat_game_data)){
				$fgd=json_decode($league->feat_game_data);
				$orig_rake=$fgd->custom_rake;
			}
			if($trans->num_rows()>0){
				$trans=$trans->result();
				$rake_info=array("orig_rake"=>$orig_rake,"in"=>0,"bonus_in"=>0,"out"=>0,"reversed"=>0,"bonus_reversed"=>0,"rake"=>0);
				$rake_in=$rake_out=$bonus_in=0;
				foreach($trans as $t){
					if($t->source==4){
						$rake_info['in']+=$t->amount;
						$rake_in+=$t->amount;
						$rake_in+=$t->bonus_amount;
						$rake_info['bonus_in']+=$t->bonus_amount;
					}elseif($t->source==5){
						$rake_info['out']+=$t->amount;
						$rake_out+=$t->amount;
					}elseif($t->source==7){
						$rake_info['reversed']+=$t->amount;
						$rake_in-=$t->amount;
						$rake_info['bonus_reversed']+=$t->bonus_amount;
					}
				}

				$rake_info['rake_p']=$rake_in>0?(1-($rake_out/$rake_in))*100:0;
				$rake_info['rake']=$rake_in-$rake_out;
				return $rake_info;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function get_rake_by_day() {
		$rake_arr=array();
		for($i=0;$i<7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			$this->db->select('cid');
			$this->db->where('first_game_cutoff >',$starttime);
			$this->db->where('first_game_cutoff <',$endtime);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$league_ids=array();
				foreach($query->result() as $l){$league_ids[]=$l->cid;}
				$this->db->select('source, sum(`amount`) as amount');
				$this->db->where_in('custom',$league_ids);
				$this->db->group_by('source');
				$trans=$this->db->get('user_balance_transactions');

				$total=$in=$out=$rev=0;
				foreach($trans->result() as $t){
					//add funds locked for the match
					if($t->source==4){ $total+=$t->amount;$in+=$t->amount;}
					//remove funds paid to winners(5) and funds reversed(7)
					else if($t->source==5){ $total-=$t->amount;$out-=$t->amount;}
					else if($t->source==7){ $total-=$t->amount;$rev-=$t->amount;}
				}
				$rake_arr[] = round($total,2);
				//$rake_arr[]=array('league_num'=>count($league_ids),"in"=>$in,"out"=>$out,"rev"=>$rev,"rake"=>number_format($total,2));
			}else{
				$rake_arr[] =0;
			}
		}

		return $rake_arr;

	}

	function get_rake_by_month($num_months=12) {
		$rake_arr=array();
		for($i=$num_months;$i>0;$i--){
			$month_start=mktime(0,0,0,(date('n')-(1*$i)),1,date('Y'));
			$month_end=mktime(0,0,0,(date('n',$month_start)+1),1,date('Y',$month_start))-1;
			$this->db->select('cid');
			$this->db->where('first_game_cutoff >',$month_start);
			$this->db->where('first_game_cutoff <',$month_end);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$league_ids=array();
				foreach($query->result() as $l){$league_ids[]=$l->cid;}
				$this->db->select('source, sum(`amount`) as amount');
				$this->db->where_in('custom',$league_ids);
				$this->db->group_by('source');
				$trans=$this->db->get('user_balance_transactions');

				$total=$in=$out=$rev=0;
				foreach($trans->result() as $t){
					//add funds locked for the match
					if($t->source==4){ $total+=$t->amount;$in+=$t->amount;}
					//remove funds paid to winners(5) and funds reversed(7)
					else if($t->source==5){ $total-=$t->amount;$out-=$t->amount;}
					else if($t->source==7){ $total-=$t->amount;$rev-=$t->amount;}
				}
				$rake_arr[] = round($total,2);
				//$rake_arr[]=array('league_num'=>count($league_ids),"in"=>$in,"out"=>$out,"rev"=>$rev,"rake"=>number_format($total,2));
			}else{
				$rake_arr[] =0;
			}
		}

		return $rake_arr;

	}

	function get_bonus_by_day() {
		$bonus_arr=array();
		for($i=0;$i < 7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			$this->db->select('SUM(bonus_amount) as bonus');
			$this->db->where('source',4);
			$this->db->where('timestamp >=',$starttime);
			$this->db->where('timestamp <=',$endtime);
			$bonus=$this->db->get('user_balance_transactions')->row();
			$bonus_arr[]=(float)(($bonus->bonus*-1));
		}

		return $bonus_arr;

	}

	function get_bonus_by_month($num_months=12) {
		$bonus_arr=array();
		$this_month=date('m');
		for($i=($this_month-($num_months-1));$i<=$this_month;$i++){
			$m=($i<1?(12+$i):($i));
			$y=($i<1?date('Y')-1:date('Y'));
			$month_begin=mktime(0,0,0,$m,1,$y);
			$n=$i+1;
			$m=($n<1?(12+$n):($n));
			$y=($n<1?date('Y')-1:date('Y'));
			$begin_of_next_month=mktime(0,0,0,$m,1,$y);
			$this->db->select('SUM(bonus_amount) as bonus');
			$this->db->where('source',4);
			$this->db->where('timestamp >=',$month_begin);
			$this->db->where('timestamp <',$begin_of_next_month);
			$bonus=$this->db->get('user_balance_transactions')->row();
			$bonus_arr[]=(float)(($bonus->bonus*-1));
		}

		return $bonus_arr;

	}

	function get_reward_by_day() {
		$reward_arr=array();
		for($i=0;$i<7;$i++) {
			$starttime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 00:00:00');
			$endtime = strtotime(date('Y-m-d',strtotime(($i-7).' days')).' 23:59:59');
			$this->db->select('cid');
			$this->db->where('first_game_cutoff >',$starttime);
			$this->db->where('first_game_cutoff <',$endtime);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			if($query->num_rows()>0){
				$league_ids=array();
				foreach($query->result() as $l){$league_ids[]=$l->cid;}
				$this->db->select('SUM(amount) as amount');
				$this->db->where_in('league_id',$league_ids);
				$reward=$this->db->get('reward_transactions')->row();

				$reward_arr[] = round(($reward->amount*-1),2);
			}else{
				$reward_arr[]=0;
			}
		}

		return $reward_arr;
	}

	function get_reward_by_month($num_months=12) {
		$reward_arr=array();
		for($i=$num_months;$i>0;$i--){
			$month_start=mktime(0,0,0,(date('n')-(1*$i)),1,date('Y'));
			$month_end=mktime(0,0,0,(date('n',$month_start)+1),1,date('Y',$month_start))-1;
			//echo "<div>".date('m/d/Y g:ia',$month_start)." - ".date('m/d/Y g:ia',$month_end)."</div>";
			$this->db->select('cid,first_game_cutoff');
			$this->db->where('first_game_cutoff >',$month_start);
			$this->db->where('first_game_cutoff <',$month_end);
			$this->db->where('status',3);
			$this->db->where("finalized",1);
			$query=$this->db->get('league');
			//echo "<div>".print_r($this->db->last_query(),true)."</pre>";
			if($query->num_rows()>0){
				$league_ids=array();
				foreach($query->result() as $l){$league_ids[]=$l->cid;}
				$this->db->select('SUM(amount) as amount');
				$this->db->where_in('league_id',$league_ids);
				$reward=$this->db->get('reward_transactions')->row();
				//echo "<div>".print_r($this->db->last_query(),true)."</pre>";
				//echo "<div style='margin-left:3em;'>".count($league_ids)." - ".round(($aff->amount*-1),2)."</div>";
				$reward_arr[] = round(($reward->amount*-1),2);
			}else{
				$reward_arr[]=0;
			}
		}
		//exit;
		return $reward_arr;
	}

	function get_payments_out_total(){
		$this->db->select('SUM(amount) as outgoing');
		$this->db->where('type',0);
		$inc=$this->db->get('payments')->row();
		return $inc->outgoing;
	}

	function get_affiliates_paid_total(){
		$this->db->select('SUM(amount) as affiliates');
		$this->db->where('reconciled',1);
		$aff=$this->db->get('affiliates_transactions')->row();
		return $aff->affiliates;
	}

	function get_liabilities_total() {
		$this->db->select('SUM(amount) as affiliates');
		$this->db->where('reconciled',0);
		$aff=$this->db->get('affiliates_transactions')->row();

		$this->db->select('SUM(amount) as rake_rewards');
		$this->db->where('reconciled',0);
		$rake=$this->db->get('reward_transactions')->row();

		$this->db->select('SUM(balance) as amount');
		$bal=$this->db->get('user_balances')->row();


		//GET ALL NON UPCOMING/LIVE LEAGUES
		$this->db->where('status <',2);
		$leagues=$this->db->get('league');
		$total_payouts=0;
		foreach($leagues->result() as $l){
			$this->db->select('cid');
			$this->db->where('league_id',$l->cid);
			$entries=$this->db->count_all_results('league_team');
			if($entries>0){
				$total_payouts+=$l->total_prize;
			}
		}
		//echo $leagues->num_rows()."<br />".$total_payouts;exit;

		/*$this->db->select('SUM(amount) as amount');
		$this->db->where('source',4);
		$locked_funds=$this->db->get('user_balance_transactions')->row();
		//echo "Locked Funds: ".$locked_funds->amount."</br>";

		$this->db->select('SUM(amount) as amount');
		$this->db->where('source',7);
		$match_reversed_funds=$this->db->get('user_balance_transactions')->row();
		//echo "Match Reversed Funds: ".$match_reversed_funds->amount."</br>";

		$this->db->select('SUM(amount) as amount');
		$this->db->where('source',5);
		$match_funds_paid=$this->db->get('user_balance_transactions')->row();*/
		//echo "Match Funds Paid: ".$match_funds_paid->amount."</br>";
		//echo "Locked Funds: ".($locked_funds->amount - $match_reversed_funds->amount - $match_funds_paid->amount)."</br>";

		//exit;
		//$total = $aff->affiliates + $rake->rake_rewards + $bal->amount + ($locked_funds->amount - $match_reversed_funds->amount - $match_funds_paid->amount);
		$total = $aff->affiliates + $rake->rake_rewards + $bal->amount + $total_payouts;
		return $total;

	}
	function get_outstanding_bonus_total(){
		$this->db->select('SUM(`bonus_balance`) as bonus');
		$bonus=$this->db->get('user_balances')->row();
		return $bonus->bonus;
	}
	function get_all_methods(){
		$methods=$this->db->get('payment_method');
		$methods=$methods->result();
		return $methods;
	}
	function get_all_gateways(){
		$gateways=$this->db->get('payment_gateways');
		$gateways=$gateways->result();
		return $gateways;
	}
	function get_gateway_by_sys_name($name){
			if(!empty($name)){
			$this->db->where('system_name',$name);
			$gateway=$this->db->get('payment_gateways');
			return $gateway->row();
		}else{
			return false;
		}
	}
	function get_gateway_by_id($id){
		if(!empty($id)){
			$this->db->where('cid',$id);
			$gateway=$this->db->get('payment_gateways');
			return $gateway->row();
		}else{
			return false;
		}
	}
	function get_gateway_by_system_name($name){
		if(!empty($name)){
			$this->db->where('system_name',$name);
			$method=$this->db->get('payment_gateways');
			return $method->row();
		}else{
			return false;
		}
	}
	function get_method_by_id($id){
		if(!empty($id)){
			$this->db->where('cid',$id);
			$method=$this->db->get('payment_method');
			return $method->row();
		}else{
			return false;
		}
	}
	function get_method_by_gateway_id($id){
		if(!empty($id)){
			$this->db->where('type_id',$id);
			$this->db->limit(1);
			$method=$this->db->get('payment_method');
			return $method->row();
		}else{
			return false;
		}
	}

	function get_setup_redirect($id){
		if(!empty($id)){
			$this->db->select('controller,setup_func');
			$this->db->where('cid',$id);
			$gateway=$this->db->get('payment_gateways');
			$gateway=$gateway->row();
			return $gateway->controller.'/'.$gateway->setup_func;
		}else{
			return false;
		}
	}
	/****************************************
	Create Method
	-------------
		Creates a new payment method, needs insert data

	****************************************/
	function create_method($insert){
		if(!empty($insert)){
			$this->db->insert('payment_method',$insert);
			return true;
		}else{
			return false;
		}
	}
	/****************************************
	Update Method
	-------------
		Updates an existing method, needs id and data

	****************************************/
	function update_method($id,$update){
		if(!empty($update) & !empty($id)){
			$this->db->where('cid',$id);
			$update=$this->db->update('payment_method',$update);
			if($update){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	/****************************************
	Delete Method
	****************************************/
	function delete_method($id){
		if(!empty($id)){
			$this->db->where('cid',$id);
			$this->db->delete('payment_method');
			return true;
		}else{
			return false;
		}
	}
	/****************************************
	Save Payment Profile
	****************************************/
	function save_payment_profile($user_id,$data){
		if(!empty($user_id) & !empty($data)){
			$this->db->select('user_id');
			$this->db->where('user_id',$user_id);
			$exists=$this->db->get('payment_profile');
			$exists=$exists->num_rows();
			if($exists>=1){
				$this->db->where('user_id',$user_id);
				if($this->db->update('payment_profile',$data)){
					return true;
				}else{
					return false;
				}
			}else{
				$data['user_id']=$user_id;
				if($this->db->insert('payment_profile',$data)){
					return true;
				}else{
					return false;
				}
			}
		}else{
			return false;
		}
	}
}
?>
