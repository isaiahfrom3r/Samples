<table class="table lobby-table tablesorter" id="lineup_table">
	<thead>
		<tr>
			<th>Pos</th>
			<th class="text-left">Player</th>
			<th>Matchup</th>
			<th>Bye</th>
			<th style="max-width:4rem;">Status</th>
			<th>YTD Pts</th>
			<th>AVG Pts</th>
			<th>Proj Pts</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="text-left grey" colspan="9">QB (1)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td>HOU@<strong>ARI</strong> 9/7 7:30pm</td>
			<td>8</td>
			<td class="injury"></td>
			<td>198</td>
			<td>18</td>
			<td>27.00</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td>HOU@<strong>ARI</strong> 9/7 7:30pm</td>
			<td>8</td>
			<td class="injury"></td>
			<td>198</td>
			<td>18</td>
			<td>27.00</td>
		</tr>
		<tr>
			<td class="text-left grey" colspan="9">RB (2-3)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>BAL</strong>@BUF 9/11 7:30pm</td>
			<td>10</td>
			<td class="injury"></td>
			<td>154</td>
			<td>14</td>
			<td>15.30</td>

		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>HOU</strong>@ARI 9/7 7:30pm</td>
			<td>7</td>
			<td class="injury"></td>
			<td>84</td>
			<td>7.6</td>
			<td>11.10</td>
		</tr>
		<tr>
			<td class="text-left grey" colspan="9">WR (2-3)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>HOU</strong>@ARI 9/7 7:30pm</td>
			<td>7</td>
			<td class="injury"></td>
			<td>56</td>
			<td>5.1</td>
			<td>9.70</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>TEN</strong>@NYJ 9/11 7:30pm</td>
			<td>8</td>
			<td class="injury"><i class="fa fa-medkit"></i> (P)</td>
			<td>66</td>
			<td>6</td>
			<td>7.40</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td>HOU@<strong>ARI</strong> 9/7 7:30pm</td>
			<td>8</td>
			<td class="injury"></td>
			<td>194</td>
			<td>17.6</td>
			<td>14.00</td>
		</tr>
		<tr>
			<td class="text-left grey" colspan="9">TE (2-3)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>NE</strong>@PHI 9/7 7:30pm</td>
			<td>9</td>
			<td class="injury"></td>
			<td>99</td>
			<td>9</td>
			<td>12.20</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>CAR</strong>@JAX 9/11 7:30pm</td>
			<td>11</td>
			<td class="injury"></td>
			<td>231</td>
			<td>21</td>
			<td>20.74</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>CAR</strong>@JAX 9/11 7:30pm</td>
			<td>11</td>
			<td class="injury"></td>
			<td>64</td>
			<td>5.8</td>
			<td>12.00</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>NE</strong>@PHI 9/7 7:30pm</td>
			<td>9</td>
			<td class="injury"></td>
			<td>125</td>
			<td>11.3</td>
			<td>10.60</td>
		</tr>
		<tr>
			<td class="text-left grey" colspan="9">K (1)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>MIN</strong>@CHI 9/7 7:30pm</td>
			<td>9</td>
			<td class="injury"></td>
			<td>33</td>
			<td>3</td>
			<td>12.00</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>BAL</strong>@BUF 9/11 7:30pm</td>
			<td>10</td>
			<td class="injury"></td>
			<td>66</td>
			<td>6</td>
			<td>8.00</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>TEN</strong>@NYJ 9/11 7:30pm</td>
			<td>8</td>
			<td class="injury"><i class="fa fa-medkit"></i> (Q)</td>
			<td>32</td>
			<td>2.9</td>
			<td>5.80</td>
		</tr>
		<tr>
			<td class="text-left grey" colspan="9">DEF/ST (1)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn active">Active</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>SEA</strong>@DET 9/7 7:30pm</td>
			<td>6</td>
			<td class="injury"></td>
			<td>44</td>
			<td>4</td>
			<td>9.00</td>
		</tr>
		<tr>
			<td class="text-left grey" colspan="9">IR (2)</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td>HOU@<strong>ARI</strong> 9/7 7:30pm</td>
			<td>8</td>
			<td class="injury"></td>
			<td>176</td>
			<td>16</td>
			<td>18.24</td>
		</tr>
		<tr>
			<td><button class="lineup-btn btn">Bench</button></td>
			<td class="text-left"><a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name</a></td>
			<td><strong>CAR</strong>@JAX 9/11 7:30pm</td>
			<td>11</td>
			<td class="injury"></td>
			<td>103</td>
			<td>9.4</td>
			<td>6.00</td>
		</tr>
	</tbody>
</table>
