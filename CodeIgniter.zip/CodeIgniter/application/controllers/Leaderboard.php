<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leaderboard extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->model('Leagues');
		$this->load->model('Misc');
		$this->load->model('Teams');
		$this->load->model('Events');
		$this->load->model('Players');
		$this->load->model('Drafts');


	}

	public function index(){

		$head['scripts'] = array(base_url().'/assets/js/leaderboard.js');
		$foot['scripts'] = array();

		$data['standings'] =  $this->Leagues->get_standings_public();


		$user = $this->users->get_user($this->users->id());
		if(isset($user)){
			redirect('/leaderboard/team/'.$user->id);
		}

		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/league/leaderboard',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function state($state){
		$head['scripts'] = array(base_url().'/assets/js/leaderboard.js');
		$foot['scripts'] = array();

		$data['standings'] =  $this->Leagues->get_standings_state($state);


		$user = $this->users->get_user($this->users->id());
		if(isset($user)){
			redirect('/leaderboard/team/'.$user->id);
		}

		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/league/leaderboard',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function team(){
		$head['scripts'] = array(base_url().'/assets/js/leaderboard.js');
		$foot['scripts'] = array();
		$data['standings'] =  $this->Leagues->get_standings($this->users->id());


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/league/leaderboard',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function bracket($cid){
		$this->db->where('id',$cid);
		$c = $this->db->get("competitions");
		$c = $c->row();


		$bracket = json_decode($c->bracket);


/*
results :
[
	[
		[[1,2], [3,4]]
	]
]
*/
		$results = array();

		foreach($bracket as $week=>$b){

			foreach($b as $two=>$bb){
				foreach($bb as $three=>$bbb){

					$this->db->where('team_id',$bbb[0]);
					$this->db->where('opp_id',$bbb[1]);
					$q = $this->db->get("matchups");
					$q = $q->row();

					if($q->team_score == $q->opp_score){
						$q->team_score = .1;
					}

					$results[$two][] = array((double)$q->team_score,(double)$q->opp_score);

					$ateams[$two][] = $bbb[0];

					foreach($bbb as $four=>$m){
						$this->db->where('id',$m);
						$q = $this->db->get("league_team");
						$q = $q->row();

						$nb[$week][$two][$three][$four] = str_ireplace("'", '', $q->name);

					}
				}
			}
		}

		$week = $this->Events->get_week();
		$tused = array();
		if($week >= 13){
			foreach($ateams as $bracket=>$team){
				foreach($team as $tm){
					if(in_array($tm, $tused)){
						continue;
					}


					$this->db->where('team_id',$tm);
					$this->db->where('week',13);
					$q = $this->db->get("matchups");
					if ($q->num_rows() == 0){
						continue;
					}
					$q = $q->row();

					$tworesults[$bracket][] = array((double)$q->team_score,(double)$q->opp_score);

					$tused[] = $q->opp_id;


				}

			}
		}




		$data['results'] =  $results;
		$data['tworesults'] =  $tworesults;
		$c->bracket = json_encode($nb);



		$data['comp'] =  $c;
		$head['scripts'] = array('/assets/js/jquery.bracket.min.js');
		$head['styles'] = array('/assets/css/jquery.bracket.min.css');

		$foot['scripts'] = $foot['styles'] = array();


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/league/bracket',$data);
		$this->load->view(THEME.'/footer',$foot);
	}







}
