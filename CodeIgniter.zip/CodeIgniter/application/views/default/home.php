<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section role="main" class="main-header d-flex justify-content-center " style="background-image: url(<?=base_url();?>assets/img/pv1.png); margin-top:65px;">

		<div class="wrap">

			<h1>Pine View Classic League</h1>


<!-- 			<a href="<?=base_url();?>register" class="btn btn-default btn-red btn-border" style="color:#fff;"></a> -->

		</div>

    </section>

    <section class="light-gray-bg">

	    <div class="container white-bg">

<!--
		    <div class="row">

			    <div class="prizes slight-overlay">

				    <h1>Welcome!</h1>
				    <span>This site will enable you to view league results, schedule and your current handicap.</span>

				    <div class="prize-grid">

					    <div class="row"></div>

					    <div class="row"></div>

					    <div class="row"></div>

					    <div class="row"></div>

				    </div>

			    </div>

		    </div>
-->

		    <div class="row">

			    <div class="full-banner">

				    <a href="https://www.motionindustries.com/productCatalogSearch.jsp" target="_blank">



				    </a>

				</div>

		    </div>

		    <div class="features">


			    <div class="row">

				    <a href="<?php echo base_url(); ?>page/view/schedule" class="col">

					    <span class="glyphicon glyphicon-calendar"></span>

					    <h3>Schedule</h3>

					    <p>View The League Schedule.</p>

				    </a>

				    <a href="<?php echo base_url(); ?>matchups/scoring" class="col">

					    <span class="glyphicon glyphicon-sort-by-order"></span>

					    <h3>Standings</h3>

					     <p>View Current League Standings</p>

				    </a>

				    <a href="<?php echo base_url(); ?>matchups/handicaps" class="col">

					    <span class="glyphicon glyphicon-flag"></span>

					    <h3>League Handicaps</h3>

					    <p>View A List Of League Handicaps</p>

				    </a>

			    </div>

		    </div>


	    </div>

    </section>

    <div id="topcontrol" title="Scroll Back to Top" style="position: fixed; bottom: 5px; right: 5px; opacity: 1; cursor: pointer;">

		<span class="backtotop control fa"></span>

	</div>
