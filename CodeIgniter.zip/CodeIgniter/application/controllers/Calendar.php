<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar extends CI_Controller {
	public function __construct() {


		parent::__construct();
		$this->load->model('Articles');
		$this->load->model('Leagues');
	}

	public function index($month=0,$year=0){
ini_set('display_errors', 0); // set to 0 for production version
error_reporting(-1);
		if(isset($_COOKIE['mlid'])){


		$head = $foot = $data = array();
		$day = 0;
		if($day == 0){
			$day = date('j');
		}
		if($month == 0){
			$month = date('m');
		}
		if($year == 0){
			$year = date('Y');
		}

		$data['year'] =  $year;
		$data['month'] =  $month;
		$data['monthno'] = $monthno =  date('m',strtotime($month."/".$day."/".$year)) ;

		if(($monthno - 1) == 0){
			$pastmonth = 12;
			$pastyear = $year - 1;
		}else{
			$pastmonth = $month -1;
			$pastyear = $year;
		}

		if(($monthno + 1) == 13){
			$nextmonth = 1;
			$nextyear = $year + 1;
		}else{
			$nextmonth = $month +1;
			$nextyear = $year;
		}

		$data['nextmonth'] =  $nextmonth;
		$data['nextyear'] =  $nextyear;
		$data['pastmonth'] =  $pastmonth;
		$data['pastyear'] =  $pastyear;

/*
		$head['scripts'] = array(base_url().'assets/js/calendar.js');
		$head['styles'] = array(base_url().'assets/css/calendar.css');
*/
		$this->db->where('id', $_COOKIE['mlid'] );
		$q = $this->db->get("task_users");
		$q = $q->row();
		$head['profile'] = $data['profile'] =  $profile = $q;


		if(isset($_SESSION['userlist'])){
			$users = array('11881595','10523935');
			$users = $_SESSION['userlist'];
			$data['active_users'] =  $users;
		}else{

			$users = array();
			$users = array($_COOKIE['mlid']);
			$_SESSION['userlist'] = $users;
		}


		$head['styles'] = array(base_url().'assets/css/calendar.css');
		$prefs = array(
		        'month_type'   => 'long',
		        'day_type'     => 'short',
		        'show_next_prev'     => 'true',
		        'next_prev_url'     => 'true',
		);
		$prefs['template'] = '

        {table_open}<div class="MLcal" border="0" cellpadding="0" cellspacing="0">{/table_open}

        {heading_row_start}<div class="cal_heading">{/heading_row_start}

        {heading_previous_cell}<div><a href="{previous_url}">&lt;&lt;</a></div>{/heading_previous_cell}
        {heading_title_cell}<div colspan="{colspan}"><h2>{heading}</h2></div>{/heading_title_cell}
        {heading_next_cell}<div><a href="{next_url}">&gt;&gt;</a></div>{/heading_next_cell}

        {heading_row_end}</div>{/heading_row_end}

        {week_row_start}<div class="cal_DOW">{/week_row_start}
        {week_day_cell}<div class="cal_dow">{week_day}</div>{/week_day_cell}
        {week_row_end}</div>{/week_row_end}

        {cal_row_start}<div>{/cal_row_start}
        {cal_cell_start}<div  class="cal_aday">{/cal_cell_start}
        {cal_cell_start_today}<div class="cal_aday">{/cal_cell_start_today}
        {cal_cell_start_other}<div class="other-month">{/cal_cell_start_other}

        {cal_cell_content}


        <span class="cal_theday ">{day}</span>
        {content}

        {/cal_cell_content}
        {cal_cell_content_today}

       <span class="highlight cal_theday">{day}</span>
        {content}

        {/cal_cell_content_today}

        {cal_cell_no_content}

        <span class="cal_theday">{day}</span>


        {/cal_cell_no_content}
        {cal_cell_no_content_today}

        <span class="highlight  cal_theday">{day}</span>


        {/cal_cell_no_content_today}

        {cal_cell_blank}&nbsp;{/cal_cell_blank}

        {cal_cell_other}{day}{/cal_cel_other}

        {cal_cell_end}</div>{/cal_cell_end}
        {cal_cell_end_today}</div>{/cal_cell_end_today}
        {cal_cell_end_other}</div>{/cal_cell_end_other}
        {cal_row_end}</div>{/cal_row_end}

        {table_close}</div>{/table_close}<div class="clearfix"></div>
';

		$this->load->library('calendar', $prefs);
		$this->load->library('calendar');
		$foot['scripts'] = $foot['styles'] = array();



		// get studio list

		// get tasks for month

		if(isset($users) && !empty($users)){
		$this->db->where_in('user_id',$users);
		}


		$this->db->where('due_month',$month);
		$this->db->where('due_year',$year);
		$q = $this->db->get("task_assignments");
		$q = $q->result();

		foreach($q as $res){
			$tasks[$res->due_day][] = $res;
			$datatask[$res->due_day] = '';
			$tids[$res->task_id] = $res->task_id;
		}


		$this->db->where_in('id',$tids);
		$q = $this->db->get("tasks");
		$q = $q->result();
		foreach($q as $res){

			$taskarray[$res->id] = $res;

		};
		foreach($taskarray as $ta){
			$this->db->select('code');
			$this->db->select('status');
			$this->db->select('id');
			$this->db->where('id',$ta->workspace_id);
			$q = $this->db->get("ci_workspaces");
			if ($q->num_rows() == 0){
				continue;
			}
			$q = $q->row();



			$worksaces[$q->id] = $q;
		}


		$usedtasks = array();

		foreach($tasks as $d=>$t){

			foreach($t as $ta){
				if(isset($usedtasks[$ta->task_id])){
					continue;
				}
				$usedtasks[$ta->task_id] = 1;
				$tinfo = $taskarray[$ta->task_id];
				if(isset( $worksaces[$tinfo->workspace_id])){
					$workspace = $worksaces[$tinfo->workspace_id];
					if(isset($workspace->code)){
						$code = "<span style='font-size:6px;'>".$workspace->code.":</span> ";
						$status = json_decode($workspace->status);
						$color = $status->color;
						if($color == 'yellow'){
							$textcolor = 'black';
						}else{
							$textcolor = '#CFD0D0';
						}

					}else{
						$code = "";
					}
				}else{
					$code = "";
				}



				$datatask[$d] .= '<span style="background:'.$color.'; color:'.$textcolor.';  " data-task="'.$ta->task_id.'" class="cal_bubble ">

				'.$code.substr($tinfo->title, 0, 16).'



				</span><br>';

			}
		}

		$usedtasks = array();
		foreach($tasks as $d=>$t){

			foreach($t as $ta){
				if(isset($usedtasks[$ta->task_id])){
					continue;
				}
				$usedtasks[$ta->task_id] = 1;
				$tinfo = $taskarray[$ta->task_id];
				if(isset( $worksaces[$tinfo->workspace_id])){
					$workspace = $worksaces[$tinfo->workspace_id];
					if(isset($workspace->code)){
						$code = "<span style='font-size:6px;'>".$workspace->code.":</span> ";
						$status = json_decode($workspace->status);
						$color = $status->color;
						if($color == 'yellow'){
							$textcolor = 'black';
						}else{
							$textcolor = '#CFD0D0';
						}

					}else{
						$code = "";
					}
				}else{
					$code = "";
				}



				$datataskm[$d] .= '<span style="background:'.$color.'; color:'.$textcolor.';  " data-task="'.$ta->task_id.'" class="cal_bubble ">

				'.$code.substr($tinfo->title, 0, 50).'



				</span><br>';

			}
		}

		$data['cal'] =  $this->calendar->generate($year, $month, $datatask);

		$data['datatask'] =  $datatask;
		$data['datataskm'] =  $datataskm;
		// get users list
			$q = $this->db->get("task_users");
			$q  = $q->result();
			foreach($q as $res){
				$userlist[$res->full_name] = $res;
			}
			ksort($userlist);
			$data['userlist'] =  $userlist;






		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/calendar/view',$data);
		$this->load->view(THEME.'/footer',$foot);

		}else{

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/calendar/noid');
		$this->load->view(THEME.'/footer');

		}
	}
	public function save_filters(){
		$userlist = array();

		foreach($_POST['users'] as $key=>$u){
			$userlist[] = $key;
		}

		$_SESSION['userlist'] = $userlist;
		$this->load->library('user_agent');
		if ($this->agent->is_referral())
		{
		    redirect( $this->agent->referrer());
		}else{
			redirect( base_url()."calendar" );
		}
	}

	public function get_workspaces($page){
		$this->output->enable_profiler(TRUE);
		$alreadymade = array();
		$this->db->select('id');
		$q = $this->db->get("workspaces");
		$q = $q->result();

/*
		foreach($q as $prior){
			$alreadymade[] = $prior->id;
		}
*/


		$token = "5bcc0618c5f8e5a804fb59be4f4d53fce3b7d254ed0fd3debd902c1671705ece";
		//setup the request, you can also use CURLOPT_URL
		$ch = curl_init('https://api.mavenlink.com/api/v1/workspaces.json?per_page=200&page='.$page);

		// Returns the data/output as a string instead of raw data
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		//Set your auth headers
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		   'Content-Type: application/json',
		   'Authorization: Bearer ' . $token
		   ));

		// get stringified data/output. See CURLOPT_RETURNTRANSFER
		$data = curl_exec($ch);

		// get info about the request
		$info = curl_getinfo($ch);

		$result = curl_exec($ch); // Execute the cURL statement
		$res =  json_decode($result); // Return the received data

		// close curl resource to free up system resources
		curl_close($ch);

		foreach($res->workspaces as $story){


			unset($story->update_whitelist);
			unset($story->account_features);
			unset($story->permissions);


			$story->status = json_encode($story->status);
			$story->due_date = strtotime($story->due_date);
			$story->effective_due_date = strtotime($story->effective_due_date);
			$story->start_date = strtotime($story->start_date);
			$story->updated_at = strtotime($story->updated_at);
			$story->created_at = strtotime($story->created_at);
			$story->internal_time_updated = time();

			$namestring = explode(':', $story->title);
			$story->code = $namestring[0];



			$this->db->where('id', $story->id);
			$q = $this->db->get("workspaces");
			if ($q->num_rows() > 0){
				$this->db->where('id', $story->id);
				$this->db->update('workspaces', $story);
			}else{
				$this->db->insert('workspaces', $story);
			}
		}




		$count = $res->meta->page_count;
		if($page == 1){
			$x = 1;
			while($count > $x ){
				$x++;



				$pc['url'] 		=  $x;
				$pc['running'] 	=  0;
				$pc['fname'] 		=  'get_workspaces';

				$this->db->where('url',$x);
				$this->db->where('fname','get_workspaces');
				$q = $this->db->get("psudo_cron");
				if ($q->num_rows() > 0){
				}else{
					$this->db->insert('psudo_cron', $pc);
				}

	/*
			    $curl = curl_init();
			    $post['test'] = 'examples daata'; // our data todo in received
			    curl_setopt($curl, CURLOPT_URL, $url);
			    curl_setopt ($curl, CURLOPT_POST, TRUE);
			    curl_setopt ($curl, CURLOPT_POSTFIELDS, $post);
			    curl_setopt($curl, CURLOPT_USERAGENT, 'api');
			    curl_exec($curl);
			    curl_close($curl);


			    echo $url." - curled "; echo "<br>";
	*/


			}
		}


	}
	public function info($tid){

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		$this->db->where('id',$tid);
		$q = $this->db->get("tasks");
		$data['task'] =  $task  = $q->row();


		// get users list
		$q = $this->db->get("task_users");
		$q  = $q->result();
		foreach($q as $res){
			$userlist[$res->id] = $res;
		}
		ksort($userlist);
		$data['userlist'] =  $userlist;

		$this->db->where('task_id',$tid);
		$q = $this->db->get("task_assignments");
		$q = $q->result();
		foreach($q as $u){
			$assigned[] = $u->user_id;
		}


		$data['assigned'] =  $assigned;


		$this->load->view(THEME.'/calendar/info',$data);
	}
	public function stall(){
		sleep(10);
		echo "test"; die;
	}
	public function get_tasks($page = 1,$nocron=0){

		$this->output->enable_profiler(TRUE);
		$alreadymade = array();
		$this->db->select('id');
		$q = $this->db->get("tasks");
		$q = $q->result();

/*
		foreach($q as $prior){
			$alreadymade[] = $prior->id;
		}
*/



		$token = "5bcc0618c5f8e5a804fb59be4f4d53fce3b7d254ed0fd3debd902c1671705ece";
		//setup the request, you can also use CURLOPT_URL
		$ch = curl_init('https://api.mavenlink.com/api/v1/stories?include=tags,assignees,workspace&per_page=200&page='.$page);

		// Returns the data/output as a string instead of raw data
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		//Set your auth headers
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		   'Content-Type: application/json',
		   'Authorization: Bearer ' . $token
		   ));

		// get stringified data/output. See CURLOPT_RETURNTRANSFER
		$data = curl_exec($ch);

		// get info about the request
		$info = curl_getinfo($ch);

		$result = curl_exec($ch); // Execute the cURL statement
		$res =  json_decode($result); // Return the received data


		// close curl resource to free up system resources
		curl_close($ch);


		foreach($res->users as $user){
			unset($user->update_whitelist);
			$this->db->where('id',$user->id);
			$q = $this->db->get("task_users");
			if ($q->num_rows() > 0){
				$this->db->where('id', $user->id);
				$this->db->update('task_users', $user);
			}else{
				$this->db->insert('task_users', $user);
			}

		}

		foreach($res->stories as $story){
			if(in_array($story->id, $alreadymade)){
				continue;
			}
			$alreadymade[] = $story->id;

/*

			if($story->id != "525821435"){
				continue;
			}else{
				echo "<pre>";
				print_r($story);
				echo "</pre>";
				die;
			}

*/
			$timestamp = strtotime($story->due_date);
			$dmon = date('m',$timestamp);
			$dday = date('j',$timestamp);
			$dyear = date('Y',$timestamp);

			foreach($story->assignee_ids as $assign){

				$assignment = array('task_id'=>$story->id,'user_id'=>$assign,'due_month'=>$dmon,'due_day'=>$dday,'due_year'=>$dyear);

				$this->db->where('task_id', $story->id);
				$this->db->where('user_id', $assign);
				$q = $this->db->get("task_assignments");
				if ($q->num_rows() > 0){
					$this->db->where('task_id', $story->id);
					$this->db->where('user_id', $assign);
					$this->db->update('task_assignments', $assignment);
				}else{
					$this->db->insert('task_assignments', $assignment);
				}

			}
			unset($story->assingee_ids);



			$story->ancestor_ids = json_encode($story->ancestor_ids);
			$story->tags = json_encode($story->tag_ids);

			if(!empty($story->tag_ids)){
				$tag = $this->get_tag_name($story->tag_ids,$story->id);
			}

			unset($story->tag_ids);
			$story->internal_time_updated = time();
			$insert[] = $story;

			$this->db->where('id', $story->id);
			$q = $this->db->get("tasks");
			if ($q->num_rows() > 0){
				$this->db->where('id', $story->id);
				$this->db->update('tasks', $story);
			}else{
				$this->db->insert('tasks', $story);
			}

		}
/*
		if(isset( $insert )){
			$this->db->insert_batch('tasks', $insert);
		}
		if(isset( $assignments )){
			$this->db->insert_batch('task_assignments', $assignments);
		}
*/
		$next = $page +1;


		$count = $res->meta->page_count;

		if($page == 1 && $nocron == 0){
			$x = 1;
			while($count > $x ){
				$x++;


				$url = 'http://internalstuff.pathfind.com/reports/calendar/get_tasks/'.$x;

				$pc['url'] 		=  $x;
				$pc['running'] 	=  0;
				$pc['fname'] 		=  'get_tasks';

				$this->db->where('url',$x);
				$this->db->where('fname','get_tasks');
				$q = $this->db->get("psudo_cron");
				if ($q->num_rows() > 0){
				}else{
					$this->db->insert('psudo_cron', $pc);
				}

	/*
			    $curl = curl_init();
			    $post['test'] = 'examples daata'; // our data todo in received
			    curl_setopt($curl, CURLOPT_URL, $url);
			    curl_setopt ($curl, CURLOPT_POST, TRUE);
			    curl_setopt ($curl, CURLOPT_POSTFIELDS, $post);
			    curl_setopt($curl, CURLOPT_USERAGENT, 'api');
			    curl_exec($curl);
			    curl_close($curl);


			    echo $url." - curled "; echo "<br>";
	*/


			}
		}





	}
	public function get_tag_name($tags,$project){

		$token = "5bcc0618c5f8e5a804fb59be4f4d53fce3b7d254ed0fd3debd902c1671705ece";
		//setup the request, you can also use CURLOPT_URL
		$ch = curl_init('https://api.mavenlink.com/api/v1/stories/'.$project.'.json?include=tags,assignees,workspace');

		// Returns the data/output as a string instead of raw data
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		//Set your auth headers
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		   'Content-Type: application/json',
		   'Authorization: Bearer ' . $token
		   ));

		// get stringified data/output. See CURLOPT_RETURNTRANSFER
		$data = curl_exec($ch);

		// get info about the request
		$info = curl_getinfo($ch);

		$result = curl_exec($ch); // Execute the cURL statement
		$res =  json_decode($result); // Return the received data


		foreach($res->tags as $tag){

			$this->db->where('name',$tag->name);
			$q = $this->db->get("task_tags");

			$return[] = $tag->name;
			if ($q->num_rows() > 0){

			}else{
				if (strpos($tag->name,'sprint_') !== false) {
				    $sprint = 1;
				}else{
					$sprint = 0;
				}

				$data = array(
	               'id' => $tag->id,
	               'name' => $tag->name,
	               'sprint' => $sprint
	            );

				$this->db->insert('task_tags', $data);

			}

		}

		// close curl resource to free up system resources
		curl_close($ch);


	}


	public function run_psudo(){
		$this->db->limit(5);
		$q = $this->db->get("psudo_cron");
		$q = $q->result();

		foreach($q as $c){
			$this->db->where('id',$c->id);
			$this->db->delete('psudo_cron');

			if($c->fname == 'get_tasks'){
				//echo "Isaiah ... get_tasks(".$c->url.")"; echo "<br>";
				//$this->get_tasks($c->url);

				$url = 'http://internalstuff.pathfind.com/reports/calendar/get_tasks/'.$c->url;


			}elseif($c->fname == "get_workspaces"){
				$url = 'http://internalstuff.pathfind.com/reports/calendar/get_workspaces/'.$c->url;
			}



			$curl = curl_init();
		    $post['test'] = 'examples daata'; // our data todo in received
		    curl_setopt($curl, CURLOPT_URL, $url);
		    curl_setopt ($curl, CURLOPT_POST, TRUE);
		    curl_setopt ($curl, CURLOPT_POSTFIELDS, $post);
		    curl_setopt($curl, CURLOPT_USERAGENT, 'api');
		    curl_exec($curl);
		    curl_close($curl);


		    echo $url." - curled "; echo "<br>";



		}


		echo "END";



	}



}
