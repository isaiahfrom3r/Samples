<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Chat extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mocks');
		$this->load->model('Chats');
	}

	function index($league_id=0){

		if($league_id == 0){
			return '';
		}

		$data['league_id'] = $league_id;
		$data['messages'] = $this->Chats->get_messages($league_id);
		$data['title'] = $league_id;
		$json = json_decode($data['messages'],true);

		foreach($json as $key=>$j){
			$user = $this->users->get_by_id($j['id']);

			$team = $this->Mocks->get_team_by_id($user->team_id);


			$json[$key]['color'] = "";
			$json[$key]['color2'] = "";
			$json[$key]['team'] = "";
		}

		$data['messages'] = json_encode($json);

		if(empty($data['messages'])){

			$data['messages'] = '['.json_encode(array('id' => 1,'pic' => 'default.png', 'message' => 'No Messages', 'time' => date('M j Y g:i A (T)', time()) )).']';
		}

		$this->load->view(THEME.'/chat/chat',$data);
	}

	public function messages($league_id){
		echo $this->Chats->get_messages($league_id);
	}

	public function smack_talk($league_id){
		echo $this->Chats->get_smack($league_id);
	}

    public function delete_chat($uid,$time,$lid){

		$messages = json_decode($this->Chats->get_messages($lid),true);

		foreach($messages as $key=>$m){
			if($uid == $m['id'] && $time == $m['time']){
				unset($messages[$key]);
			}
		}

		$update = array(
			'messages' => json_encode($messages),
		);

		$this->db->where('id', $lid);
		$this->db->update('league_chats', $update);



	}
	public function delete_smack($uid,$time,$lid){

		$messages = json_decode($this->Chats->get_smack($lid),true);

		foreach($messages as $key=>$m){
			if($uid == $m['id'] && $time == $m['time']){
				unset($messages[$key]);
			}
		}

		$update = array(
			'messages' => json_encode($messages),
		);

		$this->db->where('id', $lid);
		$this->db->update('league_smack', $update);



	}

    public function chat_submit_old($uid,$lid){
		$filename = './chats/'.$lid.'_.json';

		$stuff = file_get_contents($filename);

		$stuff = json_decode($stuff);


		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');

		$this->form_validation->set_rules('chat', 'chat', 'strip_tags|required|xss_clean|trim');


/*
		if($this->leagues->own_league($lid,$uid) != 1){
			return ;
		}
*/



		if ($this->form_validation->run() == FALSE)
		{
			return '';

		}



		$data = array(
           'id' => $uid,
           'message' => $_POST['chat'],
           'time' => date('M j Y g:i A (T)', time()),
        );

		$stuff[] = $data;

		$content = json_encode($stuff);

		if($handle = fopen($filename, 'w+')){
		if(is_writable($filename)){
		if(fwrite($handle, $content) === FALSE){
		//echo "Cannot write to file $filename";
		exit;
		}
		//echo "The file $filename was created and written successfully!";
		fclose($handle);
		}
		else{
		//echo "The file $filename, could not written to!";
		exit;
		}
		}
		else{
		//echo "The file $filename, could not be created!";
		exit;
		}
	}

	public function chat_submit($uid,$lid,$message="",$admin=0){
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		if($admin == 1){
			$user = array(
				'avatar' => "",
				'username' => '',
			);
			$user = json_encode($user);
			$user = json_decode($user);
		}else{
			$user = $this->users->get_by_id($uid);
		}


		if($user->avatar == ""){
			$user->avatar = 'default.png';
		}


		if($_POST['chat'] == "" && $message==""){
			echo'nothing'; die;
		}

		if($message ==""){
			$message = $_POST['chat'];
		}

		$data = array(
           'id' => $uid,
           'pic' => $user->avatar,
           'username' => $user->username,
           'message' => $message,
           'display_time' => date('m/j/Y g:i A (T)', time()),
           'time' => time(),
           'admin' => $admin
        );



        $this->Chats->save_chat($lid, $data);

        if (!file_exists('./chats/'.$lid)) {
		    mkdir('./chats/'.$lid, 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y'), 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y').'/'.date('F'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y').'/'.date('F'), 0777, true);
		}


        $filename = './chats/'.$lid.'/'.date('Y').'/'.date('F').'/chat.json';

		$stuff = file_get_contents($filename);

		$stuff = json_decode($stuff);

		$data = array(
           'id' => $uid,
           'message' => $_POST['chat'],
           'time' => date('M j Y g:i A (T)', time())
        );

		$stuff[] = $data;

		$content = json_encode($stuff);

		if($handle = fopen($filename, 'w+')){
			if(is_writable($filename)){
				if(fwrite($handle, $content) === FALSE){
				//echo "Cannot write to file $filename";
				exit;
				}
				//echo "The file $filename was created and written successfully!";
				fclose($handle);
			}


        }



	}

	public function smack_submit($uid,$lid,$message="",$admin=0){
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		if($admin == 1){
			$user = array(
				'avatar' => "",
				'username' => '',
			);
			$user = json_encode($user);
			$user = json_decode($user);
		}else{
			$user = $this->users->get_by_id($uid);
		}


		if($user->avatar == ""){
			$user->avatar = 'default.png';
		}


		if($_POST['chat'] == "" && $message==""){
			echo'nothing'; die;
		}

		if($message ==""){
			$message = $_POST['chat'];
		}

		$data = array(
           'id' => $uid,
           'pic' => $user->avatar,
           'username' => $user->username,
           'message' => $message,
           'display_time' => date('M j Y g:i A (T)', time()),
           'time' => time(),
           'admin' => $admin
        );



        $this->Chats->save_smack($lid, $data);

        if (!file_exists('./chats/'.$lid)) {
		    mkdir('./chats/'.$lid, 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y'), 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y').'/'.date('F'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y').'/'.date('F'), 0777, true);
		}


        $filename = './chats/'.$lid.'/'.date('Y').'/'.date('F').'/smack.json';

		$stuff = file_get_contents($filename);

		$stuff = json_decode($stuff);

		$data = array(
           'id' => $uid,
           'message' => $_POST['chat'],
           'time' => date('M j Y g:i A (T)', time())
        );

		$stuff[] = $data;

		$content = json_encode($stuff);

		if($handle = fopen($filename, 'w+')){
			if(is_writable($filename)){
				if(fwrite($handle, $content) === FALSE){
				//echo "Cannot write to file $filename";
				exit;
				}
				//echo "The file $filename was created and written successfully!";
				fclose($handle);
			}


        }



	}





}
