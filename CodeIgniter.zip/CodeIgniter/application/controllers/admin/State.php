<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class State extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
        $this->load->model('states');
        $this->load->model('Misc');
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){
		$data['states']= $states = $this->Misc->states_list();
		$data['status']= $this->states->get_all_status();



		if(count($_POST) > 5){
			foreach($states as $skey=>$s){
				if(!isset($_POST[$skey]['col_a'])){
					$_POST[$skey]['col_a'] = 0;

				}
				if(!isset($_POST[$skey]['col_b'])){
					$_POST[$skey]['col_b'] = 0;

				}
				if(!isset($_POST[$skey]['col_c'])){
					$_POST[$skey]['col_c'] = 0;

				}
				if(!isset($_POST[$skey]['col_d'])){
					$_POST[$skey]['col_d'] = 0;

				}
				if(!isset($_POST[$skey]['col_e'])){
					$_POST[$skey]['col_e'] = 0;

				}

			}
		}
		if(isset($_POST['AL'])){


			foreach($_POST as $key=>$s){

				if($key == ""){
					continue;
				}

				$this->states->update_add_state($key,$s);

			}
			$this->alert->set('State Settings Saved','success');
			redirect('/admin/state');

		}

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/State/state',$data);
		$this->load->view(ADMIN_THEME.'/footer');

	}
	public function view(){
		$data['states']= $states = $this->Misc->states_list();
		$data['status']= $this->states->get_all_status();
		$data['comp_info']= $this->states->get_all_info($data['states']);
		$data['countries']= $this->Misc->countries();
		$data['c_info'] = $this->states->get_country_info($data['countries']);


		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/State/state_view',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}




}
