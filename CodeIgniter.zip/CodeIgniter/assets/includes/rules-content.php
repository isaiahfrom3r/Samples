<div class="tab-content">

    <div role="tabpanel" class="tab-pane fade in active" id="scoring">
	    <h3>NFL Scoring</h3>

		<p>All scoring can be adjusted by private league commissioners (or) in public leagues offered by YouRulz.</p>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>PASSING</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>Passing TD</td>
					<td>(4)</td>
				</tr>
				<tr>
					<td>Passing 25yds</td>
					<td>(1) *fractional scoring available in private leagues</td>
				</tr>
				<tr>
					<td>Passing INT</td>
					<td>(-1)</td>
				</tr>
			</tbody>
		</table>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>RUSHING</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>Rushing 10yds</td>
					<td>(1) *fractional scoring available in private leagues</td>
				</tr>
				<tr>
					<td>Rushing TD</td>
					<td>(6)</td>
				</tr>
			</tbody>
		</table>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>RECEIVING</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>Receiving 10yds</td>
					<td>(1) *fractional scoring available in some leagues</td>
				</tr>
				<tr>
					<td>Reception</td>
					<td>(1) *(PPR) customizable for RB/WR/TE in some leagues</td>
				</tr>
				<tr>
					<td>Receiving TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>2PT Conversion</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>Fumble Lost</td>
					<td>(-2)</td>
				</tr>
				<tr>
					<td>Returned TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>Offensive Fum Returned TD</td>
					<td>(6)</td>
				</tr>
			</tbody>
		</table>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>KICKING</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>FG 0-19yds</td>
					<td>(3)</td>
				</tr>
				<tr>
					<td>FG 20-29yds</td>
					<td>(3)</td>
				</tr>
				<tr>
					<td>FG 30-39yds</td>
					<td>(3)</td>
				</tr>
				<tr>
					<td>FG 40-49yds</td>
					<td>(4)</td>
				</tr>
				<tr>
					<td>FG 50+yds</td>
					<td>(5)</td>
				</tr>
				<tr>
					<td>Extra Point</td>
					<td>(1)</td>
				</tr>

			</tbody>
		</table>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>DEF TEAM / SPECIAL TEAMS</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>DEF Sack</td>
					<td>(1)</td>
				</tr>
				<tr>
					<td>DEF INT</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>DEF Fum-Rec</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>DEF TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>DEF Safety</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>DEF Blocked Kick</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>D/ST Punt Return TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>D/ST Kickoff Return TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>D/ST Punt Return 10yds</td>
					<td>(1) *fractional scoring available in private leagues</td>
				</tr>
				<tr>
					<td>D/ST Kickoff Return 10yds</td>
					<td>(1) *fractional scoring available in private leagues</td>
				</tr>
				<tr>
					<td>DEF 0pts allowed</td>
					<td>(10)</td>
				</tr>
				<tr>
					<td>DEF 1-6pts allowed</td>
					<td>(7)</td>
				</tr>
				<tr>
					<td>DEF 7-13pts allowed</td>
					<td>(4)</td>
				</tr>
				<tr>
					<td>DEF 14-20pts allowed</td>
					<td>(1)</td>
				</tr>
				<tr>
					<td>DEF 21-27pts allowed</td>
					<td>(1)</td>
				</tr>
				<tr>
					<td>DEF 28-34pts allowed</td>
					<td>(-1)</td>
				</tr>
				<tr>
					<td>DEF 28-34pts allowed</td>
					<td>(-4)</td>
				</tr>
			</tbody>
		</table>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>DEF PLAYERS</strong></td>
					<td><strong>STANDARD SCORING (disabled by default)</strong></td>
				</tr>
				<tr>
					<td>DEF Tackle</td>
					<td>(1)</td>
				</tr>
				<tr>
					<td>DEF Sack</td>
					<td>(0.2)*players only; not for compiled team statistics</td>
				</tr>
				<tr>
					<td>DEF INT</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>DEF Fum-Rec</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>DEF TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>DEF Safety</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>DEF Blocked Kick</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>D/ST Punt Return TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>D/ST Kickoff Return TD</td>
					<td>(6)</td>
				</tr>
				<tr>
					<td>D/ST Punt Return 10yds</td>
					<td>(1) *fractional scoring available in private leagues</td>
				</tr>
				<tr>
					<td>D/ST Kickoff Return 10yds</td>
					<td>(1) *fractional scoring available in private leagues</td>
				</tr>
			</tbody>
		</table>

		<p>Note that all individual players (offensive and defensive) are eligible for scoring punt return and kickoff return yardage and touchdown scoring if enabled. This does not affect D/ST also being awarded points.</p>

		<p>Note that YouRulz disables defensive players by default.</p>

		<p>Leagues playing with defensive players will be awarded points for both the player (and) the team defense / special teams should they have both on their roster.</p>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>PASSING BONUS</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>Passing YDS 300+</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>Passing YDS 400+</td>
					<td>(5)</td>
				</tr>
				<tr>
					<td>Passing YDS 500+</td>
					<td>(6)</td>
				</tr>
			</tbody>
		</table>

		<p>*** (yards milestone and scoring can be set by commissioners in private leagues)</p>
		<p>Note that bonus points are issued one time based on the final yardage and do not compile. For example, a QB who passes for 454 yards would be awarded (5) points, not (2) + (5) bonus points. For in-game substitution leagues, bonus points are only based on the statistics compiled by the athlete(s) while active.</p>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>RUSHING BONUS</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>Rushing YDS 100+</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>Rushing YDS 150+</td>
					<td>(3)</td>
				</tr>
				<tr>
					<td>Rushing YDS 200+</td>
					<td>(4)</td>
				</tr>
			</tbody>
		</table>

		<p>*** (yards milestone and scoring can be set by commissioners in private leagues)</p>

		<p>Note that bonus points are issued one time based on the final yardage and do not compile. For example, a RB who rushes for 162 yards would be awarded (3) points, not (2) + (3) bonus points. For in-game substitution leagues, bonus points are only based on the statistics compiled by the athlete(s) while active.</p>

		<table class="table">
			<tbody>
				<tr>
					<td><strong>RECEIVING BONUS</strong></td>
					<td><strong>STANDARD SCORING</strong></td>
				</tr>
				<tr>
					<td>Receiving YDS 100+</td>
					<td>(2)</td>
				</tr>
				<tr>
					<td>Receiving YDS 150+</td>
					<td>(3)</td>
				</tr>
				<tr>
					<td>Receiving YDS 200+</td>
					<td>(4)</td>
				</tr>
			</tbody>
		</table>

		<p>*** (yards milestone and scoring can be set by commissioners in private leagues)</p>

		<p>Note that bonus points are issued one time based on the final yardage and do not compile. For example, a WR who receives for 181 yards would be awarded (3) points, not (2) + (3) bonus points. For in-game substitutions leagues, bonus points are only based on the statistics compiled by the athlete(s) while active.</p>

		<p><strong>PASS INTERFERENCE (enabled by default)</strong></p>

		<p>Enabled by default. Standard Passing & Receiving Statistical scoring is earned by the passer (and) the receiver (WR/TE/RB) as if it was a completed pass.</p>

		<p>Pass Interference yardage & reception data is compiled separate from actual passing and receiving stats and does not count towards bonus milestones.</p>

		<p>For example (QB) attempts a 43 yard pass to a (WR) and pass interference is called and upheld in the game. The QB & WR would be issued the scoring they would obtain for a 43 yard pass as based on the league’s specific scoring settings.</p>
    </div>

    <div role="tabpanel" class="tab-pane fade" id="lineup_updates">

	    <h3>In-Game Lineup Updates</h3>

	    <p>YouRulz offers a one-of-a kind in-game substitution option that allows you to substitute players in any starting position on the fly during live games. This adds an unprecedented experience for those looking to “coach their team to victory”.</p>

		<p>Note that this is available in Free Premium Leagues and Paid Entry Leagues only.</p>

		<p>Our in-game substitutions allow you to:</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>Substitute players during NFL games as often as you want</li>
			<li>Earn fantasy points from players during the time they are “active”</li>
			<li>Track their progressive scoring with a unique scoring timeline display</li>
		</ul>

		<p>For example, your starting QB goes down with an injury. You can pull him for your bench QB as you see fit, whether it be for a single series, a quarter, the whole game, or any duration you desire. All in-game substitutions are timestamp delivery based and will result in your team having a combined score of all your players during the time they were listed as a starter. A timeline will display for each player to show you their specific active usage.</p>

		<p><strong>Default Real-Time Cool Down Timer for each Roster:</strong> (120 seconds)</p>
		<p>*can be set to 1/2/5/10/15/30/60/120/240 minute increments or switched OFF in private leagues</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="roster_positions">

	    <h3>NFL Roster Positions</h3>
	    <p>(Standard)</p>

	    <p>Default Roster positions for YouRulz include a total of (9) starters, (6) bench spots, and (2) injured reserve designations. Your “active roster” can only contain 9 + 6 = 15 total spots. The IR designation does not count towards this total. The positions are as follows:</p>

	    <table class="table">
			<tbody>
				<tr>
					<td>(1)</td>
					<td>QB</td>
				</tr>
				<tr>
					<td>(2)</td>
					<td>RBs</td>
				</tr>
				<tr>
					<td>(2)</td>
					<td>WRs</td>
				</tr>
				<tr>
					<td>(1)</td>
					<td>TE</td>
				</tr>
				<tr>
					<td>(1)</td>
					<td>FLEX (RB/WR/TE)</td>
				</tr>
				<tr>
					<td>(1)</td>
					<td>K</td>
				</tr>
				<tr>
					<td>(1)</td>
					<td>Team DEF / ST</td>
				</tr>
				<tr>
					<td>(6)</td>
					<td>BENCH spots, can be any position</td>
				</tr>
			</tbody>
	    </table>

		<p>IR spots are for any player you wish to disable due to injury. IR spots are counted separately from the 15 active roster spots, thus providing your team with a total of 17 possible spots. Should you have 16 or 17 players (due to using IR), other players on your roster will need to be dropped (or) moved to IR accordingly.  The injury designation for a player is based on data received from Rotowire.com.</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="optional_positions">

	    <h3>Optional Roster Positions</h3>
	    <p>(Private Leagues)</p>

	    <p>Should your commissioner opt to enable DEFENSIVE POSITIONS, the following will become available:</p>

		<p>(DL) (DB) (LB) (DT) (DE) (CB) (S)</p>

		<p>Alternatively, your commissioner may set all defensive players to have a standard designation of (D) without any required specificity.</p>

		<h3>Optional Number of Roster Positions (Private Leagues)</h3>

		<p>Should your commissioner opt to change the default # of players on a roster, “IR slots” “starter slots” or “bench slots” specifically, they will be able to do so. This will allow for multi QB leagues, multi FLEX leagues, etc… or any reasonable arrangement of players.</p>

		<p>53 is the maximum number of player slots allowed during commissioner setup.</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="draft_settings">

	    <h3>Draft Settings</h3>
	    <p>(Public &amp; Private Leagues)</p>

	    <p>Leagues are joined via the YouRulz lobby. Upon successfully joining a league the user will be able to participate and draft accordingly when the date & time of the draft begins.</p>

		<p>All standard drafts are based on a “snake draft”  or “straight round” format.</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>The draft order is randomized (1) hour before the start of the draft</li>
			<li>Snake Draft = “snakes” such as 1,2,3,4,5,6,7,8,8,7,6,5,4,3,2,1,1,2,3,etc….</li>
			<li>Straight Round = “straight” such as 1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8,etc…</li>
			<li>All drafts are conducted “online”</li>
			<li>Participants may set themselves to auto-draft</li>
			<li>Participants who have not set auto-draft and are not “live/online” will auto-draft upon the countdown clock being met</li>
			<li>60 seconds is the standard timer for each pick in each round</li>
		</ul>

		<p>All private leagues will have the draft managed by league commissioners. The commissioner will be able to:</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>set the draft as STANDARD (online) and complete as described above</li>
			<li>set the draft as OFFLINE (commissioner responsible for filling all rosters)</li>
			<li>set the league as KEEPER (in advance, pick players for certain rosters as being picked in certain rounds, thus eliminating the player from being draft eligible. In addition, the commissioner can “exclude” a user from any specific round should the round have been lost and accounted for manually via a trade in a prior season (or) for any other reason determined by the commissioner.</li>
		</ul>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>Adjust the draft type and draft order</li>
			<li>Set the round timer for each pick (60 seconds by default)</li>
			<li>Pause a live draft at any time</li>
			<li>Back up (remove mistaken picks, reset the clock, allow for re-picking)</li>
			<li>Pick for any specific user (in the event of connectivity loss by a user)</li>
		</ul>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="league_formats">

	    <h3>League Formats</h3>

	    <p>(Public &amp; Private Leagues)</p>

	    <p>YouRulz offers 3 specific league types. Keeper leagues are also available for any of the 3 league types, thus providing 6 possible options. There are public leagues available in all formats. See each specific league’s setup and rules before joining. The league types are:</p>

	    <p><strong>H2H Standard</strong></p>

	    <p>H2H leagues will allow fantasy teams to match up against one another week by week. Upon the conclusion of each NFL week, teams win or lose, and thus, the league’s standings change.</p>

		<p>Tiebreakers are based on (division record if there are divisions) | (points scored) | (points allowed) in that order.</p>

		<p>H2H matchups will follow a round-robin equal-play style where each team plays against the other teams in the league as evenly as possible. Any “additional weeks” requiring gameplay will transpire within the division (if divisions exist). At the conclusion of the H2H league regular season, playoffs begin as specified in the playoffs description.</p>

		<p><strong>Points Only League</strong></p>

		<p>The standard points only league will simply score fantasy points from NFL week 1 thru NFL week 17 (or as specified by the commissioner for the final week of the season) where the final rankings are determined after all scoring has finalized. There are no H2H matchups. Teams simply accumulate points based on the scoring earned.</p>

		<p><strong>Points with H2H Playoffs</strong></p>

		<p>The playoff format will work by scoring points (without H2H) until the playoffs begin. Upon the playoffs beginning, teams will be seeded and the playoffs will unfold in a H2H format exactly as described in the H2H League format above and as cited in the playoff description section.</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="league_sizes">

	    <h3>League Sizes / Prizes / Entry Costs</h3>
	    <p>(Public &amp; Private Leagues)</p>

	    <p>All leagues, their size, prize payouts, and entry costs are clearly defined for every league prior to the user joining. This is public information.</p>

		<p>Sizes / prizes / entry costs cannot be changed after a league is created. In order for a league to run, it must be 100% full. Leagues that do not fill will automatically expire and refund the users who have entered accordingly.</p>

		<p>Most standard (public) leagues created by YouRulz are:</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>8 / 10 / 12 team leagues (no divisions)</li>
		</ul>

		<p>Leagues are required to have an even number of users. Custom sizes include:</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>6 / 8 / 10 / 12 / 14 / 16 / 18 / 20 / 22 / 24 / 26 / 28 / 30 / 32</li>
		</ul>

		<p>Leagues can also be set to have divisions as follows:</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>(1) = no divisions</li>
			<li>2 / 4 / 6 / 8 divisions (options based on the # of teams)</li>
		</ul>

		<p>A commissioner may set up divisions to group user’s teams into each respective division for the purpose of playoff seeding. For example, the winner of a division may have the 3rd best record overall but since they won their division, they are seed 2 and thus get a bye-week. Division segmenting also takes priority in the play-rate for teams where teams in the division will be played more than once if all teams cannot be played more than once throughout the year.</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="waivers">

    	<h3>Waivers / Free Agents</h3>

    	<p>Commissioners can specify whatever waiver settings they desire for their league.</p>

    	<p><strong>Trades, Waiver & Free Agent Process Schedule</strong></p>

		<p>Waivers for both public and all private leagues will run from the first game (Sunday at 1PM ET or until the player plays) thru (Wednesday at 2AM ET). Free agent (first come first serve transactions) will take place from (Wednesday at 2AM ET) thru (Sunday at 1PM ET or until the player plays). The only exception to the rule is Thursday and Saturday games. When an athlete’s game starts, they will automatically become a “waiver” player until the cycle fully resets. Trades & Waivers process at 2AM ET each Wednesday.</p>

		<p>Trades can be revoked, or, expedited when a commissioner approves them ahead of time. The three waiver setting options are as follows:</p>

		<p><strong>First Come First Serve Waivers</strong> (private leagues only)</p>

		<p>In this format, there are no “waivers” in the sense of pending pickups. Players can be picked up at will. Al available players are marked as free agents and can be added at any time by any user.</p>

		<p><strong>Blind Bidding</strong> (standard / public enabled by default)</p>

		<p>Blind bidding works like a silent auction. All available players on waivers are available for any team in the league to place a silent bid on. At the time waivers are processed, the highest bidder wins. In the event of a tie, the team with the worse record will be awarded the transaction.</p>

		<p>All transactions are kept private (viewable only by the submitter) until the time waivers process. At that time, all bid requests and player awarding appears in the transaction log like any waiver or free agent pickup.</p>

		<p>In this format, each team has a “waiver budget” and once it is exhausted, no additional waiver requests can be placed. The default budget is $500.00. Waiver bids must be submitted in even dollars (such as $17.00) and not (0.01).</p>

		<p>Commissioners can specify the waiver budget during setup.</p>

		<p><strong>Reverse Standings | Standard Waivers</strong> (private leagues only)</p>

		<p>Week (1) After the Draft --- team waiver priorities are based on a reverse order from their draft position for making waiver claims.</p>

		<p>Moving forward, each week, the team in last place (or with the fewest points) is the team that will have the highest priority waiver request for processing.</p>

		<p>The team manager with the highest waiver priority making a claim on a player gets to add all of their waiver pickups / transactions before any other user. Standings tiebreakers are based on points. For example:</p>

		<p>Team One (0-2 record) 212 points (2nd priority)</p>
		<p>Team Two (0-2 record) 177 points (1st priority)</p>

		<p>Once all waiver transactions transpire for the team with the highest priority, the waiver processing continues for each team down the list that has placed waiver requests until all player requests are submitted.</p>

		<p>Obviously, players where only 1 user placed a waiver request will be awarded the player since there is no prioritization necessary to process the request.</p>
		<p>If no one claims a player before the end of the waiver period, the player becomes a free agent and can be added by any manager in the league during the free agent time period.</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="playoffs">

	    <h3>Playoffs</h3>
	    <p>(Public &amp; Private Leagues)</p>

	    <p>Depending on the size of the league, public leagues and their playoff settings vary. Check the specific rules and scoring for each league as set up by YouRulz for details.</p>

		<p><strong>H2H League Playoffs</strong></p>

		<p>Each H2H league will have a playoff, typically conducted in week 14/15/16 of the NFL season whereas a specified # of teams make the playoffs, a specified # (or none) have a bye-week in the playoffs, and playoff rounds are seeded in a traditional format.</p>

		<p>For example: (12) team league = 6 teams make playoffs.</p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>Week 14 = seed 6 plays 3, seed 4 plays 5. Seed 1 and 2 on bye-week.</li>
			<li>Week 15 = seed 1 versus lowest ranked team, seed 2 versus other remaining opponent.</li>
			<li>Week 16 = championship round for 2 remaining teams</li>
		</ul>

		<p><strong>For private leagues, the commissioner can determine:</strong></p>

		<ul style="list-style:circle;margin-bottom:1rem;padding-left:1rem;">
			<li>The # of teams that make the playoffs</li>
			<li>The # of teams (if any) that earn a bye-weeks in round 1 of the playoffs</li>
			<li>The week # that playoffs begin (and the season ends)</li>
		</ul>

		<p>For example, a league may not want to use week 17 of the NFL season (due to benched players) so their playoffs may be week 14/15/16 as is the case in most leagues. For larger leagues, the desire may be for it to start earlier.</p>

		<p>The YouRulz software will automatically determine seeding and the # of weeks needed in order to properly advance the playoff brackets. This cannot be modified.</p>

		<p><strong>Playoff Tiebreakers</strong></p>

		<p>Playoff tiebreakers cannot be modified. Tiebreakers are based on league record (and if still tied) then points for (the points scored by the user).</p>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="statistical_data">

	    <h3>Statistical Data</h3>

	    <p>All statistical data and player likenesses are based on the data provided by our data company, SportRadar LLC (the official data provider of the NFL) and RotoWire.com. YouRulz does not have the ability to manually adjust any statistics. Upon the conclusion of any NFL game, finalized box-scores are published with finalized statistics.</p>

		<p>Upon statistics being finalized, all results (fantasy points, winners, losers, standings adjustments, and other changes to the league) will transpire as determined by YouRulz and our programmatic schedule. While we strive to ensure all results are based on accurate information, statistical data updates provided to us significantly after the conclusion of an event may not be used.</p>

    </div>

</div>


















