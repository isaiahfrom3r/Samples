<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

function has_post_thumbnail($postid, $type='pages')
{
	$CI =& get_instance();
	$CI->db->select('thumbnail');
	$CI->db->where('thumbnail !=','');
	$CI->db->limit(1);
	$CI->db->where('id',$postid);
	$q=$CI->db->get($type);
	if($q->num_rows()>0){
		return true;
	}
	else
	{
		return false;
	}
}
function the_post_thumbnail($postid,$type='pages',$size=null, $attr=null)
{
	if($attr==null){
		$attr = array(
			'class'	=> "",
			'alt'	=> "",
			'title'	=> "",
		);
	}
	$CI =& get_instance();
	$CI->db->select('thumbnail');
	$CI->db->limit(1);
	$CI->db->where('id',$postid);
	$q=$CI->db->get($type);

	if($q->num_rows()>0){
		$thumbnail=$q->row();
		$thumbnailurl=$thumbnail->thumbnail;
		//print_r($thumbnail);
		if(is_array($attr['class'])){
			$class=implode(' ',$attr['class']);
		}else{
			$class=$attr['class'];
		}
		if(isset($size)){
			if(is_array($size)){
				echo '<img class="feature-image '.$class.'" src="'.base_url($thumbnailurl).'" alt="'.@$attr['alt'].'" title ="'.$attr['title'].'" width="'.$size[0].'" height="'.$size[1].'" />';
			}else{
				echo '<img class="feature-image '.$size.' '.$class.'" src="'.base_url($thumbnailurl).'" alt="'.@$attr['alt'].'" title ="'.$attr['title'].'" />';
			}
		}else{
			echo '<img class="feature-image '.$class.'" src="'.base_url($thumbnailurl).'" alt="'.@$attr['alt'].'" title ="'.$attr['title'].'" />';
		}
	}else{
		echo 'No image found.';
	}
}
function get_the_post_thumbnail($postid)
{

}

// --------------------------------------------------------------------

/* End of file post_thumbnail_helper.php */
/* Location: ./system/application/helpers/MY_language_helper.php */
