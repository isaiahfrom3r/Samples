<?php
class Chats extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }
	public function create($data){
		$this->db->insert('leagues', $data);
		return $this->db->insert_id();
	}
	public function update($id,$data){
		$this->db->where('id', $id);
		$this->db->update('leagues', $data);
	}
	public function get_league($id){
		$this->db->where('id',$id);
		$q = $this->db->get("leagues");
		$q = $q->result();
		return $q[0];
	}
	/*
	*  respond
	*
	*  set weather or not we want to join the league. This will remove the invite and either add us to the league or not as well as adding us it to our my_angular_chats
	*
	*  @Peram:
	*  @Return:
	*
	*  Isaiah Arnold
	*
	*  1/15/15
	*/
	public function respond($league,$resp,$id){
		if($resp == 2){
			$this->db->where('id',$id);
			$q = $this->db->get("my_angular_chats");
			$q = $q->result();

			$invites = json_decode($q[0]->angular_chat_invites);
			$join = json_decode($q[0]->joined_angular_chats);


			foreach($invites as $inv){
				if($inv->id == $league){
					$join[] = $inv;
				}
				else{
					$newinv[] = $inv;
				}
			}

			$invites = $newinv;

			$data = array(
               'angular_chat_invites' => json_encode($invites),
               'joined_angular_chats' => json_encode($join)
            );

			$this->db->where('id', $id);
			$this->db->update('my_angular_chats', $data);



			$this->db->where('id',$league);
			$q = $this->db->get("leagues");
			$q = $q->result();

			$members = json_decode( $q[0]->members );


			$members[] = $id;


            $data = array(
              'members' => json_encode($members)
            );

           $this->db->where('id', $league);
           $this->db->update('leagues', $data);

			return;
		}
		else{

		}


	}

	/*
	*  is_joined
	*
	*  checks if user is in the angular_chat
	*
	*  @Peram: id
	*  @Return: true/false
	*
	*  Isaiah Arnold
	*
	*  1/15/15
	*/
	public function is_joined($league,$id){
		$users= array();
		$this->db->where('id',$league);
		$q = $this->db->get("leagues");
		$q = $q->result();

		$users = json_decode($q[0]->members);

		if(in_array($id, $users)){
			return true;
		}
		else{
			return false;
		}
	}

	/*
	*  upcoming
	*
	*  gets the upcoming angular_chats
	*
	*  @Peram: null
	*  @Return: angular_chats
	*
	*  Isaiah Arnold
	*
	*  1/15/15
	*/
	public function upcoming(){
		$this->db->where('id',$this->members->id());
		$q = $this->db->get("my_angular_chats");
		$q = $q->result();


		$data['invites']  = json_decode($q[0]->angular_chat_invites);
		$data['joined']  = json_decode($q[0]->joined_angular_chats);

		return $data;

	}
	/*
	*  save_chat
	*
	*  saves the chat submit
	*
	*  @Peram: $league id, data
	*  @Return: nothing
	*
	*  Isaiah Arnold
	*
	*  1/19/15
	*/
	public function save_chat($lid,$data){
		$this->db->where('id',$lid);
		$q = $this->db->get("league_chats");

		$old = array();

		if ($q->num_rows() > 0)
		{
			$q = $q->result();

		$old = json_decode($q[0]->messages,true);
		if(!is_array($old)){
			$old = array($data);
		}
		else{
			$old[] = $data;
		}
		$this->config->load('dreamco');
		$old = array_slice($old, -$this->config->item('chat_comments'));
		$old = json_encode($old);

		$messages = array(
           'messages' => $old
        );


		$this->db->where('id', $lid);
		$this->db->update('league_chats', $messages);

		}
		else{
			$q = $q->result();

			$old[] = $data;
			$old = json_encode($old);

			$messages = array(
	           'messages' => $old,
	           'id' => $lid
			);

			$this->db->insert('league_chats', $messages);
		}

	}

	/*
	*  save_smack
	*
	*  saves the smack talk submit
	*
	*  @Peram: $league id, data
	*  @Return: nothing
	*
	*  Sean Cleveland
	*
	*  12/7/17
	*/
	public function save_smack($lid,$data){
		$this->db->where('id',$lid);
		$q = $this->db->get("league_smack");

		$old = array();

		if ($q->num_rows() > 0){
			$q = $q->result();

            $old = json_decode($q[0]->messages,true);
            if(!is_array($old)){
                $old = array($data);
            }else{
                $old[] = $data;
            }
            $this->config->load('dreamco');
            $old = array_slice($old, -$this->config->item('chat_comments'));
            $old = json_encode($old);

            $messages = array(
               'messages' => $old
            );


            $this->db->where('id', $lid);
            $this->db->update('league_smack', $messages);
		}else{
			$q = $q->result();

			$old[] = $data;
			$old = json_encode($old);

			$messages = array(
	           'messages' => $old,
	           'id' => $lid
			);

			$this->db->insert('league_smack', $messages);
		}

	}
    /*
	*  get_messages
	*
	*  gets messages by id
	*
	*  @Peram: league id
	*  @Return: messages
	*
	*  Isaiah Arnold
	*
	*  1/19/15
	*/
	public function get_messages($lid){

		$this->db->where('id',$lid);
		$q = $this->db->get("league_chats");
		$q = $q->result();

		if(isset($q[0] ) &&   strlen($q[0]->messages)>20){

			$json = json_decode($q[0]->messages,true);
			$newj = array();
			foreach($json as $key=>$j){
				if(isset($j['admin'])){
					if($j['admin'] == 1){
						$j['admin'] = 'admin';
					}
				}
				$newj[$key] = $j;
				$user = $this->users->get_by_id($j['id']);

			}

			return json_encode($newj);
		}else{
			return '[{"id":"9","pic":"9.png","username":"No ","message":"Chat Not started","display_time":"  '.date('M j Y g:i A (T)' ,time()).' ","time":'.time().'}]' ;
		}


	}

       /*
	*  get_smack
	*
	*  gets messages by id
	*
	*  @Peram: league id
	*  @Return: messages
	*
	*  Sean Cleveland
	*
	*  12/7/17
	*/
	public function get_smack($lid){

		$this->db->where('id',$lid);
		$q = $this->db->get("league_smack");
		$q = $q->result();

		if(isset($q[0] ) &&   strlen($q[0]->messages)>20){

			$json = json_decode($q[0]->messages,true);
			$newj = array();
			foreach($json as $key=>$j){
				if(isset($j['admin'])){
					if($j['admin'] == 1){
						$j['admin'] = 'admin';
					}
				}
				$newj[$key] = $j;
				$user = $this->users->get_by_id($j['id']);

			}

			return json_encode($newj);
		}else{
			return '[{"id":"9","pic":"9.png","username":"No ","message":"Chat Not started","display_time":"  '.date('M j Y g:i A (T)' ,time()).' ","time":'.time().'}]' ;
		}


	}

    public function chat_submit($uid,$lid,$message="",$admin=0){
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		if($admin == 1){
			$user = array(
				'avatar' => "",
				'username' => '',
			);
			$user = json_encode($user);
			$user = json_decode($user);
		}else{
			$user = $this->users->get_by_id($uid);
		}


		if($user->avatar == ""){
			$user->avatar = 'default.png';
		}


		if($_POST['chat'] == "" && $message==""){
			echo'nothing'; die;
		}

		if($message =="" ){
			$message = $_POST['chat'];
		}

		$data = array(
           'id' => $uid,
           'pic' => $user->avatar,
           'username' => $user->username,
           'message' => $message,
           'display_time' => date('M d g:i a', time()),
           'time' => time(),
           'admin' => $admin
        );



        $this->Chats->save_chat($lid, $data);

        if (!file_exists('./chats/'.$lid)) {
		    mkdir('./chats/'.$lid, 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y'), 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y').'/'.date('F'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y').'/'.date('F'), 0777, true);
		}


        $filename = './chats/'.$lid.'/'.date('Y').'/'.date('F').'/chat.json';

		$stuff = file_get_contents($filename);

		$stuff = json_decode($stuff);

		$data = array(
           'id' => $uid,
           'message' => $_POST['chat'],
           'time' => date('M j Y g:i A (T)', time())
        );

		$stuff[] = $data;

		$content = json_encode($stuff);

		if($handle = fopen($filename, 'w+')){
			if(is_writable($filename)){
				if(fwrite($handle, $content) === FALSE){
				//echo "Cannot write to file $filename";
				exit;
				}
				//echo "The file $filename was created and written successfully!";
				fclose($handle);
			}


        }



	}

    public function smack_submit($uid,$lid,$message="",$admin=0){
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		if($admin == 1){
			$user = array(
				'avatar' => "",
				'username' => '',
			);
			$user = json_encode($user);
			$user = json_decode($user);
		}else{
			$user = $this->users->get_by_id($uid);
		}

		if($user->avatar == ""){
			$user->avatar = 'default.png';
		}

		if($_POST['chat'] == "" && $message==""){
			echo'nothing'; die;
		}

		if($message =="" ){
			$message = $_POST['chat'];
		}

		$data = array(
           'id' => $uid,
           'pic' => $user->avatar,
           'username' => $user->username,
           'message' => $message,
           'display_time' => date('M d g:i a', time()),
           'time' => time(),
           'admin' => $admin
        );

        $this->Chats->save_smack($lid, $data);

        if (!file_exists('./chats/'.$lid)) {
		    mkdir('./chats/'.$lid, 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y'), 0777, true);
		}
		if (!file_exists('./chats/'.$lid.date('Y').'/'.date('F'))) {
		    mkdir('./chats/'.$lid.'/'.date('Y').'/'.date('F'), 0777, true);
		}

        $filename = './chats/'.$lid.'/'.date('Y').'/'.date('F').'/smack.json';

		$stuff = file_get_contents($filename);

		$stuff = json_decode($stuff);

		$data = array(
           'id' => $uid,
           'message' => $_POST['chat'],
           'time' => date('M j Y g:i A (T)', time())
        );

		$stuff[] = $data;

		$content = json_encode($stuff);

		if($handle = fopen($filename, 'w+')){
			if(is_writable($filename)){
				if(fwrite($handle, $content) === FALSE){
				//echo "Cannot write to file $filename";
				exit;
				}
				//echo "The file $filename was created and written successfully!";
				fclose($handle);
			}


        }



	}

	/*
	*  add_invite
	*
	*  adds the user to the invite if they are not already
	*
	*  @Peram: id, league
	*  @Return: nothing
	*
	*  Isaiah Arnold
	*
	*  1/14/15
	*/
	public function add_invite($id,$league){
		$this->db->where('id',$id);
		$q = $this->db->get("my_angular_chats");
		$q = $q->result();

		if(!empty($q)){
			$row = $q[0];

			$data[] = array(
               'id' => $league->id,
               'time' => strtotime($league->angular_chat_start),
               'name' => $league->name
            );

            $invites = json_decode($row->angular_chat_invites);

            foreach($invites as $i){
            	if($i->id == $league->id){
	            	$data = "";
	            }
            }
            if(is_array($data)){
            	$invites = array_merge($invites,$data);
            }
            else{
	            return;
            }

			$info = array(
               'id' => $id,
               'angular_chat_invites' => json_encode($invites),
               'joined_angular_chats' => $row->joined_angular_chats
            );

			$this->db->where('id', $id);
			$this->db->update('my_angular_chats', $info);
		}
		else{

			$data[] = array(
               'id' => $league->id,
               'time' => strtotime($league->angular_chat_start),
               'name' => $league->name
            );
            $data = json_encode($data);
            $info = array(
               'id' => $id,
               'angular_chat_invites' => $data,
               'joined_angular_chats' => ''
            );

			$this->db->insert('my_angular_chats', $info);
		}
	}
}
