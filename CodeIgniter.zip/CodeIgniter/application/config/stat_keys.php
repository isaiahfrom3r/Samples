<?php
	$config['passing_td'] = 'PTD';
	$config['passing_td_bonus'] = 'PTDB';
	$config['passing_yds'] = 'PYDS';
	$config['passing_300'] = 'P300+';
	$config['passing_50'] = 'P50+';
	$config['2pt_pass'] = '2PTP';
	$config['rushing_td'] = 'RUTD';
	$config['rushing_td_bonus'] = 'RUTDB';
	$config['rushing_yds'] = 'RUYDS';
	$config['rushing_100'] = 'RU100+';
	$config['rushing_25'] = 'RU25+';
	$config['fumble_lost'] = 'FUM';
	$config['2pt_rush'] = 'RU2PT';
	$config['receiving_rec'] = 'REC';
	$config['receiving_td'] = 'RETD';
	$config['receiving_yds'] = 'REYDS';
	$config['receiving_td_bonus'] = 'RETDB';
	$config['receiving_100'] = 'RE100+';
	$config['receiving_25'] = 'RE25+';
	$config['2pt_rec'] = 'RE2PT';
	$config['kicking_pat'] = 'PAT';
	$config['kicking_fg'] = 'FG';
	$config['kicking_bonus'] = 'FGB';

	$config['turnover'] = 'TO';
	$config['def_sfty'] = 'SFTY';
	$config['def_sack'] = 'SK';
	$config['def_td'] = 'TD';
	$config['def_pts_alw'] = 'PTSALW';
	$config['def_yds_alw_10'] = 'YDSALW';
	$config['pat_block'] = 'BLK';
?>
