<style >

	.feature-image{
		max-width: 200px;
	}
</style>
<div class="row-fluid">
	<?php if(!empty($shop)){ ?>
		<a href="<?=site_url('shop/view/'.$shop->slug);?>" target="_new">shop Preview</a>
	<?php } ?>
	<!--END Information block -->
	<div class="pull-right">
		<a href="<?=site_url('admin/shop/edit')?>" class="btn green" class="btn btn-small confirm">Create New shop</a>
	</div>
	<div class="clearfix"></div><br>

	<?php echo form_open_multipart('/admin/shop/save_shop/', array('id' => 'shop_form'));?>
	<div class="row-fluid">
		<div class="col-md-9">
		<div class="card ">
			<div class="card-header">
				<h2>shops
					<small>
						Publish an shop using the CMS tool below. Remember to choose an author and a category using the tools below. The slug is for the URL and should not contain spaces. Typically, the slug matches the post title, only with dashes.

					</small>
				</h2>
			</div>
		<div class="">
			<?//="<pre>".print_r($edit_page,true)."</pre>";?>
			<? 	$default_lang='english';
				if(isset($edit_page->title) && !empty($edit_page->title))
					$title=$edit_page->title;
				if(isset($edit_page->content) && !empty($edit_page->content))
					$content=$edit_page->content;
				if(isset($edit_page->excerpt) && !empty($edit_page->excerpt))
					$excerpt=$edit_page->excerpt;
				if(isset($edit_page->seo_keywords) && !empty($edit_page->seo_keywords))
					$seo_keywords=$edit_page->seo_keywords;
				if(isset($edit_page->seo_desc) && !empty($edit_page->seo_desc))
					$seo_desc=$edit_page->seo_desc;
				?>
			<input type="hidden" name="shop_id" id="shop_id" value="<?=set_value('shop_id',(isset($edit_page->id) && !empty($edit_page->id))?$edit_page->id:"")?>"/>

					<div class="form-body">
						<div class="form-group">
							<div class="control-group">

								<div class="controls">
									<div class="col-md-12">
										<label class=" control-label">Label</label>
										<input class="form-control" type="text" name="label" id="label" class="full-width required" value="<?=set_value('label',(isset($edit_page->label) && !empty($edit_page->label))?$edit_page->label:"")?>">
										<p class="help-block">This is the label the admin will see in the list of shops</p>
									</div>
								</div>
							</div>
						</div>
						<div class="tabbable tabbable-custom tabbable-full-width">
							<ul class="localization nav nav-tabs hide">
								<?php $langs = array('English'=>'English'); $default_lang = 'English'; ?>
								<?foreach($langs as $l=>$extra_info):?>
								<li<?=($l==$default_lang)?" class='active'":""?>><a href="#<?=$l?>" data-toggle="tab"><?=ucfirst($l)?></a></li>
								<?endforeach;?>
							</ul>
						</div>
						<?//="<pre>".print_R($this->session->all_userdata(),true)."</pre>"?>
						<div class="localization tab-content">
							<?foreach($langs as $l=>$extra_info):?>
							<div id="<?=$l?>" class="tab-pane<?=($l==$default_lang)?" active":""?>">
								<div class="form-group">
									<div class="control-group">


										<div class="controls">
											<div class="col-md-12">
												<label class=" control-label">Title</label>
												<input class="form-control" type="text" name="title" class="title full-width required" value="<?=set_value('title['.$l.']',(isset($title) && !empty($title))?$title:"")?>">
											</div>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="control-group">
										<label class="col-md-12 control-label">Content</label>
										<div class="controls">
											<div class="col-md-12">
												<textarea name="content" id="body_text" style="width:100%;" class="content form-control tinymce  full-width required"><?=set_value('content['.$l.']',(isset($content) && !empty($content))?$content:"")?></textarea>
											</div>
										</div>
									</div>
								</div>
								<br>
								<div class="form-group">
									<div class="control-group">


										<div class="controls">
											<div class="col-md-12">
												<label class=" control-label">Product Link</label><span class="help-text">Amazon / EBAY / ETSY</span>
												<input class="form-control" type="text" name="buy_link" class="title full-width required" value="<?php if(isset($shop->buy_link)){echo $shop->buy_link;} ?>">
											</div>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="control-group">


										<div class="controls">
											<div class="col-md-12">
												<label class=" control-label">Product Cost</label><span class="help-text"></span>
												<input class="form-control" type="text" name="price" class="title full-width required" value="<?php if(isset($shop->price)){echo $shop->price;} ?>">
											</div>
										</div>
									</div>
								</div>

								<div class="clearfix"></div><br>

								<div class="form-group col-md-12">
									<div class="row-fluid pull-left" id="featureimage">
										<h3>Feature Image</h3>
										<?if(isset($edit_page) && has_post_thumbnail($edit_page->id,'shops')){
											echo "<div><h4>Current Image</h4>";
											the_post_thumbnail($edit_page->id,'shops','medium');
											echo "</div>";
											?> <label for="remove">Remove Image</label><input id="remove" type="checkbox" name="remove" value="0"> <?php
											}?>
										<div class="form-group">
											<div class="control-group">
												<label class="control-label">Choose image to use as feature</label>
												<div class="controls">
													<input type="file" name="featureimage" />
													<?=form_error('featureimage');?>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="control-group">

										<div class="controls">
											<div class="col-md-12">
												<label class="control-label">Excerpt</label>
												<textarea class="form-control" rows="2" name="excerpt" style="width:100%;" class="excerpt mceEditor full-width"><?=set_value('excerpt['.$l.']',(isset($excerpt) && !empty($excerpt))?$excerpt:"")?></textarea>
											</div>
										</div>
									</div>
								</div>
								<div class="clearfix"></div>
								<div class="row-fluid">
										<div class="form-group">
											<div class="control-group">

												<div class="controls">
													<div class="col-md-12">
														<label class=" control-label">Meta Description</label>
														<textarea class="form-control" rows="2" name="seo_desc" style="width:100%;" class="seo_desc full-width"><?=set_value('seo_desc['.$l.']',(isset($seo_desc) && !empty($seo_desc))?$seo_desc:"")?></textarea>
													</div>
												</div>
											</div>
										</div>
										<div class="form-group">
											<div class="control-group">

												<div class="controls">
													<div class="col-md-12">
														<label class="control-label">Meta Keywords</label>
														<textarea class="form-control" rows="2" name="seo_keywords" style="width:100%;" class="seo_keywords full-width"><?=set_value('seo_keywords['.$l.']',(isset($seo_keywords) && !empty($seo_keywords))?$seo_keywords:"")?></textarea>
													</div>
												</div>
											</div>
										</div>
										<div class="clearfix"></div><br>
								</div>
								<?endforeach;?>
							</div>
						</div>
					</div>

		</div>
		<div class="clearfix"></div>
		</div>
		</div>
		<div class="col-md-3">
		<div class="card">
			<div class="card-header">

				shop Info

			</div>

		<div class="">
			<div class="portlet box yellow-casablanca">
				<div class="portlet-title">
					<div class="caption">
					</div>
				</div>
				<div class="portlet-body form">
					<div class="form-body">
						<div class="form-group">
							<div class="control-group">

								<div class="col-md-12">
									<label class=" control-label-shop">Slug</label>
									<input class="form-control" type="text" name="slug" id="slug" class="full-width required" value="<?=set_value('slug',(isset($edit_page->slug) && !empty($edit_page->slug))?$edit_page->slug:"")?>">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="control-group">

								<div class="col-md-12">
									<label class=" control-label-shop">Status</label>
									<select class="form-control" id="status" name="status" class="full-width required">
										<option value="published" <?=set_select("status","published",(isset($edit_page->status) && !empty($edit_page->status) && $edit_page->status=="published")?TRUE:FALSE)?>>Publish</option>
										<option value="draft" <?=set_select("status","draft",(isset($edit_page->status) && !empty($edit_page->status) && $edit_page->status=="draft")?TRUE:FALSE)?>>Draft</option>
									</select>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="control-group">

								<div class="col-md-12">
									<label class=" control-label-shop">Visibility</label>
									<select class="form-control" id="visibility" name="visibility" class="full-width required">
										<option value="public" <?=set_select("visibility","public",(isset($edit_page->visibility) && !empty($edit_page->visibility) && $edit_page->visibility=="public")?TRUE:FALSE)?>>Public</option>
										<option value="loggedin" <?=set_select("visibility","loggedin",(isset($edit_page->visibility) && !empty($edit_page->visibility) && $edit_page->visibility=="loggedin")?TRUE:FALSE)?>>Logged In Members Only</option>
									</select>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="control-group">

								<div class="col-md-12">

									<label class=" control-label-shop">Author</label>
									<select class="form-control" id="author_id" name="author_id" class="full-width required">

										<?foreach($users as $u):?>
										<option value="<?=$u->id?>" <?=set_select("author_id",$u->id,((isset($edit_page->author_id) && !empty($edit_page->author_id) && $edit_page->author_id==$u->id) || (!isset($edit_page->author_id) && empty($edit_page->author_id) && $this->users->id()==$u->id))?TRUE:FALSE)?>><?=$u->username?></option>
										<?endforeach;?>
									</select>
								</div>
							</div>
						</div>


						<div class="form-group">
							<div class="control-group">

								<div class="col-md-12">
									<label class="control-label-shop">Post Date</label>
									<input class="form-control" type="text"  id="post_date" name="post_date" class="form-control required" value="<?=set_value('post_date',(isset($edit_page->post_date) && !empty($edit_page->post_date))?date('m/d/Y h:i A',$edit_page->post_date):date('m/d/Y h:i A',time()))?>" />
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="control-group">
								<label class="col-md-12 control-label-shop">Categories</label>
								<div class="col-md-12">

									<?=$this->shops->show_categories($categories,$shop_cats)?>
								</div>
							</div>
						</div>
					</div>
					<?/*<div class="control-group">
						<label class="control-label">Other Options</label>
						<div class="controls">
							<label class="checkbox"><input type="checkbox" name="allow_comments" id="allow_comments" value="1" <?=set_checkbox('allow_comments',(isset($edit_page->allow_comments) && $edit_page->allow_comments==1)?TRUE:FALSE)?>> Allow Comments?</label>
				</div>
			</div>
			*/?>
			<div class="col-md-12">
				<div class="form-actions pull-right">
					<div class="control-group">
						<input class="btn btn-success" type="submit">
					</div>
				</div>
			</div>
			<div class="clearfix"></div><br>
		</div>
		</form>
	</div>
</div>
<div class="clearfix"></div>
</div>
