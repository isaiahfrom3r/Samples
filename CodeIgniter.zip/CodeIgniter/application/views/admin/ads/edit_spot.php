<div class="row-fluid card">
	<div class="card-header">

	<h3 id="adduser">Edit Ad Placement</h3>

	<!--Information block -->
	<div class="portlet box green">

		<div class="portlet-body">
			<!--Insert information block here-->
			<div class="note note-success">
				<p>
					Simply fill out the form below. It is recommended that you include the image size in the name.
				</p>
			</div>
		</div>
	</div>

</div>
	<form id="form" action="" method="post">
	<!--END Information block -->
	<div class="portlet box green col-md-12">
		<div class="portlet-title">
			<div class="caption">

					<fieldset id="personal">
			</div>
		</div>
		<div class="portlet-body form">
		<div class="form-body">
		<div class="form-group">

		<div class="control-group">
		<label class="col-md-3 control-label">Name:</label>
		<div class="col-md-9">
		<input class="form-control" name="name" id="name" type="text" value="<?=set_value('name', $spot->name);?>" />
		<?=form_error('name');?>
		<p class="help-block"></p>
		</div>
		</div>
		</div>
		<div class="clearfix"></div>
		<div class="form-group">
		<div class="control-group">
		<label class="col-md-3 control-label">Max banners in the placement:</label>
		<div class="col-md-9">
		<input class="form-control" name="max_banners" id="max_banners" type="text" value="<?=set_value('max_banners', $spot->max_banners);?>" />
		<?=form_error('max_banners');?>
		<p class="help-block"><div style="font-size: 10px; color: #cecece;">Theme code:
		&lt;?=$this->ads->spot(<?=$spot->cid;?>);?&gt;
		</p></div>
		</div>
		</div>
		</div>
		<div class="clearfix"></div>
		</fieldset>
		</div>
		<div class="clearfix"></div><br>
		<div class="form-actions">
		<input id="button1" type="submit" class="btn btn-success pull-right" value="Save" />
		</div>
		<div class="clearfix"></div><br>
		</form>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
</div>
</div>
</div>
