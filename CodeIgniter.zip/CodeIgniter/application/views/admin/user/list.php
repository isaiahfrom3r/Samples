<?php ini_set('display_errors', 0); // set to 0 for production version
error_reporting(-1); ?>
<div class="card">
	<div class="card-header">
		<h4 class="pull-left">Users</h4>

		<form class="pull-right" action="" id="user_search_form" method="get" role="form" style="max-width:450px;">
			<div class="input-group">
				<input type="text" class="form-control" name="search" placeholder="Search users...">
				<span class="input-group-addon">
					<button class="btn btn-primary" type="submit">Go</button>
				</span>
			</div>
			Search for users by username, name, or email address.
		</form>

		<div style="clear:both;"></div>
		<small>* = Interested User</small>
	</div>

	<div class="card-body">
		<div class="clearfix"></div><br>


		<?php
		$source = array(
			1 => 'Returning Customer',
			2 => 'Family/Friend',
			3 => 'FFE Email',
			4 => 'FFE Facebook Posts',
			5 => 'FFE Twitter Posts',
			6 => 'Rotowire Email',
			7 => 'Rotowire Commercial',
			8 => 'Rotowire Website',
			9 => 'Rotowire Interview',
			10 => 'Rotowire Football Guide',
			11 => 'Fantasy Alarm Email',
			12 => 'Fantasy Alarm Blog Posts',
			13 => 'Fantasy Alarm Web Ads',
			14 => 'Fantasy Twitter Posts',
			15 => 'Fantasy Alarm Interview',
			16 => 'Other',
		);
		?>

		<div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th>ID</th>
						<th>Username</th>
						<th>Name</th>
<!-- 						<th>State</th> -->
<!-- 						<th>IP</th> -->
						<th>Join Date</th>
						<th>Email</th>
						<th>Actions</th>
<!-- 						<th></th> -->
						<th></th>
					</tr>
				</thead>
				<tbody>

					<?foreach($users as $u):?>
					<?php if($u->usersource < 1){$u->usersource = 1;} ?>

					<tr>

						<td><?=$u->id?></td>
						<td ><?=$u->username?> <?php if($u->interest == "Yes"){echo "*";} ?></td>
						<td ><?=$u->first_name?> <?=$u->last_name?></td>
<!-- 						<td><?=$u->state?></td> -->
<!--
						<td>
							<?php if(strlen($u->IP > 1)){ ?>

								<?=$u->IP?>
							<?php }else{ ?>
								Pending
							<?php } ?>
						</td>
-->
						<th><?=date('m/d/Y',$u->join_date)?></th>
						<td ><?=$u->email?></td>
						<td>
							<div data-info='<?=json_encode($u)?>'  data-uid="<?=$u->id?>" class="btn btn-info edit_user"> Edit</div>






						</td>
						<td>
							<?php if($u->active == 1){ ?>
							<div  data-status="Deactivate" data-fname="<?=$u->first_name?>" data-lname="<?=$u->last_name?>"  data-uid="<?=$u->id?>" class="btn btn-danger active_user"> Deactivate</div>
							<?php }else{ ?>
							<div  data-status="Activate" data-fname="<?=$u->first_name?>" data-lname="<?=$u->last_name?>" data-uid="<?=$u->id?>" class="btn btn-warning active_user"> Activate</div>
							<?php } ?>

						</td>
						<td>

							<a href="<?php echo base_url(); ?>admin/user/login_as/<?=$u->id?>" class="btn btn-success">Login</a>

						</td>

						<td>

							<!-- Button trigger modal -->
							<button type="button" class="btn btn-warning " data-toggle="modal" data-target="#InfoModal<?=$u->id?>">
							  Info
							</button>

							<!-- Modal -->
							<div class="modal fade" id="InfoModal<?=$u->id?>" tabindex="-1" role="dialog" aria-labelledby="InfoModal<?=$u->id?>" aria-hidden="true">
							  <div class="modal-dialog">
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							        <h4 class="modal-title" id="myModalLabel">User Information</h4>
							      </div>
							      <div class="modal-body">

							      <strong>Name: 	</strong> <?=$u->first_name?> <?=$u->last_name?> <br>
							      <strong>Email: 	</strong> <?=$u->email?><br>
							      <strong>Join Date:</strong> <?=date('m/d/Y',$u->join_date)?><br>


								 <h4> Survey Information</h4>

								  <?php

								  $social = json_decode($u->social);
								  unset($u->social);
								  $u->social = $social[0]."";
								  unset($social[0]);

								  foreach($social as $s){
								  	$u->social = $u->social." , ".$s;
								  }

								  $comm = json_decode($u->communication);
								  unset($u->communication);
								  $u->communication = $comm[0]."";
								  unset($comm[0]);

								  foreach($comm as $s){
								  	$u->communication = $u->communication." , ".$s;
								  }


								  ?>

								  <strong> Source:		  </strong>  <?=str_ireplace("_", " ", $u->source)?> <br>
								  <strong> Relation:	  </strong>  <?=str_ireplace("_", " ", $u->relation)?>    <br>
								  <strong> Reason:		  </strong>  <?=str_ireplace("_", " ", $u->reason)?>   <br>
								  <strong> Social: 		  </strong>  <?=str_ireplace("_", " ", $u->social)?>   <br>
								  <strong> Subscriber:	  </strong>  <?=str_ireplace("_", " ", $u->subscriber)?>   <br>
								  <strong> Communication: </strong>  <?=str_ireplace("_", " ", $u->communication)?>   <br>
								  <strong> Interested: 	  </strong>  <?=str_ireplace("_", " ", $u->interest)?>   <br>



							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							      </div>
							    </div>
							  </div>
							</div>

						</td>
					</tr>
					<?endforeach;?>
				</tbody>
			</table>
		</div>
		<?=$this->pagination->create_links();?>
	</div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="edit_user_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title c-white" id="myModalLabel">Edit User</h4>
			</div>
			<div class="modal-body">
				<form action="" id="user_update_form" method="post" accept-charset="utf-8">
					<div class="clearfix"></div><br>
					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" class="form-control" id="username" name="username" placeholder="Enter a username">
						<p class="help-block">At least 4 characters, letters or numbers only</p>
					</div>
					<input type="hidden" class="form-control" id="user_id_post" name="id" >

					<div class="form-group">
						<label for="username">First Name</label>
						<input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name">
					</div>
					<div class="form-group">
						<label for="username">Last Name</label>
						<input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter Last Name">
					</div>
					<div class="form-group">
						<label for="email">Email</label>
						<input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
						<p class="help-block">A valid email address</p>
					</div>
					<div class="form-group">
						<label for="">Password</label>
						<input type="text" class="form-control" id="filedforp" name="filedforp" placeholder="Leave Blank to do nothing">
					</div>
					<div class="form-group">
						<label for="">Admin</label>
						<input type="text" class="form-control" id="admin" name="admin" placeholder="Set value to 1 to enable Admin Meta Controlls">
					</div>


			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Discard</button>
				<input type="submit" class="btn btn-success" value="Update">
			</div>


			<div class="form-group">

					</div>
			</form>
		</div>
	</div>
</div>
<!-- Confirm Delete -->
<!-- Modal -->
<div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="deleteConfirm" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title c-white" id="myModalLabel">Delete User</h4>
			</div>
			<div class="modal-body">
				<br>
				<h4>Are you sure you want to <span id='remove_status'></span> <span id='remove_fname'></span> <span id='remove_lname'></span>?</h4>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
				<a id='statusurl' href="" type="button" class="btn btn-danger">Yes</a>
			</div>
		</div>
	</div>
</div>
