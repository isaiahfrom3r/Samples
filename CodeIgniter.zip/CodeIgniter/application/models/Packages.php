<?php
class Packages extends CI_Model {

	 function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	function get_all($ordered=false)
	{
		if($ordered){
			$this->db->order_by('order');
		}
		$all=$this->db->get('products');
		$all=$all->result();
		return $all;
	}
	function get_by_id($id){
		if(!empty($id) || $id==0){
			$this->db->where('cid',$id);
			$pkg=$this->db->get('products');
			$pkg=$pkg->row();
			return $pkg;
		}else{
			return false;
		}
	}
	function create($insert_data){

		$insert=array(
			'name'=>$insert_data['name'],
			'description'=>$insert_data['description'],
			'price'=>$insert_data['price'],
			'type'=>$insert_data['type'],
			'extradata'=>$insert_data['extradata'],
			'order'=>$insert_data['order'],
		);

		//$insert['extradata']=json_encode($insert['extradata']);
		/*
}elseif($insert_data['type']=="product"){
			$insert['extradata']=$insert_data['product_data'];
		}
*/
		if($this->db->insert('products',$insert)){
			return true;
		}else{
			return false;
		}
	}

	function edit($edit_id,$edit_data){
		if(!empty($edit_id) & !empty($edit_data)){
			//echo "<h3>Edit_id</h3><pre>".print_r($edit_id,true)."</pre>";
			//echo "<h3>Edit_data</h3><pre>".print_r($edit_data,true)."</pre>";
			//exit;
			$update=array(
				'name'=>$edit_data['name'],
				'description'=>$edit_data['description'],
				'price'=>$edit_data['price'],
				'type'=>$edit_data['type'],
				'extradata'=>$edit_data['extradata'],
				'order'=>$edit_data['order'],
			);
			/*
if($edit_data['type']=="subscription"){
				$update['extradata']=array(
					"duration_months"=>$edit_data['duration_months'],
					"length"=>$edit_data['length'],
					"unit"=>$edit_data['unit'],
					"trialOccurrences"=>$edit_data['trialOccurrences'],
					"trialAmount"=>$edit_data['trialAmount'],
					"trialfirstrunonly"=>$edit_data['trialfirstrunonly'],
				);
				$update['extradata']=json_encode($update['extradata']);
*/
			/*
}elseif($edit_data['type']=="product"){
				$update['extradata']=$edit_data['product_data'];
			}
*/
			$this->db->where('cid',$edit_id);
			if($this->db->update('products',$update)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function delete($delete){
		if(is_array($delete)){
			foreach($delete as $d){
				$this->db->or_where('cid',$d);
			}
		}else{
			$this->db->where('cid',$delete);
		}
		if($this->db->delete('products')){
			return true;
		}else{
			return false;
		}
	}
}
