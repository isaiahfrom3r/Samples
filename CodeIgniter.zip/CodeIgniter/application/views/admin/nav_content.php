<header id="header" class="clearfix" data-ma-theme="bluegray">

	<ul class="h-inner">
		<li class="hi-trigger ma-trigger" data-ma-action="sidebar-open" data-ma-target="#sidebar">
			<div class="line-wrap">
				<div class="line top"></div>
				<div class="line center"></div>
				<div class="line bottom"></div>
			</div>
		</li>
		<li class="hi-logo hidden-xs">
			<a href="<?php echo base_url(); ?>admin"><?=$this->options->get('site_name')?></a>
		</li>
	</ul>
	<!-- Top Search Content -->
	<div class="h-search-wrap">
		<div class="hsw-inner">
			<i class="hsw-close zmdi zmdi-arrow-left" data-ma-action="search-close"></i>
			<input type="text">
		</div>
	</div>
</header>
<?php
$menu = $this->menus->display(197);

?>


<section id="main">

	<aside id="sidebar" class="sidebar c-overflow">
		<div class="s-profile">
                    <a href="" data-ma-action="profile-menu-toggle">

                        <div class="sp-info">
                            <?=$this->session->admin['username']?>
                        </div>
                    </a>


                </div>
		<ul class="main-menu">
			<?php foreach($menu['menu'] as $m){ ?>
				<?php if(isset($m['sub'])){ ?>
					<li class="sub-menu">
						<a href="" data-ma-action="submenu-toggle"><i class="<?=$m['details']['icon']?>"></i> <?=$m['details']['name']?></a>
						<ul>
							<?php foreach($m['sub'] as $s){ ?>

								<li><a href="<?=base_url().$s['details']['url']?>"><?=$s['details']['name']?></a></li>

							<?php } ?>


						</ul>
					</li>
				<?php } else{ ?>
					<?php

					?>
					<li>
						<a href="<?=base_url().$m['details']['url']?>"><i class="<?=$m['details']['icon']?>"></i> <?=$m['details']['name']?></a>
					</li>

				<?php } ?>
			<?php } ?>
		</ul>
	</aside>

	<section id="content">
		<div class="container">

