<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct() {


		parent::__construct();
		$this->load->model('Articles');
		$this->load->model('Leagues');
	}

	public function index()
	{

		if(isset($_GET['comp'])){
			if($this->users->is_loggedin()){
				$this->Leagues->add_to_invite($_GET['comp'],$this->users->id());
			}else{
				$this->session->comp = $_GET['comp'];
			}
		}


		if($this->users->is_loggedin()){

			redirect('/dashboard');

		}else{
			redirect('/login');
		}


		if(isset($_GET['user'])){
			$refer = $this->users->get_user($this->users->get_user_id_from_username($_GET['user']));

			if($this->users->is_loggedin()){
				$this->alert->set('Referrals for new users only' ,'error');
				redirect('/');
			}else{
				$this->session->refer = $refer->username;
				$refwelcome =  "Welcome any new account creation will be registering as ".$refer->username."'s referral.";
				$this->alert->set($refwelcome ,'success_long');
				redirect('/');
			}
		}



		$data['ffe_weekly'] =  $this->Articles->get_articles(24,3);
		$head['scripts'] = array(base_url().'assets/js/rssfeed.js');
		$foot['scripts'] = array();
		$data['content'] =  $content = $this->options->get_grouped_options('home',1);




		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/home',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function player(){
		redirect('/lobby');
		$this->users->is_loggedin(1);
		$head['teams'] = $data['teams'] =  $teams = $this->Leagues->get_my_leagues();
		$data['comps'] =  $comps = $this->Leagues->get_my_competitions();
		$data['ffe_weekly'] =  $this->Articles->get_articles('',6);
		$head['scripts'] = array('/assets/js/home.js','/assets/js/rssfeed.js');
		$foot['scripts'] = array('');
		$data['news'] =  $this->Players->get_all_user_news($this->users->id());
		$data['season_start'] =  $this->Leagues->get_season_start();

		$data['standings'] =  $this->Leagues->get_standings($this->users->id());


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/home/player',$data);
		$this->load->view(THEME.'/footer',$foot);
	}

	public function subscribe(){
		$this->load->library('MailChimp',array('api_key'=>'1e04ac93b2759c5ab44b8b8a78b297fe-us15'));
		$result = $this->mailchimp->get('lists');
		$list_id = '0686ed2334';
		$result = $this->mailchimp->post("lists/$list_id/members", [
                'email_address' => $_POST['email'],
                'status'        => 'subscribed',
        ]);
		if ($this->mailchimp->success()) {

 		    $this->alert->set('Thanks for subscribing to our email list.','success');
		} else {
 		    $this->alert->set('You may already be subscribed.','error');
		}
		redirect('/');
	}



}
