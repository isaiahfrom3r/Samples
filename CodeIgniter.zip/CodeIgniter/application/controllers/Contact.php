<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Cms_model');
	}



	public function index($id='')
	{
		$data['user'] = $this->users->get_user($this->users->id());
		$data['content'] =  $content  = $this->options->get_grouped_options('contact',1);

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('phone', 'Phone #', 'required');
// 		$this->form_validation->set_rules('subject', 'Subject','required');
		$this->form_validation->set_rules('message', 'Message', 'required');
		//$this->form_validation->set_rules('recaptcha_response_field', 'Recaptcha', 'required|callback_check_captcha');

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{

			ini_set('display_errors', 1); // set to 0 for production version
			error_reporting(E_ALL);
			$_POST['subject'] = "Motion Industries Bracket Breakdown - Contact";
			//email message
			$email_data['name'] = $this->input->post('name');
			$email_data['email'] = $this->input->post('email');
			$email_data['phone'] = $this->input->post('phone');
			$email_data['message'] = $this->input->post('message');
			$email_data['company'] = $this->input->post('company');
			$subject = 'Contact Form Submission: '.$this->input->post('subject');
			$subject = $_POST['subject'];




			$this->emails->send_mail($this->options->get('admin_email'), 'contact', $email_data,$subject);


			$this->alert->set($content['contact_thanks'],'success');
			redirect('lobby');

		}


		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/contact',$data);
		$this->load->view(THEME.'/footer');
	}

}
