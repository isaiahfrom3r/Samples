<?php
$start = strtotime('- 11 months');
$end = strtotime('-1 months');
$month = $start;
$months[] = date('F Y', $start);
while($month <= $end) {
  $month = strtotime("+1 month", $month);
  $months[] = date('F Y', $month);
}
$usersbymonth = $this->users->get_month_array();
?>
<script>
	$(document).ready(function(){

    /*-----------------------------------------
        Make some random data for the Chart
    -----------------------------------------*/
	var months = <?=json_encode($months)?>;
	console.log(months[0]);
    var d3 = [];
    for (var i = 0; i <= 12; i += 1) {
        //d3.push([i, i+5]);
    }
    console.log(d3);
    <?php
    foreach($usersbymonth as $key=>$user){
    ?>
    	d3.push([<?=$key?>, <?=$user?>+1]);
    <?php

    }
    ?>
	console.log(d3);

    /*---------------------------------
        Chart Options
    ---------------------------------*/
    var options = {
        series: {
            shadowSize: 0,
            curvedLines: { //This is a third party plugin to make curved lines
                apply: true,
                active: true,
                monotonicFit: true
            },
            lines: {
                show: false,
                lineWidth: 0,
            },
        },
        grid: {
            borderWidth: 0,
            labelMargin:10,
            hoverable: true,
            clickable: true,
            mouseActiveRadius:6,

        },
        xaxis: {
            tickDecimals: 0,
            ticks: false
        },

        yaxis: {
            tickDecimals: 0,
            ticks: false
        },

        legend: {
            show: false
        }
    };

    /*---------------------------------
        Let's create the chart
    ---------------------------------*/
    if ($("#curved-line-chart")[0]) {
        $.plot($("#curved-line-chart"), [
            {data: d3, lines: { show: true, fill: 0.98 }, label: 'Users', stack: true, color: '#f1dd2c' }
        ], options);
    }

    /*---------------------------------
         Tooltips for Flot Charts
    ---------------------------------*/
    if ($(".flot-chart")[0]) {
        $(".flot-chart").bind("plothover", function (event, pos, item) {
            if (item) {
	            console.log(item);
                var x = item.datapoint[0].toFixed(0),
                    y = item.datapoint[1].toFixed(0);
                    console.log(x);
                $(".flot-tooltip").html(months[x] +' '+ (y - 1)+ ' Users').css({top: item.pageY+5, left: item.pageX+5}).show();
            }
            else {
                $(".flot-tooltip").hide();
            }
        });

        $("<div class='flot-tooltip' class='chart-tooltip'></div>").appendTo("body");
    }
});
</script>
