<?php

class Profiles extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();

    }
    public function get_field_by_id($id){
	    $this->db->where('id',$id);
	    $q = $this->db->get("user_profile_fields");
	    $q = $q->row();

	    return $q;
    }
    public function get_fields(){
	    $fields = $this->db->list_fields('users_profile');

	    // unset id's
	    unset($fields[0]);
	    unset($fields[1]);
	    $pass = array();
	    foreach($fields as $field){
	    	$this->db->where('slug',$field);
	    	$q = $this->db->get("user_profile_fields");


	    	if ($q->num_rows() > 0){
	    		$q = $q->row();
	    	}else{
		    	$q = array(
		    		'name' => strtoupper($field),
		    		'slug' => $field,
		    		'type' => 'text',
		    		'category' => 0,
		    	);
		    	$this->insert_update_field_data($q);
	    	}
	    	$pass[] = $q;

	    }
	  return $pass;
    }
    public function add_category($name){
	    $this->db->where('name',$name);
	    $q = $this->db->get("user_proifle_categories");
	    if ($q->num_rows() > 0){
	    	$this->alert->set('Category Added','success');
			redirect('admin/profile');
	    }else{
		    $this->db->insert('user_proifle_categories', array('name'=>$name));
	    }

    }
    public function insert_update_field($post){

	    $this->db->where('slug',$post['slug']);
	    $q = $this->db->get("user_profile_fields");
	    $data = array(
           'name' 		=> $post['name'],
           'slug' 		=> $post['slug'],
           'type' 		=> $post['type'],
           'category' 	=> $post['category'],
           'options'	=> json_encode($post['options'])
        );
	    if ($q->num_rows() > 0){


		    $this->db->where('slug',$post['slug']);
		    $this->db->update('user_profile_fields', $data);
	    }else{
		    $this->db->insert('user_profile_fields', $data);
	    }

    }
    public function remove_field($slug){
	    $this->db->where('slug',$slug);
	    $this->db->delete('user_profile_fields');
    }
    public function delete_cat($id){
	    $this->db->where('id',$id);
	    $this->db->delete('user_proifle_categories');

    }
    public function insert_update_field_data($data){
	    if(isset($data['id'])){
		    $this->db->where('id', $data['id']);
		    $this->db->update('user_profile_fields', $data);

	    }else{
		    $this->db->insert('user_profile_fields', $data);
	    }
    }
    public function get_cats(){
	    $q = $this->db->get('user_proifle_categories');
	    $q = $q->result();
	    return $q;
    }


}
?>
