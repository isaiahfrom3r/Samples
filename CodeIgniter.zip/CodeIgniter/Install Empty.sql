-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 13, 2018 at 01:00 PM
-- Server version: 5.1.73
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tspnpool_m6SCPMA3xdEbeYfU`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_admin_ip`
--

CREATE TABLE `ci_admin_ip` (
  `id` int(11) NOT NULL,
  `ip` varchar(245) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_ad_banners`
--

CREATE TABLE `ci_ad_banners` (
  `cid` int(11) NOT NULL,
  `spot_id` int(11) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  `code` text,
  `image` varchar(128) DEFAULT NULL,
  `url` text,
  `max_impressions` int(11) DEFAULT '0',
  `max_clicks` int(11) DEFAULT '0',
  `impressions` int(15) DEFAULT '0',
  `clicks` int(15) DEFAULT '0',
  `start_date` int(15) DEFAULT '0',
  `end_date` int(15) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `timestamp` int(11) DEFAULT '0',
  `last_loaded` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_ad_spots`
--

CREATE TABLE `ci_ad_spots` (
  `cid` int(11) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `max_banners` int(2) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_articles`
--

CREATE TABLE `ci_articles` (
  `id` int(11) NOT NULL,
  `label` varchar(128) NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(128) NOT NULL,
  `author_id` int(11) NOT NULL,
  `post_date` int(15) NOT NULL,
  `content` longtext NOT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT '0',
  `excerpt` mediumtext NOT NULL,
  `thumbnail` text NOT NULL,
  `status` varchar(16) NOT NULL,
  `visibility` varchar(16) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_article_categories`
--

CREATE TABLE `ci_article_categories` (
  `id` int(11) NOT NULL,
  `label` varchar(128) NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(128) NOT NULL,
  `parent_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_article_category_relation`
--

CREATE TABLE `ci_article_category_relation` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_email_templates`
--

CREATE TABLE `ci_email_templates` (
  `id` int(11) UNSIGNED NOT NULL,
  `slug` varchar(55) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `rule` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_email_templates`
--

INSERT INTO `ci_email_templates` (`id`, `slug`, `subject`, `body`, `rule`) VALUES
(1, 'contact', '{\"english\":\"Contact Form Submission\"}', '{\"english\":\"<p>You have recieved a contact form submission from {{name}}.&nbsp;<\\/p>\\r\\n<p>Their message was&nbsp;<\\/p>\\r\\n<p><em>{{message}}<\\/em><\\/p>\\r\\n<p>Their contact information is:&nbsp;<\\/p>\\r\\n<p><strong>Name:<\\/strong> {{name}}<\\/p>\\r\\n<p><strong>Phone:<\\/strong> {{phone}}<\\/p>\\r\\n<p><strong>Company:<\\/strong> {{company}}<\\/p>\\r\\n<p><strong>Email:<\\/strong>&nbsp;{{email}}<\\/p>\"}', 'System'),
(3, 'invite_friends', '{\"english\":\"Invite Friends\"}', '{\"english\":\"<p>{{message}}<\\/p>\\r\\n<p>Your friend {{name}}&nbsp;thinks you might like to join the Motion Industries&nbsp;website.<\\/p>\\r\\n<p>You can learn more about Motion Industries and why we are the place to play all your season long football by checking us out. Remember that it is fast, free, and easy to sign up and you can play against {{name}}, other friends, family, or any sports fan out there! Here is the website: {{link}}.<br \\/>{{name}}&nbsp;hopes you will check it out.<\\/p>\\r\\n<p>The Motion Industries&nbsp;Team<\\/p>\"}', 'System'),
(4, 'password_change', '{\"english\":\"Password Change\"}', '{\"english\":\"<p>Hello {{name}},<\\/p>\\r\\n<p>We have recieved a password reset notice for your email at Motion Industries. If this was you please click <a href=\\\"{{url}}\\\"> here <\\/a> or copy and paste&nbsp;the link below to reset your password.&nbsp;<\\/p>\\r\\n<p>Link : {{url}}<\\/p>\\r\\n<p>If this was not you please ignore and contact our support team if any problems presist.&nbsp;<\\/p>\"}', 'System'),
(7, 'invite_to_league', '{\"english\":\"Motion Industries \\u2013 You\\u2019ve Been Invited to a League\"}', '{\"english\":\"<p>{{message}}<\\/p>\\r\\n<p>Your friend {{name}} has invited you to join his&nbsp;Motion Industries Bracket Breakdown contest. You can join it by creating an account on Motion Industries.net and then enter the league information below using the JOIN LEAGUE tool.<\\/p>\\r\\n<p>Visit {{url}}&nbsp;now to start.<\\/p>\\r\\n<p>League ID: {{id}}<br \\/>Key: {{key}}<\\/p>\"}', 'system'),
(16, 'register', '{\"english\":\"Welcome to Motion Industries\"}', '{\"english\":\"<p>Thank you for joining. You can log in with your username and password at any time at https:\\/\\/www.mipickem.com.<\\/p>\\r\\n<p>You can also use the forgot password tool if you ever need to.<\\/p>\"}', 'system');

-- --------------------------------------------------------

--
-- Table structure for table `ci_invites`
--

CREATE TABLE `ci_invites` (
  `id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_leagues`
--

CREATE TABLE `ci_leagues` (
  `cid` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `name` varchar(245) NOT NULL,
  `size` int(11) NOT NULL,
  `key` varchar(245) NOT NULL,
  `public_id` varchar(245) NOT NULL,
  `season` int(11) NOT NULL,
  `round` int(11) NOT NULL DEFAULT '1',
  `public` int(11) NOT NULL DEFAULT '0',
  `locked` int(11) NOT NULL DEFAULT '0',
  `open` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_league_chats`
--

CREATE TABLE `ci_league_chats` (
  `id` int(11) NOT NULL,
  `messages` longtext NOT NULL,
  `update` varchar(245) NOT NULL,
  `displayed` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_league_smack`
--

CREATE TABLE `ci_league_smack` (
  `id` int(11) NOT NULL,
  `messages` longtext NOT NULL,
  `update` varchar(245) NOT NULL,
  `displayed` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_league_team`
--

CREATE TABLE `ci_league_team` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `league_id` int(11) NOT NULL,
  `picks` longtext,
  `tb1` int(11) DEFAULT '0',
  `tb2` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_menus`
--

CREATE TABLE `ci_menus` (
  `id` int(11) UNSIGNED NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) UNSIGNED NOT NULL,
  `menuFK` int(11) UNSIGNED DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `new_tab` enum('0','1') NOT NULL,
  `css` text,
  `description` text NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `effect` varchar(255) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `dreamco_tab` enum('0','1') NOT NULL DEFAULT '0',
  `icon` varchar(245) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_menus`
--

INSERT INTO `ci_menus` (`id`, `group_id`, `parent_id`, `menuFK`, `title`, `label`, `url`, `new_tab`, `css`, `description`, `color`, `effect`, `order`, `created_at`, `updated_at`, `dreamco_tab`, `icon`) VALUES
(141, 0, 0, NULL, 'Main', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(142, 0, 0, NULL, 'Admin', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(154, 142, 0, NULL, 'untitled', 'CMS', 'admin/cms', '0', NULL, '', NULL, NULL, 2, 1466434637, 1466439819, '0', 'zmdi zmdi-book-image'),
(160, 142, 0, NULL, 'untitled', 'Menu', 'admin/menu', '0', NULL, '', NULL, NULL, 4, 1466436332, 1466442980, '1', 'zmdi zmdi-menu'),
(161, 142, 0, NULL, 'untitled', 'Email', 'admin/email/email_templates', '0', NULL, '', NULL, NULL, 3, 1466448350, 1466448350, '1', 'zmdi zmdi-email-open'),
(162, 141, 0, NULL, 'untitled', 'Home', '/index.php', '0', NULL, '', NULL, NULL, 0, 1467126209, 1519223249, '0', ''),
(163, 141, 0, NULL, 'untitled', 'Register', '/register', '0', NULL, '', NULL, NULL, 1, 1467126223, 1519056152, '0', ''),
(164, 141, 0, NULL, 'untitled', 'Login', '/login', '0', NULL, '', NULL, NULL, 2, 1467126367, 1498245820, '0', ''),
(168, 0, 0, NULL, 'Rules', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(169, 168, 0, NULL, 'untitled', 'Scoring', 'rules_scoring', '0', NULL, '', NULL, NULL, 0, 1467128616, 1498743582, '0', ''),
(170, 168, 0, NULL, 'untitled', 'In-Game Substitutions', 'rules_in_game', '0', 'Build a team that will dominate the field', '', NULL, NULL, 1, 1467128622, 1498743529, '0', ''),
(171, 168, 0, NULL, 'untitled', 'Roster Positions', 'rules_rosters', '0', NULL, '', NULL, NULL, 2, 1467128642, 1498743573, '0', ''),
(172, 168, 0, NULL, 'untitled', 'Optional Positions', 'rules_optional', '0', NULL, '', NULL, NULL, 3, 1467128654, 1498743612, '0', ''),
(173, 168, 0, NULL, 'untitled', 'Draft Settings', 'rules_draft', '0', NULL, '', NULL, NULL, 4, 1467128669, 1498743638, '0', ''),
(174, 168, 0, NULL, 'untitled', 'League Formats', 'rules_format', '0', NULL, '', NULL, NULL, 5, 1467128681, 1498743662, '0', ''),
(175, 168, 0, NULL, 'untitled', 'Playoffs', 'rules_playoffs', '0', NULL, '', NULL, NULL, 8, 1467128693, 1498743759, '0', ''),
(176, 168, 0, NULL, 'untitled', 'Waivers', 'rules_waivers', '0', NULL, '', NULL, NULL, 7, 1467128710, 1498743708, '0', ''),
(177, 168, 0, NULL, 'untitled', 'Statistical Data', 'rules_stats', '0', 'For newbies, here', '', NULL, NULL, 9, 1467128724, 1498743825, '0', ''),
(182, 168, 0, NULL, 'untitled', 'League Sizes', 'rules_sizes', '0', NULL, '', NULL, NULL, 6, 1467142924, 1498743714, '0', ''),
(185, 0, 0, NULL, 'Footer', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(186, 185, 0, NULL, 'untitled', 'How To Play', '/page/view/how_to_play', '0', NULL, '', NULL, NULL, 0, 1467228096, 1519078606, '0', ''),
(187, 185, 0, NULL, 'untitled', 'Official Rules', '/page/view/rules', '0', NULL, '', NULL, NULL, 5, 1467228120, 1519062338, '0', ''),
(188, 185, 0, NULL, 'untitled', 'About Us', '/page/view/about', '0', NULL, '', NULL, NULL, 2, 1467228133, 1519075064, '0', ''),
(189, 185, 0, NULL, 'untitled', 'Terms & Privacy', '/page/view/terms', '0', NULL, '', NULL, NULL, 6, 1467228165, 1519079347, '0', ''),
(196, 142, 0, NULL, 'untitled', 'Users', '/admin/user', '0', NULL, '', NULL, NULL, 0, 1468015927, 1468015927, '0', 'zmdi zmdi-accounts'),
(197, 0, 0, NULL, 'Article Admin', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(198, 197, 0, NULL, 'untitled', 'CMS', '/admin/cms', '0', NULL, '', NULL, NULL, 2, 1468950628, 1468950628, '0', 'zmdi zmdi-book-image'),
(199, 197, 0, NULL, 'untitled', 'Articles', '#', '0', NULL, '', NULL, NULL, 3, 1468950664, 1468950664, '0', 'zmdi zmdi-collection-text'),
(200, 197, 199, 199, 'untitled', 'Categories', '/admin/article/categories', '0', NULL, '', NULL, NULL, 0, 1468950698, 1468950698, '0', ''),
(201, 197, 199, 199, 'untitled', 'List', '/admin/article/list_all', '0', NULL, '', NULL, NULL, 1, 1468950716, 1468950716, '0', ''),
(202, 197, 0, NULL, 'untitled', 'Dashboard', '/admin', '0', NULL, '', NULL, NULL, 0, 1468950737, 1468950737, '0', 'zmdi zmdi-view-compact'),
(203, 197, 0, NULL, 'untitled', 'Email', '/admin/email/email_templates', '0', NULL, '', NULL, NULL, 1, 1468950785, 1468950785, '0', 'zmdi zmdi-email-open'),
(207, 0, 0, NULL, 'Main Logged', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(208, 207, 0, NULL, 'untitled', 'Home', '/lobby', '0', NULL, '', NULL, NULL, 1, 1490198230, 1519139486, '0', ''),
(215, 0, 0, NULL, 'Logged In Sub Menu', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(222, 0, 0, NULL, 'Mobile Logged In', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(235, 222, 0, NULL, 'untitled', 'Logout', '/logout', '0', NULL, '', NULL, NULL, 6, 1493820030, 1493820030, '0', ''),
(236, 215, 0, NULL, 'untitled', 'Your Profile', '/user/edit', '0', NULL, '', NULL, NULL, 1, 1498676007, 1498679141, '0', ''),
(237, 215, 0, NULL, 'untitled', 'Logout', '/logout', '0', NULL, '', NULL, NULL, 2, 1498676018, 1498676018, '0', ''),
(254, 0, 0, NULL, 'Logged In NO LEAGUE', '', '', '0', NULL, '', NULL, NULL, 0, NULL, NULL, '0', NULL),
(256, 254, 0, NULL, 'untitled', 'About', '/page/view/about', '0', NULL, '', NULL, NULL, 2, 1503696550, 1503696550, '0', ''),
(257, 254, 0, NULL, 'untitled', 'Mock Drafts', '#', '0', NULL, '', NULL, NULL, 1, 1503696579, 1503696579, '0', ''),
(258, 254, 257, 257, 'untitled', 'Mock Draft Lobby', '/mlobby', '0', NULL, '', NULL, NULL, 0, 1503696608, 1503696608, '0', ''),
(259, 254, 257, 257, 'untitled', 'Your Mocks', '/mock/teams', '0', NULL, '', NULL, NULL, 1, 1503696628, 1503696628, '0', ''),
(260, 254, 0, NULL, 'untitled', 'Lobby', '/lobby', '0', NULL, '', NULL, NULL, 0, 1503696654, 1503696654, '0', ''),
(261, 254, 0, NULL, 'untitled', 'Rules', '/page/view/rules', '0', NULL, '', NULL, NULL, 51, 1503696711, 1503696711, '0', ''),
(263, 222, 0, NULL, 'untitled', 'Home', '/lobby', '0', NULL, '', NULL, NULL, 0, 1503932947, 1519312029, '0', ''),
(278, 222, 0, NULL, 'untitled', 'Standings', '/league/standings', '0', NULL, '', NULL, NULL, 3, 1503933220, 1519312050, '0', ''),
(297, 207, 0, NULL, 'untitled', 'Standings', '/league/standings', '0', NULL, '', NULL, NULL, 2, 1504814293, 1519139611, '0', ''),
(299, 207, 0, NULL, 'untitled', 'My Leagues', '/league/home', '0', NULL, '', NULL, NULL, 3, 1513196120, 1519221701, '0', ''),
(304, 215, 316, 316, 'untitled', 'Add Funds', '/funds/add', '0', NULL, '', NULL, NULL, 0, 1515703098, 1515703242, '0', ''),
(305, 215, 316, 316, 'untitled', 'Withdraw $', '/funds/withdraw', '0', NULL, '', NULL, NULL, 1, 1515703119, 1515703223, '0', ''),
(306, 215, 316, 316, 'untitled', 'Transaction History', '/funds/history', '0', NULL, '', NULL, NULL, 2, 1515703137, 1515703209, '0', ''),
(311, 185, 0, NULL, 'untitled', 'Contact', '/contact', '0', NULL, '', NULL, NULL, 3, 1517497619, 1519062345, '0', ''),
(312, 142, 0, NULL, 'untitled', 'Manage Global Settings', '/admin/settings/edit/1', '0', NULL, '', NULL, NULL, 5, 1518032238, 1518032954, '0', 'zmdi zmdi-code-setting'),
(316, 215, 0, NULL, 'untitled', 'Funds', '', '0', NULL, '', NULL, NULL, 0, 1518124070, 1518124070, '0', ''),
(321, 142, 0, NULL, 'untitled', 'Logout', '/logout', '0', NULL, '', NULL, NULL, 6, 1518124785, 1518124804, '0', 'zmdi zmdi-power'),
(323, 185, 0, NULL, 'untitled', 'Prizes', '/page/view/prizes', '0', NULL, '', NULL, NULL, 4, 1519062379, 1519062379, '0', ''),
(324, 207, 0, NULL, 'untitled', 'My Account', '/user/edit', '0', NULL, '', NULL, NULL, 4, 1519139712, 1519146070, '0', ''),
(325, 207, 208, 208, 'untitled', 'Join A Private League', '/league/join', '0', NULL, '', NULL, NULL, 1, 1519139776, 1519224391, '0', ''),
(326, 207, 208, 208, 'untitled', 'Create A League', '/league/create', '0', NULL, '', NULL, NULL, 2, 1519139796, 1519764705, '0', ''),
(327, 207, 0, NULL, 'untitled', 'Logout', '/user/logout', '0', NULL, '', NULL, NULL, 5, 1519140061, 1519140061, '0', ''),
(328, 222, 0, NULL, 'untitled', 'My Leagues', '/league/home', '0', NULL, '', NULL, NULL, 4, 1519312066, 1519312066, '0', ''),
(329, 222, 0, NULL, 'untitled', 'My Account', '/user/edit', '0', NULL, '', NULL, NULL, 5, 1519312089, 1519312089, '0', ''),
(330, 222, 0, NULL, 'untitled', 'Join A Private League', '/league/join', '0', NULL, '', NULL, NULL, 1, 1519312113, 1519312113, '0', ''),
(331, 222, 0, NULL, 'untitled', 'Create A Private League', '/league/create', '0', NULL, '', NULL, NULL, 2, 1519312140, 1519312140, '0', ''),
(333, 185, 0, NULL, 'untitled', 'FAQ\'s', '/page/view/faqs', '0', NULL, '', NULL, NULL, 1, 1519758064, 1519758064, '0', ''),
(334, 207, 208, 208, 'untitled', 'Lobby', '/lobby', '0', NULL, '', NULL, NULL, 0, 1519844560, 1519844560, '0', ''),
(335, 142, 0, NULL, 'untitled', 'Advertisements', '', '0', NULL, '', NULL, NULL, 1, 1519910645, 1519910857, '0', 'zmdi zmdi-tv-list'),
(336, 142, 335, 335, 'untitled', 'Advertisements', '/admin/Advertisement/ads', '0', NULL, '', NULL, NULL, 0, 1519910663, 1519917652, '0', ''),
(337, 142, 335, 335, 'untitled', 'Advertisement Locations', '/admin/Advertisement/spots', '0', NULL, '', NULL, NULL, 1, 1519910683, 1519917669, '0', '');

-- --------------------------------------------------------

--
-- Table structure for table `ci_message_board`
--

CREATE TABLE `ci_message_board` (
  `cid` int(11) UNSIGNED NOT NULL,
  `league_id` int(11) DEFAULT NULL,
  `author` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `message` longtext NOT NULL,
  `post_time` int(11) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `in_reply_to` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_meta`
--

CREATE TABLE `ci_meta` (
  `id` int(11) NOT NULL,
  `url` text NOT NULL,
  `seo` text NOT NULL,
  `name` varchar(245) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_options`
--

CREATE TABLE `ci_options` (
  `cid` int(11) NOT NULL,
  `group` varchar(245) NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` longtext NOT NULL,
  `editor` int(11) DEFAULT NULL,
  `editable` int(1) NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT 'text',
  `default_values` text NOT NULL,
  `nice_name` varchar(64) NOT NULL,
  `rules` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_options`
--

INSERT INTO `ci_options` (`cid`, `group`, `name`, `value`, `editor`, `editable`, `type`, `default_values`, `nice_name`, `rules`) VALUES
(1, '1', 'site_name', 'The Social Pool Network ', 0, 1, 'text', '', 'Site Name', 'required|max_length[128]\n'),
(81, '1', 'current_round', '1', 0, 0, 'text', '', 'Current Round', ''),
(82, '16', 'total_points_tb', '0', 0, 1, 'text', '0', 'Total Points in Championship Game', ''),
(83, '16', 'total_rebounds_tb', '0', 0, 1, 'text', '0', 'Total Rebounds in Championship Game', ''),
(74, '15', 'round_1', 'March 15-16', 0, 1, 'text', '', 'Round 1', ''),
(75, '15', 'round_2', 'March 17-18', 0, 1, 'text', '', 'Round 2', ''),
(76, '15', 'round_3', 'March 22-23', 0, 1, 'text', '', 'Round 3', ''),
(77, '15', 'round_4', 'March 24-25', 0, 1, 'text', '', 'Round 4', ''),
(78, '15', 'round_5', 'March 31', 0, 1, 'text', '', 'Round 5', ''),
(79, '15', 'round_6', 'April 2', 0, 1, 'text', '', 'Round 6', ''),
(16, '1', 'keywords', 'The Social Pool Network ', NULL, 1, 'text', '', 'Keywords', ''),
(17, '1', 'description', 'The Social Pool Network ', NULL, 1, 'text', '', 'Description', ''),
(18, '3', 'contact_thanks', 'Thanks for contacting us! ', NULL, 1, 'text', '', 'Contact Thanks', ''),
(19, '3', 'contact_title', 'Contact Us', NULL, 1, 'text', '', 'Contact Title', ''),
(20, '3', 'contact_text', '<p class=\"p1\"><span class=\"s1\">Have a question about SITE_NAME or looking to learn more about SITE_NAME? Contact us using the form below.</span></p>', 1, 1, 'textarea', '', 'Contact From Text', ''),
(72, '1', 'tournament_id', '3', 0, 1, 'text', '', 'Tournament ID (Developer Variable)', ''),
(21, '1', 'admin_email', 'isaiah@dreamcodesign.com', NULL, 1, 'text', '', 'Admin Email', ''),
(23, '4', 'support_title', 'Support	', NULL, 1, 'text', '', 'Support Title', ''),
(24, '4', 'support_thanks', 'Thanks for contacting us! ', NULL, 1, 'text', '', 'Support Thanks', ''),
(25, '1', 'facebook', '#', NULL, 1, 'text', '', 'Facebook Home', ''),
(26, '1', 'twitter', '#', NULL, 1, 'text', '', 'Twitter Home', ''),
(39, '', 'avatar_small_width', '48', NULL, 0, 'hidden', '', '', ''),
(33, '7', 'referal_text', 'Below you can see your referals that have joined and also see if any of them have paid entries. ', 1, 1, 'textarea', '', '', ''),
(31, '7', 'referal_title', 'Referrals', NULL, 1, 'text', '', 'Referal Title', ''),
(30, '6', 'registration_content', '', 1, 1, 'textarea', '', 'Regristration Content', ''),
(41, '', 'avatar_medium_width', '145', NULL, 0, 'hidden', '', '', ''),
(34, '7', 'share_title', 'Invite Friends', NULL, 1, 'text', '', '', ''),
(35, '7', 'share_text', '', 1, 1, 'textarea', '', '', ''),
(36, '', 'avatar_medium_height', '145', NULL, 0, 'hidden', '', '', ''),
(37, '', 'avatar_big_width', '230', NULL, 0, 'hidden', '', '', ''),
(38, '', 'avatar_big_height', '230', NULL, 0, 'hidden', '', '', ''),
(40, '', 'avatar_small_height', '48', NULL, 0, 'hidden', '', '', ''),
(42, '1', 'linked_account_provider_data', '{\"facebook\":{\"icon\":\"icon-facebook\",\"user_table_column\":\"facebook_id\",\"usermeta_key\":\"facebook_connect\",\"id\":\"658383290976626\",\"secret\":\"acd4660f981e966666fcbc749db08236\",\"scope\":[\"email\",\"public_profile\",\"user_friends\"],\"keys\":{\"id\":\"id\",\"first_name\":\"first_name\",\"user_friends\":\"summary\",\"last_name\":\"last_name\",\"username\":\"username\",\"birthday\":\"birthday\",\"email\":\"email\",\"gender\":\"gender\",\"location\":\"location\",\"link\":\"link\",\"image\":\"image\"}},\"twitter\":{\"icon\":\"icon-twitter\",\"secret\":\"eFqbzBCtdZURT9Pv4z14Ro8n8eChTSYxXlzBg6jboGWulhbojS\",\"user_table_column\":\"twitter_id\",\"usermeta_key\":\"twitter_connect\",\"id\":\"0qLCTbgcc0Jgwbp6UFzBMBYq1\"},\"rotogrinder\":{\"icon\":\"icon-roto\",\"secret\":\"\",\"user_table_column\":\"rotogrinder\",\"usermeta_key\":\"roto_connect\"},\"google\":{\"icon\":\"icon-google-plus\",\"user_table_column\":\"google_id\",\"usermeta_key\":\"google_connect\",\"id\":\"865676584431.apps.googleusercontent.com\",\"secret\":\"NYBH2z8bKt2fKUpcdDWTV5jf\"},\"linkedin\":{\"icon\":\"icon-linkedin\",\"user_table_column\":\"linkedin_id\",\"usermeta_key\":\"linkedin_connect\",\"id\":\"q1gvatcveysq\",\"secret\":\"vyusYGnpds7H7b34\"}}\n', NULL, 0, 'hidden', '', '', ''),
(43, '1', 'start_welcome', 'Welcome!', NULL, 1, 'text', '', 'Login Welcome', ''),
(44, '1', 'gambling_resricted_states', '[\"AZ\",\"IA\",\"LA\",\"MT\",\"VT\",\"NV\"]', NULL, 0, 'hidden', '', '', ''),
(45, '8', 'join_text', 'Text about the join process', 1, 1, 'textarea', '', 'Website Name', ''),
(55, '1', 'season', '2018', 0, 1, 'text', '', 'Season', ''),
(73, '1', 'empty', '', NULL, 1, 'text', '', 'Empty', '');

-- --------------------------------------------------------

--
-- Table structure for table `ci_options_groups`
--

CREATE TABLE `ci_options_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(245) NOT NULL DEFAULT '',
  `description` varchar(245) NOT NULL DEFAULT '',
  `slug` varchar(245) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_options_groups`
--

INSERT INTO `ci_options_groups` (`id`, `name`, `description`, `slug`) VALUES
(1, 'Site', 'Global', 'general'),
(15, 'NCAA DATES', 'Tournament Dates', 'ncaa_dates'),
(16, 'NCAA Tiebreakers', 'Tiebreaker Input', 'tiebreaker');

-- --------------------------------------------------------

--
-- Table structure for table `ci_payments`
--

CREATE TABLE `ci_payments` (
  `cid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `trans_id` varchar(20) NOT NULL,
  `amount` varchar(16) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0 - Withdrawal, 1 - Payment',
  `status` varchar(32) NOT NULL,
  `approval_code` varchar(32) NOT NULL,
  `product_id` varchar(15) NOT NULL,
  `time` int(15) NOT NULL,
  `method_id` int(11) NOT NULL,
  `raw_return_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_payment_gateways`
--

CREATE TABLE `ci_payment_gateways` (
  `cid` int(11) NOT NULL,
  `nice_name` varchar(128) NOT NULL,
  `system_name` varchar(64) NOT NULL,
  `controller` varchar(128) NOT NULL,
  `checkout_func` varchar(32) NOT NULL DEFAULT 'checkout',
  `renew_func` varchar(32) NOT NULL DEFAULT 'renew',
  `setup_func` varchar(32) NOT NULL DEFAULT 'setup',
  `edit_func` varchar(32) NOT NULL DEFAULT 'edit',
  `unsubscribe_func` varchar(32) NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_payment_gateways`
--

INSERT INTO `ci_payment_gateways` (`cid`, `nice_name`, `system_name`, `controller`, `checkout_func`, `renew_func`, `setup_func`, `edit_func`, `unsubscribe_func`) VALUES
(1, 'Authorize.net', 'authnet', 'authnet', 'checkout', 'renew', 'setup', 'edit', 'unsubscribe'),
(2, 'Paypal Pro', 'paypalpro', 'paypalpro', 'checkout', 'renew', 'setup', 'edit', 'false'),
(3, 'Paypal Standard', 'paypalstandard', 'paypalstandard', 'checkout', 'renew', 'setup', 'edit', 'false'),
(4, 'Debitway', 'debitway', 'debitway', 'checkout', 'renew', 'setup', 'edit', 'false');

-- --------------------------------------------------------

--
-- Table structure for table `ci_payment_method`
--

CREATE TABLE `ci_payment_method` (
  `cid` int(15) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `type_id` varchar(15) NOT NULL,
  `data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_payment_method`
--

INSERT INTO `ci_payment_method` (`cid`, `name`, `description`, `type_id`, `data`) VALUES
(6, 'Paypal Standard', 'Check out securely with Paypal&trade;', '3', '{\"account_email\":\"\",\"currency_codes\":\"USD\"}'),
(8, 'Authorize.net', 'Authorize.net', '1', '{\"api_login\":\"\",\"api_key\":\"\",\"test_mode\":\"0\"}');

-- --------------------------------------------------------

--
-- Table structure for table `ci_payment_profile`
--

CREATE TABLE `ci_payment_profile` (
  `cid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `billing_first_name` varchar(32) NOT NULL,
  `billing_last_name` varchar(32) NOT NULL,
  `billing_address` varchar(128) NOT NULL,
  `billing_address2` varchar(32) NOT NULL,
  `billing_city` varchar(64) NOT NULL,
  `billing_state` varchar(64) NOT NULL,
  `billing_zip` int(10) NOT NULL,
  `billing_country_code` varchar(4) NOT NULL,
  `billing_phone` varchar(16) NOT NULL,
  `shipping_first_name` varchar(32) NOT NULL,
  `shipping_last_name` varchar(32) NOT NULL,
  `shipping_address` varchar(128) NOT NULL,
  `shipping_address2` varchar(32) NOT NULL,
  `shipping_city` varchar(64) NOT NULL,
  `shipping_state` varchar(64) NOT NULL,
  `shipping_zip` int(10) NOT NULL,
  `shipping_country_code` varchar(4) NOT NULL,
  `card_last4` int(4) NOT NULL,
  `card_type` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_player_news`
--

CREATE TABLE `ci_player_news` (
  `id` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `article` longtext NOT NULL,
  `updateid` int(11) NOT NULL,
  `player_id` varchar(234) NOT NULL,
  `headline` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_products`
--

CREATE TABLE `ci_products` (
  `cid` int(15) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `extradata` text NOT NULL,
  `type` varchar(32) NOT NULL,
  `order` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sport_event`
--

CREATE TABLE `ci_sport_event` (
  `cid` varchar(255) NOT NULL,
  `gamestart` int(15) NOT NULL,
  `sport` varchar(4) NOT NULL,
  `season` int(4) NOT NULL,
  `home` varchar(245) DEFAULT NULL,
  `home_team_score` tinyint(4) NOT NULL,
  `home_team_seed` int(11) DEFAULT NULL,
  `away` varchar(245) DEFAULT NULL,
  `away_team_score` tinyint(4) NOT NULL,
  `away_team_seed` int(11) DEFAULT NULL,
  `game_type` varchar(255) NOT NULL COMMENT '1 = Regular Season 2 = Second Round Playoffs 3 = Super Bowl 4 = Exhibition 6 = First Round Playoffs 7 = Conference Championships 9 = Pro Bowl ',
  `final` tinyint(4) NOT NULL DEFAULT '0',
  `segment_num` varchar(4) NOT NULL,
  `minutes` tinyint(4) NOT NULL,
  `seconds` tinyint(4) NOT NULL,
  `home_money_line` float DEFAULT NULL,
  `away_money_line` float DEFAULT NULL,
  `over_under` float DEFAULT NULL,
  `spread` float DEFAULT NULL,
  `status` varchar(245) DEFAULT NULL,
  `tourney` int(11) DEFAULT '0',
  `bracket` varchar(245) DEFAULT NULL,
  `round` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sport_player`
--

CREATE TABLE `ci_sport_player` (
  `cid` varchar(60) NOT NULL,
  `team_id` varchar(245) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `sport` varchar(8) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `abbr_name` varchar(255) NOT NULL,
  `position` varchar(30) NOT NULL,
  `number` tinyint(4) DEFAULT '0',
  `injured` tinyint(1) NOT NULL,
  `injury_code` varchar(245) NOT NULL,
  `injury_text` varchar(245) NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `idprank` int(11) NOT NULL,
  `height` varchar(245) DEFAULT NULL,
  `weight` varchar(245) DEFAULT NULL,
  `college` varchar(245) DEFAULT NULL,
  `draft_round` int(11) DEFAULT NULL,
  `draft_pick` int(11) DEFAULT NULL,
  `draft_year` int(11) DEFAULT NULL,
  `draft_team` varchar(245) DEFAULT NULL,
  `experience` int(11) DEFAULT NULL,
  `dob` varchar(245) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sport_team`
--

CREATE TABLE `ci_sport_team` (
  `cid` varchar(245) NOT NULL,
  `name` varchar(32) NOT NULL,
  `subname` varchar(245) DEFAULT NULL,
  `alias` varchar(32) NOT NULL,
  `sport` varchar(8) NOT NULL,
  `conference` varchar(245) NOT NULL,
  `conf_win` int(11) DEFAULT NULL,
  `conf_loss` int(11) DEFAULT NULL,
  `win` int(11) DEFAULT NULL,
  `loss` int(11) DEFAULT NULL,
  `rank` varchar(245) DEFAULT 'NR',
  `active` int(11) NOT NULL DEFAULT '0',
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_states`
--

CREATE TABLE `ci_states` (
  `id` int(11) NOT NULL,
  `state` varchar(245) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1: both 2: free 3: none',
  `col_a` int(11) NOT NULL,
  `col_b` int(11) NOT NULL,
  `col_c` int(11) NOT NULL,
  `col_d` int(11) NOT NULL,
  `col_e` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_support_message`
--

CREATE TABLE `ci_support_message` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_support_ticket`
--

CREATE TABLE `ci_support_ticket` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `subject` varchar(64) NOT NULL,
  `message` text NOT NULL,
  `assigned_user_id` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `incomplete` int(11) DEFAULT NULL,
  `pending` int(11) DEFAULT NULL,
  `proccessing` int(11) DEFAULT NULL,
  `complete` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_team_projections`
--

CREATE TABLE `ci_team_projections` (
  `id` int(11) NOT NULL,
  `team_id` varchar(122) NOT NULL,
  `week` int(11) NOT NULL,
  `season` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `breakdown` longtext NOT NULL,
  `stats` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_users`
--

CREATE TABLE `ci_users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL DEFAULT '',
  `first_name` varchar(245) DEFAULT NULL,
  `last_name` varchar(245) DEFAULT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `avatar` varchar(255) DEFAULT 'default.jpg',
  `join_date` varchar(255) NOT NULL DEFAULT '',
  `updated_at` datetime DEFAULT NULL,
  `level` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_admin` int(1) NOT NULL DEFAULT '0',
  `phone` varchar(245) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(245) DEFAULT '',
  `country` varchar(245) DEFAULT NULL,
  `usersource` varchar(245) DEFAULT NULL,
  `dob` varchar(245) DEFAULT '',
  `zip` varchar(245) DEFAULT '',
  `refer` varchar(245) DEFAULT '',
  `facebook_id` varchar(245) NOT NULL,
  `twitter_id` varchar(245) NOT NULL,
  `google_id` varchar(245) NOT NULL,
  `admin` int(11) NOT NULL,
  `IP` varchar(245) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_users`
--

INSERT INTO `ci_users` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `avatar`, `join_date`, `updated_at`, `level`, `active`, `is_admin`, `phone`, `address`, `city`, `state`, `country`, `usersource`, `dob`, `zip`, `refer`, `facebook_id`, `twitter_id`, `google_id`, `admin`, `IP`) VALUES
(1, 'dansmith', 'Isaiah', 'Arnold', 'isaiahfrom3r@gmail.com', '$2y$10$4LsSdTSIgLe2e3YK36qAcuRrwaASgRysm5aCaL36bkZXWasl1fMZy', '1.jpg', '1460991482', NULL, 1, 1, 0, '2692440362', '58035 County Line Road Rivers Mi, 49093', 'Three Rivers', 'MI', '0', NULL, '', '49093', NULL, '', '', '', 1, '68.48.182.89'),
(2, 'dreamco', 'DreamCo', 'Admin', 'admin@dreamcodesign.com', '$2y$10$EY1N5WbzZN.C3/9xuUgb5OIzuKTlJHTT848T.BCURMWHaAURS1lnm', 'default.jpg', '1467991482', NULL, 2, 1, 1, NULL, '', '', '', '0', NULL, '', '', NULL, '', '', '', 0, '50.77.184.177'),
(3, 'mccringleberry', 'Isaiah', 'Arnold', 'isaiah@isaiaharnold.com', '$2y$10$6mWN9lEgexCFZrgdeJLX1OVl/Kg0f7/AoOYKLcPSVyLj7bogzsZJG', 'default.jpg', '1467991482', NULL, 0, 1, 0, '2692440362', '', '', 'MI', '0', '1', '788940000', '49093', NULL, '', '', '', 0, '68.48.182.89');

-- --------------------------------------------------------

--
-- Table structure for table `ci_users_profile`
--

CREATE TABLE `ci_users_profile` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `city` text,
  `state` text,
  `zip` text,
  `address1` text,
  `adress2` text,
  `first_name` text,
  `last_name` text,
  `email` text,
  `phone` text,
  `lines` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_user_balances`
--

CREATE TABLE `ci_user_balances` (
  `cid` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `balance` varchar(12) DEFAULT '0',
  `bonus_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `tourney_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `ticket_1` int(4) NOT NULL DEFAULT '0',
  `ticket_2` int(4) NOT NULL DEFAULT '0',
  `ticket_3` int(4) NOT NULL DEFAULT '0',
  `ticket_4` int(4) NOT NULL DEFAULT '0',
  `points` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_user_balance_transactions`
--

CREATE TABLE `ci_user_balance_transactions` (
  `cid` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `source` int(3) DEFAULT '0' COMMENT '0 - n/a, 1 - payment, 2 - promo, 3 - funds withdrawal; 4 - money locked for pending contest; 5 - moneys user won from a contest :D ; 6 - moneys lost in a contest :( ; 7 - reversal of contest entry fee when contest is unfilled; 8 - Admin Adjustment; 9 - Af',
  `promo_id` int(11) NOT NULL DEFAULT '0',
  `debit` int(1) DEFAULT '1' COMMENT '1 - money/points added to user balance; 0 - money/points withdrawn from user balance',
  `amount` varchar(12) DEFAULT '0',
  `bonus_amount` decimal(15,2) NOT NULL,
  `tourney_amount` decimal(15,2) NOT NULL,
  `ticket_amount` decimal(15,2) NOT NULL,
  `ticket_id` int(5) NOT NULL,
  `ticket_type` tinyint(1) NOT NULL,
  `ticket_value` decimal(15,2) NOT NULL,
  `points` varchar(12) DEFAULT '0',
  `payment_id` int(11) DEFAULT NULL,
  `comment` varchar(250) DEFAULT '',
  `custom` varchar(64) DEFAULT '',
  `timestamp` int(11) DEFAULT '0',
  `new_balance` decimal(15,2) NOT NULL,
  `new_bonus_balance` decimal(15,2) NOT NULL,
  `new_tourney_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `refer_profit_id` varchar(245) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_user_profile_fields`
--

CREATE TABLE `ci_user_profile_fields` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(245) DEFAULT NULL,
  `slug` varchar(245) DEFAULT NULL,
  `type` varchar(245) DEFAULT NULL,
  `category` varchar(245) DEFAULT NULL,
  `options` varchar(245) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_user_proifle_categories`
--

CREATE TABLE `ci_user_proifle_categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(245) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ci_withdrawals`
--

CREATE TABLE `ci_withdrawals` (
  `cid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `method` int(1) NOT NULL DEFAULT '0',
  `paypal_email` varchar(128) NOT NULL,
  `check_name` varchar(64) NOT NULL,
  `check_address` varchar(256) NOT NULL,
  `staff_notes` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0 - pending (just submitted); 1 - pending info; 2 - declined; 3 - paid;',
  `req_timestamp` int(11) NOT NULL,
  `paid_timestamp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_options`
--
ALTER TABLE `ci_options`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `ci_options_groups`
--
ALTER TABLE `ci_options_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_users`
--
ALTER TABLE `ci_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ci_users`
--
ALTER TABLE `ci_users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
