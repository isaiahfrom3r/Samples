<?
   if ($this->session->flashdata('success') != '')
   {
   	echo '<div class="alert alert-success"><a class="close" data-dismiss="alert" href="#">&times;</a>'.$this->session->flashdata('success').'</div>';
   }
   if ($this->session->flashdata('error') != '')
   {
   	echo '<div class="alert alert-error"><a class="close" data-dismiss="alert" href="#">&times;</a>'.$this->session->flashdata('error').'</div>';
   }
   ?>



<div class="card">
	<div class="card-header">

		<h4 class="pull-left">Service Desk List</h4>

		   <span class="pull-right">
		      <a href="<?=site_url('admin/desk/form');?>" class="btn purple-plum">Create New</a>
		   </span>


	<div class="clearfix"></div><br>
<small>Edit the name and url of all service desks here. </small>
</div>

<div class="portlet box purple-plum">


   <div class="portlet-body">
      <div class="table-responsive">
         <table class="table table-striped table-bordered table-hover">
            <thead>
               <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Slug</th>
               </tr>
            </thead>
            <tbody>
               <?foreach($pages as $p):?>
               <tr>

                  <td><?=$p->id?></td>
				  <td><?=$p->name?></td>
				  <td><?=$p->slug?></td>
                  <td>
                        <a  class="nomarg btn btn-info" href="<?=site_url('admin/desk/form/'.$p->id);?>">
                        	<i class="zmdi zmdi-edit"></i>
                        </a>


                        <a  class="nomarg btn btn-danger" href="<?=site_url('admin/desk/delete/'.$p->id);?>">
                        	<i class="zmdi zmdi-delete"></i>
                        </a>

                  </td>
               </tr>
               <?endforeach;?>
            </tbody>
         </table>
      </div>
   </div>
</div>

<div class="clearfix"></div><br>
</div>
