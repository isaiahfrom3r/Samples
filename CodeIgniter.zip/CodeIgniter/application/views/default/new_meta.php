<nav class="navbar navbar-inverse navbar-fixed-top hidden-xs" style="    z-index: 99999;
    background: transparent;
    margin-top: 10px;
	border: none;
    margin-left: 5px;
	max-width: 20%;
	position: fixed;
	bottom: 0px;
	cursor: pointer;
		">
	<form action="/admin/meta/pass" method="post" accept-charset="utf-8">
		<?php
		$str = str_split(uri_string());
		$uri = '';
		foreach($str as $s){
			if(is_numeric($s)){
				break;
			}
			$uri .=$s;
		}

		?>

		<label></label><input  type="hidden" name="url" value="<?=$uri?>">
		<button type="submit" class="btn btn-info btn-xs metta_edit">Edit Page META</button>

	</form>
</nav>
