<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Cms_model');
	}



	public function view($id='')
	{

		$data['page'] = $page = $this->Cms_model->get_page($id);

		$meta['metas'] = $this->Cms_model->get_meta($page);
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/page/'.$page['file'],$data);
		$this->load->view(THEME.'/footer');
	}



	public function notfound(){
		$data['page'] = $page = $this->Cms_model->get_page(404);

		$meta['metas'] = $this->Cms_model->get_meta($page);
		$this->load->view(THEME.'/header',$meta);
		$this->load->view(THEME.'/page/page-view',$data);
		$this->load->view(THEME.'/footer');
	}

}
