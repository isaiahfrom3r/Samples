<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

/**

THIS IS TOTALLY NOT DONE

 * LinkedIn OAuth2 Provider
 * https://developer.linkedin.com/documents/authentication
 *
 * @package    CodeIgniter/OAuth2
 * @category   Provider
 * @author     Benjamin Hill benjaminhill@gmail.com
 * @copyright  (c) Same as parent project
 * @license    http://philsturgeon.co.uk/code/dbad-license
 */
class OAuth2_Provider_Twitter extends OAuth2_Provider {

  public $method = 'POST';
  public $scope_seperator = ' ';

  public function __construct(array $options = array()) {
    if (empty($options['scope'])) {
      $options['scope'] = array(
          'r_basicprofile',
          'r_emailaddress'
      );
    }

    // Array it if its string
    $options['scope'] = (array) $options['scope'];


    parent::__construct($options);
  }

  public function url_authorize() {
	ini_set('display_errors', 1); // set to 0 for production version
	error_reporting(E_ALL);



	echo "tesasdft"; die;
    return 'https://api.twitter.com/oauth2/token?oauth_consumer_key=vYO8YQKdtUfTQ28fXricUX2cE?oauth_nonce=9c7adf076d5eb0050a202500c7332490?oauth_signature_method=HMAC-SHA1?oauth_timestamp=1413399651?oauth_token=1710082141-epRzq25z3hWIwmtLuXAW9moLpWBXIxAg9ElliSl?oauth_version=2';
  }

  public function url_access_token() {
    return 'https://api.twitter.com/oauth2/token?oauth_consumer_key=vYO8YQKdtUfTQ28fXricUX2cE?oauth_nonce=9c7adf076d5eb0050a202500c7332490?oauth_signature_method=HMAC-SHA1?oauth_timestamp=1413399651?oauth_token=1710082141-epRzq25z3hWIwmtLuXAW9moLpWBXIxAg9ElliSl?oauth_version=2';
  }

  public function get_user_info(OAuth2_Token_Access $token) {
	  echo "<pre>";
	  print_r($token);
	  echo "</pre>";
echo "test"; die;
    $url_profile = 'https://api.twitter.com/v1/people/~:(id,first-name,last-name,headline,picture-url,site-standard-profile-request)?format=json&' . http_build_query(array(
                'oauth2_access_token' => $token->access_token,
    ));
    $user = json_decode(file_get_contents($url_profile), true);

    $url_email = 'https://api.twitter.com/v1/people/~/email-address?format=json&' . http_build_query(array(
                'oauth2_access_token' => $token->access_token,
    ));
    $user_email = json_decode(file_get_contents($url_email), true);

	echo "Doesn't Work.";exit;

	return array(
		'uid' => $user['id'],
		'nickname' => null,
		'name' => null,
		'first_name' => $user['firstName'],
		'last_name' => $user['lastName'],
		'title' => $user['headline'],
		'gender' => null,
		'birthday' => null,
		'email' => $user_email,
		'location' => null,
		'description' => null,
		'image' => $user['pictureUrl'],
		'urls' => array(
            'Linkedin' => $user->siteStandardProfileRequest->url
        ),
	);
  }

}
