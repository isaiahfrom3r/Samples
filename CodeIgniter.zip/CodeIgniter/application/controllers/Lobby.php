<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lobby extends CI_Controller {
	public function __construct() {
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);
		parent::__construct();
		$this->load->model('Leagues');
		$this->load->model('Misc');
		$this->load->model('Teams');
		$this->users->is_loggedin(1);

	}

	public function index(){




		redirect('/lobby');

	}
	public function get_lobby_rows(){

		$this->Leagues->get_lobby_rows();
	}
	public function check_first($user){
		$user = $this->users->get_by_id($user);

		if($user->lobby == 1){
			echo 1;
		}else{
			echo 0;

			$data = array(
               'lobby' => 1,

            );

			$this->db->where('id', $user->id);
			$this->db->update('users', $data);

		}

	}
	public function lobby(){
		$data['ticker'] =  $ticker  = $this->options->get_grouped_options('lobby_news',1);

		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		    $ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
		    $ip = $_SERVER['REMOTE_ADDR'];
		}
		if($ip == "68.48.182.89"){
			//redirect('/mlobby');
		}
		$user = $this->users->get();
		$data['user'] =  $user;
		$head['scripts'] =  array('/assets/js/lobby.js','/assets/js/owl.carousel.js','/assets/js/ticker.js');
		$foot['scripts'] =  array();
		$data['user'] =  $this->users->get();
		foreach($my as $m){
			$myids[$m->id] = $m->mock_id;
		}
		$data['myids'] =  $myids;

		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/lobby/lobby',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function get_rows($uid){
		$rows = $this->Leagues->get_lobby_rows($uid);

	}
	public function get_lobby_info_main($lid){
		$head['scripts'] = array(base_url().'assets/js/downcount.js');

		$data['league'] = $league = $this->Leagues->get_by_id($lid);
		$this->load->view(THEME.'/draft/header',$head);
		$this->load->view(THEME.'/lobby/lobby_info_main',$data);
	}
	public function show_teams($lid){
		$data['teams'] = $teams = $this->Leagues->get_league_teams($lid);

		$head['scripts'] = array(base_url().'assets/js/downcount.js');

		$data['league'] = $league = $this->Leagues->get_by_id($lid);
		$data['scoring'] = $scoring = $this->Leagues->get_scoring($league->scoring);
		$this->load->view(THEME.'/draft/header',$head);
		$this->load->view(THEME.'/lobby/show_teams',$data);
	}
	public function get_lobby_info($lid){
		$head['scripts'] = array(base_url().'assets/js/downcount.js');

		$data['league'] = $league = $this->Leagues->get_by_id($lid);
		$data['scoring'] = $scoring = $this->Leagues->get_scoring($league->scoring);
		$this->load->view(THEME.'/draft/header',$head);
		$this->load->view(THEME.'/lobby/loby_info',$data);
	}
	public function view_league($lid){
		 $this->users->update($this->users->id(), array('team_id'=> $lid));
		 redirect('league/home');
	}
	public function mlobby(){
		$data['data'] =  array();
		$data['head'] =  array();
		$data['foot'] =  array();
		$data['user'] =  $this->users->get();
		$data['mocks'] =  $this->Mocks->get_lobby_mocks();
		$data['mymock'] =  $my = $this->Mocks->get_my_mocks();
		foreach($my as $m){
			$myids[$m->id] = $m->mock_id;
		}
		$data['myids'] =  $myids;

		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/lobby/mlobby',$data);
		$this->load->view(THEME.'/footer',$foot);
	}


}
