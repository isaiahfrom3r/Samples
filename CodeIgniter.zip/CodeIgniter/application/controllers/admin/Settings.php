<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * menu Controller
 *
 * This class controller is used for manage menu.
 */
class Settings extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->users->is_admin(1);
    }
	// This is a prurchased plugin modifed to work with dreamco's system
	public function index(){
		$data['groups'] =  $this->options->get_groups();
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/settings/list',$data);
		$this->load->view(ADMIN_THEME.'/footer');

	}
	public function edit($group){
		$fields=$data['fields']=$this->options->get_fields_by_group($group);
		$data['group'] =  $group;

		$this->db->where('id',$group);
		$q = $this->db->get("options_groups");
		$q = $q->row();

		$data['groupdata'] =  $q;

		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/settings/edit',$data);
		$this->load->view(ADMIN_THEME.'/footer');

	}
	public function rotowire(){
		$this->db->where('id',1);
		$q = $this->db->get("ci_rotowire_update");
		$time = $q->row();
		$data['time'] =  $time->time;
		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/settings/rotowire',$data);
		$this->load->view(ADMIN_THEME.'/footer');
	}
	public function change($gid){


		$this->load->view(ADMIN_THEME.'/header');
		$this->load->view(ADMIN_THEME.'/settings/change');
		$this->load->view(ADMIN_THEME.'/footer');

	}
	public function newoption(){
		$this->form_validation->set_rules('name', 'slug', 'required');
		$this->form_validation->set_rules('nice_name', 'Nice Name', 'required');
		$this->form_validation->set_rules('editor', 'Editor', 'required');
		$this->form_validation->set_rules('editable', 'Editable', 'required');
		$this->form_validation->set_rules('group', 'Group', 'required');
		$this->form_validation->set_rules('type', 'Type', 'required');
		if ($this->form_validation->run() === false) {

			$this->alert->set('Creation Failed','error');
			redirect('admin/settings/edit/'.$_POST['group']);
		} else {

			$this->options->create_opt($_POST);

			$this->alert->set('Site Variable Created','success');
			redirect('admin/settings/edit/'.$_POST['group']);
		}


	}
	public function save_vars(){
		foreach($_POST['post'] as $key=>$p){

			$this->db->where('cid', $key);
			$this->db->update('options', $p);


		}

		$this->load->library('user_agent');
		$this->alert->set('Data Saved','success');
		redirect($this->agent->referrer());


	}




}
