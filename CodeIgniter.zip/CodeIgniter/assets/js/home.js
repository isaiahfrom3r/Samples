function lineup(cid) {
	console.log(HOST_NAME+"/league/show_team/"+cid);
	$.ajax({
	    type: "GET",
	    url: HOST_NAME+"/league/show_team/"+cid,
	    dataType: "html",
	    success: function (data) {
			$('#lineup').html(data);
			$('#lineup').fadeIn(500);
	    },
	    error: function (req, error) {
	        $('#lineup').html("<p>An error occured retrieving the lineup. Please try again.</p>");
	    }
	});
}

function clearTeam() {
	$('#lineup').fadeOut(300);
}
