<section class="content">
	<div class="container">
		<div class="row">
		<h2 class="title"><?=$content['support_title'];?></h2>
		<div class="row">
			<div class="col-md-6">
				<p><?=$content['support_text']?></p>
				<div class="clearfix"></div><br>
				<div class="text-center"><a href="<?=site_url('/page/view/rules')?>" class="btn btn-default blue">View Rules</a></div>
				<br />
			</div>
			<div class="col-md-6">
				<form action="" method="post" class="form-horizontal">
					<div class="control-group<?$e=form_error('name'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Name</label>
						<div class="controls">
							<input class="form-control" type="text" name="name" value="<?=set_value('name');?>" />
							<?=form_error('name');?>
						</div>
					</div>
					<div class="control-group<?$e=form_error('email'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Email</label>
						<div class="controls">
							<input class="form-control" type="text" name="email" <?=set_value('email');?> />
							<?=form_error('email');?>
						</div>
					</div>
					<div class="control-group<?$e=form_error('phone'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Phone</label>
						<div class="controls">
							<input  class="form-control"type="text" name="phone" <?=set_value('phone');?> />
							<?=form_error('phone');?>
						</div>
					</div>
					<div class="control-group<?$e=form_error('subject'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Subject</label>
						<div class="controls">
							<select class="form-control" name="subject">

								<option value="Non Member &#45; Question About Joining" <?php echo set_select('subject','Non Member &#45; Question About Joining',TRUE); ?>>Non Member &#45; Question About Joining</option>
								<option value="Member &#45; General Support Question" <?php echo set_select('subject','Member &#45; General Support Question',TRUE); ?>>Member &#45; General Support Question</option>
								<option value="Member &#45; Website Abuse Submission" <?php echo set_select('subject','Member &#45; Website Abuse Submission'); ?>>Member &#45; Website Abuse Submission</option>
								<option value="Member &#45; Game Play Support" <?php echo set_select('subject','Member &#45; Game Play Support'); ?>>Member &#45; Game Play Support</option>
								<option value="Other" <?php echo set_select('subject','Other'); ?>>Other</option>
							</select>
							<?=form_error('subject');?>
						</div>
					</div>
					<div class="control-group<?$e=form_error('message'); echo (!empty($e))?' error':'';?>">
						<label class="control-label">Message</label>
						<div class="controls">
							<textarea  class="form-control" name="message"><?=set_value('message');?></textarea>
							<?=form_error('message');?>
						</div>
					</div>
					<div class="clearfix"></div><br>
					<div class="form-actions text-center">
						<input type="submit" class="btn btn-default red" value="Submit" />
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
</section>
