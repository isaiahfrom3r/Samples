<div class="card">
	<div class="card-header">
		<h3>Categories</h3>
		Create new blog/article categories here or click to edit existing ones. Remember - the slug should not contain spaces as this is for the articles URL.
	</div>
	<div class="row-fluid">
		<div class="col-md-12">
			<!--Information block -->
			<div class="portlet box yellow-casablanca">

				<div class="portlet-body">
					<!--Insert information block here-->
					<div class="note note-success">
						<p>
						</p>
					</div>
				</div>
			</div>
			<!--END Information block -->
			<?//="<pre>".print_R($categories,true)."</pre>"?>
			<div class="portlet box green">

				<div class="portlet-body">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover" data-options='{"sortList":[[0,0]],"headers":{"2":{"sorter":false}}}'>
							<thead>
								<tr>
									<th>Label</th>
									<th>Slug</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($categories)){ ?>
								<?function show_cat($cats,$prefix=""){
									foreach($cats as $c):?>
								<tr>
									<td><?=$prefix.$c['label']?></td>
									<td><?=$c['slug']?></td>
									<td>
										<a class="btn btn-info" href="<?=site_url('admin/article/edit_category/'.$c['id'])?>" rel="tooltip" title="Edit"><i class="zmdi zmdi-edit"></i></a>
										<a class="btn btn-danger" href="<?=site_url('admin/article/delete_category/'.$c['id'])?>" rel="tooltip" title="Delete" class="confirm"><i class="zmdi zmdi-delete"></i></a>
									</td>
								</tr>
								<?if(!empty($c['children'])){
									show_cat($c['children'],$prefix."&mdash;");
									}?>
								<?endforeach;
									}
									show_cat($categories)
									?>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<br>
	</div>
</div>
<div class="card">
	<div class="card-header">
		<h3>Create New Category</h3>
	</div>
	<div class="col-md-12">
		<div class="portlet box green">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-file-o"></i>
				</div>
			</div>
			<div class="portlet-body">
				<div class="table-responsive">
					<form method="post" class="form-inline" action="<?=site_url('admin/article/categories')?>">
						<table class="table table-striped table-bordered table-hover" >
							<tbody>
								<tr>
									<td>
										<div class="control-group<?$e=form_error('label');echo (!empty($e)?" error":"")?>">
											<div class="controls">
												<input class="form-control" type="text" name="label" id="label" value="<?=set_value('label');?>" placeholder="Label"/>
												<?=form_error('label')?>
											</div>
										</div>
									</td>
									<td>
										<div class="control-group<?$e=form_error('title');echo (!empty($e)?" error":"")?>">
											<div class="controls">
												<input class="form-control" type="text" name="title" id="title" value="<?=set_value('title');?>" placeholder="Title"/>
												<?=form_error('title')?>
											</div>
										</div>
									</td>
									<td>
										<div class="control-group<?$e=form_error('slug');echo (!empty($e)?" error":"")?>">
											<div class="controls">
												<input class="form-control" type="text" name="slug" id="slug" value="<?=set_value('slug');?>" placeholder="Slug"/>
												<?=form_error('slug')?>
											</div>
										</div>
									</td>
									<td class="hide">
										<div class="control-group<?$e=form_error('parent');echo (!empty($e)?" error":"")?>">
											<div class="controls">
												<select class="form-control" name="parent" id="parent">
													<option value="0" <?=set_select('parent',0);?>>No Parent</option>
													<?if(!empty($all_categories)):?>
													<?foreach($all_categories as $ac):?>
													<option value="<?=$ac->id?>" <?=set_select('parent',$ac->id);?>><?=$ac->label?></option>
													<?endforeach;?>
													<?endif;?>
												</select>
												<?=form_error('parent')?>
											</div>
										</div>
									</td>
									<td>
										<input type="submit" class="btn btn green" value="Create New Category" />
									</td>
								</tr>
							</tbody>
						</table>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
			<br>
</div>
</div>
</div>
