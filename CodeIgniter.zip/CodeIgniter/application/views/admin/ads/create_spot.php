<div class="card">

	<div class="card-header"><h3>New Advertisement Placement</h3>
	<small ><p>
					Simply fill out the form below. It is recommended that you include the image size in the name.
				</p></small>


				<?php echo validation_errors(); ?>

</div>
	<!--Information block -->
	<div class="portlet box green ">

	<!--END Information block -->
	<div class="portlet box green col-md-12">

		<div class="portlet-body form">
		<form class="form-horizontal" method="post" role="form">
		<div class="form-body">
		<div class="form-group">
		<div class="control-group">
		<label class="col-md-3 control-label">Name:</label>
		<div class="col-md-9">
		<input class="form-control" name="name" id="name" type="text" value="<?=set_value('name');?>" />
		<?=form_error('name');?>
		</div>
		</div>
		</div>
		<div class="clearfix"></div>
		<div class="form-group">
		<div class="control-group">
		<label class="col-md-3 control-label">Max banners in the placement:</label>
		<div class="col-md-9">
		<input class="form-control" name="max_banners" id="max_banners" type="text" value="<?=set_value('max_banners', 1);?>" />
		<?=form_error('max_banners');?>
		</div>
		</div>
		</div>
		<div class="clearfix"></div>
		</fieldset>
		</div>
		<div class="clearfix"></div><br>
		<div class="form-actions">
		<input id="button1" type="submit" class="btn btn-success pull-right" value="Save" />
		</div>
		<div class="clearfix"></div><br>
		</form>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
</div>
</div>
</div>
