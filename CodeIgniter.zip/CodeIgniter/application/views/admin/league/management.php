<style>
    #league_management .filter { float:left;}
/*     #league_management .filter > label {font-size: 12w;} */
    #league_management .checkbox input {margin-left:10px !important;}
    #league_management .radio input {  margin-left:-20px !important;}
    #league_management .filters {border-top: 1px solid #bbb; padding-top: 1rem;}
/*     .apply_filter {margin-top:25px;} */
    .radio{
	    margin-top: -20px;
    }
    th{
	    font-size: 14px;
	    font-weight: bold;
    }
    .hover:hover{
	    background: rgba(127, 127, 127, 0.34);
    }
    .hover{
	    padding: 10px;
    }

</style>
<div class="card" id="league_management">
	<div class="card-header">
		<h4 class="pull-left">League Management</h4>

		<form class="pull-right" action="" id="league_search_form" method="get" role="form" style="max-width:250px;">
			<div class="input-group">
				<?php
				if(!isset($_GET['search'])){
					$_GET['search'] = "";
				}
				?>
				<input type="text" class="form-control" name="search" placeholder="Search leagues by name..." value="<?=$_GET['search']?>">
				<span class="input-group-addon">
					<button class="btn btn-primary" type="submit">Go</button>
				</span>
			</div>
		</form>
		<div class="clearfix"></div><br>
		<small>
		Below you can use the following filters to search leagues. <br>
		League Type: Select one of the 3 league options <br>
		Join Status: filter leagues that are full or not full. <br>
		Previous Season: This allows you to select the desired season <br>
		Privacy: This allows you to toggle between public and private leagues. <br>
		In Game Swaps: This filter allows you to show swap leagues or normal leagues.

		</small>
		<div class="clearfix"></div><br>
		<small>

		You may login as a commissioner if you wish to make league changes. For Public leagues you must be logged into admin and then the system will log you in as a user in that league. If you are logged into the admin you will have commish settings.

		</small>



		<div style="clear:both;"></div>

        <?php
        $type1 = $type2 = $type3 = $join1 = $join2 = $prevSelect = $p2 = $p1 = $ig2 = $ig1 = "";

        foreach ($filters as $filter=>$val) {
            if ($filter == "type"){
                foreach($val as $v) {
                    switch ($v) {
                        case 1: $type1 = " checked";  break;
                        case 2: $type2 = " checked";  break;
                        case 3: $type3 = " checked";  break;
                    }
                }
            }
            if ($filter == "join_status") {
                switch ($val) {
                    case 0: $join1 = " checked";    break;
                    case 1: $join2 = " checked";    break;
                }
            }
            if ($filter == "prevSeason") {
                $prevSelect = $val;
            }
            if ($filter == "privacy") {
                switch ($val) {
                    case 0: $p1 = " checked";    break;
                    case 1: $p2 = " checked";    break;
                }
            }
            if ($filter == "in_game_subs") {
                switch ($val) {
                    case 0: $ig1 = " checked";    break;
                    case 1: $ig2 = " checked";    break;
                }
            }
        }
        ?>
        <div class="filters">
            <form method="post" role="form" action="">
                <div class="league-filter col-md-3 filter">
                    <label>League Type</label><br>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="type[]" value='1'<?=$type1 ?>> H2H
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name='type[]' value='2'<?=$type2 ?>> Points
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name='type[]' value='3'<?=$type3 ?>> Points w/H2H Playoffs
                        </label>
                    </div>
                </div>
                <div class="league-filter col-md-3 filter">
                    <label>Join Status</label><br><br>
                    <div class="radio">
                        <label>
                            <input step="margin-top:0px !important;" type="radio" name="join_status" value="0"<?= $join1 ?>> Unlocked (not yet filled)
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" name="join_status" value="1"<?= $join2 ?>> Locked (full)
                        </label>
                    </div>
                </div>

                <div class="league-filter filter col-md-3">
                    <label>Privacy</label><br>
                    <div class="radio">
                        <label>
                            <input step="margin-top:0px !important;" type="radio" name="privacy" value="0"<?= $p1 ?>> Public
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" name="privacy" value="1"<?= $p2 ?>> Private
                        </label>
                    </div>
                </div>

                 <div class="league-filter filter col-md-3">
                    <label>In Game Swaps</label><br>
                    <div class="radio">
                        <label>
                            <input step="margin-top:0px !important;" type="radio" name="in_game_subs" value="0"<?= $ig1 ?>> Off
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" name="in_game_subs" value="1"<?= $ig2 ?>> On
                        </label>
                    </div>
                </div>
				<div class="clearfix"></div>
                <div class="league-filter col-md-3 filter pull-left">
                    <label>Previous Seasons</label><br>
                    <select name="prevSeasons">
                        <option value="9999">--</option>
                <?php   foreach ($seasons as $season) {
                            $selected = $season == $prevSelect ? " selected" : "";  ?>
                        <option value="<?= $season ?>"<?= $selected ?>><?= $season ?> Season</option>
                <?php   }   ?>
                    </select>
                </div>
				<button style="margin: 2px;" class="btn btn-success apply_filter pull-right" type="submit"><i class="zmdi zmdi-filter-list"></i> Filter</button>
				<a style="margin: 2px;" class="btn btn-danger pull-right" href="<?php echo base_url(); ?>admin/leagueM/management">Clear Filters</a>
            </form>
        </div>
    </div>
    <?php
    $currentURL = current_url(); //http://myhost/main

	$params   = $_SERVER['QUERY_STRING']; //my_id=1,3

	$fullURL = $currentURL . '?' . $params;
	$saveurl = $fullURL;
	if(!isset($_GET['sort'])){
		$_GET['sort'] = "";
	}
	if(!isset($_GET['dir'])){
		$_GET['dir'] = "";
	}
	$sort = $_GET['sort'];
	$dir = $_GET['dir'];


	if($dir == 'ASC'){
		$dir = "DESC";
	}else{
		$dir = "ASC";
	}

	$fullURL = str_ireplace("&sort=entry_fee", '', $fullURL);
	$fullURL = str_ireplace("&sort=draft_start", '', $fullURL);
	$fullURL = str_ireplace("&sort=size", '', $fullURL);
	$fullURL = str_ireplace("&dir=ASC", '', $fullURL);
	$fullURL = str_ireplace("&dir=DESC", '', $fullURL);

    ?>

	<div class="card-body">
		<div class="clearfix"></div><br>
		<div class="table-responsive">
            <table id="" class="table table-bordered table-hover ">
				<thead>
					<tr>
						<th>ID</th>
						<th>League Name</th>
						<th><a href="<?=$fullURL?>&dir=<?=$dir?>&sort=size">Size</a></th>
                        <th>Entries</th>
						<th><a href="<?=$fullURL?>&dir=<?=$dir?>&sort=entry_fee">Entry Fee</a></th>
						<th>League Type</th>
                        <th><a href="<?=$fullURL?>&dir=<?=$dir?>&sort=draft_start">Draft Date</a></th>
                        <th><a href="<?=$fullURL?>&dir=<?=$dir?>&sort=draft_start">Draft Time</a></th>
						<th>Actions</th>
						<th></th>
					</tr>
				</thead>
				<tbody>

			<?php   foreach($leagues as $league){
                    $entry_fee = $league->entry_fee == 0 ? "FREE" : $league->entry_fee;
                    $entries = count($this->Leagues->get_actual_league_teams($league->cid));

                    switch ($league->type) {
                        case 1: $leagueType = "H2H"; break;
                        case 2: $leagueType = "Points"; break;
                        case 3: $leagueType = "Pts w/ H2H"; break;
                    }

                    $draftDate = date("n/j/y",$league->draft_start);
                    $draftTime = date("g:ia T", $league->draft_start);
                    $teams = $this->Leagues->get_league_teams($league->cid);
                    ?>
					<tr>
						<td><?= $league->cid ?></td>
						<td><?= $league->name ?></td>
						<td><?= $league->size ?></td>
                        <td><?= $entries ?></td>
						<td><?= $entry_fee ?></td>
						<td><?= $leagueType ?></td>
                        <td><?= $draftDate ?></td>
                        <td><?= $draftTime ?></td>
						<td>
							<a href="<?php echo base_url(); ?>admin/user/login_as_redirect/<?= $league->owner ?>/comish" class="btn btn-success">Login As Commish</a>
						</td>
						<td>
							<!-- Button trigger modal -->
							<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal<?=$league->cid?>">
							  Remove Teams
							</button>

							<!-- Modal -->
							<div class="modal fade" id="myModal<?=$league->cid?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							        <h4 class="modal-title" id="myModalLabel">Remove and Refund Team</h4>
							      </div>
							      <div class="modal-body"><div class="clearfix"></div><br>
							      <?php

							      foreach($teams as $team){
								      if(!isset($team->name) || $team->name == ""){
									      $team->name = "Empty Team #".$team->id;
								      }
							      	?>
							      	<div class="hover" id="thisrow<?=$team->id?>">
							      	<h5 class="pull-left"><?=$team->name?> </h5>
							      	<?php if($team->user_id > 0){ ?>
							      	<div tid="<?=$team->id?>" style="margin: 2px;" class="remove_the_guy pull-right btn btn-danger" >Remove</div>
							      	<?php } ?>
							      	<div class="clearfix"></div>
							      	</div>
							      	<?php
							      }
							      ?>


							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							      </div>
							    </div>
							  </div>
							</div>

						</td>
					</tr>
            <?php   }   ?>
				</tbody>
			</table>
		</div>
		<?= $this->pagination->create_links();?>
	</div>
</div>

<script>
    $(function(){
        $('#league_table').tablesorter({
            headers:{
                0:{sorter: false},
                3:{sorter: false},
                4:{sorter: false},
                7:{sorter: false},
                8:{sorter: false}
            },
            debug: true
        });


		$( ".remove_the_guy" ).click(function() {
		    var id = $(this).attr('tid');
		    var URL = HOST_NAME+"admin/leagueM/remove/"+id;
		    var reload = "<?=$saveurl?>";
			$.ajax({
			    url: URL,
			    success: function (data) {
				    console.log(data);
					$('#thisrow'+id).fadeOut();
			    }
			});
		});

    });
</script>
