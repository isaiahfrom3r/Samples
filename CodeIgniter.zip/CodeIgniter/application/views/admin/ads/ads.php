<div class="card">
	<div class="col-md-12">
		<h3>Advertisements <a href="<?php echo base_url(); ?>admin/Advertisement/create_banner" class="btn btn-info pull-right">Create Advertisement</a></h3>

		<small> Below you can view advertisement results or Edit and Delete Advertisements.  </small>
		<!--END Information block -->
		<div class="portlet box green">
						<div class="portlet-body">
				<div id="pager">
					<?php echo $this->pagination->create_links(); ?>
				</div>
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover" data-options='{"sortList":[[0,0]],"headers":{"5":{"sorter":false}}}'>
						<thead>
							<tr>
								<th>Banner Name</th>
								<th>Status</th>
								<th>Impressions</th>
								<th>Clicks</th>
								<th>CTR</th>
								<th width="60px">Action</th>
								<th width="60px"></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $ad): ?>
							<tr>
								<td><a href="<?=site_url('admin/Advertisement/edit_banner/'.$ad->cid);?>"><?=$ad->name;?></a></td>
								<td align="center" width="40"><i class="zmdi <?=$ad->status == '0'?'zmdi-pause':'zmdi-play';?>"></i></td>
								<td align="center" width="90"><?=$ad->impressions;?></td>
								<td align="center" width="60"><?=$ad->clicks;?></td>
								<td align="center" width="50"><?=number_format(($ad->impressions > 0?($ad->clicks / $ad->impressions * 100):0), 2);?>%</td>
								<td>
									<a href="<?=site_url('admin/Advertisement/edit_banner/'.$ad->cid);?>" class="btn btn-info " title="Edit page"><i class="zmdi zmdi-edit"></i></a>

								</td>
								<td>
									<a href="javascript: if (confirm('Are you sure you want to delete this ad?')) { window.location='<?=site_url('admin/Advertisement/delete_banner/'.$ad->cid);?>' };" class="btn btn-danger " title="Delete page"><i class="zmdi zmdi-delete" ></i></a>
								</td>

							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<div id="pager">
						<?php echo $this->pagination->create_links(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
</div>
</div>
