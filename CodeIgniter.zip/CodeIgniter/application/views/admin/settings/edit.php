<style type="text/css" media="screen">
	.fg-line:not(.form-group){
		width: 100%;
	}
</style>
<div class="card">
	<div class="card-header">
		<h4><?=$groupdata->description?> Settings</h4>

		<?php if($group == 9){ ?>
			<small>Create a new field for every ticker item you want in the lobby. Simply copy the slug format with a new trailing number at the end. The name is for reference only. </small>
		<?php }elseif($group == 2){ ?>
			<small>Each field below correlates to a tab in the rules page. You may change any content below but do not change the slugs or the content will disappear on the front end. </small>
		<?php }else{ ?>

			<small>You may edit fields below. Creating new fields will not impact the public website until the developer utilizes the newly created variable. If you want to change a variable but are unsure please contact your development team.</small>
		<?php } ?>
	<div class="clearfix"></div><br>
	<a class="btn btn-info" href="<?=base_url()?>admin/settings">Back</a>
	<!-- Button trigger modal -->
	<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">
	Create New Field
	</button>

	</div>
</div>




<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Create Options Section</h4>
			</div>
			<div class="modal-body">
				<form method="post" action="/admin/settings/newoption">
					<div class="col-md-12">
						<div class="form-group">
							<label for="username">Slug (no spaces)</label>
							<div class="fg-line"><input type="text" class="form-control" name="name" value=""></div>
						</div>
						<div class="form-group">
							<label for="username">Nice Name</label>
							<div class="fg-line"><input type="text" class="form-control" name="nice_name" value=""></div>
						</div>
						<div class="form-group">
							<label class="col-md-12 p-0" for="username">Editor</label>
							<div class=" col-md-6 p-0">
                                <label>
                                    <input type="radio" name="editor" value="0">
                                    <i class="input-helper"></i>
                                    No
                                </label>
                            </div>
                            <div class="col-md-6 p-0">
                                <label>
                                    <input type="radio" name="editor" value="1">
                                    <i class="input-helper"></i>
                                    Yes
                                </label>
                            </div>

						</div>
						<input type="hidden" class="form-control" name="editable" value="1">
						<input type="hidden" class="form-control" name="group" value="<?=$group?>">

						<div class="clearfix"></div>
						<div class="m-t-15" style="border-top: 1px;">

                            <div class="form-group">
	                            <label class="col-md-12 p-0" for="type">Field Type</label>
                                <div class="fg-line">
                                    <div class="select">
                                        <select name="type" class="form-control">
                                            <option>text</option>
                                            <option>textarea</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>




					</div>
			</div>
			<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Discard</button>
			<button type="submit" class="btn btn-primary">Save</button>
			</div>
			</form>
		</div>
	</div>
</div>
<div class="clearfix"></div>
<br>
<form method="post" action="/admin/settings/save_vars">
	<div class="clearfix"></div>
	<?foreach($fields as $f):?>
	<div class="card">
		<div class="clearfix"></div>
		<br>
		<div class="col-md-12">
			<div class="form-group">
				<label for="username">Name</label>
				<input type="text" class="form-control"  name="post[<?=$f->cid?>][nice_name]"  value="<?=$f->nice_name?>">
			</div>
			<div class="form-group">
				<label for="username">Slug</label>
				<input type="text" class="form-control"  name="post[<?=$f->cid?>][name]"  value="<?=$f->name?>">
			</div>
			<div class="form-group">
				<div class="control-group<? $e=form_error($f->name);echo (!empty($e))?' error':'';?>">
					<?if($f->type=="text"):?>
					<input class="form-control" type="text" name="post[<?=$f->cid?>][value]" value="<?=set_value($f->name,$this->options->get($f->name))?>"/>
					<?elseif($f->type=="select"):?>
					<select class="form-control" name="post[<?=$f->cid?>][value]">
						<?foreach(json_decode($f->default_values) as $d):?>
						<option value="<?=$d->value?>" <?=set_select($f->name,$d->value,(($this->options->get($f->name)==$d->value)?TRUE:FALSE));?>><?=$d->label?></option>
						<?endforeach;?>
					</select>
					<?elseif($f->type=="textarea"):?>
					<textarea  class="form-control <?php if($f->editor == 1){ echo 'tinymcesmall'; } ?>" rows="5" name="post[<?=$f->cid?>][value]"><?=set_value($f->name,$this->options->get($f->name))?></textarea>
					<?endif;?>
					<?=form_error($f->name)?>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<br>
	</div>
	<?endforeach;?>

	<button type="submit" class="btn btn-success">Save Variables</button>

</form>
