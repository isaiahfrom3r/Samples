<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User class.
 *
 * @extends CI_Controller
 */
class User extends CI_Controller {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {

		parent::__construct();

        $this->load->model('Mailchimp');
	}


	public function index() {



	}
	public function set_team($tid,$uid){

		$data = array('team_id' => $tid);
		$this->db->where('id',$uid);
		$this->db->update('users', $data);
	}
	function getAge($year, $month, $day){
	    $date = "$year-$month-$day";
	    echo "<pre>";
	    print_r($date);
	    echo "</pre>";
	    if(version_compare(PHP_VERSION, '5.3.0') >= 0){
	        $dob = new DateTime($date);
	        $now = new DateTime();
	        return $now->diff($dob)->y;
	    }
	    $difference = time() - strtotime($date);
	    return floor($difference / 31556926);
	}

    /**
	 * register function.
	 *
	 * @access public
	 * @return void
	 */
	public function register() {

		$content = $this->options->get_grouped_options('register',1);

		if( !empty($content) && isset($content) ){
			$data['content'] = $content;
		}

		// preventing errors
		$passon = array(
			'username' => '',
		    'email' => '',
		    'password' => '',
		    'password_confirm' => '',
		    'first_name' => '',
		    'last_name' => '',
		    'phone' => '',
		    'address' => '',
		    'city' => '',
		    'state' => '',
		    'dob' => Array
		       (
		           'month' => 1,
		           'date' => 1,
		           'year' => 1999,
		       ),

		    'zip' => '',
		    'usersource' => 1,
		    'lang' => 'english',
		    'facebook_id' => '',
		    'twitter_id' => '',
		    'comp_id' => '',
		);

		if(isset($this->session->social)){


			if($this->session->social['provider'] == 'facebook'){
				$passon['email'] = $this->session->social['email'];
				$passon['facebook_id'] = $this->session->social['uid'];
			}
			if($this->session->social['provider'] == 'twitter'){

				$passon['twitter_id'] = $this->session->social['uid'];
				$passon['username'] = $this->session->social['screen_name'];

				$names = explode(' ', $this->session->social['name']);

				$passon['first_name'] = $names[0];
				$passon['last_name']  = $names[1];

			}else{
				$passon['first_name'] = $this->session->social['first_name'];
				$passon['last_name']  = $this->session->social['last_name'];
			}

		}

		if(isset($this->session->comp)){
			$passon['comp_id'] = $this->session->comp;
		}



		// load form helper and validation library
		$this->load->model('Misc');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['states']=$this->Misc->states_list();
		$data['countries']=$this->Misc->countries();
		// set validation rules
		$this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_numeric|min_length[4]|is_unique[users.username]', array('is_unique' => 'This username already exists. Please choose another one.'));
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]', array('is_unique' => 'The email you entered is already registered. If you need to reset your password, please select the reset password link.'));
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');
		$this->form_validation->set_rules('email_confirm', 'Confirm Email', 'trim|required|min_length[6]|matches[email]');
// 		$this->form_validation->set_rules('phone', 'Phone', 'required');
// 		$this->form_validation->set_rules('address', 'Address', 'required');
/*
		$this->form_validation->set_rules('city', 'City', 'required');
		$this->form_validation->set_rules('state', 'State', '');
*/
		$this->form_validation->set_rules('country', 'Country', 'required');
// 		$this->form_validation->set_rules('zip', 'Zip', 'required');
		$this->form_validation->set_rules('checkbox_terms', 'Agree To Terms', 'required');



		if ($this->form_validation->run() === false) {
			if(isset($_POST['username'])){
				$passon = $_POST;
			}
			// validation not ok, send validation errors to the view
		} else {
			//$age = $this->getAge($_POST['dob']['year'],$_POST['dob']['month'],$_POST['dob']['date']);

/*
			//$_POST['dob'] =  strtotime($_POST['dob']['month'].'/'.$_POST['dob']['date'].'/'.$_POST['dob']['year']);
			if($age < 13){
				$this->alert->set('The account age must be greater then 13.','error');
				redirect('/login');
			}
*/
			$comp = $_POST['comp_id'];
            $newsletter = $_POST['checkbox_newsletter'];
			unset($_POST['checkbox_terms']);
			unset($_POST['checkbox_newsletter']);
			unset($_POST['lang']);
			unset($_POST['comp_id']);
			unset($_POST['password_confirm']);
			unset($_POST['email_confirm']);
			$_POST['join_date'] = time();

			$_POST['password'] = $this->users->hash_password($_POST['password']);

			$this->session->refer = '';

			$_POST['active'] = 1;
			$_POST['pass_time'] = time();

			if ($this->users->create_user($_POST)) {
                if ($newsletter){
                    $this->load->library('MailChimp',array('api_key'=>'1e04ac93b2759c5ab44b8b8a78b297fe-us15'));
                    $list_id = '0686ed2334';
/*
                    $result = $this->mailchimp->post("lists/$list_id/members", [
                            'email_address' => $_POST['email'],
                            'status'        => 'subscribed',
                    ]);
*/

                    $post = [
                            'email_address' => $_POST['email'],
                            'status'        => 'subscribed',
                    ];

                    $result = $this->Mailchimp->process($post,"lists/$list_id/members");

                }

				$this->load->model('Leagues');

// 				$this->Leagues->add_to_invite($comp,$this->db->insert_id());

				$this->alert->set('Your account has been created.','success');

                $email_data = array();
                $subject = "Welcome to ".$this->options->get('site_name');
                $this->emails->send_mail($this->input->post('email'), 'register', $email_data,$subject);

				redirect('/user/picture_upload_edit?new=1');
			} else {

				// user creation failed, this should never happen
				$this->alert->set('There was a problem creating your new account. Please try again.','error');

			}

		}

		$data['post'] =  $passon;
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/register',$data);
		$this->load->view(THEME.'/footer');

	}

	public function more_info(){
		if(isset($_GET['complete'])  && $_GET['complete'] == 1){
			$this->alert->set('Please Complete the Registration Process','info');
			redirect('/user/more_info');
		}
		// needs validation etc or group it in with normal reg, this is "step 3"


		$this->form_validation->set_rules('source', 'Source', 'required');
		$this->form_validation->set_rules('relation', 'Relation', 'required');
		$this->form_validation->set_rules('reason', 'Reason', 'required');
		$this->form_validation->set_rules('subscriber', 'Subscriber', 'required');
		$this->form_validation->set_rules('interest', 'Interest', 'required');


		if ($this->form_validation->run() === false) {

		} else {


			$user = $this->users->get_user($this->users->id());


			$update = $_POST;

			$update['social'] = json_encode($update['social']);
			$update['communication'] = json_encode($update['communication']);

			$this->db->where('id', $user->id);
			$this->db->update('users', $update);

			redirect('lobby');
		}


		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/more_info',$data);
		$this->load->view(THEME.'/footer');
	}

	/**
	 * my_account function.
	 *
	 * @access public
	 * @return void
	 */
	public function edit() {
		$this->load->model('Misc');
		$this->users->is_loggedin(1);
		$data['user'] =  $user = $this->users->get_user($this->users->id());

		$passon = array(
		    'email' => $user->email,
		    'first_name' => $user->first_name,
		    'last_name' => $user->last_name,
		    'phone' => $user->phone,
		    'state' => $user->state,
		    'zip' => $user->zip,
		    'city' => $user->city,
		);
		$data['states']=$this->Misc->states_list();
		$data['countries']=$this->Misc->countries();

		// create the data object

		// load form helper and validation library
		$this->load->helper('form');
		$this->load->library('form_validation');

		// set validation rules
		if(isset($_POST['email']) && $user->email != $_POST['email']){
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]');
		}else{
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		}

		$passupdate = 0;
		if(isset($_POST['password']) && strlen($_POST['password']) > 2){
			$passupdate = 1;
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
			$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');
		}


// 		$this->form_validation->set_rules('phone', 'Phone', 'required');
		$this->form_validation->set_rules('first_name', 'First Name', 'required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required');

        // Mailchimp Integration Data
        //$listID = $this->Mailchimp->default_list;
        //$mc_info=$this->Mailchimp->lists_member_info($listID,$user->email);

        if (isset($mc_info->data[0])){
            $data['newsletter_status'] = $mc_status = $mc_info->data[0]->status;
        } else {
            $data['newsletter_status'] = "unsubscribed";
        }

		if ($this->form_validation->run() == false) {


		} else {
            if(!isset($_POST['checkbox_newsletter']) && $_POST['email'] != ''){
                //$this->Mailchimp->lists_unsubscribe($listID,$_POST['email']);
            }elseif(isset($_POST['checkbox_newsletter']) && $_POST['email'] != ''){
                //$this->Mailchimp->lists_subscribe($listID,$_POST['email']);
            }

            unset($_POST['checkbox_newsletter']);


			if($passupdate == 1){
				$this->users->update_password( $user->id, $_POST['password'] );
			}
			unset($_POST['password']);
			unset($_POST['password_confirm']);
			$this->users->update($user->id, $_POST);

			$this->alert->set('Account Edited Successfully','success');
			redirect('/user/edit');

		}


		$data['post'] =  $passon;
		// send error to the view
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/edit', $data);
		$this->load->view(THEME.'/footer');

	}



	function forgot()
	{
		$this->form_validation->set_rules('email', 'Email', 'required');

		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{
			$hashToStoreInDb = password_hash($_POST['email'], PASSWORD_BCRYPT);

			$user = $this->users->get_user_by_mail($_POST['email']);


			if(!empty((array) $user)){

				$email_data = array(
					'url'  => base_url().'user/change_password?key='.$hashToStoreInDb,
					'name' => $user->first_name." ".$user->last_name,
				);

				$subject = $this->options->get('site_name').' - Your Reset Password Link';

				$this->emails->send_mail($user->email,'password_change',$email_data,$subject);

				$this->alert->set('Please check your email for reset instructions.' , 'success');
				redirect('/user/login');

			}else{
				$this->alert->set('Email Not Found' , 'error');
				redirect('/user/forgot');

			}


		}

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/forgot_password');
		$this->load->view(THEME.'/footer');

	}
	function change_password(){
		if(!isset($_GET['key'])){
			$this->alert->set('No Key Found' , 'error');
			redirect('/user/forgot');
		}


		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		$this->form_validation->set_rules('password_confirm', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');


		if ($this->form_validation->run() == FALSE)
		{

		}
		else
		{


			$string = $_GET['key'];
			$match = password_verify($_POST['email'], $string);
			if($match == 1){
				$user = $this->users->get_user_by_mail($_POST['email']);

				if(!empty((array) $user)){
					$this->users->update_password( $user->id , $_POST['password'] );

					$this->alert->set('Your password has been reset' , 'success');
					redirect('/login');

				}else{

					$this->alert->set('Unknown Error Occurred' , 'error');
					redirect('/user/forgot');

				}

			}else{
				$this->alert->set('Please try again. Something did not match' , 'error');
				redirect('/user/forgot');
			}



		}


		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/change_password');
		$this->load->view(THEME.'/footer');

	}


	/**
	 * my_account function.
	 *
	 * @access public
	 * @return void
	 */
	public function my_account() {
		$this->users->is_loggedin(1);
		$data['content'] =  $content = $this->options->get_grouped_options('account',1);
		$data['user_balance'] =  $this->user_funds->user_balance($this->users->id());
		$data['pending_withdrawal'] =  0;
		$data['user'] =  $user = $this->users->get_user($this->users->id());
		$data['referrals'] =  $this->users->get_my_referals();



		// send error to the view
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/account', $data);
		$this->load->view(THEME.'/footer');

	}
	function picture_upload_edit()
	{
		$this->users->is_loggedin(1);
		$data['user'] = $this->users->get_user($this->users->id());

		$head['scripts'] = array(
				'/assets/js/plupload.full.min.js',
				'/assets/js/jquery.Jcrop.js',
				'/assets/js/picture_upload_1.js',
		);
		$head['styles'] = array('/assets/css/jquery.Jcrop.css');
		$foot['styles'] = $foot['scripts'] = array();

		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/user/picture_upload_edit', $data);
		$this->load->view(THEME.'/footer',$foot);
	}
	function add_avatar(){
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: no-store, no-cache, must-revalidate");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");

		if (!is_dir('./uploads/')){mkdir('./uploads/');}
		if (!is_dir('./uploads/temp/')){mkdir('./uploads/temp/');}

		$gallery_type=0;
		// Get parameters
		$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
		$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 0;
		$fileName = isset($_REQUEST["name"]) ? $_REQUEST["name"] : '';
		$fileName = preg_replace('/[^\w\._]+/', '_', $fileName);

		$this->load->model('images');
		$img_name='file';
		//Upload Config settings
		$config['upload_path'] = './uploads/temp';
		$config['allowed_types'] = 'png|jpg';
		//Load imgs upload library
		$this->load->library('upload');
		//Upload file and return data
		$this->upload->initialize($config);
		if ($this->upload->do_upload($img_name)) {
			$img_data=$this->upload->data();
			$new_imgname=md5(rand(0, 1000000).$fileName).$img_data['file_ext'];
			$new_imgpath=$img_data['file_path'].$new_imgname;
			rename($img_data['full_path'], $new_imgpath);

			$final_width=$this->options->get('avatar_big_width');
			$final_height=$this->options->get('avatar_big_height');
			$aspectratio=$final_width/$final_height;
			$return=array(
				"status"=>1,
				"url"=>'/uploads/temp/'.$new_imgname,
				"filename"=>$new_imgname,
				"width"=>$img_data['image_width'],
				"height"=>$img_data['image_height'],
				"final_width"=>$final_width,
				"final_height"=>$final_height,
				"aspectratio"=>$aspectratio
			);
		} else {
			$return=array(
				"status"=>0,
				"error"=>$this->upload->display_errors()
			);
		}

		echo json_encode($return);
	}
	/*----------------------------------------------------------------------
		CROP AVATAR
			This function deals with the avatar after the user has cropped it

	-----------------------------------------------------------------------*/
	function crop_avatar(){
		if($this->input->post('submit')!= 'Submit'){
			$avatar=$this->session->userdata('avatar');
			if(!empty($avatar)){
				//delete files
				@unlink('./uploads/avatar_big/'.$avatar);
				@unlink('./uploads/avatar_medium/'.$avatar);
				@unlink('./uploads/avatar_small/'.$avatar);
				//update db
				$update=array("avatar"=>"");
				$this->db->where("id",$this->users->id());
				$this->db->update("users",$update,$where);
				//update session
				$this->session->set_userdata('avatar','');
				//redirect!
				$this->alert->set('Image Deleted','success');
				redirect('user/picture_upload_edit');
			}else{
				$this->alert->set('Nothing To Delete!','error');
				redirect('user/picture_upload_edit');
			}
		}else{
			if (!is_dir('./uploads/')){mkdir('./uploads/');}
			if (!is_dir('./uploads/avatar_big/')){mkdir('./uploads/avatar_big/');}
			if (!is_dir('./uploads/avatar_medium/')){mkdir('./uploads/avatar_medium/');}
			if (!is_dir('./uploads/avatar_small/')){mkdir('./uploads/avatar_small/');}

			$edit=$this->input->post('edit');
			if(isset($edit) && $edit==1){
				$edit=true;
				$redirect="user/picture_upload_edit";
			}else{
				$edit=false;
				$redirect="user/picture_upload";
			}
			$temp_image = $this->input->post('temp_image');
			$x = $this->input->post('x');
			$y = $this->input->post('y');
			$w = $this->input->post('w');
			$h = $this->input->post('h');
			if (is_numeric($x) && is_numeric($y) && is_numeric($w) && is_numeric($h))
			{
				$this->load->library('image_lib');
				$reg_data = $this->session->userdata('reg_data');
				$config['image_library'] = 'gd2';
				$config['source_image'] = './uploads/temp/'.$temp_image;;
				$config['x_axis'] = $x;
				$config['y_axis'] = $y;
				$config['width'] = $w;
				$config['height'] = $h;
				$config['maintain_ratio'] = FALSE;
				$this->image_lib->initialize($config);

				if ( ! $this->image_lib->crop())
				{
					$this->alert->set($this->image_lib->display_errors(),'error');
					redirect($redirect);
				}
				else
				{
					//cropped image ok, now resize it to meet big_avatar size
					$this->image_lib->clear();
					$config['image_library'] = 'gd2';
					$config['source_image'] = './uploads/temp/'.$temp_image;
					$config['create_thumb'] = FALSE;
					$config['maintain_ratio'] = TRUE;
					$config['master_dim'] = 'width';
					$config['width'] = $this->options->get('avatar_big_width');
					$config['height'] = $this->options->get('avatar_big_height');
					$this->image_lib->initialize($config);
					if ( ! $this->image_lib->resize())
					{
						$this->alert->set($this->image_lib->display_errors(),'error');
						redirect($redirect);
					}
					else
					{
						if($edit){

							$reg_data['Picture Upload']['big_avatar'] = $temp_image;
							$this->users->save_picture($this->users->id(), $reg_data['Picture Upload']);
							$this->alert->set('Avatar Saved','success');

							if($_POST['new'] == 1){
								redirect('/user/more_info');
							}else{
								redirect($redirect);
							}
						}else{
							$reg_step_data = $this->registrations->get_step_by_name('Picture Upload');
							$reg_data['Picture Upload']['big_avatar'] = $temp_image;
							$this->session->unset_userdata('reg_data');
							$this->session->set_userdata('reg_data', $reg_data);

							//redirect to the next step
							$next_step = $this->registrations->get_next_step($reg_step_data->order);

							redirect($next_step->url_handler);
						}
					}
				}
			}
			else
			{
				$this->alert->set('Error processing image.!','error');

				redirect('user/picture_upload_edit');

			}
		}
	}


	/**
	 * login function.
	 *
	 * @access public
	 * @return void
	 */
	public function login() {
//		ini_set('display_errors', 0); // set to 0 for production version
//		error_reporting(-1);

		//$this->session->set_userdata('admin',array('awesome','cool'));
		$this->load->helper('cookie');
		// create the data object
// 		$data = new stdClass();

		// load form helper and validation library
		$this->load->helper('form');
		$this->load->library('form_validation');

		// set validation rules
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');


		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);

		if ($this->form_validation->run() == false) {


		} else {

			// set variables from the form
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			if ($this->users->resolve_user_login($username, $password)) {

				$user_id = $this->users->get_user_id_from_username($username);
				$user    = $this->users->get_user($user_id);

				if(isset($_POST['remember']) && $_POST['remember'] == 1){
	                $cookie = array(
		                'name'   => 'remember_me_motion',
		                'value'  => $user->username,
		                'expire' => time()+86500,
	                );
	                set_cookie($cookie);
   				}

				// set session user datas

				$sesdata = array(
					'id'			=> (int)$user->id,
					'username'		=> (string)$user->username,
					'email'			=> $user->email,
					'first_name'	=> $user->first_name,
					'last_name'		=> $user->last_name,
					'level'			=> $user->level,
					'admin'			=> $user->level,
				);

				if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
				    $ip = $_SERVER['HTTP_CLIENT_IP'];
				} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
				} else {
				    $ip = $_SERVER['REMOTE_ADDR'];
				}

				$this->Users->update($user->id,array('IP' => $ip));

				if($user->active == 0){
					$this->alert->set('Your account has been suspended. If you find this to be a mistake please contact support. ','error');
					redirect('/contact');
				}

				if($user->level > 1){
					$this->session->set_userdata('admin',$sesdata);
					redirect('/admin');
				}else{
					$this->session->set_userdata('user',$sesdata);
				}




				if($_SESSION['camefrom']){
					$camefrom = $_SESSION['camefrom'];
					unset($_SESSION['camefrom']);
					$this->alert->set($this->options->get('start_welcome'),'success');
					redirect($camefrom);
				}


				$this->alert->set($this->options->get('start_welcome'),'success');
				redirect('/dashboard');
			} else {
				// login failed
				$this->alert->set('Wrong username or password.','error');
			}

		}
		$data['cook'] =  $cook = get_cookie('remember_me_motion');
		// send error to the view
		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/user/login', $data);
		$this->load->view(THEME.'/footer');

	}
	function invite()
	{
		$this->users->is_loggedin(1);
		$this->load->helper('email');
		$data['user'] = $this->users->get_user($this->users->id());
		$use_real_name = $this->input->post('use_real_name');
		$friend_emails = $this->input->post('invite_email');
		$message = $this->input->post('invite_message');

		if(is_array($friend_emails)) {

			foreach($friend_emails as $friend_email)
			{

				//make sure email is good
				if(valid_email($friend_email)) {
					//email confirmation code
					if($use_real_name == 'yes') {
					$email_data['name'] = $data['user']->first_name.' '.$data['user']->last_name;
					} else {
					$email_data['name'] = $data['user']->username;
					}
					$email_data['email'] = $data['user']->email;
					$email_data['user'] = $data['user']->username;
					$email_data['link'] = base_url().'?user='.$data['user']->username;
					if(!empty($message)) { $email_data['message'] = $message.'<hr />'; } else { $email_data['message'] = ''; }
					$subject='You are invited to Next Gen FFE';


					$this->emails->send_mail(trim($friend_email),'invite_friends',$email_data,$subject);
				}
			}
			$this->alert->set('Invites Sent','success');
			redirect('account');
		}

		$this->load->view($data['theme'].'/invite_a_friend', $data);
	}
		/**
	 * logout function.
	 *
	 * @access public
	 * @return void
	 */
	public function logout() {

		// create the data object
		$data = new stdClass();

		if ($this->session->userdata('user') > 0 ) {

			// remove session datas
			$this->session->sess_destroy();
			$this->alert->set('Logout Successful','success');
			// user logout ok
			redirect('/user/login');

		} else {
			$this->session->sess_destroy();
			// there user was not logged in, we cannot logged him out,
			// redirect him to site root
			redirect('/');

		}

	}




}
