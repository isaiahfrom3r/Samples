<!DOCTYPE html>
<?php ini_set('display_errors', 0); // set to 0 for production version
error_reporting(-1); ?>

<html lang="en">
	<script>
		var HOST_NAME = '<?=base_url()?>';
	</script>
	<?php $user = $this->users->get_user($this->users->id()); ?>



	<head>
		<meta charset="utf-8">

		<?php if($this->uri->segment(2) == 'bracket'){?>
			<meta name="viewport" content="width=device-width, initial-scale=.5, maximum-scale=12.0, minimum-scale=.25, user-scalable=yes"/>
		<?php }else{?>
			<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php }?>


		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<link rel="icon" type="image/png" href="/favicon.png">

		<?php
		// check if meta was passed

		if(!empty($metas)){
			$this->load->view(THEME.'/assets/meta.php',array('metas' => $metas));
		}else{
			$this->load->view(THEME.'/assets/meta.php');
		}?>

		<?php $this->load->view(THEME.'/assets/scripts.php'); ?>
		<?php $this->load->view(THEME.'/assets/styles.php');  ?>
		<?php $this->load->view(THEME.'/assets/alerts.php');  ?>

	</head>
	<?php if($_SESSION['admin']['id'] > 0 ){
		$this->load->view(THEME.'/new_meta.php');
	}?>
	<body>

		<div id="fb-root"></div>
		<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=1944261639131382&autoLogAppEvents=1';
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>



	<?php
	if(!isset($profile)){
		$profile = array();
	}

	if($this->users->is_loggedin()){


		$teams = $this->Leagues->get_my_leagues(); // Got to set this here so every page can access this info when logged in
		//$this->load->view(THEME.'/nav_logged.php',array('user' => $user,'teams'=>$teams));
		//$this->load->view(THEME.'/secondary_nav_logged.php',array('user' => $user,'teams'=>$teams));
		$this->load->view(THEME.'/nav.php',$profile);

	}else{
		$this->load->view(THEME.'/nav.php',$profile);
		$this->load->view(THEME.'/login.php');
	}?>

	<?php
	if(isset($scripts) && !empty($scripts)){

		$this->load->view(THEME.'/assets/eqscripts.php',array('items'=>$scripts));
		unset($scripts);
	}?>

	<?php
	if(isset($styles) && !empty($styles)){
		$this->load->view(THEME.'/assets/eqstyles.php',array('items'=>$styles));
		unset($styles);
	}?>

	<div id="magic_cover" class="modal-backdrop fade in" style="cursor: pointer; display: none;"></div>


	<script>
window.setTimeout(checkState, 10000);
function checkState(){
	console.log("yo");
}
</script>
