<div class="modal" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModal" aria-hidden="true">

	<form action="<?php echo base_url(); ?>/login" method="post" accept-charset="utf-8">

		<div class="modal-dialog" role="document">

			<div class="modal-content">

				<div class="modal-header">

					<h5 class="modal-title">Login</h5>

					<button type="button" class="close" data-dismiss="modal" aria-label="Close">

						<span aria-hidden="true">&times;</span>

					</button>

				</div>

				<div class="modal-body">

					<div class="form-group">

						<label for="username">Username</label>

						<input type="text" class="form-control" id="username" name="username" placeholder="Your username">

					</div>

					<div class="form-group">

						<label for="password">Password</label>

						<input type="password" class="form-control" id="password" name="password" placeholder="Your password">

					</div>

					<hr>

					<div class="social-login text-center">

						<h3>Social Login</h3>

						<a href="/auth/connect/facebook" class="btn  facebook_color">Facebook</a>

						<a href="/twitter" class="btn twitter_color">Twitter</a>

					</div>

				</div>

				<div class="modal-footer text-center">

					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

					<input type="submit" class="btn btn-success" value="Login">

				</div>

			</div>

		</div>

	</form>

</div>
