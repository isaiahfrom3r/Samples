jQuery(document).ready(function($){
	$(document.body).on("click",'#select_all',function(){
		if(this.checked){
			$('.select_many').attr('checked','checked');
		}else{
			$('.select_many').removeAttr('checked')
		}
	});

	$(document.body).on("change","#label",function(e){
		var slug=$(this).val().toLowerCase();
		slug=slug.replace(/ /g, "_");
		slug=slug.replace("'", "");
		slug=slug.replace("\"", "");
		slug=slug.replace(";", "");
		slug=slug.replace(":", "");
		$('#slug').val(slug);
		$('#title').val($(this).val());
	});
});
