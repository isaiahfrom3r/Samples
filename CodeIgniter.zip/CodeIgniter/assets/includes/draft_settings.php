<h4>Update Draft Settings</h4>

<hr>

<form method="post" action="">
	<div class="form-group third">
		<label>Draft Type</label>
		<select class="form-control" name="" id="draft_type">
			<option value="" selected>Snake Draft</option>
			<option value="">Straight Round</option>
			<option value="offline">Offline</option>
			<option value="">Keeper</option>
		</select>
	</div>

	<div class="form-group third">
		<label>Draft Date &amp; Time</label>
		<input class="form-control" type="text" value="2017/07/13 18:00" name="" id="draft_date">
	</div>

	<div class="form-group third">
		<label>Draft Clock (Seconds)</label>
		<input class="form-control" type="text" value="60" name="">
	</div>

	<div id="offline_info">
		<hr>
		<h4><i class="fa fa-warning"></i> Offline Draft Reminder</h4>
		<p>You selected an OFFLINE draft. You, the commissioner are 100% responsible for the data entry of all players for all teams. If team data is input after week 1, you can still finalize teams however no prior scoring data, match-ups, or any other statistical logging will transpire for any team. Your league’s first week will simply default to the next upcoming week that has not yet begun.</p>
	</div>

	<div id="draft_date_notice">
		<hr>
		<h4><i class="fa fa-warning"></i> Draft Notice</h4>
		<p>You have selected a date that is after the start of week 1 of the NFL season. No prior scoring data, match-ups, or any other statistical logging will transpire for any team. Your league’s first week will simply default to the next upcoming week that has not yet begun.</p>
	</div>

	<hr>

	<div class="text-center">
		<button class="btn btn-default" type="submit">Update</button>
	</div>

</form>

<script type="text/javascript">
	$(document).ready(function(){

		$('#draft_date').datetimepicker({
			minDate: 0,
		});

		$('#offline_info').hide();
		$('#draft_type').on('change',function(){
			var divisions = $(this).val();
			if(divisions === 'offline'){
				$('#offline_info').show();
			}else{
				$('#offline_info').hide();
			}
		});
	});
</script>
