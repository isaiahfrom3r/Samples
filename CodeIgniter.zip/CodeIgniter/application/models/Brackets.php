<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Brackets extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function get_bracket(){
		$tid = $this->options->get('tournament_id');

		$this->db->where('cid',$tid);
		$q = $this->db->get("sport_bracket");
		$q = $q->row();
		return $q;

	}
	public function get_season_bracket($season){

		$this->db->where('season',$season);
		$q = $this->db->get("sport_bracket");
		$q = $q->row();
		return $q;

	}

	public function insert_update_team($team){

		$this->db->where('cid',$team['cid']);
		$q = $this->db->get("sport_team");

		if ($q->num_rows() > 0){

			$this->db->where('cid',$team['cid']);
			$this->db->update('sport_team', $team);

		}else{

			$this->db->insert('sport_team', $team);

		}

	}





}//  end feed class
