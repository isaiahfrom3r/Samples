$( document ).ready(function() {
   function director(){
   		console.log('director');

   }
   var tcardblock = 0;
/*
   $(document).on('hover', ".team", function() {
   		var tid = $(this).attr( "team" );
   		console.log(tid);
   		//$('.link_team_'+tid).addClass('teamHighlight');
   		$('.link_team_'+tid).toggleClass("teamHighlight");
   });
*/
/*

   $(".team").hover(function () {
	   var tid = $(this).attr( "team" );
	   console.log(tid);
	   if(tid > 0){
   	  		 $('.link_team_'+tid).toggleClass("teamHighlight");
   	   }
   });
*/
   // left for ref

   $(document).on('click', ".teamCard", function() {
	   tcardblock = 1;
	    var tid = $(this).attr( "team" );

	    if(tid > 0){

	    console.log(HOST_NAME+'league/team_card/'+tid);
   		jQuery.ajax({
			url: HOST_NAME+'league/team_card/'+tid,
			success: function(data) {


				$('#TeamCardModal .modal-content').html(data);


				$('.toast').hide();
			}

		});


		$('#TeamCardModal').modal('show');

		}else{

			var message = "No Team Selected";
			var type = 'error';
			var tlocation = 'toast-top-right';
			var time = 1000
			if(type == 'success_long'){
				type = 'success';
				time = 10000;
			}

			toastr.options = {
			  "closeButton": true,
			  "debug": false,
			  "positionClass": tlocation,
			  "onclick": null,
			  "showDuration": "1000",
			  "hideDuration": "1000",
			  "timeOut": time,
			  "progressBar": true,
			  "extendedTimeOut": "1000",
			  "showEasing": "swing",
			  "hideEasing": "linear",
			  "showMethod": "fadeIn",
			  "hideMethod": "fadeOut"
			}

			if(type == "info"){
				toastr.info( message );
			}
			if(type == "success"){
				toastr.success( message );
			}
			if(type == "warning"){
				toastr.warning( message );
			}
			if(type == "error"){
				toastr.error( message );
			}


		}


   });
   $(document).on('click', "#bracket_submit", function() {
	   $('.saving').show();
	   $('.saved').hide();
	    var lid = $("#league_id").val();

	    var tb1 = $('.tb1_input').val();
	    var tb2 = $('.tb2_input').val();


	    if(lid > 0 && tb1 > 0 && tb2 > 0){

		    console.log(HOST_NAME+'league/update_tb/'+lid+'/'+tb1+'/'+tb2);

	   		jQuery.ajax({
				url: HOST_NAME+'league/update_tb/'+lid+'/'+tb1+'/'+tb2,
				success: function(data) {



					$('.saving').hide();
					$('.saved').show();
					$('.TB_SAVE').show();



					var message = "Tiebreakers saved";
					var type = 'success';
					var tlocation = 'toast-top-right';
					var time = 1000
					if(type == 'success_long'){
						type = 'success';
						time = 10000;
					}

					toastr.options = {
					  "closeButton": true,
					  "debug": false,
					  "positionClass": tlocation,
					  "onclick": null,
					  "showDuration": "1000",
					  "hideDuration": "1000",
					  "timeOut": time,
					  "progressBar": true,
					  "extendedTimeOut": "1000",
					  "showEasing": "swing",
					  "hideEasing": "linear",
					  "showMethod": "fadeIn",
					  "hideMethod": "fadeOut"
					}

					if(type == "info"){
						toastr.info( message );
					}
					if(type == "success"){
						toastr.success( message );
					}
					if(type == "warning"){
						toastr.warning( message );
					}
					if(type == "error"){
						toastr.error( message );
					}


				}

			});

		}else{
// 			alert('Please add both Tiebreakers.');
			var message = "Please add both Tiebreakers.";
			var type = 'error';
			var tlocation = 'toast-top-right';
			var time = 5000
			if(type == 'success_long'){
				type = 'success';
				time = 10000;
			}

			toastr.options = {
			  "closeButton": true,
			  "debug": false,
			  "positionClass": tlocation,
			  "onclick": null,
			  "showDuration": "1000",
			  "hideDuration": "1000",
			  "timeOut": time,
			  "progressBar": true,
			  "extendedTimeOut": "1000",
			  "showEasing": "swing",
			  "hideEasing": "linear",
			  "showMethod": "fadeIn",
			  "hideMethod": "fadeOut"
			}

			if(type == "info"){
				toastr.info( message );
			}
			if(type == "success"){
				toastr.success( message );
			}
			if(type == "warning"){
				toastr.warning( message );
			}
			if(type == "error"){
				toastr.error( message );
			}
		}


   });
   $(document).on('click', ".team", function() {
	   $('.saving').show();
	   $('.saved').hide();
	    var tid = $(this).attr( "team" );
	    var cround = $("#round").val();
	    var lid = $("#league_id").val();
	    var round = $(this).attr( "round" );
	    var group = $(this).attr( "group" );
	    var gid = $(this).attr( "gkey" );

	    if(tcardblock == 1){
		    tcardblock = 0;
		    return;
	    }

	    if(round >= cround){
	    if(tid.length > 0){

		    console.log(HOST_NAME+'league/update_bracket/'+lid+'/'+tid+'/'+round+'/'+group+'/'+gid);

	   		jQuery.ajax({
				url: HOST_NAME+'league/update_bracket/'+lid+'/'+tid+'/'+round+'/'+group+'/'+gid,
				success: function(data) {


					if(data == 0){

						$('.saving').hide();
						$('.saved').show();

						var message = "Bracket Locked";
						var type = 'error';
						var tlocation = 'toast-top-right';
						var time = 1000
						if(type == 'success_long'){
							type = 'success';
							time = 10000;
						}

						toastr.options = {
						  "closeButton": true,
						  "debug": false,
						  "positionClass": tlocation,
						  "onclick": null,
						  "showDuration": "1000",
						  "hideDuration": "1000",
						  "timeOut": time,
						  "progressBar": true,
						  "extendedTimeOut": "1000",
						  "showEasing": "swing",
						  "hideEasing": "linear",
						  "showMethod": "fadeIn",
						  "hideMethod": "fadeOut"
						}

						if(type == "info"){
							toastr.info( message );
						}
						if(type == "success"){
							toastr.success( message );
						}
						if(type == "warning"){
							toastr.warning( message );
						}
						if(type == "error"){
							toastr.error( message );
						}


					}else{


						$('#bracket_block').replaceWith(data);

						$('.saving').hide();
						$('.saved').show();

						var message = "Bracket Saved";
						var type = 'success';
						var tlocation = 'toast-top-right';
						var time = 1000
						if(type == 'success_long'){
							type = 'success';
							time = 10000;
						}

						toastr.options = {
						  "closeButton": true,
						  "debug": false,
						  "positionClass": tlocation,
						  "onclick": null,
						  "showDuration": "1000",
						  "hideDuration": "1000",
						  "timeOut": time,
						  "progressBar": true,
						  "extendedTimeOut": "1000",
						  "showEasing": "swing",
						  "hideEasing": "linear",
						  "showMethod": "fadeIn",
						  "hideMethod": "fadeOut"
						}

						if(type == "info"){
							toastr.info( message );
						}
						if(type == "success"){
							toastr.success( message );
						}
						if(type == "warning"){
							toastr.warning( message );
						}
						if(type == "error"){
							toastr.error( message );
						}



					}

				}

			});

		}
		}else{

			var message = "You cannot make selections for rounds already started";
				var type = 'warning';
				var tlocation = 'toast-top-right';
				var time = 5000
				if(type == 'success_long'){
					type = 'success';
					time = 10000;
				}

				toastr.options = {
				  "closeButton": true,
				  "debug": false,
				  "positionClass": tlocation,
				  "onclick": null,
				  "showDuration": "1000",
				  "hideDuration": "1000",
				  "timeOut": time,
				  "progressBar": true,
				  "extendedTimeOut": "1000",
				  "showEasing": "swing",
				  "hideEasing": "linear",
				  "showMethod": "fadeIn",
				  "hideMethod": "fadeOut"
				}

				if(type == "info"){
					toastr.info( message );
				}
				if(type == "success"){
					toastr.success( message );
				}
				if(type == "warning"){
					toastr.warning( message );
				}
				if(type == "error"){
					toastr.error( message );
				}

		}


		tcardblock = 0;


   });
   setInterval(director, 10000);

   director();



});
