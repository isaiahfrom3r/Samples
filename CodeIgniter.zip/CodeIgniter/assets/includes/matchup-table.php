<table class="table lobby-table tablesorter" id="matchup_table">
	<tbody>
		<tr class="starter">
			<td class="position">
				QB
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(QB)</span></a>
				<div class="details">
					Bye 8 | YTD 198 | AVG 18 | PROJ <span class="green">26.5</span> <br>
					<strong>OAK</strong>@DEN 9/7 Q1 7:04
				</div>
			</td>
			<td class="total-points">
				18.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				QB
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(QB)</span></a>
				<div class="details">
					Bye 8 | YTD 176 | AVG 16 | PROJ 20.54 <br>
					HOU@<strong>ARI</strong> 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
	</tbody>
</table>
<table class="table lobby-table tablesorter" id="matchup_table">
	<tbody>
		<tr class="starter">
			<td class="position">
				RB
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(RB)</span></a>
				<div class="details">
					Bye 10 | YTD 154 | AVG 14 | PROJ 15.30 <br>
					<strong>BAL</strong>@BUF 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr class="starter">
			<td class="position">
				RB
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(RB)</span></a>
				<div class="details">
					Bye 7 | YTD 84 | AVG 7.6 | PROJ 11.10 <br>
					<strong>HOU</strong>@ARI 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				RB
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(RB)</span></a>
				<div class="details">
					Bye 8 | YTD 176 | AVG 16 | PROJ 18.24 <br>
					HOU@<strong>ARI</strong> 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
	</tbody>
</table>
<table class="table lobby-table tablesorter" id="matchup_table">
	<tbody>
		<tr class="starter">
			<td class="position">
				WR
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(WR)</span></a>
				<div class="details">
					Bye 7 | YTD 56 | AVG 5.1 | PROJ 9.70 <br>
					<strong>HOU</strong>@ARI 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr class="starter">
			<td class="position">
				WR
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(WR)</span></a>
				<div class="details">
					Bye 8 | YTD 66 | AVG 6 | PROJ 7.40 <i class="fa fa-medkit"></i> <span class="red">(P)</span><br>
					<strong>TEN</strong>@NYJ 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				WR
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(WR)</span></a>
				<div class="details">
					Bye 8 | YTD 194 | AVG 17.6 | PROJ 14.00 <br>
					HOU@<strong>ARI</strong> 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
	</tbody>
</table>
<table class="table lobby-table tablesorter" id="matchup_table">
	<tbody>
		<tr class="starter">
			<td class="position">
				TE
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(TE)</span></a>
				<div class="details">
					Bye 9 | YTD 99 | AVG 9 | PROJ 12.20 <br>
					<strong>NE</strong>@PHI 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr class="starter">
			<td class="position">
				TE
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(TE)</span></a>
				<div class="details">
					Bye 11 | YTD 231 | AVG 21 | PROJ 20.74 <br>
					<strong>CAR</strong>@JAX 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				TE
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(TE)</span></a>
				<div class="details">
					Bye 11 | YTD 64 | AVG 5.8 | PROJ 12.00 <br>
					<strong>CAR</strong>@JAX 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				TE
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(TE)</span></a>
				<div class="details">
					Bye 9 | YTD 125 | AVG 11.3 | PROJ 10.60 <br>
					<strong>NE</strong>@PHI 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				TE
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(TE)</span></a>
				<div class="details">
					Bye 9 | YTD 125 | AVG 11.3 | PROJ 10.60 <br>
					<strong>NE</strong>@PHI 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
	</tbody>
</table>
<table class="table lobby-table tablesorter" id="matchup_table">
	<tbody>
		<tr class="starter">
			<td class="position">
				K
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(K)</span></a>
				<div class="details">
					Bye 9 | YTD 33 | AVG 3 | PROJ 12.00 <br>
					<strong>MIN</strong>@CHI 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				K
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(K)</span></a>
				<div class="details">
					Bye 10 | YTD 66 | AVG 6 | PROJ 8.00 <br>
					<strong>BAL</strong>@BUF 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				K
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(K)</span></a>
				<div class="details">
					Bye 8 | YTD 32 | AVG 2.9 | PROJ 5.80 <i class="fa fa-medkit"></i> <span class="red">(Q)</span> <br>
					<strong>TEN</strong>@NYJ 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
	</tbody>
</table>
<table class="table lobby-table tablesorter" id="matchup_table">
	<tbody>
		<tr class="starter">
			<td class="position">
				DEF/ST
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(DEF/ST)</span></a>
				<div class="details">
					Bye 6 | YTD 44 | AVG 4 | PROJ 9.00 <br>
					<strong>SEA</strong>@DET 9/7 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="starter no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
		<tr>
			<td class="position">
				DEF/ST
			</td>
			<td class="text-left">
				<a href="#" data-toggle="modal" data-target="#playercard"><img src="assets/img/default.jpeg" alt="" /> Player Name <span class="mobile-position">(DEF/ST)</span></a>
				<div class="details">
					Bye 11 | YTD 103 | AVG 9.4 | PROJ 6.00 <br>
					<strong>CAR</strong>@JAX 9/11 7:30pm
				</div>
			</td>
			<td class="total-points">
				0.0
			</td>
			<tr class="no-border">
				<td colspan="3">
					<a href="#" data-toggle="modal" data-target="#playercard" class="player-card-btn" title="Player Card"><i class="fa fa-drivers-license-o fa-lg"></i></a>
					<a href="#" class="timeline-btn" title="Player Timeline"><i class="material-icons">timeline</i></a>
				</td>
			</tr>
		</tr>
	</tbody>
</table>
