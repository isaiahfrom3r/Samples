<div class="card">
	<div class="card-header">
		<h3>Articles</h3>
		Edit the articles which have already been published by hovering over them and using the edit option.
	</div>
<div class="row-fluid col-md-12">



	<!--END Information block -->
	<div class="pull-right">
	<a href="<?=site_url(ADMIN_THEME.'/article/edit')?>" class="btn btn-info" class="btn btn-small confirm">Create New Article</a>
	</div>
	<div class="clearfix"></div><br>
	<div class="clearfix"></div>

		<?//="<pre>".print_r($articles,true)."</pre>";?>
		<div class="portlet box green">

		<div class="portlet-body">
			<div class="table-responsive">
		<table class="table table-condensed table-striped table-bordered tablesorter" data-options='{"sortList":[[1,0]],"headers":{"0":{"sorter":false},"6":{"sorter":false}}}'>
			<thead>
				<tr>
					<th>Label</th>
					<th>Author</th>
					<th>Post Date</th>
					<th>Status</th>
					<th>Visibility</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?if(!empty($articles)):?>
					<?foreach($articles as $a):?>
						<tr>
							<td><?=$a->label?></td>
							<td><?$author=$this->users->get_user($a->author_id);echo $author->username?></td>
							<td><?=date('m/d/Y G:i',$a->post_date)?></td>
							<td><?=$a->status?></td>
							<td><?=$a->visibility?></td>
							<td>
								<a class="btn btn-info" href="<?=site_url(ADMIN_THEME."/article/edit/".$a->id)?>" rel="tooltip" title="Edit"><i class="zmdi zmdi-edit"></i></a>
								<a class="btn btn-danger" href="<?=site_url(ADMIN_THEME."/article/delete/".$a->id)?>" rel="tooltip" title="Delete" class="confirm"><i class="zmdi zmdi-delete"></i></a>
							</td>
						</tr>
					<?endforeach;?>
				<?else:?>
					<tr><td colspan="6">No Articles Found</td></tr>
				<?endif;?>
			</tbody>
		</table>
		<div class="clearfix"></div><br>

	</div>
</div>
</div>
</div>
 <div class="clearfix"></div></div>


