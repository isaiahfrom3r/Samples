console.log("payout");
$("input").change(function(){
	console.log('update1');
	run_tallies();
});
var fstop = 0;
run_tallies();
 function run_tallies(){
    var amount = parseInt($('.pool').val());
	var sum = 0;

	$( ".payamount" ).each(function() {
		var num =  parseInt($(this).val());
		if (num > 0) {
			sum = sum + num;
		}

	});
	$( ".payamounthonor" ).each(function() {

		var num =  parseInt($(this).val());
		if (num > 0) {
			sum = sum + num;
		}

	});
	var rem = parseInt(amount - sum);

	$('.remlable').removeClass('paygreen');
	$('.remlable').removeClass('payred');

	if(rem >= 0){
		$('.remlable').addClass('paygreen');
	}else{
		$('.remlable').addClass('payred');
	}
	$('.remainging').html(rem);


}


$(".pForm").submit(function(e){
	console.log(fstop);
	if(fstop == 0){
    	e.preventDefault();

	    var amount = parseInt($('.pool').val());
		var sum = 0;

		$( ".payamount" ).each(function() {
			var num =  parseInt($(this).val());
			if (num > 0) {
				sum = sum + num;
			}

		});
		$( ".payamounthonor" ).each(function() {

			var num =  parseInt($(this).val());
			if (num > 0) {
				sum = sum + num;
			}

		});
		var rem = parseInt(amount - sum);

	    if(rem == 0){
		    fstop = 1;
		    $('form').unbind('submit').submit();
	    }else if(rem > 0){
		    alert("Payouts are to low!");
	    }else{
		    alert("Payouts are to high!");
	    }

     }else{
	    $(".pForm").removeClass('pForm');
	    $( "form" ).submit();
    }

});
