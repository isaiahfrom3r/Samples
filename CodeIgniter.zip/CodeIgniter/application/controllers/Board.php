<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Board extends CI_Controller {
	public function __construct() {


		parent::__construct();
		$this->load->model('Articles');
		$this->load->model('Leagues');
	}
	public function set_tag($tag,$user){
		$data = array(
           'active_tag' => $tag,
        );

		$this->db->where('id', $user);
		$this->db->update('task_users', $data);

		redirect('/board');
	}
	public function index($month=0,$year=0){

		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

		if(isset($_COOKIE['mlid'])){

		$this->db->order_by('id','DESC');
		$this->db->where('sprint',1);
		$q = $this->db->get("task_tags");
		$q = $q->result();

		$data['sprints'] = $sprints =  $q;


/*
		$head['scripts'] = array(base_url().'assets/js/calendar.js');
		$head['styles'] = array(base_url().'assets/css/calendar.css');
*/
		$this->db->where('id', $_COOKIE['mlid'] );
		$q = $this->db->get("task_users");
		$q = $q->row();
		$head['profile'] = $data['profile'] =  $profile = $q;


		if(isset($_SESSION['userlist'])){
			$users = array('11881595','10523935');
			$users = $_SESSION['userlist'];
			$data['active_users'] =  $users;
		}else{

			$users = array();
			$users = array($_COOKIE['mlid']);
			$_SESSION['userlist'] = $users;
		}

		$this->db->where('id', $_COOKIE['mlid'] );
		$q = $this->db->get("task_users");
		$q = $theuser = $q->row();
		$data['user'] =  $theuser;
		if($q->active_tag < 1){
			$this->set_tag($data['sprints'][0]->id, $_COOKIE['mlid'] );
		}else{
			$needtag = 1;
			foreach($sprints as $s){
				if($s->id == $theuser->active_tag){
					$needtag = 0;
				}
			}

			if($needtag == 1){
				$this->set_tag($data['sprints'][0]->id, $_COOKIE['mlid'] );
			}
		}



		$head['styles'] = array(base_url().'assets/css/board.css');
		$head['scripts'] = array(base_url().'assets/js/board.js');
		$foot['scripts'] = $foot['styles'] = array();



		$this->db->order_by('due_date','ASC');
		$this->db->like('tags',$profile->active_tag);
// 		$this->db->where_in('id',$tids);
		$q = $this->db->get("tasks");
		$q = $q->result();

		foreach($q as $res){
			$tids[] = $res->id;
			$taskarray[$res->id] = $res;

		};
		foreach($taskarray as $ta){
			$this->db->select('code');
			$this->db->select('status');
			$this->db->select('id');
			$this->db->where('id',$ta->workspace_id);
			$q = $this->db->get("ci_workspaces");

			if ($q->num_rows() == 0){
				continue;
			}
			$q = $q->row();



			$worksaces[$q->id] = $q;
		}


		$usedtasks = array();

		foreach($taskarray as $ta){
			$this->db->where('task_id', $ta->id);
			$q = $this->db->get("task_sprint_status");
			if ($q->num_rows() > 0){
				$q = $q->row();
				$sendtask[$q->level][] = $ta;
			}else{
				$data = array(
	               'level' => 1,
	               'task_id' => $ta->id,
	            );

				$this->db->insert('task_sprint_status', $data);

				$sendtask[1][] = $ta;
			}
		}

		$this->db->where_in("task_id",$tids);
		$q = $this->db->get("task_assignments");
		$q = $q->result();


		foreach($q as $as){
			;
			if($as->user_id < 1){
				continue;
			}
			$userassignments[$as->task_id][] = $as->user_id;
			$users[$as->user_id] = $as->user_id;

		}
		foreach($users as $key=>$u){

			$this->db->where('id',$u);
			$q = $this->db->get("task_users");
			$q = $q->row();
			$users[$key] = $q;
		}
		unset($users[0]);

		$data['users'] =  $users;
		$data['userassignments'] =  $userassignments;
		$data['datatask'] =  $sendtask;
		$data['workspaces'] =  $worksaces;
		// get users list
			$q = $this->db->get("task_users");
			$q  = $q->result();
			foreach($q as $res){
				$userlist[$res->full_name] = $res;
			}
			ksort($userlist);
			$data['userlist'] =  $userlist;






		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/board/view',$data);
		$this->load->view(THEME.'/footer',$foot);

		}else{

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/board/noid');
		$this->load->view(THEME.'/footer');

		}
	}

	public function move($tid,$path){


		$data = array(
           'level' => $path,
           'task_id' => $tid,
        );
		$this->db->where('task_id',$tid);
		$this->db->update('task_sprint_status', $data);
	}









}
