<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mock extends CI_Controller {
	public function __construct() {

		parent::__construct();
		$this->load->model('Teams');
		$this->load->model('Players');
		$this->load->model('Mocks');
		$this->load->model('Drafts');
		$this->load->model('Chats');
	}
	public function index(){
		redirect('/mock/draft');
	}
	public function teams(){
		$data['data'] =  array();
		$head[''] = array();
		$foot[''] = array();

		$data['mocks'] =  $this->Mocks->get_my_mocks();

		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/mock/teams',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function invite($mock){
		$user  = $this->users->get();

		$data['mid'] =  $mock;

		// validation
		$this->form_validation->set_rules('comp', 'Compitions', 'required');
		if ($this->form_validation->run() === false) {
		}else{

			$subject = "You have been invited to YouRulz";

			foreach($_POST['email'] as $e){


				$this->db->where('id',$_POST['comp']);
				$q = $this->db->get("mocks");
				$q = $q->row();


				$email_data = array(
					'first' => $user->first_name,
					'last' => $user->last_name,
					'code' => $q->share_id,
				);

				$this->emails->send_mail($e,'invite_to_mock',$email_data,$subject);
			}

			$this->alert->set('Your friends have been invited','success');
			redirect('/dashboard');


		}


		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/mock/invite',$data);
		$this->load->view(THEME.'/footer');
	}
	public function join_private(){

		// validation
		$this->form_validation->set_rules('code', 'Code', 'required');
		if ($this->form_validation->run() === false) {
		}else{
			$mock = $this->Mocks->check_get_code($_POST['code']);

			if($mock == 1){
				$this->alert->set('Invalid Code!','error');

				redirect('mock/join_private');
			}else{
				redirect('mock/join/'.$mock);
			}

		}

		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/mock/join_private',$data);
		$this->load->view(THEME.'/footer');

	}
	public function join($mid){
		$canjoin = $this->Mocks->check_join_status($mid);
		//isaiah when done redirect them away if they are owner
		$leauge =  $this->Mocks->get_mock_by_id($mid);
		if($leauge->draft_start < time()){
			$this->alert->set('Draft Started','error');

			redirect('/mlobby');
		}

		if($leauge->owner == $this->users->id()){
			$this->alert->set('Draft Already Joined','error');

			redirect('/mlobby');
		}

		$rawteams = $this->Mocks->get_mock_teams($mid);

		$exists = array();
		foreach($rawteams as $t){
			if($t->user == 0){
				$joinable[] = $t;
			}else{
				$exists[] = $t;
			}
		}
		if(count($joinable) == 0){
			$this->alert->set('Draft Full','error');

			redirect('/mlobby');
		}

		$data['teams']['joinable'] =  $joinable;
		$data['teams']['already'] =  $exists;

		$this->form_validation->set_rules('team', 'Position', 'required');
		if ($this->form_validation->run() === false) {
		}else{
			$user  = $this->users->get();
			$update = array(
				'user_id' => $this->users->id(),
				'user' => 1,
				'auto' => 0,
				'name' => $user->username,
			);


			$this->db->where('id',$_POST['team']);
			$this->db->update('mock_team', $update);

			$this->alert->set('You have successfully joined!','success');
			redirect('/mlobby');


		}



		$this->load->view(THEME.'/header');
		$this->load->view(THEME.'/mock/join',$data);
		$this->load->view(THEME.'/footer');
	}
	public function create(){
		$data['data'] =  array();
		$head['scripts'] = array('/assets/js/mockcreate.js','//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js');
		$foot['scripts'] = array();


		$this->form_validation->set_rules('owners_position', 'Draft Position', 'required');
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('start_time', 'Start Time', 'required');
		$this->form_validation->set_rules('team_count', 'Team Count', 'required');

		if ($this->form_validation->run() === false) {
		}else{

			$start_time_clock = strtotime($_POST['start_time']) + 31;

			$mock = array(
				'owner' => $this->users->id(),
				'name'	=> $_POST['name'],
				'current_pick' => 1,
				'draft_order' => '',
				'draft_results' => '',
				'draft_start' => strtotime($_POST['start_time']),
				'clock' => $start_time_clock,
				'share_id' => $this->users->id()."Z".(round(substr(time(), 4))).date('d').'URLZ',

			);

			// insert it and return id;
			$mock_id = $this->Mocks->create_mock($mock);
			$user  = $this->users->get();

			$mock_team = array(
				'user_id' => $this->users->id(),
				'mock_id' => $mock_id,
				'name' => $user->username,
				'roster' => '',
				'draft_position' => $_POST['owners_position'],
				'user' => 1,
				'auto' => 0,
			);
			$this->Mocks->create_mock_team($mock_team);

			$p = 1;
			while($p <= $_POST['team_count']){

				$positions[$p] = $p;
				$p++;
			}

			$i = 1;
			unset($positions[$_POST['owners_position']]);

			while($i < $_POST['team_count']){

				$dp = array_rand($positions, 1);
				unset($positions[$dp]);

				$mock_team = array(
					'user_id' => 0,
					'mock_id' => $mock_id,
					'name' => '',
					'roster' => '',
					'draft_position' => $dp,
					'user' => 0,
					'auto' => 0,
				);

				$this->Mocks->create_mock_team($mock_team);
				$i++;
			}

			$data['teams'] = $teams = $this->Mocks->get_mock_teams($mock_id);


			$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);



			redirect('/mlobby');
		}


		$this->load->view(THEME.'/header',$head);
		$this->load->view(THEME.'/mock/create',$data);
		$this->load->view(THEME.'/footer',$foot);
	}
	public function show($lid='3')
	{
		ini_set('memory_limit','-1');
		$foot['scripts'] = array();
		$head['styles'] = array('/assets/css/icons.css');
		$head['scripts'] = array(base_url().'assets/js/draft.js',base_url().'assets/js/downcount.js');
		$foot['styles'] = array();
		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);

		// grab teams and give them a map
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		foreach($data['teams'] as $key=>$team){
			if($team->user_id == $this->users->id()){
				$data['myteam'] =  $team;
			}
			if($team->draft_map == ""){
				$dm = $this->Mocks->draft_map_update($team->id);
				$data['teams'][$key]->draft_map = $dm;
			}
			$incteams[$team->user_id] = $team->user_id;
		}

		// grab draft order
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);

		$data['league'] =  $this->Mocks->get_mock_by_id($lid);

		if(!in_array($this->users->id(), $incteams)){
			echo "This is not your Draft!"; die;
		}
		$this->load->view(THEME.'/mock/header',$head);
		$this->load->view(THEME.'/mock/main_show',$data);
		$this->load->view(THEME.'/mock/footer',$foot);

	}
	public function draft($lid='3')
	{
		ini_set('memory_limit','-1');
		$foot['scripts'] = array();
		$head['styles'] = array('/assets/css/icons.css');
		$head['scripts'] = array(base_url().'assets/js/draft.js',base_url().'assets/js/downcount.js');
		$foot['styles'] = array();
		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);

		// grab teams and give them a map
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		foreach($data['teams'] as $key=>$team){
			if($team->user_id == $this->users->id()){
				$data['myteam'] =  $team;
			}
			if($team->draft_map == ""){
				$dm = $this->Mocks->draft_map_update($team->id);
				$data['teams'][$key]->draft_map = $dm;
			}
			$incteams[$team->user_id] = $team->user_id;
		}

		// grab draft order
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);

		$data['league'] =  $this->Mocks->get_mock_by_id($lid);

		if(!in_array($this->users->id(), $incteams)){
			echo "This is not your Draft!"; die;
		}
		$this->load->view(THEME.'/mock/header',$head);
		$this->load->view(THEME.'/mock/main',$data);
		$this->load->view(THEME.'/mock/footer',$foot);

	}
	public function login_as_very_long_function_abscract_words_random($id='',$draft=''){
		$user = $this->users->get_user($id);

		$sesdata = array(
			'id'			=> (int)$user->id,
			'username'		=> (string)$user->username,
			'email'			=> $user->email,
			'first_name'	=> $user->first_name,
			'last_name'		=> $user->last_name,
			'level'			=> $user->level,
			'admin'			=> $user->level,
		);


		$this->session->set_userdata('user',$sesdata);
		$this->alert->set('You are logged in as '.strtoupper($user->username),'success');
		redirect('/mock/admin/'.$draft);



	}
	public function admin($lid='3')
	{
		ini_set('memory_limit','-1');
		$foot['scripts'] = array();
		$head['styles'] = array('/assets/css/icons.css');
		$head['scripts'] = array(base_url().'assets/js/draft.js',base_url().'assets/js/downcount.js');
		$foot['styles'] = array();
		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);

		// grab teams and give them a map
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		foreach($data['teams'] as $key=>$team){
			if($team->user_id == $this->users->id()){
				$data['myteam'] =  $team;
			}
			if($team->draft_map == ""){
				$dm = $this->Mocks->draft_map_update($team->id);
				$data['teams'][$key]->draft_map = $dm;
			}
			$incteams[$team->user_id] = $team->user_id;
		}

		// grab draft order
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);

		$data['league'] =  $this->Mocks->get_mock_by_id($lid);

		if(!in_array($this->users->id(), $incteams)){
			echo "This is not your Draft!"; die;
		}
		$this->load->view(THEME.'/mock/header',$head);
		$this->load->view(THEME.'/mock/main',$data);
		$this->load->view(THEME.'/mock/footer',$foot);

	}

	public function update_que($tid){
		$data['team'] =  $this->Mocks->get_team_by_id($tid);

		$this->load->view(THEME.'/mock/mock_player_que.php',$data);
	}

	public function mobile_que($tid){
		$data['team'] =  $this->Mocks->get_team_by_id($tid);

		$this->load->view(THEME.'/mock/mock_mobile_que.php',$data);
	}
	public function update_lineup($lid,$tid){
		$data['team'] =  $this->Mocks->get_team_by_id($tid);
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);

		$this->load->view(THEME.'/mock/mock_lineup.php',array('order' => $order,'teams' => $teams,'mid' => $lid));
	}
	public function get_cur_pick($lid){
		$league = $data['league'] =  $this->Mocks->get_mock_by_id($lid);
		$pick = $this->Mocks->get_pick($lid);

		echo $pick;
	}
	public function get_cur_picker_lineup($mid){
		$league = $data['league'] =  $this->Mocks->get_mock_by_id($mid);


		$pick = $this->Mocks->get_pick($mid);
		if($pick > 240){
			return 100;
		}
		$team = $this->Mocks->get_picker($mid);
		echo $team;
	}
	public function update_my_roster($tid){
		$data['team'] = $this->Mocks->get_team_by_id($tid);

		$this->load->view(THEME.'/mock/team-sidebar',$data);
	}
	public function player_info($pid='',$lid){
		$data['player'] =  $this->Players->get_by_id($pid);
		$data['league'] = $league = $this->Mocks->get_mock_by_id($lid);
		$this->load->view(THEME.'/mock/mock_draft_mid',$data);

	}
	public function update_results_tab($lid,$tid){
		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		$data['team'] =  $this->Mocks->get_team_by_id($tid);;
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);
		$data['league'] =  $this->Mocks->get_mock_by_id($lid);
		$this->load->view(THEME.'/mock/mock_results',$data);

	}
	public function mobile_update_results_tab($lid,$tid){
		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		$data['team'] =  $this->Mocks->get_team_by_id($tid);;
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);
		$data['league'] =  $this->Mocks->get_mock_by_id($lid);
		$this->load->view(THEME.'/mock/mock_results_mobile',$data);

	}
	public function cpu_pick($lid){

		// check to see if cpu is up
		$league = $data['league'] =  $this->Mocks->get_mock_by_id($lid);


		$pick = $this->Mocks->get_pick($lid);
		if($pick > 240){
			return 100;
		}
		$team = $this->Mocks->get_picker($lid);
		$teamarr = $this->Mocks->get_team_by_id($team);




		// find the player they should take
		$i = 0;

		$checkforbye = 0;
		$exclueds = array();
		while($checkforbye == 0){
			$player = $this->Mocks->find_player($league,$pick,$team);
			echo "<pre>";
			print_r($player);
			echo "</pre>";

			$addex = $this->Mocks->bye_check($player,$league,$pick,$team);

			if($addex == 1){
				$checkforbye++;
			}else{
				$exclueds[$addex] = $addex;
			}

			$i ++;

			// must have to take them or something
			if($i == 10){
				$checkforbye++;
			}

		}


		if(empty($player)){
			return 0;
		}

		// adjust draft map
		$redflag = $this->Mocks->adjust_map($player,$team,$pick);
		if($redflag == 1){
			//echo "mapping broken!"; die;
		}

		// add to roster
		$this->Mocks->add_to_roster($player,$team);


		// update curr pick
		$this->Mocks->update_pick($pick,$league->id);


		$this->Mocks->update_draft_log($player,$league->id);


		if(strlen($player) > 5){
			$player = $this->Players->get_by_id($player);
			$name = $player->first_name." ".$player->last_name;
		}else{
			$player = $this->Teams->get_by_id($player);

			$name = $player->city." ".$player->name;
		}
		if($teamarr->name == ""){
			$teamarr->name = "CPU ".$teamarr->draft_position;
		}
		$message = $teamarr->name." has drafted ". $name;
		$this->Chats->chat_submit(0,$lid,$message,1);

		// respond that pick is in
		echo 1;
	}
	public function post_draft($lid){
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);
		$data['league'] =  $this->Mocks->get_mock_by_id($lid);


		$this->load->view(THEME.'/mock/post_draft',$data);

	}
	public function draft_player($tid,$lid,$pid){

		if(strlen($pid) < 1){
			echo 'No Player Selected';die;
		}
		// make sure that guys is on the clock
		$league = $data['league'] =  $this->Mocks->get_mock_by_id($lid);
		$pick = $this->Mocks->get_pick($lid);
		$team = $this->Mocks->get_picker($lid);
		$teamarr = $this->Mocks->get_team_by_id($team);

		if($league->draft_start > time()){
			echo "Draft Not Started"; die;
		}

		if(!isset($teamarr->id)){
			echo "Draft Is Over"; die;
		}
		if($teamarr->id != $tid){
			echo "Team Not On Clock"; die;
		}

		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = $players = array_merge($data['players'],$data['sport_teams']);

		// is player available
		foreach($data['players'] as $plrys){
			$pids[] = $plrys->cid;
		}
		if(!in_array($pid, $pids)){
			echo "Player Already Drafted!";  die;
		}

/*
		$checklegal = $this->Mocks->check_legal($teamarr,$pid);
		if($checklegal == 0){
			echo "No room for this player";  die;
		}
*/



		$redflag = $this->Mocks->adjust_map($pid,$team,$pick);
		// add the guy and stuff
		$this->Mocks->add_to_roster($pid,$team);

		$this->Mocks->update_draft_log($pid,$league->id);

		// update curr pick
		$this->Mocks->update_pick($pick,$league->id);

		$data = array(
           'clock' => strtotime('+30 seconds'),
        );

		$this->db->where('id', $lid);
		$this->db->update('mocks', $data);
		// if final pick then set the rosters and junk

		if(strlen($pid) > 5){
			$player = $this->Players->get_by_id($pid);
			$name = $player->first_name." ".$player->last_name;
		}else{
			$player = $this->Teams->get_by_id($pid);

			$name = $player->city." ".$player->name;
		}
		if($teamarr->name == ""){
			$teamarr->name = "CPU ".$teamarr->draft_position;
		}
		$message = $teamarr->name." has drafted ". $name;
		$this->Chats->chat_submit(0,$lid,$message,1);

	}
	public function is_drafted($pid,$lid){
		$leauge =  $this->Mocks->get_mock_by_id($lid);
		$picks = json_decode($leauge->draft_results,true);

		if(empty($picks)){
			echo 1;
		}else{
			if(!in_array($pid, $picks)){
				echo 1;
			}else{
				echo 0;
			}
		}





	}
	public function update_teams_tab($tid){
		$teamarr = $this->Mocks->get_team_by_id($tid);

		 $this->load->view(THEME.'/mock/league_teams',array('team'=>$teamarr));
	}
	public function player_pool($lid){
		$data['players'] = $this->Players->get_mock_available_players($lid);
		$data['sport_teams'] =  $this->Teams->get_all_draftable_mock($lid);
		$data['players'] = array_merge($data['players'],$data['sport_teams']);


		echo json_encode($data['players']);

	}
	public function live_teams($lid){
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);



		echo json_encode($teams);

	}

	public function team_info($pid='',$lid){
		$data['player'] =  $this->Teams->get_by_id($pid);
		$data['league'] = $league = $this->Mocks->get_mock_by_id($lid);
		$this->load->view(THEME.'/mock/mock_draft_mid_d',$data);

	}
	public function update_drafter($lid,$my){
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($lid);
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$lid);
		$data['mid'] =  $lid;
		$data['myid'] =  $my;
		$this->load->view(THEME.'/mock/mock_current_draft',$data);

	}

	public function auto($lid,$autokey){

		$league = $this->Mocks->get_mock_by_id($lid);
		if($league->autokey == $autokey){

			$data = array(
               'auto' => 1,
            );

			$this->db->where('id', $league->id);
			$this->db->update('Mocks', $data);


			$feed = 'wget -O /dev/null -q '.base_url().'mock/do_auto/'.$lid.' --no-check-certificate';

			$feed = $this->execInBackground($feed);

			$this->alert->set('Your team should be available shortly!','success');
			redirect('home/player');
		}


	}
	public function get_drafted_guys($lid){

		$league = $this->Mocks->get_mock_by_id($lid);
		$res = json_decode($league->draft_results,true);
		echo json_encode($res);


	}
	public function do_auto($lid){

		$league = $this->Mocks->get_mock_by_id($lid);

		$i = 0;
		$end = 1000;
		while($i < $end){

			$feed = base_url().'mock/cpu_pick/'.$lid.'/'.$league->autokey.'/1';

			$return = $this->cpu_pick($lid,$league->autokey,1);

			if($return == 100){
				$this->db->where('league_id',$league->id);
				$q = $this->db->get("league_team");
				$q = $q->result();

				foreach($q as $team){

					$this->Mocks->set_roster($team->id,1);
				}


				exit;
			}


			$i++;
		}

		$this->db->where('league_id',$league->id);
		$q = $this->db->get("league_team");
		$q = $q->result();

		foreach($q as $team){
			$this->Mocks->set_roster($team->id,1);
		}



	}
	public function add_que($pid,$uid){
		$this->Mocks->add_to_que($pid,$uid);
	}
	public function que_up($pid,$uid){
		$this->Mocks->que_up($pid,$uid);
	}
	public function que_down($pid,$uid){
		$this->Mocks->que_down($pid,$uid);
	}
	public function remove_que($pid,$uid){
		$this->Mocks->remove_to_que($pid,$uid);
	}
	public function execInBackground($cmd) {
		    if (substr(php_uname(), 0, 7) == "Windows"){
		        pclose(popen("start /B ". $cmd, "r"));
		    }
		    else {
		        exec($cmd . " > /dev/null &");
		    }
		}

	/**
	* our main curl function
	*
	* @since    1.0.0
	*
	* @param none
	* @return none
	*/
	function curl_for_data($feed){
		$ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $feed);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    $output = curl_exec($ch);
	    curl_close($ch);

	    return $output;
	}
	function curl_for_data_nowait($feed){
		$ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $feed);
	    curl_setopt($ch, CURLOPT_TIMEOUT_MS, 1);
		curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 0.1);
	    $output = curl_exec($ch);
	    curl_close($ch);

	    return $output;
	}

	public function update_live($mid){
		$data = array(
			'live' => time(),
		);

		$this->db->where('id', $mid);
		$this->db->update('mock_team', $data);


	}
	public function pause_draft($mid){
		$mock = $this->Mocks->get_mock_by_id($mid);
		if($mock->paused == 1){
			$paused = 0;
			$message = "Draft has resumed";
		}else{
			$paused = 1;
			$message = "Draft Paused";
		}


		$data = array(
			'paused' => $paused,
		);

		$this->db->where('id', $mid);
		$this->db->update('mocks', $data);

		$this->advanceIT($mid);


		$this->Chats->chat_submit(0,$mid,$message,1);

		echo $paused;

	}

	public function undo_pick($mid){
		$mock = $this->Mocks->get_mock_by_id($mid);
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($mid);
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$mid);


		foreach($order as $key=>$o){
			$pick = 1;
			foreach($o as $keynum=>$n){

				$new[$keynum]['round'] = $key;
				$new[$keynum]['pick'] = $keynum;
				$new[$keynum]['player'] = $n;
				$pick++;
			}
		}

		$player = $new[$mock->current_pick -1 ]['player'];
		$results = json_decode($mock->draft_results,true);
		$guy = end($results);


		unset($results[$guy]);


		$nmock = array(
			'draft_results' => json_encode($results),
			'current_pick' => ($mock->current_pick - 1),
		);
		$this->advanceIT($mid);

		$this->db->where('id', $mid);
		$this->db->update('mocks', $nmock);

		echo "<pre>";
		print_r($this->db->last_query());
		echo "</pre>";

		$teamarr = $this->Mocks->get_team_by_id($player);

		$newteam = array();
		$team_roster = json_decode($teamarr->roster,true);
		foreach($team_roster as $key=>$ros){
			foreach($ros as $keyp=>$p){
				if($p != $guy){
					$newteam[$key][$keyp] = $p;
				}
			}
		}


		$data = array(
		    'roster' => json_encode($newteam)
		);

		$this->db->where('id', $teamarr->id);
		$this->db->update('mock_team', $data);

		echo "<pre>";
		print_r($this->db->last_query());
		echo "</pre>";


		$this->Chats->chat_submit(0,$mid,'Previous Pick Reversed',1);

	}
	public function draft_board($mid){
		$foot['styles'] = array();
		$foot['scripts'] = array();
		$head['styles'] = array();
		$league = $data['league'] =  $this->Mocks->get_mock_by_id($mid);

		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		    $ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
		    $ip = $_SERVER['REMOTE_ADDR'];
		}

		if($ip != "73.74.157.47"){


			if($league->final == 0){
				$head['scripts'] = array(base_url().'assets/js/board.js');
			}

		}else{
			echo "<pre>";
			print_r('SCRIPT HAS BEEN REMOVED');
			echo "</pre>";
			$head['scripts'] = array();

		}

		$data['teams'] = $teams = $this->Mocks->get_mock_teams($mid);

		$this->load->view(THEME.'/mock/header',$head);
		$this->load->view(THEME.'/mock/mock_draft-board',$data);
		$this->load->view(THEME.'/mock/footer',$foot);


	}
	public function board_content($mid){


		$league = $data['league'] =  $this->Mocks->get_mock_by_id($mid);
		$data['teams'] = $teams = $this->Mocks->get_mock_teams($mid);

		$this->load->view(THEME.'/mock/mock_draft-board',$data);


	}
	public function auto_toggle($mid){
		$teamarr = $this->Mocks->get_team_by_id($mid);
		if($teamarr->auto == 1){
			$auto = 0;
		}else{
			$auto = 1;
		}

		$data = array(
			'auto' => $auto,
		);

		$this->db->where('id', $mid);
		$this->db->update('mock_team', $data);

		echo $auto;
	}

	//CRON FOR DRAFT RUNS EVERY 5 SECONS
	public function cron(){
		$this->check_lock();


		$this->db->where('final',0);
		$this->db->where('paused',0);
 		//$this->db->where('cid !=',3387);
		$this->db->where('draft_start <',time());
		$q = $this->db->get("mocks");

		$q = $q->result();

		$i = 1;
		while($i <= 36){

			foreach($q as $key=>$m){


				$rawteams = $this->Mocks->get_mock_teams($m->id);

				$exists = array();
				foreach($rawteams as $t){
					if($t->user == 0){
						$joinable[] = $t;
					}else{
						$exists[] = $t;
					}
				}


				if(empty($exists)){
					$data = array(
		               'final' => 1,
		            );

					$this->db->where('id', $m->id);
					$this->db->update('mocks', $data);

					unset($q[$key]);
					continue;
				}




/*
				$feed = 'wget -O /dev/null -q '.base_url().'mock/run_draft/'.$m->id.' --no-check-certificate';
				echo $feed;
				$feed = $this->execInBackground($feed);
*/
				$this->run_draft($m->id);

			}
			$i++;
			echo 'sleep'; echo "<br>";
			sleep(5);

		}

		$this->unlock_it();

	}
	public function email(){

	}
	public function run_draft($mid){
		ini_set('display_errors', 1); // set to 0 for production version
		error_reporting(E_ALL);
		$myFile = FCPATH."lock/lockdraftmockall.txt";
		if (file_exists($myFile)) {

		} else {
		  $fh = fopen($myFile, 'w');
		  fwrite($fh, 'yo'."\n");
		  fclose($fh);
		}



		$fp = fopen(FCPATH."lock/lockdraftmockall.txt", "r+");



		if(!flock($fp, LOCK_EX | LOCK_NB)) {

			$data = array(
               'time' => time(),
               'lid' => $mid,
            );

			$this->db->insert('issues', $data);

		    echo 'Unable to obtain lock';
		    exit(-1);


		     fclose($fp);
		}



		$data['teams'] = $teams = $this->Mocks->get_mock_teams($mid);
		$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$mid);
		$pick = $this->Mocks->get_pick($mid);
		$team = $this->Mocks->get_picker($mid);
		$teamarr = $this->Mocks->get_team_by_id($team);
		$mock = $this->Mocks->get_mock_by_id($mid);
		if($mock->paused == 1){
			echo "PAUSED"; die;
		}


		$made = 0;
		$this->db->where('id',$mid);
		$q = $this->db->get("mocks");
		$q = $q->row();
		$picked = array();
		if(isset($q->draft_results)){
			$picked = json_decode($q->draft_results,true);
		}
		if(!isset($teamarr)){
			$data = array(
               'final' => 1,
            );

			$this->db->where('id', $mid);
			$this->db->update('mocks', $data);
			exit;
		}


		echo "<pre>";
		print_r($teamarr);
		echo "</pre>";

		if($teamarr->user_id == 0){
 			$this->cpu_pick($mid);
			$made = 1;
		}

		if($teamarr->auto == 1){

			if(strlen($teamarr->que) > 5){
				$que = json_decode($teamarr->que);
				$pickq = 0;
				foreach($que as $q){

					if(!is_array($picked) || !in_array($q, $picked)){
						// draft him;
						if($made == 0){
							$this->draft_player($team,$mid,$q);
							$made = 1;
							$pickq = 1;
						}

					}

				}

				if($pickq == 0){
					if($made == 0){
						$this->cpu_pick($mid);
						$made = 1;
					}
				}

			}else{
				if($made == 0){
					$this->cpu_pick($mid);
					$made = 1;
				}


			}
		}

		if(time() > $mock->clock){

			if(strlen($teamarr->que) > 5){
				$que = json_decode($teamarr->que);
				$pickq = 0;
				foreach($que as $q){

					if(!is_array($picked) || !in_array($q, $picked)){
						// draft him;
						if($made == 0){
							$this->draft_player($team,$mid,$q);
							$made = 1;
							$pickq = 1;
						}

					}

				}

				if($pickq == 0){
					if($made == 0){
						$this->cpu_pick($mid);
						$made = 1;
					}

				}

			}else{
				if($made == 0){
					$this->cpu_pick($mid);
					$made = 1;
				}

			}


		}


		// check if pick was made
		if($made ==1){

			$this->advanceIT($mid);

		}else{
			echo 'didnt pick anything'; echo "<br>";
		}




		fclose($fp);


	}

	public function advanceIT($mid){
			$data = array(
               'clock' => strtotime('+30 seconds'),
            );

			$this->db->where('id', $mid);
			$this->db->update('mocks', $data);
	}

	public function create_public_games(){
		$counts = array(6,8,10,12,14,16);
		foreach($counts as $tc){
		ini_set('display_errors', 0); // set to 0 for production version
		error_reporting(-1);

			$thetime = strtotime('+15 Minutes');


			$seconds = $thetime;
			$thetime = round($seconds / (15 * 60)) * (15 * 60);



			$mock = array(
				'owner' => '',
				'name'	=> 'Public Mock Draft',
				'current_pick' => 1,
				'draft_order' => '',
				'draft_results' => '',
				'draft_start' => $thetime,
				'share_id' => time().'000'.'URLZ',
				'clock' => ($thetime +180)
			);

			// insert it and return id;
			$mock_id = $this->Mocks->create_mock($mock);
			$user  = $this->users->get();

			$p = 1;
			while($p <= $tc){

				$positions[$p] = $p;
				$p++;
			}

			$i = 0;

			while($i < $tc){

				$dp = array_rand($positions, 1);
				unset($positions[$dp]);

				$mock_team = array(
					'user_id' => 0,
					'mock_id' => $mock_id,
					'name' => '',
					'roster' => '',
					'draft_position' => $dp,
					'user' => 0,
					'auto' => 1,
				);

				$this->Mocks->create_mock_team($mock_team);
				$i++;
			}

			$data['teams'] = $teams = $this->Mocks->get_mock_teams($mock_id);


			$data['order'] =  $order = $this->Mocks->grab_create_order($data['teams'],$mock_id);

		}

	}

	public function lock_it(){
		return ;
		$data = array(
            'onoff' => 1,
            'time' => time()
        );

		$this->db->where('cid', 2);
		$this->db->update('lock', $data);
	}
	public function unlock_it(){
		return ;
		$data = array(
            'onoff' => 0,
            'time' => time()
        );

		$this->db->where('cid', 2);
		$this->db->update('lock', $data);
	}
	public function check_lock(){
		return ;
		$this->db->where('cid',2);
		$q = $this->db->get("lock");
		$q = $q->row();

		if($q->onoff == 1){
			$data = array(
               'time' => time(),
               'lid' => $mid,
            );

			$this->db->insert('issues', $data);

			echo "File Locked!"; die;
		}else{
			$this->lock_it();
		}

	}



}
