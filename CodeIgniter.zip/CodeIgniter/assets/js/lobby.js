$(document).ready(function(){

	update_rows();
	$(document).on('click', ".info_toggle", function() {
   		 var league = $(this).attr('data-league');

   		console.log(HOST_NAME+'/lobby/get_lobby_info/'+league);
   		$.ajax({
	       url: HOST_NAME+'/lobby/get_lobby_info/'+league,
	    }).done(function(done) {
		    $('.league_content_modal').html(done);

	   });

   });
   $(document).on('click', ".info_toggle2", function() {
   		 var league = $(this).attr('data-league');

   		console.log(HOST_NAME+'/lobby/get_lobby_info_main/'+league);
   		$.ajax({
	       url: HOST_NAME+'/lobby/get_lobby_info_main/'+league,
	    }).done(function(done) {
		    $('.league_info_modal').html(done);

	   });

   });

   $(document).on('click', ".size_toggle", function() {
   		 var league = $(this).attr('data-league');

   		console.log(HOST_NAME+'/lobby/show_teams/'+league);
   		$.ajax({
	       url: HOST_NAME+'/lobby/show_teams/'+league,
	    }).done(function(done) {
		    $('.size_toggle_modal').html(done);

	   });

   });



	$(".place").change(function(){
		console.log('update1');
		run_filters();
	});
	$(document).on('click', ".styletype", function() {
		run_filters();
	});
	$(document).on('click', "#myleagues", function() {
		run_filters();
	});


	function update_rows(){
		console.log('Update Rows');
		var uid = 0;
		$.ajax({
	       url: HOST_NAME+'/lobby/get_rows/'+uid,
	    }).done(function(done) {


			$( done ).each(function() {
				if (typeof $(this).html() !== "undefined") {

				var element = $(this);
				var id = $(element).attr('id');
					if ( $( "#"+id ).length ) {
						$( "#"+id ).html($(element).html());
					}else{
						$("#lobby_table tbody").append(element);
					}

				}


			});

	   });
	}
	window.setInterval(function(){
		update_rows();

	}, 20000);
	function run_filters(){
		update_rows();
		console.log('filter');
		// show all
		$( ".lobby_row_class" ).show();

		// grab filters
		var csize_min = parseInt($('#size_min').val());
		var csize_max = parseInt($('#size_max').val());
		var cfee_max = parseInt($('#fee_max').val());
		var cstyle = parseInt($('input[name=style]:checked').val() );
		var cfee_min = parseInt($('#fee_min').val());
		var datemin = new Date($('#datetimepicker1').val());
			datemin = datemin.getTime()/1000;
		var datemax = new Date($('#datetimepicker2').val());
			datemax = (datemax.getTime()/1000) + 86400;

		//loop rows
		$( ".lobby_row_class" ).each(function() {

			// get row vars
			var lsize	 =   parseInt($(this).find('.lsize').attr('data-val'));
			var lfee	 =   parseInt($(this).find('.lfee').attr('data-val'));
			var lmy	 	 =   parseInt($(this).attr('data-my'));
			var ltupe	 =   parseInt($(this).find('.ltupe').attr('data-val'));
			var ldraft	 =   parseInt($(this).find('.ldraft').attr('data-val'));
			var ltype	 =   parseInt($(this).find('.ltype').attr('data-val'));


			// show or hide
			if(lsize > csize_max || lsize < csize_min){
				$(this).hide();
			}
			if(lfee > cfee_max || lfee < cfee_min){
				$(this).hide();
			}

			if(ldraft > datemax || ldraft < datemin){
				$(this).hide();
			}


			if(ltype != cstyle && !isNaN(cstyle)){
				console.log(cstyle);
				$(this).hide();
			}

			if($( '#myleagues' ).prop( "checked" ) ){

			}else{
				console.log(lmy);
				if(lmy == 1){
					$(this).hide();
				}
			}






		});

	}



	// tablesorter

	$("#lobby_table").tablesorter({
		headers: { 0: { sorter: false}, 6: { sorter: false} }
	});
	$("#add_qb_table").tablesorter({
		headers: { 0: { sorter: false}, 12: { sorter: false}, },
		sortList: [[4,1]],
	});
	$("#add_rb_table").tablesorter({
		headers: { 0: { sorter: false}, 12: { sorter: false}, },
		sortList: [[4,1]],
	});
	$("#add_wr_table").tablesorter({
		headers: { 0: { sorter: false}, 10: { sorter: false}, },
		sortList: [[4,1]],
	});
	$("#add_k_table").tablesorter({
		headers: { 0: { sorter: false}, 10: { sorter: false}, },
		sortList: [[5,1]],
	});
	$("#add_dst_table").tablesorter({
		headers: { 0: { sorter: false}, 10: { sorter: false}, },
		sortList: [[4,0]],
	});
	$("#add_def_table").tablesorter({
		headers: { 0: { sorter: false}, 8: { sorter: false}, },
	});



	$('.filter-toggle').on('click',function(){
		$('.lobby .filters').slideToggle();
	});

	$( function() {

		$( "#entry_fee" ).slider({
			range: true,
			min: 0,
			max: 100,
			values: [ 0, 60 ],
			slide: function( event, ui ) {
				$( "#entry_value" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
				var div = document.getElementById('entry_value');
				var maxvalue = $( "#entry_fee" ).slider( "values", 1 );

				if( maxvalue < 90 ){
					var newmax = $( "#entry_fee" ).slider( "values", 1 );
				}else{
					var newmax = "No Limit";
				}
				$('#fee_min').val($( "#entry_fee" ).slider( "values", 0 ));
				$('#fee_max').val($( "#entry_fee" ).slider( "values", 1 ));
				div.innerHTML = "$" + $( "#entry_fee" ).slider( "values", 0 ) + " - " + newmax;
				run_filters();
			},
			stop: function(event, ui){
		        $( "#entry_value" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
				var div = document.getElementById('entry_value');
				var maxvalue = $( "#entry_fee" ).slider( "values", 1 );

				if( maxvalue < 90 ){
					var newmax = $( "#entry_fee" ).slider( "values", 1 );
				}else{
					var newmax = "No Limit";
				}
				$('#fee_min').val($( "#entry_fee" ).slider( "values", 0 ));
				$('#fee_max').val($( "#entry_fee" ).slider( "values", 1 ));
				div.innerHTML = "$" + $( "#entry_fee" ).slider( "values", 0 ) + " - " + newmax;
				run_filters();
		    }
		});
		var div = document.getElementById('entry_value');
		var maxvalue = $( "#entry_fee" ).slider( "values", 1 );

		if( maxvalue < 90 ){
			var newmax = $( "#entry_fee" ).slider( "values", 1 );
		}else{
			var newmax = "No Limit";
		}

		div.innerHTML = "$" + $( "#entry_fee" ).slider( "values", 0 ) + " - $" + newmax;



		$( "#size" ).slider({
			range: true,
			min: 6,
			max: 32,
			values: [ 6, 24 ],
			slide: function( event, ui ) {
				$( "#size_value" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
				var div = document.getElementById('size_value');
				div.innerHTML = $( "#size" ).slider( "values", 0 ) +
				" - " + $( "#size" ).slider( "values", 1 );

				$('#size_min').val($( "#size" ).slider( "values", 0 ));
				$('#size_max').val($( "#size" ).slider( "values", 1 ));
				run_filters();
			},
			stop: function(event, ui){
				$( "#size_value" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
				var div = document.getElementById('size_value');
				div.innerHTML = $( "#size" ).slider( "values", 0 ) +
				" - " + $( "#size" ).slider( "values", 1 );

				$('#size_min').val($( "#size" ).slider( "values", 0 ));
				$('#size_max').val($( "#size" ).slider( "values", 1 ));
				run_filters();
			}
		});
		var div = document.getElementById('size_value');
		div.innerHTML = $( "#size" ).slider( "values", 0 ) +
		" - " + $( "#size" ).slider( "values", 1 );

		$( "#datetimepicker1" ).datepicker({ minDate: 0, maxDate: "+1M +10D" });
		$( "#datetimepicker2" ).datepicker({ minDate: 0, maxDate: "+1M +10D" });

	} );

});
