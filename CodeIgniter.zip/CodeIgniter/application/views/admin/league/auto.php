<div class="card">
	<div class="card-header">
		<h3>Auto Leagues</h3>
		Set up auto leagues to fill the public lobby. Custom scoring can be created under the scoring tab. <hr><br>

		*Leagues that do not fill will be automatically refunded. <br>
		*Leagues that fill within <?=$this->options->get('auto_cutoff')?> minutes will not be recreated but leagues that fill before that time will be remade and put back into the lobby for new users to join. <br>
		*You may change the start time at any point but the leagues already created will hold that original time. <br>
		*The league creation script runs every minute to spin up any games yet to be created.
	</div>
<div class="row-fluid col-md-12">



	<!--END Information block -->
	<div class="pull-right">
	<a href="<?=site_url(ADMIN_THEME.'/league/create_auto')?>" class="btn btn-info" class="btn btn-small confirm">Create New Auto LEague</a>
	</div>
	<div class="clearfix"></div><br>
	<div class="clearfix"></div>

		<?//="<pre>".print_r($articles,true)."</pre>";?>
		<div class="portlet box green">

		<div class="portlet-body">
			<div class="table-responsive">
		<table class="table table-condensed table-striped table-bordered tablesorter" data-options='{"sortList":[[1,0]],"headers":{"0":{"sorter":false},"6":{"sorter":false}}}'>
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Type</th>
					<th>Size</th>
					<th>Start</th>
					<th>Fee</th>
					<th>Swap</th>
					<th>Pass Interference</th>
					<th>Fractional</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?if(!empty($leagues)):?>
					<?foreach($leagues as $s):?>
						<tr>
							<td><?=$s->cid?></td>
							<td><?=$s->name?></td>
							<td> <?php if($s->type == 1){ echo "Free" ;}elseif($s->type == 2){echo "Premium";}else{echo "Paid";}  ?> </td>
							<td><?=$s->size?></td>
							<td><?= date('Y/m/d G:i ',$s->draft_start);?></td>
							<td>$<?=number_format($s->entry_fee,2)?></td>
							<td><?php if($s->in_game_subs == 1){echo "YES";}else{echo "NO";} ?></td>
							<td><?php if($s->p_int_scoring == 1){echo "YES";}else{echo "NO";} ?></td>
							<td><?php if($s->fractional == 1){echo "YES";}else{echo "NO";} ?></td>
							<td>
								<a class="btn btn-info" href="<?=site_url(ADMIN_THEME."/league/create_auto/".$s->cid)?>" rel="tooltip" title="Edit"><i class="zmdi zmdi-edit"></i></a>
							</td>
						</tr>
					<?endforeach;?>
				<?else:?>
					<tr><td colspan="12">No Leagues Found</td></tr>
				<?endif;?>
			</tbody>
		</table>
		<div class="clearfix"></div><br>

	</div>
</div>
</div>
</div>
 <div class="clearfix"></div></div>


