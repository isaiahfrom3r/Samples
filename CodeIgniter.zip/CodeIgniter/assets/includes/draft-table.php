<?php $positions = array('QB'=>'QB','RB'=>'RB','WR'=>'WR','TE'=>'TE','K'=>'K','D/ST'=>'D/ST','D'=>'D');?>
<?php $i = 1; while($i <= 50):?>
<tr>
	<td><?=array_rand($positions);?></td>
	<td><?=$i;?></td>
	<td class="player-name"><a href="#" data-toggle="modal" data-target="#playercard">Player Name</a></td>
	<td>Team Name</td>
	<td><?=rand(1,6);?></td>
	<td class="draft-buttons">
		<button class="btn btn-default btn-small draft">Draft</button>
		<button class="btn btn-default btn-small queue">Queue</button>
	</td>
</tr>
<?php $i++; endwhile;?>
