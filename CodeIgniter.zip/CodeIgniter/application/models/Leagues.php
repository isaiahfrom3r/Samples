<?php

class Leagues extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
        $this->load->model('Users');
    }

    public function get_part($string, $part, $num="",$key="/"){
	/*
	*  get_part
	*
	*  gets the part of the id string passed by sports data
	*
	*  @Peram: $strng, $part or the array, $only a number, $what do you wnat to explode by
	*  @Return: $part
	*
	*  IsaiahArnold
	*
	*  9/29/14
	*/
		$pieces = explode($key, $string);
		//echo $string; echo "<br>"; // debug helper
		$return = $pieces[$part];

		if($num !=""){
			$return = preg_replace("/[^0-9]/","",$return);
			return $return;
		}
		else{
			return $return;
		}

	}
	public function count_picks($lid,$league=array(),$uid=0){
		if($uid == 0){
			$uid = $this->users->id();
		}

		$bracket =  $this->Brackets->get_bracket();
		$bracket =  json_decode($bracket->bracket,true);

		$picks = $this->Leagues->get_my_picks($lid,$uid);


		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		    $ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
		    $ip = $_SERVER['REMOTE_ADDR'];
		}

/*

		if(empty($picks)){
			$this->Leagues->save_default_picks($league,$bracket);
			$picks = $this->Leagues->get_my_picks($lid,$uid);
		}
*/

// 		$picks = $this->get_my_picks($lid,$uid);

		$count = 0;
		$total = 0;

		foreach($picks as $cgroup=>$pick){

			foreach($pick as $cround=>$p){

				foreach($p as $gms){
					if($gms != ""){
						$count++;
					}

					$total ++;

				}

			}

		}

		$message = "";


		$ties = $this->get_tiebreakers($lid,$uid);

		$tb = 0;
		if($ties['tb1'] > 0){


			$count ++;
		}else{
			$tb =1;
		}
		if($ties['tb2'] > 0){
			$count ++;
		}else{
			$tb =1;
		}

		$total = $total+2;

		if($count != $total){


			$diff = $total - $count;
			$message .= " Bracket Missing ".$diff." picks ";


		}else{
		}
		if($tb == 1){
			$message .= "and one ore more of your tiebreakers are empty.";
		}

		if($message != ""){
			$color = "#ed2424";

		}else{
			$color = "green";
			$message .= "All Picks and Tiebreakers have been saved.";
		}



		echo "<span style='color:".$color.";' class='t-top t-xl bordered toolsize' data-tooltip='".$message."'  >".$count."/".$total."</span>";


	}
	public function get_tiebreakers($lid,$uid=0){
		if($uid == 0){
			$uid = $this->users->id();
		}

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$uid);
		$q = $this->db->get("league_team");
		$q = $q->row();

		return array('tb1'=>$q->tb1,'tb2'=>$q->tb2);
	}
	public function get_my_picks($lid,$uid=0){
		if($uid == 0){
			$uid = $this->users->id();
		}

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$uid);
		$q = $this->db->get("league_team");
		$q = $q->row();

		return json_decode($q->picks,true);
	}
	public function get_score($lid,$uid=0){
		return 0;
		if($uid == 0){
			$uid = $this->users->id();
		}

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$uid);
		$q = $this->db->get("league_team");
		$q = $q->row();

		$this->db->where('league_id',$lid);
		$this->db->where('team_id',$q->id);
		$q = $this->db->get("league_standings");
		$q = $q->row();

		return $q->score;
	}
	public function my_rank($lid,$uid=0){
		if($uid == 0){
			$uid = $this->users->id();
		}

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$uid);
		$q = $this->db->get("league_team");
		$q = $q->row();

		$this->db->where('league_id',$lid);
		$this->db->where('team_id',$q->id);
		$q = $this->db->get("league_standings");
		$q = $q->row();

		return $q->rank;
	}

	public function get_my_team($lid,$uid=0){
		if($uid == 0){
			$uid = $this->users->id();
		}

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$uid);
		$q = $this->db->get("league_team");
		$q = $q->row();

		return $q;
	}
	public function save_picks($lid,$picks){


		$data = array(

           'picks' => json_encode($picks),

        );

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$this->users->id());
		$this->db->update('league_team', $data);

	}
	public function save_default_picks($league,$bracket,$uid=0){
		if($uid == 0){
		    $uid = $this->users->id();
	    }
		$lid = $league->cid;
		foreach($bracket as $group=>$b){
			foreach($b as $round=>$nex){
				if($round >= $league->round){

					foreach($nex as $gid=>$gm){


						$picks[$group][$round][$gid] = "";

					}
				}
			}
		}


		$data = array(

           'picks' => json_encode($picks),

        );

		$this->db->where('league_id',$lid);
		$this->db->where('user_id',$uid);
		$this->db->update('league_team', $data);

		return $picks;

	}
	public function get_count($lid){
		$this->db->where('league_id',$lid);
		$q = $this->db->get("league_team");

		return  $q->num_rows();
	}
	public function ordinal($number) {
	    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
	    if ((($number % 100) >= 11) && (($number%100) <= 13))
	        return $number. 'th';
	    else
	        return $number. $ends[$number % 10];
	}

	public function create_league($info){


	    $this->db->insert('leagues', $info);
	    return $this->db->insert_id();
    }

    public function create_team($info){


	    $this->db->insert('league_team', $info);
	    $tid = $this->db->insert_id();


	    $lcount = $this->Leagues->get_count($info['league_id']);

	    $data = array(
           'league_id' => $info['league_id'],
           'team_id' => $tid,
           'rank' => $lcount,
           'score' => 0,
        );

	    $this->db->insert('league_standings', $data);

	    return $tid;
    }
    public function randomPassword() {
	    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
	    $pass = array(); //remember to declare $pass as an array
	    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
	    for ($i = 0; $i < 8; $i++) {
	        $n = rand(0, $alphaLength);
	        $pass[] = $alphabet[$n];
	    }
	    return implode($pass); //turn the array into a string
	}
	public function get_lobby_rows($uid=0){

		if($uid == 0){
		    $uid = $this->users->id();
	    }
		$this->db->where('public > ',0);
		$q = $this->db->get("leagues");
		$q = $q->result();

		foreach($q as $lg){
			$this->db->where('league_id',$lg->cid);
			$this->db->where('user_id > ',0);
			$q = $this->db->get("league_team");
			$lg->total_joined = $q->num_rows();

			if($q->num_rows() == $lg->size){
				continue;
			}else{
				$leagues[] = $lg;
			}
		}

		$teams = $this->get_my_leagues($uid);

		$myleagues = array();
		if(count($teams) > 0){

			foreach($teams as $team){
				$lgs[] = $team->league_id;
			}
			$this->db->where_in('cid',$lgs);
			$q = $this->db->get("leagues");
			$q = $q->result();

			$season = $this->options->get('season');
			foreach($q as $lg){

				if($lg->season == $season){
					$this->db->where('league_id',$lg->cid);
					$this->db->where('user_id > ',0);
					$q = $this->db->get("league_team");
					$lg->total_joined = $q->num_rows();


					$leagues[] = $lg;
					$myleagues[] = $lg->cid;
				}
			}

		}
		$data['myleagues'] =  $myleagues;
		$data['leagues'] =  $leagues;
		$this->load->view(THEME.'/lobby/lobby_rows',$data);
	}
    public function update_team($info,$tid){

	    $this->db->where('id', $tid);
	    $this->db->update('league_team', $info);
    }

    public function update_league($info,$lid){

	    $this->db->where('cid', $lid);
	    $this->db->update('leagues', $info);
    }

    public function get_by_id($id){
	    $this->db->where('cid',$id);
	    $q = $this->db->get("leagues");
	    $q = $q->row();
	    return $q;
    }
    public function get_all(){
	    $q = $this->db->get("leagues");
	    $q = $q->result();
	    return $q;
    }

    public function get_standings($league,$limit=100,$start){
	    $lid = $league->cid;
	    $this->db->limit($limit,$start);
		$this->db->where('league_id',$lid);
		$this->db->order_by('rank','ASC');
	    $q = $this->db->get("league_standings");
	    $q = $q->result();
	    foreach($q as $s){
		   $standings[$s->team_id] = $s;
	    }
	    return $standings;

    }
	public function is_full($lid){
		$league = $this->get_league_by_id($lid);

		if($league->size == 0){
			return 0;
		}else{

			$teams = $this->get_league_teams($lid);

			if($league->size > count($teams)){
				return 0;
			}else{
				return 1;
			}


		}

	}

    public function get_team_by_id($tid){
	    $this->db->where('id',$tid);
	    $q = $this->db->get("league_team");
	    $q = $q->row();
		return $q;
    }
    public function RandomString()
	{
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $randstring = '';
	    for ($i = 0; $i < 10; $i++) {
	        $randstring = $characters[rand(0, strlen($characters))];
	    }
	    return $randstring;
	}
	public function get_my_leagues($user=0){
	    if($user == 0){
		    $user = $this->users->id();
	    }
	    $this->db->where('user_id',$user);
	    $this->db->order_by('league_id','ASC');
	    $q = $this->db->get("league_team");
	    $q = $q->result();
	    return $q;
    }

    public function get_league_by_id($id){
	    $this->db->where('cid',$id);
	    $q = $this->db->get("leagues");
	    $q = $q->row();
	    $league = $q;


	    return $league;
    }

	 public function get_league_teams($lid){
	    $this->db->where('league_id',$lid);
	    $q = $this->db->get("league_team");
	    $q = $q->result();
	    $return = array();
	    foreach($q as $r){
	    	$return[$r->id] = $r;
	    }

	    return $return;
    }

    public function get_messages($lid) {
        $this->db->where('league_id', $lid);
        $this->db->where('in_reply_to', 0);
        $this->db->order_by('post_time', 'DESC');
        $q = $this->db->get('message_board');
        $q = $q->result();

        foreach ($q as $msg) {
            $user = $this->Users->get_user($msg->author);
            $team = $this->get_my_league_team_by_id($user->team_id, $user->id);
            $msg->author_name = $team->name;
            $msg->avatar = $this->get_team_pic($team);

            $msg->replies = count($this->get_message_replies($msg->cid));
        }

        return $q;

    }

    public function get_message_by_id($msg) {
        $this->db->where('cid',$msg);
        $q = $this->db->get('message_board');
        $q = $q->row();

        $user = $this->Users->get_user($q->author);
        $team = $this->get_my_league_team_by_id($user->team_id, $user->id);
        $q->author_name = $team->name;
        $q->avatar = $this->get_team_pic($team);

        return $q;
    }

    public function get_message_replies($msg) {
        $this->db->where('in_reply_to', $msg);
        $this->db->order_by('post_time', 'ASC');
        $q = $this->db->get('message_board');
        $q = $q->result();

        foreach ($q as $rep) {
            $user = $this->Users->get_user($rep->author);
            $team = $this->get_my_league_team_by_id($user->team_id, $user->id);
            $rep->author_name = $team->name;
            $rep->avatar = $this->get_team_pic($team);
        }

        return $q;
    }

    public function add_message_view($msg){
        $this->db->select('views');
        $this->db->where('cid', $msg);
        $q = $this->db->get('message_board');
        $q = $q->row();

        $newView = $q->views + 1;

        $data = array(
            'views' => $newView
        );

        $this->db->where('cid',$msg);
        $this->db->update('message_board', $data);
        return "Added";
    }

    public function get_league_team_emails($lid){
        $teams = $this->get_league_teams($lid);

        $emails = array();
        foreach ($teams as $team) {
            $user = $this->Users->get_user($team->user_id);
            $emails[] = $user->email;
        }

        return $emails;
    }




    public function get_leagues($season='',$filters){
        if ($season == ''){
            $season = $this->options->get('season');
        }
        $joinStatus = 99;

        foreach ($filters as $filter=>$value) {
            if ($filter == "type") {
                $this->db->where_in('type', $value);
            }
            if ($filter == "join_status") {
                $joinStatus = $value;
            }
            if ($filter == "prevSeasons") {
                $season = $value;
            }
        }


        $this->db->where('season', $season);
        $this->db->order_by('name', 'ASC');
        $q = $this->db->get('leagues');
       //echo $this->db->last_query() . "<BR>";
        $q = $q->result();
        $return = array();

        if ($joinStatus == 0) {
            foreach($q as $league) {
                $numTeams = count($this->Leagues->get_league_teams($league->cid));
                if ($numTeams < $league->size) {
                    $return[] = $league;
                }
            }
            return (object) $return;
        } elseif ($joinStatus == 1) {
            foreach($q as $league) {
                $numTeams = count($this->Leagues->get_league_teams($league->cid));
                if ($numTeams == $league->size) {
                    $return[] = $league;
                }
            }

            return (object) $return;
        }

        return $q;
    }

	public function get_leagues_pagi($season,$num,$limit, $filters){
        if ($season == ''){
            $season = $this->options->get('season');
        }
        $joinStatus = 99;
        foreach ($filters as $filter=>$value) {
            if ($filter == "type") {
                $this->db->where_in('type', $value);
            }
            if ($filter == "join_status") {
                $joinStatus = $value;
            }
             if ($filter == "prevSeasons") {
                $season = $value;
            }
       }
        $this->db->where('season', $season);
		$this->db->limit($limit,$num);
		$q = $this->db->get('leagues');
		$q = $q->result();

        $return = array();

        if ($joinStatus == 0) {
            foreach($q as $league) {
                $numTeams = count($this->Leagues->get_league_teams($league->cid));
                if ($numTeams < $league->size) {
                    $return[] = $league;
                }
            }
            return (object) $return;
        } elseif ($joinStatus == 1) {
            foreach($q as $league) {
                $numTeams = count($this->Leagues->get_league_teams($league->cid));
                if ($numTeams == $league->size) {
                    $return[] = $league;
                }
            }

            return (object) $return;
        }

		return $q;
	}
	public function get_leagues_by_keyword($season,$keyword, $filters){
        if ($season == ''){
            $season = $this->options->get('season');
        }
        $joinStatus = 99;
        foreach ($filters as $filter=>$value) {
            if ($filter == "type") {
                $this->db->where_in('type', $value);
            }
            if ($filter == "join_status") {
                $joinStatus = $value;
            }
            if ($filter == "prevSeasons") {
                $season = $value;
            }
        }

        if(!empty($keyword)){
            $this->db->where('season',$season);
			$this->db->like('name',$keyword);
			$this->db->or_like('cid',$keyword);

			$q = $this->db->get("leagues");
			$q = $q->result();
            $return = array();

            if ($joinStatus == 0) {
                foreach($q as $league) {
                    $numTeams = count($this->Leagues->get_league_teams($league->cid));
                    if ($numTeams < $league->size) {
                        $return[] = $league;
                    }
                }
                return (object) $return;
            } elseif ($joinStatus == 1) {
                foreach($q as $league) {
                    $numTeams = count($this->Leagues->get_league_teams($league->cid));
                    if ($numTeams == $league->size) {
                        $return[] = $league;
                    }
                }

                return (object) $return;
            }

            return $q;
		}
	}

	public function get_leagues_by_keyword_pagi($season,$keyword,$offset,$per_page, $filters){
        if ($season == ''){
            $season = $this->options->get('season');
        }
        $joinStatus = 99;
        foreach ($filters as $filter=>$value) {
            if ($filter == "type") {
                $this->db->where_in('type', $value);
            }
            if ($filter == "join_status") {
                $joinStatus = $value;
            }
            if ($filter == "prevSeasons") {
                $season = $value;
            }
        }

		if(!empty($keyword)){
            $this->db->where('season',$season);

			$this->db->like('name',$keyword);
			$this->db->or_like('cid',$keyword);
			$this->db->limit($per_page,$offset);
			$q = $this->db->get("leagues");
			$q = $q->result();
            $return = array();

            if ($joinStatus == 0) {
                foreach($q as $league) {
                    $numTeams = count($this->Leagues->get_league_teams($league->cid));
                    if ($numTeams < $league->size) {
                        $return[] = $league;
                    }
                }
                return (object) $return;
            } elseif ($joinStatus == 1) {
                foreach($q as $league) {
                    $numTeams = count($this->Leagues->get_league_teams($league->cid));
                    if ($numTeams == $league->size) {
                        $return[] = $league;
                    }
                }

                return (object) $return;
            }

            return $q;
		}
	}

    public function get_archived_seasons($season) {
        $this->db->distinct();
        $this->db->select('season');
        $this->db->not_like('season', $season);
        $q = $this->db->get('leagues');

        return $q->result();
    }



}
?>
