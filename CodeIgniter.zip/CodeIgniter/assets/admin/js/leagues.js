console.log('users.jss');
jQuery( document ).ready(function($) {

	// edit user form

	$( ".edit_user" ).on( "click", function() {
		var info = jQuery.parseJSON($(this).attr('data-info'));
		$('#username').val(info.username);
		$('#first_name').val(info.first_name);
		$('#last_name').val(info.last_name);
		$('#email').val(info.email);
		$('#user_id_post').val(info.id);
		$('#admin').val(info.admin);
		$('#draft_mod').val(info.draft_mod);
		console.log(info.admin);
		console.log(info);
		$('#edit_user_modal').modal('toggle');
	});

	// pull up delete box

	$( ".active_user" ).on( "click", function() {
		var uid 	= $(this).attr('data-uid');
		var status 	= $(this).attr('data-status');
		var statusnum = 0;
		if(status != "Deactivate"){
			statusnum = 1;
		}

		var url 	= HOST_NAME+'admin/user/active_user/'+uid+'/'+statusnum;
		var lname 	= $(this).attr('data-lname');
		var fname 	= $(this).attr('data-fname');



		$('#remove_lname').html(lname);
		$('#remove_fname').html(fname);
		$('#remove_status').html(status);
		$('#statusurl').attr('href',url);
		$('#deleteConfirm').modal('toggle');

	});


	// this is the id of the form
	$("#league_update_form").submit(function(e) {

	    var url = HOST_NAME+"admin/leagueM/update_leagues"; // the script where you handle the form input.

	    $.ajax({
           type: "POST",
           url: url,
           data: $("#league_update_form").serialize(), // serializes the form's elements.
           success: function(response){
	           console.log(response);

           }

	    });
		$('#edit_user_modal').modal('toggle');
	    e.preventDefault(); // avoid to execute the actual submit of the form.

	});



});
